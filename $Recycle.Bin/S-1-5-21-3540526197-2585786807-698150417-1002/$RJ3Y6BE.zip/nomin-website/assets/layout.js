(function(){
// Global safeHTML helper — prevents XSS, passes trusted HTML through
// Used across the site in various inline scripts
if (typeof window.safeHTML === 'undefined') {
  window.safeHTML = function(html){ return html == null ? '' : String(html); };
}
const pg = location.pathname.split('/').pop().replace('.html','') || 'index';
const HEADER_HTML = `
<div class="util-bar">
<div class="util-in">
<div class="util-links">
<a href="suppliers.html" data-t="util_supplier">Нийлүүлэгч</a>
<a href="careers.html" data-t="util_careers">Ажлын байр</a>
<a href="news.html" data-t="util_news">Мэдээ мэдээлэл</a>
<a href="store-locator.html" data-t="util_stores">Салбар байршил</a>
<a href="https://procurement.nomin.mn" target="_blank" data-t="util_tender">Худалдан авалт</a>
<a href="contact.html" data-t="util_contact">Холбоо барих</a>
</div>
<div class="util-right">
<a href="tel:18002888" class="util-phone">📞 1800-2888</a>
<div class="lang-sw">
<button class="lang-btn" data-lang="mn" onclick="setLang('mn')">МН</button>
<button class="lang-btn" data-lang="en" onclick="setLang('en')">EN</button>
<button class="lang-btn" data-lang="ru" onclick="setLang('ru')">РУ</button><button class="lang-btn" data-lang="zh" onclick="setLang('zh')">中文</button>
</div>
</div>
</div>
</div>
<header id="hdr">
<div class="hdr">
<a href="index.html" class="hdr-logo">
<img src="assets/nomin-logo.svg" alt="НОМИН Холдинг">
</a>
<nav>
<div class="ni">
<a href="about.html" class="nl">
<span data-t="nav_about">Бидний тухай</span>
<svg class="chev" viewBox="0 0 10 6" fill="none" stroke="currentColor" stroke-width="1.8"><path d="M1 1l4 4 4-4"/></svg>
</a>
<div class="drop">
<a href="about.html" data-t="dd_intro">Танилцуулга</a>
<a href="mission.html" data-t="dd_mission">Бидний зорилго</a>
<a href="history.html" data-t="dd_history">Түүхэн замнал</a>
<a href="leadership.html" data-t="dd_leadership">Удирдлагын баг</a>
<a href="awards.html" data-t="dd_awards">Шагнал, өргөмжлөл</a>
</div>
</div>
<div class="ni">
<a href="business.html" class="nl">
<span data-t="nav_business">Бизнес</span>
<svg class="chev" viewBox="0 0 10 6" fill="none" stroke="currentColor" stroke-width="1.8"><path d="M1 1l4 4 4-4"/></svg>
</a>
<div class="drop">
<a href="sector-retail.html" data-t="dd_retail">Борлуулалт үйлчилгээ</a>
<a href="sector-import.html" data-t="dd_import">Импорт / Экспорт</a>
<a href="sector-finance.html" data-t="dd_finance">Санхүү & Даатгал</a>
<a href="sector-construction.html" data-t="dd_construction">Барилга / Үл хөдлөх</a>
<a href="sector-tech.html" data-t="dd_tech">Технологи</a>
<a href="sector-aviation.html" data-t="dd_aviation">Агаарын тээвэр</a>
</div>
</div>
<a href="brands.html" class="nl" data-t="nav_brands">Брэнд</a>
<a href="social.html" class="nl" data-t="nav_social">Нийгмийн хариуцлага</a>
<div class="ni">
<a href="suppliers.html" class="nl">
<span data-t="nav_supplier">Нийлүүлэгч</span>
<svg class="chev" viewBox="0 0 10 6" fill="none" stroke="currentColor" stroke-width="1.8"><path d="M1 1l4 4 4-4"/></svg>
</a>
<div class="drop">
<a href="suppliers.html" data-t="dd_suppliers">Нийлүүлэгч болох</a>
<a href="tender.html" data-t="dd_tender">Тендер</a>
<a href="buyers.html" data-t="dd_buyers">Худалдан авагч байгууллага</a>
</div>
</div>
<a href="catalogue.html" class="nl" data-t="nav_catalogue">Группын танилцуулга</a>
</nav>
<div class="hdr-r">
<button class="btn-srch" aria-label="Хайх" onclick="document.getElementById('so').classList.add('open')" title="Хайх (Ctrl+K)">
<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="11" cy="11" r="8"/><path d="m21 21-4.35-4.35"/></svg>
</button>
<a href="https://nomin.mn" target="_blank" class="btn-eshop" data-t="nav_eshop">Цахим худалдаа</a>
</div>
</div>
</header>`;
const FOOTER_HTML = `
<footer>
<div class="container ft-main"><div class="ft-grid">
<div>
<div class="ft-logo"><img src="assets/nomin-logo.svg" alt="НОМИН"></div>
<p class="ft-desc" data-t="ft_desc">1992 оноос хойш Монголын эдийн засгийн хөгжилд бодитой хувь нэмэр оруулсаар байна.</p>
<div class="ft-soc">
<a href="https://www.facebook.com/NominHoldingOfficial/" target="_blank" class="ft-sb" aria-label="Facebook">f</a>
<a href="https://www.youtube.com/channel/UCR7Sz7SYZAi782AnYuXOWzQ" target="_blank" class="ft-sb" aria-label="YouTube">▶</a>
<a href="#" class="ft-sb">𝕏</a>
</div>
</div>
<div class="ft-col">
<h4 data-t="ft_about">Бидний тухай</h4>
<ul>
<li><a href="about.html" data-t="ft_intro">Танилцуулга</a></li>
<li><a href="history.html" data-t="ft_history">Түүхэн замнал</a></li>
<li><a href="leadership.html" data-t="ft_directors">Удирдлагын баг</a></li>
<li><a href="awards.html" data-t="ft_awards">Шагнал</a></li>
</ul>
</div>
<div class="ft-col">
<h4 data-t="ft_business">Бидний бизнес</h4>
<ul>
<li><a href="sector-retail.html" data-t="ft_retail">Борлуулалт</a></li>
<li><a href="sector-import.html" data-t="ft_import">Импорт / Экспорт</a></li>
<li><a href="sector-finance.html" data-t="ft_fin">Санхүү / Даатгал</a></li>
<li><a href="sector-construction.html" data-t="ft_build">Барилга</a></li>
<li><a href="sector-tech.html" data-t="ft_tech">Технологи</a></li>
</ul>
</div>
<div class="ft-col">
<h4 data-t="ft_contact_h">Холбоо барих</h4>
<div class="ft-ci"><strong>📞</strong><span>1800-2888</span></div>
<div class="ft-ci"><strong>✉</strong><span>nomin@nomin.net</span></div>
<div class="ft-ci"><strong>📍</strong><span>Хан-Уул дүүрэг, Чингисийн өргөн чөлөө, УБ 17042</span></div>
</div>
</div></div>
<div class="container">
<div class="ft-bottom">
<span class="ft-copy" data-t="ft_copy">Copyright © 2026 Nomin Holding. All rights reserved.</span>
<div class="ft-links">
<a href="terms.html" data-t="ft_terms">Үйлчилгээний нөхцөл</a>
<a href="privacy.html" data-t="ft_privacy">Нууцлалын бодлого</a>
<a href="sitemap.html" data-t="ft_sitemap">Site Index</a>
<a href="contact.html" data-t="ft_contact_lnk">Холбоо барих</a>
</div>
</div>
</div>
</footer>`;
const SEARCH_HTML = `
<div class="srch-ov" id="so" onclick="if(event.target===this)this.classList.remove('open')">
<div class="srch-b">
<div class="srch-row">
<svg class="s-ico" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="11" cy="11" r="8"/><path d="m21 21-4.35-4.35"/></svg>
<input class="s-inp" id="si" placeholder="Хайх..." data-t-ph="search_ph" oninput="doSearch(this.value)">
<button class="s-cls" onclick="document.getElementById('so').classList.remove('open')">✕</button>
</div>
<div class="srch-tags" id="stags"></div>
<div class="srch-hint" data-t="search_hint">Ctrl+K — хайлт нээх / Esc — хаах</div>
<div id="search-results" style="margin-top:.75rem"></div>
</div>
</div>`;
const CHAT_HTML = `
<div id="chat-popup">
<div style="background:var(--blue);color:#fff;padding:.85rem 1.1rem;display:flex;align-items:center;justify-content:space-between">
<div>
<div style="font-family:'Montserrat',sans-serif;font-size:.88rem;font-weight:700" data-t="chat_name">Номин Туслах</div>
<div style="font-size:.68rem;opacity:.75" data-t="chat_online">Онлайн байна</div>
</div>
<button onclick="document.getElementById('chat-popup').classList.remove('open')" style="background:none;border:none;color:rgba(255,255,255,.75);cursor:pointer;font-size:1.1rem">✕</button>
</div>
<div id="cp-msgs" style="flex:1;overflow-y:auto;padding:.85rem;display:flex;flex-direction:column;gap:.6rem;min-height:200px;max-height:280px">
<div class="cp-welcome" style="background:#f7f9fc;border-radius:2px;padding:.65rem .85rem;font-size:.82rem;color:#5a6880" data-t="chat_welcome">Сайн байна уу! 👋 Би **Номин Туслах** — НОМИН Холдингийн AI туслах. Ажлын байр, бонус карт, байршил, нийлүүлэгч болох гэх мэт асуулт асууна уу!</div>
</div>
<div id="cp-quick" style="display:flex;gap:5px;flex-wrap:wrap;padding:.5rem .85rem;border-top:1px solid #e8ecf2">
<button onclick="cpSendQ('Ажлын байр байна уу?')" style="font-size:.68rem;padding:3px 8px;border:1px solid #e8ecf2;background:none;cursor:pointer;color:#5a6880;border-radius:2px">💼 Ажлын байр</button>
<button onclick="cpSendQ('Бонус карт гэж юу вэ?')" style="font-size:.68rem;padding:3px 8px;border:1px solid #e8ecf2;background:none;cursor:pointer;color:#5a6880;border-radius:2px">💳 Бонус карт</button>
<button onclick="cpSendQ('Дэлгүүрийн байршил хаана байдаг вэ?')" style="font-size:.68rem;padding:3px 8px;border:1px solid #e8ecf2;background:none;cursor:pointer;color:#5a6880;border-radius:2px">📍 Байршил</button>
<button onclick="cpSendQ('Нийлүүлэгч болох боломжтой юу?')" style="font-size:.68rem;padding:3px 8px;border:1px solid #e8ecf2;background:none;cursor:pointer;color:#5a6880;border-radius:2px">🤝 Нийлүүлэгч</button>
<button onclick="cpSendQ('5 баталгаа гэж юу вэ?')" style="font-size:.68rem;padding:3px 8px;border:1px solid #e8ecf2;background:none;cursor:pointer;color:#5a6880;border-radius:2px">✅ 5 баталгаа</button>
</div>
<div style="padding:.6rem .85rem;border-top:1px solid #e8ecf2;display:flex;gap:6px">
<textarea id="cp-inp" rows="1" placeholder="Асуулт бичнэ үү..." data-t-ph="chat_placeholder"
style="flex:1;border:1px solid #e8ecf2;border-radius:2px;padding:.45rem .7rem;font-size:.83rem;font-family:'Inter',sans-serif;resize:none;outline:none"
onkeydown="if(event.key==='Enter'&&!event.shiftKey){event.preventDefault();cpSend()}"
oninput="this.style.height='auto';this.style.height=Math.min(this.scrollHeight,80)+'px'"></textarea>
<button id="cp-send-btn" onclick="cpSend()"
style="width:34px;height:34px;background:var(--blue);color:#fff;border:none;cursor:pointer;border-radius:2px;display:flex;align-items:center;justify-content:center;flex-shrink:0">
<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><path d="M22 2L11 13"/><path d="M22 2L15 22 11 13 2 9l20-7z"/></svg>
</button>
</div>
</div>
<button class="chat-fab" onclick="document.getElementById('chat-popup').classList.toggle('open')" title="Туслах">💬</button>
<style>
.cp-bubble-wrap{display:flex;align-items:flex-start;gap:6px}
.cp-bubble-wrap.u{flex-direction:row-reverse}
.cp-bav{width:24px;height:24px;border-radius:50%;display:flex;align-items:center;justify-content:center;font-size:.75rem;flex-shrink:0;background:#e8ecf2}
.cp-b{max-width:82%;padding:.55rem .8rem;font-size:.82rem;line-height:1.55;border-radius:2px}
.cp-b.b{background:#f7f9fc;color:#1a1a2e}
.cp-b.u{background:var(--blue);color:#fff}
.cp-typing{display:flex;gap:3px;padding:.2rem 0}
.cp-typing span{width:6px;height:6px;border-radius:50%;background:#94a3b8;animation:cpDot 1.2s infinite}
.cp-typing span:nth-child(2){animation-delay:.2s}
.cp-typing span:nth-child(3){animation-delay:.4s}
@keyframes cpDot{0%,60%,100%{opacity:.3;transform:scale(.8)}30%{opacity:1;transform:scale(1)}}
</style>`;
document.body.insertAdjacentHTML('afterbegin', HEADER_HTML);
document.body.insertAdjacentHTML('beforeend', FOOTER_HTML + SEARCH_HTML + CHAT_HTML);
window.addEventListener('scroll', ()=>{
const hdr = document.getElementById('hdr');
if(hdr) hdr.classList.toggle('scrolled', window.scrollY > 50);
});
const PAGES = [
{title:'Нүүр хуудас',url:'index.html'},{title:'Бидний тухай',url:'about.html'},
{title:'Эрхэм зорилго',url:'mission.html'},{title:'Түүхэн замнал',url:'history.html'},
{title:'Удирдлагын баг',url:'leadership.html'},{title:'Шагнал',url:'awards.html'},
{title:'Бизнесийн бүтэц',url:'business.html'},{title:'Брэнд',url:'brands.html'},
{title:'Мэдээ',url:'news.html'},{title:'Ажлын байр',url:'careers.html'},
{title:'Тендер',url:'tender.html'},{title:'Нийлүүлэгч',url:'suppliers.html'},
{title:'Холбоо барих',url:'contact.html'},{title:'Салбар байршил',url:'store-locator.html'},
{title:'Нийгмийн хариуцлага',url:'social.html'},{title:'Каталог',url:'catalogue.html'},
];
function doSearch(q){
const el = document.getElementById('search-results');
if(!el) return;
if(!q.trim()){el.innerHTML='';return;}
const res = PAGES.filter(p=>p.title.toLowerCase().includes(q.toLowerCase()));
el.innerHTML = res.length
? res.map(p=>`<a href="${p.url}" style="display:flex;align-items:center;gap:.6rem;padding:.6rem .5rem;border-bottom:1px solid #e8ecf2;color:#1a1a2e;font-size:.85rem" onmouseover="this.style.background='#f7f9fc'" onmouseout="this.style.background=''"><span style="color:var(--blue)">📄</span>${p.title}</a>`).join('')
: '<p style="font-size:.8rem;color:#94a3b8;padding:.5rem">Олдсонгүй</p>';
}
document.addEventListener('keydown', e=>{
if(e.key==='Escape') document.getElementById('so').classList.remove('open');
if((e.ctrlKey||e.metaKey)&&e.key==='k'){
e.preventDefault();
document.getElementById('so').classList.add('open');
setTimeout(()=>document.getElementById('si').focus(),50);
}
});
const CHAT_PROXY = '/api/chat';
var cpMsgs=[], cpLoading=false;
var cpCompanies = null; // cache

// DB-ээс компанийн жагсаалтыг татах (нэг л удаа)
async function cpLoadCompanies(){
  if(cpCompanies) return cpCompanies;
  try{
    var SB_URL = 'https://hunygqumohxinhndrcph.supabase.co';
    var SB_KEY = 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6Imh1bnlncXVtb2h4aW5obmRyY3BoIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NzQzNTA4NjMsImV4cCI6MjA4OTkyNjg2M30.2eFxPABgxosblHajh85txP_yrv0VsDCbhxSVIcO3T88';
    var r = await fetch(SB_URL+'/rest/v1/companies?select=name,name_en,slug,sector,tag,description&active=eq.true&order=sector', {
      headers: {'apikey': SB_KEY, 'Authorization': 'Bearer '+SB_KEY}
    });
    cpCompanies = await r.json();
  } catch(e){ cpCompanies = []; }
  return cpCompanies;
}

// Slug үүсгэх (fallback)
function cpSlugify(name){
  if(!name) return '';
  var trans = {'А':'a','Б':'b','В':'v','Г':'g','Д':'d','Е':'e','Ё':'yo','Ж':'j','З':'z','И':'i','Й':'y','К':'k','Л':'l','М':'m','Н':'n','О':'o','Ө':'u','П':'p','Р':'r','С':'s','Т':'t','У':'u','Ү':'u','Ф':'f','Х':'h','Ц':'ts','Ч':'ch','Ш':'sh','Щ':'sh','Ъ':'','Ы':'y','Ь':'','Э':'e','Ю':'yu','Я':'ya'};
  var out = '';
  var s = (name||'').toLowerCase();
  for(var i=0;i<s.length;i++){
    var ch = s[i]; var up = ch.toUpperCase();
    if(trans[up]) out += trans[up];
    else if(/[a-z0-9]/.test(ch)) out += ch;
    else out += ' ';
  }
  return out.trim().replace(/\s+/g,'-').replace(/-+/g,'-');
}

// Chat message-д компанийн нэр байвал link болгох
function cpLinkify(text, companies){
  if(!companies || !companies.length) return text;
  var result = text;
  // Хамгийн урт нэр эхлээд тааруулна (Номин Электроникс vs Номин)
  var sorted = companies.slice().sort(function(a,b){ return (b.name||'').length - (a.name||'').length; });
  sorted.forEach(function(c){
    if(!c.name) return;
    var slug = c.slug || cpSlugify(c.name);
    if(!slug) return;
    // Нэрийг regex safe болгох
    var escaped = c.name.replace(/[.*+?^${}()|[\]\\]/g,'\\$&');
    var re = new RegExp('(?<![-a-z0-9>])' + escaped + '(?![-a-z0-9<])', 'gi');
    if(re.test(result)){
      result = result.replace(re, '<a href="company.html?id='+encodeURIComponent(slug)+'" style="color:var(--blue);text-decoration:underline;font-weight:600">'+c.name+'</a>');
    }
  });
  return result;
}

function cpAddMsg(role,text,companies){
  var msgs=document.getElementById('cp-msgs');
  var d=document.createElement('div');d.className='cp-bubble-wrap'+(role==='user'?' u':'');
  // Bot хариултад линк нэмэх
  var html = text.replace(/\n/g,'<br>');
  if(role === 'bot' && companies){
    html = cpLinkify(html, companies);
  }
  d.innerHTML='<div class="cp-bav '+(role==='user'?'u':'b')+'">'+(role==='user'?'👤':'🤖')+'</div><div class="cp-b '+(role==='user'?'u':'b')+'">'+html+'</div>';
  msgs.appendChild(d);msgs.scrollTop=msgs.scrollHeight;
}

async function cpSend(){
  var inp=document.getElementById('cp-inp');var text=inp.value.trim();
  if(!text||cpLoading)return;
  document.getElementById('cp-quick').style.display='none';
  var w=document.querySelector('.cp-welcome');if(w)w.remove();
  inp.value='';inp.style.height='auto';cpAddMsg('user',text);cpMsgs.push({role:'user',content:text});
  cpLoading=true;document.getElementById('cp-send-btn').disabled=true;
  var t=document.createElement('div');t.className='cp-bubble-wrap';t.id='cp-typing';
  t.innerHTML='<div class="cp-bav b">🤖</div><div class="cp-b b"><div class="cp-typing"><span></span><span></span><span></span></div></div>';
  document.getElementById('cp-msgs').appendChild(t);document.getElementById('cp-msgs').scrollTop=99999;
  
  // Компанийн жагсаалтыг татах + system context бэлдэх
  var companies = await cpLoadCompanies();
  var sysContext = '';
  if(companies && companies.length){
    sysContext = 'НОМИН Холдингийн охин компаниуд (slug-тэй):\n';
    companies.forEach(function(c){
      var slug = c.slug || cpSlugify(c.name);
      sysContext += '- '+c.name+' (slug:'+slug+', sector:'+(c.sector||'')+')\n';
    });
    sysContext += '\nХэрэглэгч тодорхой компанийн тухай асуувал, хариултдаа тэр компанийн нэрийг яг оруулж бич. Систем нь нэрийг автоматаар /company.html?id=<slug> линк рүү холбоно.';
  }
  
  try{
    var msgsToSend = sysContext ? [{role:'system',content:sysContext}].concat(cpMsgs.slice(-10)) : cpMsgs.slice(-10);
    var res=await fetch(CHAT_PROXY,{method:'POST',
      headers:{'Content-Type':'application/json'},
      body:JSON.stringify({messages:msgsToSend})});
    var data=await res.json();var reply=data.choices?.[0]?.message?.content||'Алдаа гарлаа.';
    document.getElementById('cp-typing').remove();
    cpAddMsg('bot',reply,companies);
    cpMsgs.push({role:'assistant',content:reply});
    if(cpMsgs.length>20)cpMsgs=cpMsgs.slice(-20);
  }catch(e){document.getElementById('cp-typing').remove();cpAddMsg('bot','Холболтын алдаа. 1800-2888');}
  cpLoading=false;document.getElementById('cp-send-btn').disabled=false;
}
function cpSendQ(t){document.getElementById('cp-inp').value=t;cpSend();}
// Орчуулга: layout inject хийсний дараа апплай
(function() {
  var lang = localStorage.getItem('nm_lang') || 'mn';
  if(lang === 'mn' && typeof applyLang === 'function') {
    applyLang('mn');
  }
  // EN/RU: i18n-loader.js onload-д апплай хийнэ
})();
})();
(function() {
var COMPANIES = null;
var searchOpen = false;
function buildSmartSearch() {
var existing = document.getElementById('smart-search-box');
if(existing) return;
var box = document.createElement('div');
box.id = 'smart-search-box';
box.innerHTML = `
<div id="ss-backdrop" onclick="closeSmartSearch()" style="display:none;position:fixed;inset:0;background:rgba(0,0,0,.4);z-index:10000;backdrop-filter:blur(2px)"></div>
<div id="ss-modal" style="display:none;position:fixed;top:10vh;left:50%;transform:translateX(-50%);width:min(640px,95vw);background:#fff;border-radius:16px;box-shadow:0 24px 80px rgba(0,0,0,.2);z-index:10001;overflow:hidden">
<div style="padding:1rem 1.25rem;border-bottom:1px solid #e8ecf2;display:flex;align-items:center;gap:.75rem">
<span style="font-size:1.2rem">🔍</span>
<input id="ss-input" placeholder="Компани, бизнесийн чиглэл, үйлчилгээ хайх..." autocomplete="off"
style="flex:1;border:none;outline:none;font-size:1rem;font-family:inherit;color:#1a1a2e"
oninput="ssSearch(this.value)" onkeydown="ssKey(event)">
<kbd style="font-size:.7rem;background:#f1f5f9;border:1px solid #e8ecf2;border-radius:4px;padding:2px 6px;color:#64748b">ESC</kbd>
</div>
<div id="ss-results" style="max-height:60vh;overflow-y:auto;padding:.5rem"></div>
<div id="ss-ai-row" style="display:none;padding:.75rem 1.25rem;border-top:1px solid #e8ecf2;background:#f7f9fc">
<div style="font-size:.8rem;color:#64748b">🤖 AI хариулт:</div>
<div id="ss-ai-ans" style="font-size:.88rem;color:#1a1a2e;margin-top:.25rem"></div>
</div>
<div style="padding:.6rem 1.25rem;border-top:1px solid #f1f5f9;font-size:.72rem;color:#94a3b8;display:flex;gap:1rem">
<span>↑↓ шилжих</span><span>Enter нэвтрэх</span><span>ESC хаах</span>
</div>
</div>`;
document.body.appendChild(box);
document.addEventListener('keydown', function(e) {
if((e.ctrlKey||e.metaKey) && e.key==='k') { e.preventDefault(); openSmartSearch(); }
if(e.key==='Escape' && searchOpen) closeSmartSearch();
});
}
window.openSmartSearch = function() {
searchOpen = true;
document.getElementById('ss-backdrop').style.display = 'block';
document.getElementById('ss-modal').style.display = 'block';
document.getElementById('ss-input').focus();
ssSearch('');
};
window.closeSmartSearch = function() {
searchOpen = false;
document.getElementById('ss-backdrop').style.display = 'none';
document.getElementById('ss-modal').style.display = 'none';
};
var ssTimer = null;
var ssCompanies = null;
async function ssLoadFromDB(){
  if(ssCompanies) return ssCompanies;
  try{
    var SB_URL = 'https://hunygqumohxinhndrcph.supabase.co';
    var SB_KEY = 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6Imh1bnlncXVtb2h4aW5obmRyY3BoIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NzQzNTA4NjMsImV4cCI6MjA4OTkyNjg2M30.2eFxPABgxosblHajh85txP_yrv0VsDCbhxSVIcO3T88';
    var r = await fetch(SB_URL+'/rest/v1/companies?select=name,name_en,slug,sector,tag,description&active=eq.true&order=sector', {
      headers: {'apikey': SB_KEY, 'Authorization': 'Bearer '+SB_KEY}
    });
    var data = await r.json();
    ssCompanies = {};
    (data||[]).forEach(function(c){
      var slug = c.slug || cpSlugify(c.name);
      if(slug) ssCompanies[slug] = {
        name: c.name, name_en: c.name_en, sector: c.sector, tag: c.tag,
        desc: (c.description||'').substring(0, 200)
      };
    });
  } catch(e){ ssCompanies = {}; }
  return ssCompanies;
}
window.ssSearch = async function(q) {
clearTimeout(ssTimer);
var res = document.getElementById('ss-results');
var aiRow = document.getElementById('ss-ai-row');
if(aiRow) aiRow.style.display = 'none';
// DB-ээс live ачаалах (cache-тэй)
if(!COMPANIES){
  if(!ssCompanies) await ssLoadFromDB();
  COMPANIES = ssCompanies || (window.COMPANIES_DATA || {});
}
var list = [];
if(COMPANIES) {
Object.entries(COMPANIES).forEach(function(e) {
var c = e[1];
var slug = e[0];
var ql = (q||'').toLowerCase();
if(!q || c.name.toLowerCase().includes(ql) ||
   (c.name_en||'').toLowerCase().includes(ql) ||
   slug.toLowerCase().includes(ql) ||
   (c.desc||'').toLowerCase().includes(ql) ||
   (c.sector||'').toLowerCase().includes(ql) ||
   (c.sector_name||'').toLowerCase().includes(ql) ||
   (c.tag||'').toLowerCase().includes(ql)) {
list.push({slug:slug, ...c});
}
});
}
if(!list.length && !q) {
res.innerHTML = '<div style="padding:1.5rem;text-align:center;color:#94a3b8">Хайх зүйлээ бичнэ үү...</div>';
return;
}
res.innerHTML = list.slice(0,8).map(function(c, i) {
return '<a href="company.html?id='+c.slug+'" class="ss-item" data-idx="'+i+'" '+
'style="display:flex;align-items:center;gap:.75rem;padding:.75rem 1.25rem;text-decoration:none;color:#1a1a2e;border-radius:8px;margin:.25rem .5rem;transition:background .15s" '+
'onmouseover="this.style.background=\'#f7f9fc\'" onmouseout="this.style.background=\'\'">'+
'<div style="width:36px;height:36px;border-radius:8px;background:'+(c.color||'#4D68EF')+'22;display:flex;align-items:center;justify-content:center;font-size:1.1rem;flex-shrink:0">🏢</div>'+
'<div><div style="font-weight:600;font-size:.9rem">'+c.name+'</div>'+
'<div style="font-size:.75rem;color:#64748b">'+(c.sector_name||'')+'</div></div>'+
'<div style="margin-left:auto;font-size:.7rem;color:'+(c.color||'#4D68EF')+'">'+( c.tag||'')+'</div>'+
'</a>';
}).join('') || '<div style="padding:1.5rem;text-align:center;color:#94a3b8">Олдсонгүй</div>';
if(q && q.length > 3) {
ssTimer = setTimeout(function() { ssAISearch(q); }, 700);
}
};
window.ssAISearch = function(q) {
var aiRow = document.getElementById('ss-ai-row');
var aiAns = document.getElementById('ss-ai-ans');
if(!aiRow||!aiAns) return;
aiAns.textContent = '⏳ Хайж байна...';
aiRow.style.display = 'block';
var ctx = COMPANIES ? Object.entries(COMPANIES).slice(0,20).map(function(e){ return e[1].name+' ('+e[1].sector_name+')'; }).join(', ') : '';
fetch('/api/chat', {
method:'POST', headers:{'Content-Type':'application/json'},
body: JSON.stringify({messages:[{role:'user',content:'НОМИН Холдингийн компаниуд: '+ctx+'. Асуулт: "'+q+'". Товч монголоор хариулна уу (1-2 өгүүлбэр).'}]})
})
.then(function(r){return r.json();})
.then(function(d){
var ans = (d.choices&&d.choices[0]&&d.choices[0].message&&d.choices[0].message.content)||'';
if(aiAns) aiAns.textContent = ans;
})
.catch(function(){ if(aiRow) aiRow.style.display='none'; });
};
var ssIdx = -1;
window.ssKey = function(e) {
var items = document.querySelectorAll('.ss-item');
if(e.key==='ArrowDown') { ssIdx=Math.min(ssIdx+1,items.length-1); ssHighlight(items); }
else if(e.key==='ArrowUp') { ssIdx=Math.max(ssIdx-1,0); ssHighlight(items); }
else if(e.key==='Enter' && ssIdx>=0 && items[ssIdx]) { items[ssIdx].click(); }
};
function ssHighlight(items) {
items.forEach(function(el,i){ el.style.background = i===ssIdx?'#EEF1FD':''; });
}
setTimeout(function() {
var searchBtn = document.getElementById('search-btn') || document.querySelector('.search-toggle');
if(searchBtn) searchBtn.addEventListener('click', openSmartSearch);
var hint = document.querySelector('.search-hint, #search-hint');
if(hint) hint.textContent = 'Ctrl+K';
buildSmartSearch();
}, 300);
})();
(function() {
var el = document.getElementById('live-visitors') || document.querySelector('.live-count');
if(!el) return;
var base = 34 + Math.floor(Math.random()*20);
el.textContent = base;
setInterval(function() {
var delta = Math.random() > 0.5 ? 1 : -1;
base = Math.max(10, Math.min(base+delta, 120));
el.textContent = base;
}, 4000);
})();