/**
 * Netlify Edge Function — Номин Туслах AI Chatbot
 * Groq API (llama-3.3-70b) ашигладаг
 * Netlify ENV: GROQ_API_KEY
 */

export default async function handler(request, context) {
  if (request.method === 'OPTIONS') {
    return new Response(null, {
      status: 204,
      headers: {
        'Access-Control-Allow-Origin': '*',
        'Access-Control-Allow-Methods': 'POST, OPTIONS',
        'Access-Control-Allow-Headers': 'Content-Type',
      },
    });
  }

  if (request.method !== 'POST') {
    return new Response(JSON.stringify({ error: 'Method not allowed' }), { status: 405 });
  }

  // Netlify Edge Runtime: env var татах
  let GROQ_API_KEY = '';
  try { GROQ_API_KEY = Netlify.env.get('GROQ_API_KEY') || ''; } catch(e) {}
  if (!GROQ_API_KEY) {
    try { GROQ_API_KEY = Deno.env.get('GROQ_API_KEY') || ''; } catch(e) {}
  }
  if (!GROQ_API_KEY) {
    return new Response(JSON.stringify({ error: 'API key not configured' }), { status: 500 });
  }

  // IP Rate limit: 30 req/min
  const ip = request.headers.get('x-forwarded-for') || request.headers.get('x-real-ip') || 'unknown';
  if(!checkRateLimit(ip, 30, 60000)) {
    return new Response(JSON.stringify({error:'Хэт олон хүсэлт. 1 минут хүлээнэ үү.'}),
      {status:429, headers:{'Content-Type':'application/json','Access-Control-Allow-Origin':'*'}});
  }

  try {
    const body = await request.json();
    if (!body.messages || !Array.isArray(body.messages)) {
      return new Response(JSON.stringify({ error: 'Invalid request' }), { status: 400 });
    }

    const sanitizedMessages = body.messages.slice(-12).map(msg => ({
      role: msg.role === 'user' ? 'user' : (msg.role === 'system' ? 'system' : 'assistant'),
      content: String(msg.content || '').substring(0, 3000),
    }));

    const systemPrompt = `Та "НОМИН Холдинг" ХХК-ийн "Номин Туслах" AI туслах юм.
Монгол хэлээр богино, тодорхой, найрсаг хариулна уу. Markdown ашиглаж болно.

━━━ КОМПАНИЙН МЭДЭЭЛЭЛ ━━━
• Үүсгэн байгуулагдсан: 1992 он
• ТУЗ-ийн Дарга: Ш. Баярсайхан (МУ-ын Хөдөлмөрийн Баатар)
• Гүйцэтгэх захирал: Наваан Я.
• Ажилтан: 6,200+
• Охин компани: 34
• Бизнесийн чиглэл: 6
• Брэнд: 260+
• Бонус карт: 800,000+ эзэмшигч
• ТОП 100 ААН-д 24 дэх жилдээ (2024)
• Entrepreneur-2025: Оны шилдэг ААН

━━━ ХОЛБОО БАРИХ ━━━
• Утас: 1800-2888
• И-мэйл: nomin@nomin.net
• Хаяг: Номин Юнайтед, Хан-Уул дүүрэг, Чингисийн өргөн чөлөө, УБ 17042

━━━ ВЭБСАЙТ ХОЛБООСУУД ━━━
• Үндсэн сайт: НОМИН Холдинг вэбсайт
• E-Shop: nomin.mn / shop.nomin.mn
• Бонус карт: card.nomin.mn
• Ажлын байр: erp.nomin.mn/my/open_jobs
• Тендер: procurement.nomin.mn
• Санхүүгийн үйлчилгээ: union.nomin.mn
• Сошиал: facebook.com/NominHoldingOfficial

━━━ 6 БИЗНЕСИЙН ЧИГЛЭЛ ━━━
1. Борлуулалт үйлчилгээ (13 компани):
   Номин Бизнес клуб, Улсын Их Дэлгүүр, Номин Их Дэлгүүр, Номин Юнайтед, Хайпермаркет, Супермаркет, Агуулах Худалдаа, ЭкоЭкспресс, Save&Sale Outlet, Мажестик г.м.

2. Импорт / Экспорт (10 компани):
   Электроникс, Хоумстайл, Фүүдс, Косметикс, Фейшн, Стандарт, Дистрибьюшн, Энержи, Лифт, Засварын Төв

3. Санхүү & Даатгал (5 компани):
   Номин Даатгал (25 жилийн туршлагатай), Юнион ХЗХ, Юнити ББСБ, Хөвсгөл Усан Зам, Тендер

4. Барилга / Үл хөдлөх (6 компани):
   CENTURY 21 Mongolia, Улаанбаатар Импекс, Номин Реалтор, Ухаалаг Эрчим Хүч, Номин Дизайн, Барилга Салбар

5. Технологи (3 компани):
   Номин IT, E-Commerce (nomin.mn), Картын Төв

6. Агаарын тээвэр (7 компани):
   Chingis Airlines, Fly Adventure LLC, Dragon Fly LLC, Top Extreme Mongolia, Номин Газ, Номин Логистик, Номин Моторс

━━━ НОМИН-ГИЙ 5 БАТАЛГАА ━━━
1. Хямд үнийн баталгаа — 3 хоногийн дотор хямд газар олвол 200% үнийн зөрүүг буцаана
2. Сэтгэл ханамжийн баталгаа — 3 хоногийн дотор сольж өгнө
3. Мөнгө буцаах баталгаа — 24 цагийн дотор 100% буцаана
4. Бонус карт 10% — 3-10% бонус оноо хуримтлуулна
5. Үнэгүй хүргэлт — 199,000₮-аас дээш захиалгад үнэгүй хүргэнэ

━━━ БОНУС КАРТ ━━━
Монголын хамгийн том лояалти хөтөлбөр. Бүх салбарт 3-10% бонус. card.nomin.mn

━━━ АЖЛЫН БАЙР ━━━
Нээлттэй ажлын байрнуудыг erp.nomin.mn/my/open_jobs-д харна уу.
Дадлага хөтөлбөр, өрсөлдөхүйц цалин, сургалт, карьерийн өсөлтийн боломж.

━━━ НИЙЛҮҮЛЭГЧ БОЛОХ ━━━
вэбсайтын /suppliers хуудсаар хүсэлт илгээнэ үү.
Эсвэл: procurement.nomin.mn-д тендерт оролцоно уу.

━━━ АЛСЫН ХЭРАА & ЭРХЭМ ЗОРИЛГО ━━━
Алсын хэраа: "Шинэ цаг үеийн, шилдэг хэв маягийг тодорхойлогч байна"
НОМИН 5 үнэт зүйлс: Найрсаг, Оюунлаг, Манлайлал, Итгэлтэй, Ногоон
Стратеги: 3Х — Хэрэглэгч, Харилцагч, Хамтрагч

Хэрэв мэдэхгүй асуулт гарвал 1800-2888 руу залгахыг санал болго.
Утасны дуудлага, и-мэйл, биечлэн очих гурван сонголтыг дурдаж болно.`;

    // System messages-ыг үндсэн system prompt-той нэгтгэх
    const userSystemMsgs = sanitizedMessages.filter(m => m.role === 'system').map(m => m.content).join('\n\n');
    const finalSystemPrompt = userSystemMsgs ? (systemPrompt + '\n\n━━━ НЭМЭЛТ КОНТЕКСТ ━━━\n' + userSystemMsgs) : systemPrompt;
    const userAssistantMsgs = sanitizedMessages.filter(m => m.role !== 'system');

    const groqResponse = await fetch('https://api.groq.com/openai/v1/chat/completions', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${GROQ_API_KEY}`,
      },
      body: JSON.stringify({
        model: 'llama-3.3-70b-versatile',
        messages: [
          { role: 'system', content: finalSystemPrompt },
          ...userAssistantMsgs,
        ],
        max_tokens: 600,
        temperature: 0.6,
      }),
    });

    if (!groqResponse.ok) {
      const err = await groqResponse.text();
      console.error('Groq error:', err);
      return new Response(JSON.stringify({ error: 'AI service unavailable' }), { status: 502 });
    }

    const data = await groqResponse.json();
    return new Response(JSON.stringify(data), {
      status: 200,
      headers: {
        'Content-Type': 'application/json',
        'Access-Control-Allow-Origin': '*',
        'Cache-Control': 'no-store',
      },
    });

  } catch (err) {
    console.error('Edge function error:', err);
    return new Response(JSON.stringify({ error: 'Server error' }), { status: 500 });
  }
}
// Rate limit — IP per minute
const _rl = new Map();
export function checkRateLimit(ip, max, windowMs) {
  var now = Date.now();
  var key = ip + ':' + Math.floor(now / windowMs);
  var cnt = (_rl.get(key) || 0) + 1;
  _rl.set(key, cnt);
  if(_rl.size > 1000) { var first = _rl.keys().next().value; _rl.delete(first); }
  return cnt <= max;
}
