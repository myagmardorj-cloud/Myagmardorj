export interface Product {
  id: string;
  name: { mn: string; en: string };
  slug: string;
  description: { mn: string; en: string };
  price: number;
  originalPrice?: number;
  images: string[];
  category: Category;
  brand: string;
  rating: number;
  reviewCount: number;
  inStock: boolean;
  stockCount: number;
  tags: string[];
  variants?: ProductVariant[];
  isNew?: boolean;
  isFeatured?: boolean;
  isBestSeller?: boolean;
}

export interface ProductVariant {
  id: string;
  name: string;
  value: string;
  type: 'size' | 'color';
  available: boolean;
}

export type Category =
  | 'electronics'
  | 'clothing'
  | 'food'
  | 'beauty'
  | 'sports'
  | 'home_decor';

export interface CartItem {
  product: Product;
  quantity: number;
  selectedVariants?: { [key: string]: string };
}

export interface Cart {
  items: CartItem[];
  total: number;
  itemCount: number;
}

export interface WishlistItem {
  productId: string;
  addedAt: Date;
}

export interface Review {
  id: string;
  productId: string;
  userId: string;
  userName: string;
  rating: number;
  comment: string;
  createdAt: Date;
}

export interface SortOption {
  value: string;
  label: { mn: string; en: string };
}

export interface FilterState {
  categories: Category[];
  priceRange: [number, number];
  brands: string[];
  inStockOnly: boolean;
  rating: number;
}
