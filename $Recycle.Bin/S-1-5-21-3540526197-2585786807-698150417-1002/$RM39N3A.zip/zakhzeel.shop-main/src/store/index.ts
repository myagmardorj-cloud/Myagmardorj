import { create } from 'zustand';
import { persist } from 'zustand/middleware';
import { CartItem, Product, FilterState } from '../types';
import { Lang } from '../i18n';

interface AppState {
  // Language
  lang: Lang;
  setLang: (lang: Lang) => void;

  // Cart
  cart: CartItem[];
  addToCart: (product: Product, quantity?: number, variants?: { [key: string]: string }) => void;
  removeFromCart: (productId: string) => void;
  updateQuantity: (productId: string, quantity: number) => void;
  clearCart: () => void;
  cartTotal: () => number;
  cartCount: () => number;

  // Wishlist
  wishlist: string[];
  toggleWishlist: (productId: string) => void;
  isInWishlist: (productId: string) => boolean;

  // UI
  cartOpen: boolean;
  setCartOpen: (open: boolean) => void;
  searchQuery: string;
  setSearchQuery: (q: string) => void;

  // Filters
  filters: FilterState;
  setFilters: (filters: Partial<FilterState>) => void;
  clearFilters: () => void;
}

const defaultFilters: FilterState = {
  categories: [],
  priceRange: [0, 10000000],
  brands: [],
  inStockOnly: false,
  rating: 0,
};

export const useStore = create<AppState>()(
  persist(
    (set, get) => ({
      lang: 'mn',
      setLang: (lang) => set({ lang }),

      cart: [],
      addToCart: (product, quantity = 1, variants) => {
        const cart = get().cart;
        const existing = cart.find((item) => item.product.id === product.id);
        if (existing) {
          set({
            cart: cart.map((item) =>
              item.product.id === product.id
                ? { ...item, quantity: item.quantity + quantity }
                : item
            ),
          });
        } else {
          set({ cart: [...cart, { product, quantity, selectedVariants: variants }] });
        }
      },
      removeFromCart: (productId) =>
        set({ cart: get().cart.filter((item) => item.product.id !== productId) }),
      updateQuantity: (productId, quantity) => {
        if (quantity <= 0) {
          get().removeFromCart(productId);
          return;
        }
        set({
          cart: get().cart.map((item) =>
            item.product.id === productId ? { ...item, quantity } : item
          ),
        });
      },
      clearCart: () => set({ cart: [] }),
      cartTotal: () =>
        get().cart.reduce((sum, item) => sum + item.product.price * item.quantity, 0),
      cartCount: () => get().cart.reduce((sum, item) => sum + item.quantity, 0),

      wishlist: [],
      toggleWishlist: (productId) => {
        const wishlist = get().wishlist;
        if (wishlist.includes(productId)) {
          set({ wishlist: wishlist.filter((id) => id !== productId) });
        } else {
          set({ wishlist: [...wishlist, productId] });
        }
      },
      isInWishlist: (productId) => get().wishlist.includes(productId),

      cartOpen: false,
      setCartOpen: (open) => set({ cartOpen: open }),
      searchQuery: '',
      setSearchQuery: (q) => set({ searchQuery: q }),

      filters: defaultFilters,
      setFilters: (filters) => set({ filters: { ...get().filters, ...filters } }),
      clearFilters: () => set({ filters: defaultFilters }),
    }),
    {
      name: 'zarlaa-store',
      partialize: (state) => ({
        cart: state.cart,
        wishlist: state.wishlist,
        lang: state.lang,
      }),
    }
  )
);
