import React, { useState, useEffect } from 'react';
import { Product } from './types';
import Navbar from './components/layout/Navbar';
import MobileNav from './components/layout/MobileNav';
import CartSidebar from './components/cart/CartSidebar';
import ToastContainer from './components/ui/Toast';
import HomePage from './pages/HomePage';
import ShopPage from './pages/ShopPage';
import ProductPage from './pages/ProductPage';
import WishlistPage from './pages/WishlistPage';
import CheckoutPage from './pages/CheckoutPage';
import SearchPage from './pages/SearchPage';
import './styles/globals.css';

type Page = 'home' | 'shop' | 'product' | 'wishlist' | 'checkout' | 'search';

export default function App() {
  const [page, setPage] = useState<Page>('home');
  const [pageData, setPageData] = useState<unknown>(null);
  const [isMobile, setIsMobile] = useState(false);

  useEffect(() => {
    const check = () => setIsMobile(window.innerWidth < 768);
    check();
    window.addEventListener('resize', check);
    return () => window.removeEventListener('resize', check);
  }, []);

  const navigate = (targetPage: string, data?: unknown) => {
    setPage(targetPage as Page);
    setPageData(data || null);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  return (
    <div style={{
      minHeight: '100vh',
      background: 'var(--gray-50)',
      paddingBottom: isMobile ? '72px' : 0,
    }}>
      <Navbar onNavigate={navigate} currentPage={page} />
      <CartSidebar onNavigate={navigate} />
      <ToastContainer />
      {page === 'home' && <HomePage onNavigate={navigate} />}
      {page === 'shop' && (
        <ShopPage
          onNavigate={navigate}
          initialCategory={(pageData as { category?: string })?.category}
        />
      )}
      {page === 'product' && pageData && (
        <ProductPage product={pageData as Product} onNavigate={navigate} />
      )}
      {page === 'wishlist' && <WishlistPage onNavigate={navigate} />}
      {page === 'checkout' && <CheckoutPage onNavigate={navigate} />}
      {page === 'search' && <SearchPage onNavigate={navigate} />}
      {isMobile && <MobileNav onNavigate={navigate} currentPage={page} />}
    </div>
  );
}
