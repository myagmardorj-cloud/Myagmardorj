import React, { useState } from 'react';
import { useStore } from '../store';
import { t } from '../i18n';
import { formatPrice } from '../lib/data';

interface CheckoutPageProps {
  onNavigate: (page: string, data?: unknown) => void;
}

type Step = 'info' | 'shipping' | 'payment' | 'success';

const PAYMENT_METHODS = [
  { id: 'card', icon: '💳', mn: 'Банкны карт', en: 'Bank Card' },
  { id: 'qpay', icon: '📱', mn: 'QPay', en: 'QPay' },
  { id: 'socialpay', icon: '🏦', mn: 'SocialPay', en: 'SocialPay' },
  { id: 'cash', icon: '💵', mn: 'Бэлнээр', en: 'Cash on Delivery' },
];

export default function CheckoutPage({ onNavigate }: CheckoutPageProps) {
  const { lang, cart, cartTotal, clearCart } = useStore();
  const total = cartTotal();
  const shippingFee = total >= 50000 ? 0 : 5000;
  const grandTotal = total + shippingFee;

  const [step, setStep] = useState<Step>('info');
  const [paymentMethod, setPaymentMethod] = useState('qpay');
  const [form, setForm] = useState({
    firstName: '',
    lastName: '',
    phone: '',
    email: '',
    district: '',
    khoroo: '',
    address: '',
    note: '',
  });
  const [errors, setErrors] = useState<{ [key: string]: string }>({});

  const update = (field: string, val: string) => {
    setForm((f) => ({ ...f, [field]: val }));
    setErrors((e) => ({ ...e, [field]: '' }));
  };

  const validateInfo = () => {
    const errs: { [key: string]: string } = {};
    if (!form.firstName) errs.firstName = lang === 'mn' ? 'Нэр оруулна уу' : 'Required';
    if (!form.lastName) errs.lastName = lang === 'mn' ? 'Овог оруулна уу' : 'Required';
    if (!form.phone || form.phone.length < 8)
      errs.phone = lang === 'mn' ? 'Зөв утасны дугаар оруулна уу' : 'Enter valid phone';
    if (!form.email || !form.email.includes('@'))
      errs.email = lang === 'mn' ? 'Зөв и-мэйл оруулна уу' : 'Enter valid email';
    setErrors(errs);
    return Object.keys(errs).length === 0;
  };

  const validateShipping = () => {
    const errs: { [key: string]: string } = {};
    if (!form.district) errs.district = lang === 'mn' ? 'Дүүрэг сонгоно уу' : 'Required';
    if (!form.khoroo) errs.khoroo = lang === 'mn' ? 'Хороо оруулна уу' : 'Required';
    if (!form.address) errs.address = lang === 'mn' ? 'Хаяг оруулна уу' : 'Required';
    setErrors(errs);
    return Object.keys(errs).length === 0;
  };

  const handleNext = () => {
    if (step === 'info' && validateInfo()) setStep('shipping');
    else if (step === 'shipping' && validateShipping()) setStep('payment');
    else if (step === 'payment') {
      clearCart();
      setStep('success');
    }
  };

  const STEPS: { id: Step; mn: string; en: string }[] = [
    { id: 'info', mn: 'Мэдээлэл', en: 'Info' },
    { id: 'shipping', mn: 'Хүргэлт', en: 'Shipping' },
    { id: 'payment', mn: 'Төлбөр', en: 'Payment' },
  ];

  const stepIdx = STEPS.findIndex((s) => s.id === step);

  if (step === 'success') {
    return (
      <main style={{ minHeight: '80vh', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
        <div style={{
          textAlign: 'center',
          padding: '3rem',
          background: 'white',
          borderRadius: 'var(--radius-lg)',
          boxShadow: 'var(--shadow-lg)',
          maxWidth: '480px',
          width: '100%',
          margin: '2rem 1rem',
        }}>
          <div style={{ fontSize: '5rem', marginBottom: '1rem' }}>🎉</div>
          <h1 style={{ fontFamily: 'var(--font-heading)', fontSize: '2rem', marginBottom: '0.75rem', color: '#10B981' }}>
            {lang === 'mn' ? 'Захиалга амжилттай!' : 'Order Placed!'}
          </h1>
          <p style={{ color: 'var(--gray-500)', marginBottom: '0.5rem', lineHeight: 1.7 }}>
            {lang === 'mn'
              ? `${form.lastName} ${form.firstName} таны захиалга хүлээн авлаа. Удахгүй таны утас руу мессеж илгээнэ.`
              : `Thank you ${form.firstName}! Your order has been received. We'll send a confirmation to your phone shortly.`}
          </p>
          <div style={{
            background: 'var(--gray-50)',
            borderRadius: 'var(--radius-sm)',
            padding: '1rem',
            margin: '1.5rem 0',
            fontSize: '0.9rem',
            color: 'var(--gray-600)',
          }}>
            <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: '0.3rem' }}>
              <span>{lang === 'mn' ? 'Захиалгын дугаар' : 'Order #'}</span>
              <strong>ZR-{Math.floor(Math.random() * 90000) + 10000}</strong>
            </div>
            <div style={{ display: 'flex', justifyContent: 'space-between' }}>
              <span>{lang === 'mn' ? 'Нийт дүн' : 'Total'}</span>
              <strong style={{ color: 'var(--brand-red)' }}>{formatPrice(grandTotal)}</strong>
            </div>
          </div>
          <button className="btn btn-primary btn-lg" onClick={() => onNavigate('home')} style={{ width: '100%' }}>
            {lang === 'mn' ? 'Нүүр хуудас руу буцах' : 'Back to Home'}
          </button>
        </div>
      </main>
    );
  }

  const Field = ({
    label, field, type = 'text', placeholder, required = true
  }: {
    label: string; field: string; type?: string; placeholder?: string; required?: boolean;
  }) => (
    <div>
      <label style={{ display: 'block', fontWeight: 600, fontSize: '0.85rem', marginBottom: '0.4rem', color: 'var(--gray-700)' }}>
        {label} {required && <span style={{ color: 'var(--brand-red)' }}>*</span>}
      </label>
      <input
        className="input"
        type={type}
        placeholder={placeholder}
        value={(form as Record<string, string>)[field]}
        onChange={(e) => update(field, e.target.value)}
        style={{ borderColor: errors[field] ? 'var(--brand-red)' : undefined }}
      />
      {errors[field] && (
        <p style={{ color: 'var(--brand-red)', fontSize: '0.78rem', marginTop: '0.3rem' }}>{errors[field]}</p>
      )}
    </div>
  );

  return (
    <main>
      <div className="container" style={{ paddingTop: '2rem', paddingBottom: '4rem', maxWidth: '1000px' }}>
        {/* Back */}
        <button
          onClick={() => step === 'info' ? onNavigate('home') : setStep(step === 'payment' ? 'shipping' : 'info')}
          style={{ color: 'var(--brand-red)', fontWeight: 600, marginBottom: '1.5rem', display: 'flex', alignItems: 'center', gap: '0.3rem' }}
        >
          ← {lang === 'mn' ? 'Буцах' : 'Back'}
        </button>

        <h1 style={{ fontFamily: 'var(--font-heading)', fontSize: '1.8rem', marginBottom: '2rem' }}>
          {t(lang, 'checkout')}
        </h1>

        {/* Step indicator */}
        <div style={{
          display: 'flex',
          alignItems: 'center',
          marginBottom: '2.5rem',
          gap: '0',
        }}>
          {STEPS.map((s, i) => (
            <React.Fragment key={s.id}>
              <div style={{
                display: 'flex',
                alignItems: 'center',
                gap: '0.5rem',
                flex: i < STEPS.length - 1 ? 'none' : 'none',
              }}>
                <div style={{
                  width: '32px',
                  height: '32px',
                  borderRadius: '50%',
                  background: i < stepIdx ? '#10B981' : i === stepIdx ? 'var(--brand-red)' : 'var(--gray-200)',
                  color: i <= stepIdx ? 'white' : 'var(--gray-400)',
                  display: 'flex',
                  alignItems: 'center',
                  justifyContent: 'center',
                  fontWeight: 800,
                  fontSize: '0.85rem',
                  flexShrink: 0,
                  transition: 'all 0.3s',
                }}>
                  {i < stepIdx ? '✓' : i + 1}
                </div>
                <span style={{
                  fontWeight: i === stepIdx ? 700 : 400,
                  fontSize: '0.88rem',
                  color: i === stepIdx ? 'var(--gray-900)' : 'var(--gray-400)',
                }}>
                  {lang === 'mn' ? s.mn : s.en}
                </span>
              </div>
              {i < STEPS.length - 1 && (
                <div style={{
                  flex: 1,
                  height: '2px',
                  background: i < stepIdx ? '#10B981' : 'var(--gray-200)',
                  margin: '0 0.75rem',
                  transition: 'background 0.3s',
                }} />
              )}
            </React.Fragment>
          ))}
        </div>

        <div style={{ display: 'grid', gridTemplateColumns: '1fr 360px', gap: '2rem', alignItems: 'start' }}>
          {/* Form */}
          <div style={{
            background: 'white',
            borderRadius: 'var(--radius)',
            padding: '2rem',
            boxShadow: 'var(--shadow-sm)',
          }}>
            {/* Step 1: Info */}
            {step === 'info' && (
              <div style={{ display: 'flex', flexDirection: 'column', gap: '1.25rem' }}>
                <h2 style={{ fontFamily: 'var(--font-heading)', fontSize: '1.2rem', marginBottom: '0.25rem' }}>
                  {lang === 'mn' ? '👤 Хувийн мэдээлэл' : '👤 Personal Information'}
                </h2>
                <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '1rem' }}>
                  <Field label={lang === 'mn' ? 'Овог' : 'Last Name'} field="lastName" placeholder={lang === 'mn' ? 'Баатар' : 'Smith'} />
                  <Field label={lang === 'mn' ? 'Нэр' : 'First Name'} field="firstName" placeholder={lang === 'mn' ? 'Болд' : 'John'} />
                </div>
                <Field label={lang === 'mn' ? 'Утасны дугаар' : 'Phone'} field="phone" type="tel" placeholder="9911 1234" />
                <Field label={lang === 'mn' ? 'И-мэйл' : 'Email'} field="email" type="email" placeholder="example@mail.com" />
              </div>
            )}

            {/* Step 2: Shipping */}
            {step === 'shipping' && (
              <div style={{ display: 'flex', flexDirection: 'column', gap: '1.25rem' }}>
                <h2 style={{ fontFamily: 'var(--font-heading)', fontSize: '1.2rem', marginBottom: '0.25rem' }}>
                  {lang === 'mn' ? '🚚 Хүргэлтийн хаяг' : '🚚 Delivery Address'}
                </h2>

                {/* Delivery type */}
                <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '0.75rem' }}>
                  {[
                    { id: 'delivery', icon: '🚚', mn: 'Хүргэлт', en: 'Delivery' },
                    { id: 'pickup', icon: '🏪', mn: 'Өөрөө авах', en: 'Pickup' },
                  ].map((opt) => (
                    <button
                      key={opt.id}
                      style={{
                        padding: '1rem',
                        borderRadius: 'var(--radius-sm)',
                        border: `2px solid ${opt.id === 'delivery' ? 'var(--brand-red)' : 'var(--gray-200)'}`,
                        background: opt.id === 'delivery' ? '#FEF2F2' : 'white',
                        display: 'flex',
                        alignItems: 'center',
                        gap: '0.5rem',
                        fontWeight: 600,
                        fontSize: '0.9rem',
                        color: opt.id === 'delivery' ? 'var(--brand-red)' : 'var(--gray-600)',
                      }}
                    >
                      {opt.icon} {lang === 'mn' ? opt.mn : opt.en}
                    </button>
                  ))}
                </div>

                <div>
                  <label style={{ display: 'block', fontWeight: 600, fontSize: '0.85rem', marginBottom: '0.4rem', color: 'var(--gray-700)' }}>
                    {lang === 'mn' ? 'Дүүрэг' : 'District'} <span style={{ color: 'var(--brand-red)' }}>*</span>
                  </label>
                  <select
                    className="input select"
                    value={form.district}
                    onChange={(e) => update('district', e.target.value)}
                    style={{ borderColor: errors.district ? 'var(--brand-red)' : undefined }}
                  >
                    <option value="">{lang === 'mn' ? 'Сонгох...' : 'Select...'}</option>
                    {['Баянзүрх', 'Сүхбаатар', 'Баянгол', 'Чингэлтэй', 'Хан-Уул', 'Налайх', 'Сонгинохайрхан', 'Багануур'].map((d) => (
                      <option key={d} value={d}>{d}</option>
                    ))}
                  </select>
                  {errors.district && <p style={{ color: 'var(--brand-red)', fontSize: '0.78rem', marginTop: '0.3rem' }}>{errors.district}</p>}
                </div>

                <Field label={lang === 'mn' ? 'Хороо / байр' : 'Khoroo / Building'} field="khoroo" placeholder={lang === 'mn' ? '1-р хороо, 32-р байр' : 'Khoroo 1, Building 32'} />
                <Field label={lang === 'mn' ? 'Дэлгэрэнгүй хаяг' : 'Detailed Address'} field="address" placeholder={lang === 'mn' ? 'Орц, давхар, тоот' : 'Entrance, Floor, Apt'} />
                <div>
                  <label style={{ display: 'block', fontWeight: 600, fontSize: '0.85rem', marginBottom: '0.4rem', color: 'var(--gray-700)' }}>
                    {lang === 'mn' ? 'Нэмэлт тэмдэглэл' : 'Note'} <span style={{ color: 'var(--gray-400)' }}>({lang === 'mn' ? 'заавал биш' : 'optional'})</span>
                  </label>
                  <textarea
                    className="input"
                    rows={3}
                    placeholder={lang === 'mn' ? 'Жишээ: 5 давхарт авчирна уу...' : 'e.g. Leave at door...'}
                    value={form.note}
                    onChange={(e) => update('note', e.target.value)}
                    style={{ resize: 'vertical' }}
                  />
                </div>
              </div>
            )}

            {/* Step 3: Payment */}
            {step === 'payment' && (
              <div style={{ display: 'flex', flexDirection: 'column', gap: '1.25rem' }}>
                <h2 style={{ fontFamily: 'var(--font-heading)', fontSize: '1.2rem', marginBottom: '0.25rem' }}>
                  {lang === 'mn' ? '💳 Төлбөрийн хэлбэр' : '💳 Payment Method'}
                </h2>
                <div style={{ display: 'flex', flexDirection: 'column', gap: '0.75rem' }}>
                  {PAYMENT_METHODS.map((pm) => (
                    <label
                      key={pm.id}
                      style={{
                        display: 'flex',
                        alignItems: 'center',
                        gap: '1rem',
                        padding: '1rem 1.25rem',
                        borderRadius: 'var(--radius-sm)',
                        border: `2px solid ${paymentMethod === pm.id ? 'var(--brand-red)' : 'var(--gray-200)'}`,
                        background: paymentMethod === pm.id ? '#FEF2F2' : 'white',
                        cursor: 'pointer',
                        transition: 'all var(--transition)',
                      }}
                    >
                      <input
                        type="radio"
                        name="payment"
                        value={pm.id}
                        checked={paymentMethod === pm.id}
                        onChange={() => setPaymentMethod(pm.id)}
                        style={{ accentColor: 'var(--brand-red)' }}
                      />
                      <span style={{ fontSize: '1.5rem' }}>{pm.icon}</span>
                      <span style={{ fontWeight: 600, fontSize: '0.95rem' }}>
                        {lang === 'mn' ? pm.mn : pm.en}
                      </span>
                    </label>
                  ))}
                </div>

                {paymentMethod === 'card' && (
                  <div style={{
                    padding: '1.25rem',
                    background: 'var(--gray-50)',
                    borderRadius: 'var(--radius-sm)',
                    display: 'flex',
                    flexDirection: 'column',
                    gap: '1rem',
                  }}>
                    <div>
                      <label style={{ display: 'block', fontWeight: 600, fontSize: '0.85rem', marginBottom: '0.4rem', color: 'var(--gray-700)' }}>
                        {lang === 'mn' ? 'Картын дугаар' : 'Card Number'}
                      </label>
                      <input className="input" placeholder="•••• •••• •••• ••••" />
                    </div>
                    <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '0.75rem' }}>
                      <div>
                        <label style={{ display: 'block', fontWeight: 600, fontSize: '0.85rem', marginBottom: '0.4rem', color: 'var(--gray-700)' }}>
                          {lang === 'mn' ? 'Дуусах огноо' : 'Expiry'}
                        </label>
                        <input className="input" placeholder="MM/YY" />
                      </div>
                      <div>
                        <label style={{ display: 'block', fontWeight: 600, fontSize: '0.85rem', marginBottom: '0.4rem', color: 'var(--gray-700)' }}>CVV</label>
                        <input className="input" placeholder="•••" />
                      </div>
                    </div>
                  </div>
                )}

                {paymentMethod === 'qpay' && (
                  <div style={{
                    textAlign: 'center',
                    padding: '2rem',
                    background: 'var(--gray-50)',
                    borderRadius: 'var(--radius-sm)',
                  }}>
                    <div style={{
                      width: '160px',
                      height: '160px',
                      background: 'white',
                      borderRadius: 'var(--radius-sm)',
                      margin: '0 auto 1rem',
                      display: 'flex',
                      alignItems: 'center',
                      justifyContent: 'center',
                      fontSize: '5rem',
                      boxShadow: 'var(--shadow-md)',
                    }}>📱</div>
                    <p style={{ fontWeight: 600, color: 'var(--gray-700)', marginBottom: '0.3rem' }}>
                      {lang === 'mn' ? 'QPay QR код скан хийнэ үү' : 'Scan QPay QR Code'}
                    </p>
                    <p style={{ color: 'var(--gray-400)', fontSize: '0.85rem' }}>
                      {lang === 'mn' ? 'Дүн: ' : 'Amount: '}<strong style={{ color: 'var(--brand-red)' }}>{formatPrice(grandTotal)}</strong>
                    </p>
                  </div>
                )}
              </div>
            )}

            <button
              className="btn btn-primary btn-lg"
              onClick={handleNext}
              style={{ width: '100%', marginTop: '2rem' }}
            >
              {step === 'payment'
                ? (lang === 'mn' ? '✓ Захиалга баталгаажуулах' : '✓ Confirm Order')
                : (lang === 'mn' ? 'Үргэлжлүүлэх →' : 'Continue →')}
            </button>
          </div>

          {/* Order Summary */}
          <div style={{
            background: 'white',
            borderRadius: 'var(--radius)',
            padding: '1.5rem',
            boxShadow: 'var(--shadow-sm)',
            position: 'sticky',
            top: '80px',
          }}>
            <h3 style={{ fontFamily: 'var(--font-heading)', fontSize: '1.1rem', marginBottom: '1.25rem' }}>
              {lang === 'mn' ? '🧾 Захиалгын дэлгэрэнгүй' : '🧾 Order Summary'}
            </h3>
            <div style={{ display: 'flex', flexDirection: 'column', gap: '0.75rem', marginBottom: '1.25rem' }}>
              {cart.map((item) => (
                <div key={item.product.id} style={{ display: 'flex', gap: '0.75rem', alignItems: 'center' }}>
                  <div style={{ position: 'relative', flexShrink: 0 }}>
                    <img
                      src={item.product.images[0]}
                      alt={item.product.name[lang]}
                      style={{ width: '52px', height: '52px', borderRadius: 'var(--radius-sm)', objectFit: 'cover' }}
                    />
                    <span style={{
                      position: 'absolute',
                      top: '-6px',
                      right: '-6px',
                      background: 'var(--brand-red)',
                      color: 'white',
                      borderRadius: '50%',
                      width: '18px',
                      height: '18px',
                      fontSize: '0.65rem',
                      fontWeight: 800,
                      display: 'flex',
                      alignItems: 'center',
                      justifyContent: 'center',
                    }}>
                      {item.quantity}
                    </span>
                  </div>
                  <div style={{ flex: 1, minWidth: 0 }}>
                    <p style={{ fontSize: '0.83rem', fontWeight: 600, overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>
                      {item.product.name[lang]}
                    </p>
                    <p style={{ fontSize: '0.8rem', color: 'var(--gray-500)' }}>
                      {formatPrice(item.product.price)}
                    </p>
                  </div>
                  <span style={{ fontSize: '0.88rem', fontWeight: 700, flexShrink: 0 }}>
                    {formatPrice(item.product.price * item.quantity)}
                  </span>
                </div>
              ))}
            </div>
            <div style={{ borderTop: '1px solid var(--gray-100)', paddingTop: '1rem', display: 'flex', flexDirection: 'column', gap: '0.5rem' }}>
              <div style={{ display: 'flex', justifyContent: 'space-between', fontSize: '0.88rem', color: 'var(--gray-600)' }}>
                <span>{t(lang, 'subtotal')}</span><span>{formatPrice(total)}</span>
              </div>
              <div style={{ display: 'flex', justifyContent: 'space-between', fontSize: '0.88rem', color: 'var(--gray-600)' }}>
                <span>{t(lang, 'shipping')}</span>
                <span style={{ color: shippingFee === 0 ? '#10B981' : 'inherit' }}>
                  {shippingFee === 0 ? t(lang, 'free') : formatPrice(shippingFee)}
                </span>
              </div>
              <div style={{
                display: 'flex',
                justifyContent: 'space-between',
                fontWeight: 800,
                fontSize: '1.1rem',
                paddingTop: '0.75rem',
                borderTop: '2px solid var(--gray-100)',
                color: 'var(--brand-red)',
              }}>
                <span>{t(lang, 'total')}</span><span>{formatPrice(grandTotal)}</span>
              </div>
            </div>

            {/* Security badges */}
            <div style={{
              marginTop: '1.25rem',
              padding: '1rem',
              background: 'var(--gray-50)',
              borderRadius: 'var(--radius-sm)',
              display: 'flex',
              flexDirection: 'column',
              gap: '0.4rem',
            }}>
              {[
                { icon: '🔒', mn: 'Аюулгүй шифрлэгдсэн', en: 'SSL Encrypted' },
                { icon: '↩️', mn: '14 хоногийн буцаалт', en: '14-day Returns' },
                { icon: '🚚', mn: 'Хурдан хүргэлт', en: 'Fast Delivery' },
              ].map((b) => (
                <div key={b.mn} style={{ display: 'flex', alignItems: 'center', gap: '0.5rem', fontSize: '0.8rem', color: 'var(--gray-600)' }}>
                  <span>{b.icon}</span>
                  <span>{lang === 'mn' ? b.mn : b.en}</span>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>

      <style>{`
        @media (max-width: 768px) {
          .checkout-grid { grid-template-columns: 1fr !important; }
        }
      `}</style>
    </main>
  );
}
