import React, { useState } from 'react';
import { Product } from '../types';
import { useStore } from '../store';
import { t } from '../i18n';
import { formatPrice, getDiscountPercent, PRODUCTS } from '../lib/data';
import ProductCard from '../components/product/ProductCard';

interface ProductPageProps {
  product: Product;
  onNavigate: (page: string, data?: unknown) => void;
}

export default function ProductPage({ product, onNavigate }: ProductPageProps) {
  const { lang, addToCart, toggleWishlist, isInWishlist, setCartOpen } = useStore();
  const [selectedImg, setSelectedImg] = useState(0);
  const [quantity, setQuantity] = useState(1);
  const [selectedVariants, setSelectedVariants] = useState<{ [key: string]: string }>({});
  const [added, setAdded] = useState(false);

  const inWishlist = isInWishlist(product.id);
  const discount = product.originalPrice
    ? getDiscountPercent(product.price, product.originalPrice)
    : 0;

  const related = PRODUCTS.filter(
    (p) => p.category === product.category && p.id !== product.id
  ).slice(0, 4);

  const colorVariants = product.variants?.filter((v) => v.type === 'color') || [];
  const sizeVariants = product.variants?.filter((v) => v.type === 'size') || [];

  const handleAddToCart = () => {
    if (!product.inStock) return;
    addToCart(product, quantity, selectedVariants);
    setAdded(true);
    setTimeout(() => {
      setAdded(false);
      setCartOpen(true);
    }, 800);
  };

  return (
    <main>
      <div className="container" style={{ paddingTop: '2rem', paddingBottom: '4rem' }}>
        {/* Breadcrumb */}
        <div style={{
          display: 'flex',
          alignItems: 'center',
          gap: '0.5rem',
          marginBottom: '2rem',
          fontSize: '0.85rem',
          color: 'var(--gray-500)',
          flexWrap: 'wrap',
        }}>
          <button onClick={() => onNavigate('home')} style={{ color: 'var(--brand-red)', fontWeight: 600 }}>
            {t(lang, 'home')}
          </button>
          <span>›</span>
          <button onClick={() => onNavigate('shop')} style={{ color: 'var(--brand-red)', fontWeight: 600 }}>
            {t(lang, 'shop')}
          </button>
          <span>›</span>
          <span style={{ color: 'var(--gray-700)' }}>{product.name[lang]}</span>
        </div>

        {/* Main product layout */}
        <div style={{
          display: 'grid',
          gridTemplateColumns: '1fr 1fr',
          gap: '3rem',
          marginBottom: '4rem',
        }}>
          {/* Images */}
          <div>
            <div style={{
              borderRadius: 'var(--radius-lg)',
              overflow: 'hidden',
              aspectRatio: '1',
              background: 'var(--gray-100)',
              marginBottom: '1rem',
              position: 'relative',
            }}>
              <img
                src={product.images[selectedImg]}
                alt={product.name[lang]}
                style={{ width: '100%', height: '100%', objectFit: 'cover' }}
              />
              {discount > 0 && (
                <div style={{ position: 'absolute', top: '1rem', left: '1rem' }}>
                  <span className="badge badge-red" style={{ fontSize: '0.9rem' }}>-{discount}%</span>
                </div>
              )}
            </div>
            {product.images.length > 1 && (
              <div style={{ display: 'flex', gap: '0.75rem' }}>
                {product.images.map((img, i) => (
                  <button
                    key={i}
                    onClick={() => setSelectedImg(i)}
                    style={{
                      width: '80px',
                      height: '80px',
                      borderRadius: 'var(--radius-sm)',
                      overflow: 'hidden',
                      border: `2px solid ${selectedImg === i ? 'var(--brand-red)' : 'transparent'}`,
                      transition: 'border-color var(--transition)',
                    }}
                  >
                    <img
                      src={img}
                      alt=""
                      style={{ width: '100%', height: '100%', objectFit: 'cover' }}
                    />
                  </button>
                ))}
              </div>
            )}
          </div>

          {/* Info */}
          <div>
            <div style={{
              display: 'flex',
              alignItems: 'center',
              gap: '0.5rem',
              marginBottom: '0.75rem',
            }}>
              <span style={{
                fontSize: '0.8rem',
                fontWeight: 700,
                color: 'var(--gray-400)',
                textTransform: 'uppercase',
                letterSpacing: '0.05em',
              }}>
                {product.brand}
              </span>
              {product.isNew && <span className="badge badge-green">{lang === 'mn' ? 'Шинэ' : 'New'}</span>}
              {product.isBestSeller && <span className="badge badge-gold">{lang === 'mn' ? 'Шилдэг' : 'Top'}</span>}
            </div>

            <h1 style={{
              fontFamily: 'var(--font-heading)',
              fontSize: 'clamp(1.4rem, 2.5vw, 2rem)',
              lineHeight: 1.2,
              marginBottom: '1rem',
            }}>
              {product.name[lang]}
            </h1>

            {/* Rating */}
            <div style={{
              display: 'flex',
              alignItems: 'center',
              gap: '0.75rem',
              marginBottom: '1.25rem',
            }}>
              <div className="stars" style={{ fontSize: '1rem' }}>
                {[1,2,3,4,5].map((s) => (
                  <span key={s} style={{ opacity: s <= Math.round(product.rating) ? 1 : 0.2 }}>★</span>
                ))}
              </div>
              <span style={{ fontWeight: 700, fontSize: '0.9rem' }}>{product.rating}</span>
              <span style={{ color: 'var(--gray-400)', fontSize: '0.85rem' }}>
                ({product.reviewCount} {t(lang, 'reviews')})
              </span>
            </div>

            {/* Price */}
            <div style={{
              background: 'var(--gray-50)',
              padding: '1.25rem',
              borderRadius: 'var(--radius-sm)',
              marginBottom: '1.5rem',
            }}>
              <div style={{ display: 'flex', alignItems: 'baseline', gap: '0.75rem' }}>
                <span style={{
                  fontFamily: 'var(--font-heading)',
                  fontSize: '2rem',
                  fontWeight: 800,
                  color: 'var(--brand-red)',
                }}>
                  {formatPrice(product.price)}
                </span>
                {product.originalPrice && (
                  <>
                    <span style={{
                      fontSize: '1.1rem',
                      color: 'var(--gray-400)',
                      textDecoration: 'line-through',
                    }}>
                      {formatPrice(product.originalPrice)}
                    </span>
                    <span className="badge badge-red">-{discount}%</span>
                  </>
                )}
              </div>
              {product.originalPrice && (
                <p style={{ fontSize: '0.85rem', color: '#10B981', fontWeight: 600, marginTop: '0.4rem' }}>
                  {lang === 'mn'
                    ? `${formatPrice(product.originalPrice - product.price)} хэмнэлтэй`
                    : `You save ${formatPrice(product.originalPrice - product.price)}`}
                </p>
              )}
            </div>

            {/* Description */}
            <p style={{
              color: 'var(--gray-600)',
              lineHeight: 1.8,
              marginBottom: '1.5rem',
              fontSize: '0.95rem',
            }}>
              {product.description[lang]}
            </p>

            {/* Color variants */}
            {colorVariants.length > 0 && (
              <div style={{ marginBottom: '1.25rem' }}>
                <p style={{ fontWeight: 700, fontSize: '0.88rem', marginBottom: '0.75rem', color: 'var(--gray-700)' }}>
                  {t(lang, 'color')}: <span style={{ color: 'var(--gray-900)' }}>{selectedVariants['color'] || colorVariants[0].value}</span>
                </p>
                <div style={{ display: 'flex', gap: '0.5rem', flexWrap: 'wrap' }}>
                  {colorVariants.map((v) => (
                    <button
                      key={v.id}
                      onClick={() => setSelectedVariants({ ...selectedVariants, color: v.value })}
                      disabled={!v.available}
                      style={{
                        padding: '0.4rem 0.9rem',
                        borderRadius: '100px',
                        border: `2px solid ${selectedVariants['color'] === v.value || (!selectedVariants['color'] && v.id === colorVariants[0].id) ? 'var(--brand-red)' : 'var(--gray-200)'}`,
                        background: selectedVariants['color'] === v.value ? '#FEF2F2' : 'white',
                        color: v.available ? 'var(--gray-800)' : 'var(--gray-300)',
                        fontSize: '0.85rem',
                        fontWeight: 600,
                        opacity: v.available ? 1 : 0.5,
                        cursor: v.available ? 'pointer' : 'not-allowed',
                        transition: 'all var(--transition)',
                      }}
                    >
                      {v.value}
                    </button>
                  ))}
                </div>
              </div>
            )}

            {/* Size variants */}
            {sizeVariants.length > 0 && (
              <div style={{ marginBottom: '1.25rem' }}>
                <p style={{ fontWeight: 700, fontSize: '0.88rem', marginBottom: '0.75rem', color: 'var(--gray-700)' }}>
                  {t(lang, 'size')}: <span style={{ color: 'var(--gray-900)' }}>{selectedVariants['size'] || ''}</span>
                </p>
                <div style={{ display: 'flex', gap: '0.5rem', flexWrap: 'wrap' }}>
                  {sizeVariants.map((v) => (
                    <button
                      key={v.id}
                      onClick={() => setSelectedVariants({ ...selectedVariants, size: v.value })}
                      disabled={!v.available}
                      style={{
                        width: '44px',
                        height: '44px',
                        borderRadius: 'var(--radius-sm)',
                        border: `2px solid ${selectedVariants['size'] === v.value ? 'var(--brand-red)' : 'var(--gray-200)'}`,
                        background: selectedVariants['size'] === v.value ? '#FEF2F2' : 'white',
                        color: v.available ? 'var(--gray-800)' : 'var(--gray-300)',
                        fontSize: '0.85rem',
                        fontWeight: 700,
                        opacity: v.available ? 1 : 0.4,
                        cursor: v.available ? 'pointer' : 'not-allowed',
                        position: 'relative',
                        transition: 'all var(--transition)',
                      }}
                    >
                      {v.value}
                      {!v.available && (
                        <div style={{
                          position: 'absolute',
                          inset: 0,
                          display: 'flex',
                          alignItems: 'center',
                          justifyContent: 'center',
                        }}>
                          <div style={{
                            width: '130%',
                            height: '2px',
                            background: 'var(--gray-300)',
                            transform: 'rotate(-45deg)',
                          }} />
                        </div>
                      )}
                    </button>
                  ))}
                </div>
              </div>
            )}

            {/* Quantity & Add to cart */}
            <div style={{ display: 'flex', gap: '1rem', marginBottom: '1rem', alignItems: 'center' }}>
              <div style={{
                display: 'flex',
                alignItems: 'center',
                border: '2px solid var(--gray-200)',
                borderRadius: 'var(--radius-sm)',
                overflow: 'hidden',
              }}>
                <button
                  onClick={() => setQuantity(Math.max(1, quantity - 1))}
                  style={{
                    width: '44px',
                    height: '44px',
                    display: 'flex',
                    alignItems: 'center',
                    justifyContent: 'center',
                    fontSize: '1.2rem',
                    color: 'var(--gray-600)',
                    background: 'var(--gray-50)',
                  }}
                >−</button>
                <span style={{
                  padding: '0 1rem',
                  fontWeight: 700,
                  fontSize: '1rem',
                  minWidth: '40px',
                  textAlign: 'center',
                }}>
                  {quantity}
                </span>
                <button
                  onClick={() => setQuantity(quantity + 1)}
                  style={{
                    width: '44px',
                    height: '44px',
                    display: 'flex',
                    alignItems: 'center',
                    justifyContent: 'center',
                    fontSize: '1.2rem',
                    color: 'var(--gray-600)',
                    background: 'var(--gray-50)',
                  }}
                >+</button>
              </div>

              <button
                className="btn btn-primary btn-lg"
                onClick={handleAddToCart}
                disabled={!product.inStock}
                style={{
                  flex: 1,
                  background: added ? '#10B981' : undefined,
                  borderColor: added ? '#10B981' : undefined,
                  opacity: product.inStock ? 1 : 0.6,
                  transition: 'all 0.3s ease',
                }}
              >
                {added
                  ? (lang === 'mn' ? '✓ Нэмлээ!' : '✓ Added!')
                  : product.inStock
                  ? t(lang, 'addToCart')
                  : t(lang, 'outOfStock')}
              </button>

              <button
                onClick={() => toggleWishlist(product.id)}
                style={{
                  width: '50px',
                  height: '50px',
                  borderRadius: 'var(--radius-sm)',
                  border: '2px solid var(--gray-200)',
                  background: inWishlist ? '#FEF2F2' : 'white',
                  fontSize: '1.3rem',
                  display: 'flex',
                  alignItems: 'center',
                  justifyContent: 'center',
                  flexShrink: 0,
                  transition: 'all var(--transition)',
                }}
              >
                {inWishlist ? '❤️' : '🤍'}
              </button>
            </div>

            {/* Stock info */}
            <div style={{
              display: 'flex',
              alignItems: 'center',
              gap: '0.5rem',
              padding: '0.75rem',
              background: product.inStock ? '#F0FDF4' : '#FEF2F2',
              borderRadius: 'var(--radius-sm)',
              fontSize: '0.85rem',
              fontWeight: 600,
              color: product.inStock ? '#10B981' : 'var(--brand-red)',
            }}>
              <span>{product.inStock ? '✅' : '❌'}</span>
              {product.inStock
                ? (lang === 'mn' ? `${product.stockCount} ширхэг үлдсэн` : `${product.stockCount} left in stock`)
                : t(lang, 'outOfStock')}
            </div>
          </div>
        </div>

        {/* Related products */}
        {related.length > 0 && (
          <section>
            <h2 style={{
              fontFamily: 'var(--font-heading)',
              fontSize: '1.8rem',
              marginBottom: '1.5rem',
            }}>
              {lang === 'mn' ? '🛍️ Төстэй бүтээгдэхүүн' : '🛍️ Related Products'}
            </h2>
            <div className="product-grid">
              {related.map((p) => (
                <ProductCard
                  key={p.id}
                  product={p}
                  onClick={() => onNavigate('product', p)}
                />
              ))}
            </div>
          </section>
        )}
      </div>

      <style>{`
        @media (max-width: 768px) {
          .product-detail-grid { grid-template-columns: 1fr !important; }
        }
      `}</style>
    </main>
  );
}
