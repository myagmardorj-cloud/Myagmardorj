import React from 'react';
import { useStore } from '../store';
import { t } from '../i18n';
import { PRODUCTS, CATEGORIES, formatPrice } from '../lib/data';
import ProductCard from '../components/product/ProductCard';

interface HomePageProps {
  onNavigate: (page: string, data?: unknown) => void;
}

export default function HomePage({ onNavigate }: HomePageProps) {
  const { lang } = useStore();

  const featured = PRODUCTS.filter((p) => p.isFeatured).slice(0, 4);
  const newArrivals = PRODUCTS.filter((p) => p.isNew).slice(0, 4);
  const bestSellers = PRODUCTS.filter((p) => p.isBestSeller).slice(0, 4);

  const catLabels: Record<string, string> = {
    electronics: t(lang, 'electronics'),
    clothing: t(lang, 'clothing'),
    food: t(lang, 'food'),
    beauty: t(lang, 'beauty'),
    sports: t(lang, 'sports'),
    home_decor: t(lang, 'home_decor'),
  };

  return (
    <main>
      {/* Hero */}
      <section style={{
        background: 'linear-gradient(135deg, #1a0a0a 0%, #2d0f0f 40%, #1a0a0a 100%)',
        padding: '5rem 0',
        position: 'relative',
        overflow: 'hidden',
      }}>
        {/* Decorative circles */}
        {[...Array(3)].map((_, i) => (
          <div key={i} style={{
            position: 'absolute',
            borderRadius: '50%',
            background: `radial-gradient(circle, rgba(230,57,70,${0.15 - i * 0.04}) 0%, transparent 70%)`,
            width: `${300 + i * 150}px`,
            height: `${300 + i * 150}px`,
            top: `${-50 + i * 30}px`,
            right: `${-100 + i * 20}px`,
          }} />
        ))}

        <div className="container" style={{ position: 'relative', zIndex: 1 }}>
          <div style={{
            display: 'grid',
            gridTemplateColumns: '1fr 1fr',
            gap: '3rem',
            alignItems: 'center',
          }}>
            {/* Text */}
            <div className="animate-fade-in">
              <div className="badge badge-red" style={{ marginBottom: '1.5rem', fontSize: '0.78rem' }}>
                {lang === 'mn' ? '🎉 Шинэ бүтээгдэхүүн нэмэгдлээ' : '🎉 New products added'}
              </div>
              <h1 style={{
                fontFamily: 'var(--font-heading)',
                fontSize: 'clamp(2rem, 4vw, 3.2rem)',
                fontWeight: 800,
                color: 'white',
                lineHeight: 1.1,
                marginBottom: '1.25rem',
              }}>
                {t(lang, 'heroTitle')}
              </h1>
              <p style={{
                color: 'rgba(255,255,255,0.7)',
                fontSize: '1.05rem',
                lineHeight: 1.7,
                marginBottom: '2rem',
                maxWidth: '440px',
              }}>
                {t(lang, 'heroSubtitle')}
              </p>
              <div style={{ display: 'flex', gap: '1rem', flexWrap: 'wrap' }}>
                <button
                  className="btn btn-primary btn-lg"
                  onClick={() => onNavigate('shop')}
                  style={{ boxShadow: '0 8px 24px rgba(230, 57, 70, 0.4)' }}
                >
                  {t(lang, 'shopNow')} →
                </button>
                <button
                  className="btn btn-lg"
                  onClick={() => onNavigate('shop')}
                  style={{
                    background: 'rgba(255,255,255,0.1)',
                    color: 'white',
                    border: '2px solid rgba(255,255,255,0.2)',
                  }}
                >
                  {t(lang, 'learnMore')}
                </button>
              </div>

              {/* Stats */}
              <div style={{
                display: 'flex',
                gap: '2rem',
                marginTop: '3rem',
                paddingTop: '2rem',
                borderTop: '1px solid rgba(255,255,255,0.1)',
              }}>
                {[
                  { val: '10,000+', label: lang === 'mn' ? 'Бүтээгдэхүүн' : 'Products' },
                  { val: '50,000+', label: lang === 'mn' ? 'Харилцагч' : 'Customers' },
                  { val: '4.8★', label: lang === 'mn' ? 'Үнэлгээ' : 'Rating' },
                ].map((stat) => (
                  <div key={stat.val}>
                    <p style={{ color: 'var(--brand-gold)', fontWeight: 800, fontSize: '1.4rem', fontFamily: 'var(--font-heading)' }}>
                      {stat.val}
                    </p>
                    <p style={{ color: 'rgba(255,255,255,0.5)', fontSize: '0.82rem' }}>{stat.label}</p>
                  </div>
                ))}
              </div>
            </div>

            {/* Hero image grid */}
            <div style={{
              display: 'grid',
              gridTemplateColumns: '1fr 1fr',
              gap: '0.75rem',
            }}>
              {featured.slice(0, 4).map((p, i) => (
                <div
                  key={p.id}
                  onClick={() => onNavigate('product', p)}
                  style={{
                    borderRadius: 'var(--radius)',
                    overflow: 'hidden',
                    cursor: 'pointer',
                    aspectRatio: i === 0 ? '1/1.2' : '1',
                    gridRow: i === 0 ? 'span 2' : 'span 1',
                    position: 'relative',
                  }}
                >
                  <img
                    src={p.images[0]}
                    alt={p.name[lang]}
                    style={{
                      width: '100%',
                      height: '100%',
                      objectFit: 'cover',
                      transition: 'transform 0.4s ease',
                    }}
                    onMouseOver={(e) => (e.currentTarget.style.transform = 'scale(1.06)')}
                    onMouseOut={(e) => (e.currentTarget.style.transform = 'scale(1)')}
                  />
                  <div style={{
                    position: 'absolute',
                    bottom: 0,
                    left: 0,
                    right: 0,
                    padding: '1rem',
                    background: 'linear-gradient(to top, rgba(0,0,0,0.8) 0%, transparent 100%)',
                  }}>
                    <p style={{ color: 'white', fontSize: '0.78rem', fontWeight: 700 }}>
                      {formatPrice(p.price)}
                    </p>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* @media mobile override */}
        <style>{`
          @media (max-width: 768px) {
            .hero-grid { grid-template-columns: 1fr !important; }
            .hero-img-grid { display: none !important; }
          }
        `}</style>
      </section>

      {/* Categories */}
      <section style={{ padding: '3rem 0', background: 'white' }}>
        <div className="container">
          <h2 style={{
            fontFamily: 'var(--font-heading)',
            fontSize: '1.8rem',
            marginBottom: '1.5rem',
            color: 'var(--gray-900)',
          }}>
            {t(lang, 'categories')}
          </h2>
          <div style={{
            display: 'flex',
            gap: '1rem',
            overflowX: 'auto',
            paddingBottom: '0.5rem',
          }}>
            {CATEGORIES.map((cat) => (
              <button
                key={cat.id}
                onClick={() => onNavigate('shop', { category: cat.id })}
                style={{
                  flexShrink: 0,
                  display: 'flex',
                  flexDirection: 'column',
                  alignItems: 'center',
                  gap: '0.5rem',
                  padding: '1.25rem 1.5rem',
                  background: 'var(--gray-50)',
                  borderRadius: 'var(--radius)',
                  border: '2px solid transparent',
                  minWidth: '100px',
                  transition: 'all var(--transition)',
                }}
                onMouseOver={(e) => {
                  (e.currentTarget as HTMLButtonElement).style.borderColor = cat.color;
                  (e.currentTarget as HTMLButtonElement).style.background = `${cat.color}15`;
                }}
                onMouseOut={(e) => {
                  (e.currentTarget as HTMLButtonElement).style.borderColor = 'transparent';
                  (e.currentTarget as HTMLButtonElement).style.background = 'var(--gray-50)';
                }}
              >
                <span style={{ fontSize: '2rem' }}>{cat.icon}</span>
                <span style={{ fontSize: '0.8rem', fontWeight: 600, color: 'var(--gray-700)' }}>
                  {catLabels[cat.id]}
                </span>
              </button>
            ))}
          </div>
        </div>
      </section>

      {/* Featured Products */}
      <section style={{ padding: '3rem 0' }}>
        <div className="container">
          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '1.5rem' }}>
            <h2 style={{ fontFamily: 'var(--font-heading)', fontSize: '1.8rem' }}>
              ⭐ {t(lang, 'featured')}
            </h2>
            <button className="btn btn-ghost btn-sm" onClick={() => onNavigate('shop')}>
              {t(lang, 'viewAll')} →
            </button>
          </div>
          <div className="product-grid">
            {featured.map((p) => (
              <ProductCard
                key={p.id}
                product={p}
                onClick={() => onNavigate('product', p)}
              />
            ))}
          </div>
        </div>
      </section>

      {/* Promo Banner */}
      <section style={{
        margin: '0 0 3rem',
        background: 'linear-gradient(135deg, var(--brand-red) 0%, #C1121F 100%)',
        padding: '3rem',
        textAlign: 'center',
        color: 'white',
      }}>
        <h2 style={{
          fontFamily: 'var(--font-heading)',
          fontSize: 'clamp(1.5rem, 3vw, 2.5rem)',
          marginBottom: '0.5rem',
        }}>
          {lang === 'mn' ? '🎁 Хавар хямдрал 30%-иас дээш!' : '🎁 Spring Sale Up to 30% Off!'}
        </h2>
        <p style={{ opacity: 0.9, marginBottom: '1.5rem', fontSize: '1.05rem' }}>
          {lang === 'mn'
            ? 'Хязгаарлагдмал хугацааны санал. Алдахгүй байгаарай!'
            : 'Limited time offer. Don\'t miss out!'}
        </p>
        <button
          className="btn btn-lg"
          onClick={() => onNavigate('shop')}
          style={{ background: 'white', color: 'var(--brand-red)', fontWeight: 800 }}
        >
          {t(lang, 'shopNow')}
        </button>
      </section>

      {/* New Arrivals */}
      <section style={{ padding: '0 0 3rem' }}>
        <div className="container">
          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '1.5rem' }}>
            <h2 style={{ fontFamily: 'var(--font-heading)', fontSize: '1.8rem' }}>
              🆕 {t(lang, 'newArrivals')}
            </h2>
            <button className="btn btn-ghost btn-sm" onClick={() => onNavigate('shop', { new: true })}>
              {t(lang, 'viewAll')} →
            </button>
          </div>
          <div className="product-grid">
            {newArrivals.map((p) => (
              <ProductCard
                key={p.id}
                product={p}
                onClick={() => onNavigate('product', p)}
              />
            ))}
          </div>
        </div>
      </section>

      {/* Best Sellers */}
      <section style={{ padding: '0 0 3rem', background: 'white' }}>
        <div className="container" style={{ paddingTop: '3rem', paddingBottom: '3rem' }}>
          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '1.5rem' }}>
            <h2 style={{ fontFamily: 'var(--font-heading)', fontSize: '1.8rem' }}>
              🔥 {t(lang, 'bestSellers')}
            </h2>
            <button className="btn btn-ghost btn-sm" onClick={() => onNavigate('shop')}>
              {t(lang, 'viewAll')} →
            </button>
          </div>
          <div className="product-grid">
            {bestSellers.map((p) => (
              <ProductCard
                key={p.id}
                product={p}
                onClick={() => onNavigate('product', p)}
              />
            ))}
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer style={{
        background: 'var(--gray-900)',
        color: 'white',
        padding: '4rem 0 2rem',
      }}>
        <div className="container">
          <div style={{
            display: 'grid',
            gridTemplateColumns: 'repeat(auto-fit, minmax(200px, 1fr))',
            gap: '2.5rem',
            marginBottom: '3rem',
          }}>
            {/* Brand */}
            <div>
              <div style={{
                fontFamily: 'var(--font-heading)',
                fontSize: '1.8rem',
                fontWeight: 800,
                color: 'var(--brand-red)',
                marginBottom: '1rem',
              }}>
                Zarlaa<span style={{ color: 'var(--brand-gold)' }}>.mn</span>
              </div>
              <p style={{ color: 'rgba(255,255,255,0.5)', fontSize: '0.88rem', lineHeight: 1.7 }}>
                {lang === 'mn'
                  ? 'Монголын хамгийн том онлайн дэлгүүр. Чанартай бүтээгдэхүүн, хурдан хүргэлт.'
                  : "Mongolia's largest online store. Quality products, fast delivery."}
              </p>
            </div>

            {/* Links */}
            {[
              {
                title: lang === 'mn' ? 'Компани' : 'Company',
                links: [
                  { label: t(lang, 'aboutUs'), href: '#' },
                  { label: t(lang, 'contact'), href: '#' },
                  { label: lang === 'mn' ? 'Карьер' : 'Careers', href: '#' },
                  { label: lang === 'mn' ? 'Блог' : 'Blog', href: '#' },
                ],
              },
              {
                title: lang === 'mn' ? 'Туслах' : 'Support',
                links: [
                  { label: lang === 'mn' ? 'Захиалга хянах' : 'Track Order', href: '#' },
                  { label: lang === 'mn' ? 'Буцаалт' : 'Returns', href: '#' },
                  { label: lang === 'mn' ? 'Хүргэлт' : 'Shipping', href: '#' },
                  { label: lang === 'mn' ? 'Тусламж' : 'Help Center', href: '#' },
                ],
              },
              {
                title: lang === 'mn' ? 'Хуулийн' : 'Legal',
                links: [
                  { label: t(lang, 'privacy'), href: '#' },
                  { label: t(lang, 'terms'), href: '#' },
                  { label: lang === 'mn' ? 'Күүки бодлого' : 'Cookie Policy', href: '#' },
                ],
              },
            ].map((group) => (
              <div key={group.title}>
                <h4 style={{ fontWeight: 700, marginBottom: '1rem', fontSize: '0.9rem', color: 'rgba(255,255,255,0.8)' }}>
                  {group.title}
                </h4>
                <div style={{ display: 'flex', flexDirection: 'column', gap: '0.6rem' }}>
                  {group.links.map((link) => (
                    <a
                      key={link.label}
                      href={link.href}
                      style={{
                        color: 'rgba(255,255,255,0.45)',
                        fontSize: '0.85rem',
                        transition: 'color var(--transition)',
                      }}
                      onMouseOver={(e) => (e.currentTarget.style.color = 'white')}
                      onMouseOut={(e) => (e.currentTarget.style.color = 'rgba(255,255,255,0.45)')}
                    >
                      {link.label}
                    </a>
                  ))}
                </div>
              </div>
            ))}

            {/* Newsletter */}
            <div>
              <h4 style={{ fontWeight: 700, marginBottom: '1rem', fontSize: '0.9rem', color: 'rgba(255,255,255,0.8)' }}>
                {t(lang, 'newsletter')}
              </h4>
              <p style={{ color: 'rgba(255,255,255,0.45)', fontSize: '0.85rem', marginBottom: '1rem', lineHeight: 1.6 }}>
                {lang === 'mn' ? 'Хямдрал, шинэ бүтээгдэхүүний мэдэгдэл авна уу.' : 'Get updates on sales and new products.'}
              </p>
              <div style={{ display: 'flex', gap: '0.5rem' }}>
                <input
                  className="input"
                  placeholder={t(lang, 'emailPlaceholder')}
                  style={{
                    background: 'rgba(255,255,255,0.1)',
                    border: '2px solid rgba(255,255,255,0.15)',
                    color: 'white',
                    flex: 1,
                  }}
                />
                <button className="btn btn-primary btn-sm" style={{ flexShrink: 0 }}>
                  →
                </button>
              </div>
            </div>
          </div>

          <div style={{
            borderTop: '1px solid rgba(255,255,255,0.1)',
            paddingTop: '2rem',
            display: 'flex',
            justifyContent: 'space-between',
            alignItems: 'center',
            flexWrap: 'wrap',
            gap: '1rem',
          }}>
            <p style={{ color: 'rgba(255,255,255,0.35)', fontSize: '0.82rem' }}>
              © 2025 Zarlaa.mn — {lang === 'mn' ? 'Бүх эрх хуулиар хамгаалагдсан' : 'All rights reserved'}
            </p>
            <div style={{ display: 'flex', gap: '1rem' }}>
              {['💳', '📱', '🏦', '💰'].map((icon, i) => (
                <div key={i} style={{
                  padding: '0.4rem 0.8rem',
                  background: 'rgba(255,255,255,0.1)',
                  borderRadius: '6px',
                  fontSize: '1rem',
                }}>
                  {icon}
                </div>
              ))}
            </div>
          </div>
        </div>
      </footer>
    </main>
  );
}
