import React, { useState, useMemo } from 'react';
import { useStore } from '../store';
import { t } from '../i18n';
import { PRODUCTS, CATEGORIES, formatPrice } from '../lib/data';
import ProductCard from '../components/product/ProductCard';
import { Category } from '../types';

interface ShopPageProps {
  onNavigate: (page: string, data?: unknown) => void;
  initialCategory?: string;
}

const SORT_OPTIONS = [
  { value: 'featured', mn: 'Онцлох', en: 'Featured' },
  { value: 'price-asc', mn: 'Үнэ ↑', en: 'Price ↑' },
  { value: 'price-desc', mn: 'Үнэ ↓', en: 'Price ↓' },
  { value: 'rating', mn: 'Үнэлгээ', en: 'Rating' },
  { value: 'new', mn: 'Шинэ', en: 'Newest' },
];

export default function ShopPage({ onNavigate, initialCategory }: ShopPageProps) {
  const { lang, searchQuery, setSearchQuery } = useStore();
  const [selectedCategory, setSelectedCategory] = useState<Category | 'all'>(
    (initialCategory as Category) || 'all'
  );
  const [sortBy, setSortBy] = useState('featured');
  const [inStockOnly, setInStockOnly] = useState(false);
  const [priceMax, setPriceMax] = useState(6000000);
  const [sidebarOpen, setSidebarOpen] = useState(false);

  const catLabels: Record<string, string> = {
    all: lang === 'mn' ? 'Бүгд' : 'All',
    electronics: t(lang, 'electronics'),
    clothing: t(lang, 'clothing'),
    food: t(lang, 'food'),
    beauty: t(lang, 'beauty'),
    sports: t(lang, 'sports'),
    home_decor: t(lang, 'home_decor'),
  };

  const filtered = useMemo(() => {
    let products = [...PRODUCTS];

    // Search
    if (searchQuery) {
      const q = searchQuery.toLowerCase();
      products = products.filter(
        (p) =>
          p.name.mn.toLowerCase().includes(q) ||
          p.name.en.toLowerCase().includes(q) ||
          p.brand.toLowerCase().includes(q) ||
          p.tags.some((tag) => tag.toLowerCase().includes(q))
      );
    }

    // Category
    if (selectedCategory !== 'all') {
      products = products.filter((p) => p.category === selectedCategory);
    }

    // Price
    products = products.filter((p) => p.price <= priceMax);

    // In stock
    if (inStockOnly) {
      products = products.filter((p) => p.inStock);
    }

    // Sort
    switch (sortBy) {
      case 'price-asc':
        products.sort((a, b) => a.price - b.price);
        break;
      case 'price-desc':
        products.sort((a, b) => b.price - a.price);
        break;
      case 'rating':
        products.sort((a, b) => b.rating - a.rating);
        break;
      case 'new':
        products.sort((a, b) => (b.isNew ? 1 : 0) - (a.isNew ? 1 : 0));
        break;
      default:
        products.sort((a, b) => (b.isFeatured ? 1 : 0) - (a.isFeatured ? 1 : 0));
    }

    return products;
  }, [searchQuery, selectedCategory, priceMax, inStockOnly, sortBy]);

  return (
    <main style={{ minHeight: '80vh' }}>
      <div className="container" style={{ paddingTop: '2rem', paddingBottom: '4rem' }}>
        {/* Breadcrumb */}
        <div style={{
          display: 'flex',
          alignItems: 'center',
          gap: '0.5rem',
          marginBottom: '1.5rem',
          fontSize: '0.85rem',
          color: 'var(--gray-500)',
        }}>
          <button onClick={() => onNavigate('home')} style={{ color: 'var(--brand-red)', fontWeight: 600 }}>
            {t(lang, 'home')}
          </button>
          <span>›</span>
          <span>{t(lang, 'shop')}</span>
        </div>

        <div style={{ display: 'grid', gridTemplateColumns: '240px 1fr', gap: '2rem', alignItems: 'start' }}>
          {/* Sidebar */}
          <aside style={{
            background: 'white',
            borderRadius: 'var(--radius)',
            padding: '1.5rem',
            boxShadow: 'var(--shadow-sm)',
            position: 'sticky',
            top: '80px',
          }}>
            <h3 style={{
              fontFamily: 'var(--font-heading)',
              fontSize: '1.1rem',
              marginBottom: '1.5rem',
              paddingBottom: '0.75rem',
              borderBottom: '2px solid var(--gray-100)',
            }}>
              {t(lang, 'filter')}
            </h3>

            {/* Categories */}
            <div style={{ marginBottom: '1.5rem' }}>
              <h4 style={{ fontSize: '0.85rem', fontWeight: 700, color: 'var(--gray-500)', marginBottom: '0.75rem', textTransform: 'uppercase', letterSpacing: '0.05em' }}>
                {t(lang, 'categories')}
              </h4>
              <div style={{ display: 'flex', flexDirection: 'column', gap: '0.25rem' }}>
                {['all', ...Object.keys(CATEGORIES.reduce((acc, c) => ({ ...acc, [c.id]: true }), {}))].map((cat) => {
                  const catObj = CATEGORIES.find((c) => c.id === cat);
                  return (
                    <button
                      key={cat}
                      onClick={() => setSelectedCategory(cat as Category | 'all')}
                      style={{
                        display: 'flex',
                        alignItems: 'center',
                        gap: '0.5rem',
                        padding: '0.5rem 0.75rem',
                        borderRadius: 'var(--radius-sm)',
                        background: selectedCategory === cat ? '#FEF2F2' : 'transparent',
                        color: selectedCategory === cat ? 'var(--brand-red)' : 'var(--gray-600)',
                        fontWeight: selectedCategory === cat ? 700 : 400,
                        fontSize: '0.88rem',
                        textAlign: 'left',
                        transition: 'all var(--transition)',
                      }}
                    >
                      {catObj && <span>{catObj.icon}</span>}
                      {catLabels[cat]}
                    </button>
                  );
                })}
              </div>
            </div>

            {/* Price range */}
            <div style={{ marginBottom: '1.5rem' }}>
              <h4 style={{ fontSize: '0.85rem', fontWeight: 700, color: 'var(--gray-500)', marginBottom: '0.75rem', textTransform: 'uppercase', letterSpacing: '0.05em' }}>
                {t(lang, 'price')}
              </h4>
              <input
                type="range"
                min="0"
                max="6000000"
                step="50000"
                value={priceMax}
                onChange={(e) => setPriceMax(Number(e.target.value))}
                style={{ width: '100%', accentColor: 'var(--brand-red)' }}
              />
              <div style={{
                display: 'flex',
                justifyContent: 'space-between',
                marginTop: '0.5rem',
                fontSize: '0.8rem',
                color: 'var(--gray-500)',
              }}>
                <span>0₮</span>
                <span style={{ fontWeight: 700, color: 'var(--brand-red)' }}>{formatPrice(priceMax)}</span>
              </div>
            </div>

            {/* In stock only */}
            <div>
              <label style={{
                display: 'flex',
                alignItems: 'center',
                gap: '0.75rem',
                cursor: 'pointer',
                fontSize: '0.88rem',
                color: 'var(--gray-700)',
              }}>
                <input
                  type="checkbox"
                  checked={inStockOnly}
                  onChange={(e) => setInStockOnly(e.target.checked)}
                  style={{ accentColor: 'var(--brand-red)', width: '16px', height: '16px' }}
                />
                {lang === 'mn' ? 'Байгаа бараа' : 'In Stock Only'}
              </label>
            </div>

            {/* Clear filters */}
            <button
              className="btn btn-ghost btn-sm"
              onClick={() => {
                setSelectedCategory('all');
                setPriceMax(6000000);
                setInStockOnly(false);
                setSearchQuery('');
              }}
              style={{ marginTop: '1.5rem', width: '100%', color: 'var(--gray-500)' }}
            >
              {t(lang, 'clear')} ✕
            </button>
          </aside>

          {/* Products area */}
          <div>
            {/* Toolbar */}
            <div style={{
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'space-between',
              marginBottom: '1.5rem',
              background: 'white',
              padding: '0.75rem 1rem',
              borderRadius: 'var(--radius-sm)',
              boxShadow: 'var(--shadow-sm)',
            }}>
              <span style={{ fontSize: '0.88rem', color: 'var(--gray-500)' }}>
                <strong style={{ color: 'var(--gray-900)' }}>{filtered.length}</strong>{' '}
                {lang === 'mn' ? 'бүтээгдэхүүн' : 'products'}
                {searchQuery && ` — "${searchQuery}"`}
              </span>
              <div style={{ display: 'flex', alignItems: 'center', gap: '0.5rem' }}>
                <span style={{ fontSize: '0.85rem', color: 'var(--gray-500)', fontWeight: 500 }}>
                  {t(lang, 'sort')}:
                </span>
                <select
                  className="input select"
                  style={{ width: 'auto', padding: '0.4rem 2rem 0.4rem 0.75rem', fontSize: '0.85rem' }}
                  value={sortBy}
                  onChange={(e) => setSortBy(e.target.value)}
                >
                  {SORT_OPTIONS.map((opt) => (
                    <option key={opt.value} value={opt.value}>
                      {lang === 'mn' ? opt.mn : opt.en}
                    </option>
                  ))}
                </select>
              </div>
            </div>

            {/* Products */}
            {filtered.length === 0 ? (
              <div style={{
                textAlign: 'center',
                padding: '4rem',
                background: 'white',
                borderRadius: 'var(--radius)',
              }}>
                <div style={{ fontSize: '4rem', marginBottom: '1rem' }}>🔍</div>
                <h3 style={{ fontFamily: 'var(--font-heading)', marginBottom: '0.5rem' }}>
                  {lang === 'mn' ? 'Бүтээгдэхүүн олдсонгүй' : 'No products found'}
                </h3>
                <p style={{ color: 'var(--gray-500)', marginBottom: '1.5rem' }}>
                  {lang === 'mn' ? 'Өөр хайлт оруулна уу' : 'Try a different search'}
                </p>
                <button
                  className="btn btn-primary btn-sm"
                  onClick={() => {
                    setSelectedCategory('all');
                    setSearchQuery('');
                  }}
                >
                  {t(lang, 'clear')}
                </button>
              </div>
            ) : (
              <div className="product-grid">
                {filtered.map((p) => (
                  <ProductCard
                    key={p.id}
                    product={p}
                    onClick={() => onNavigate('product', p)}
                  />
                ))}
              </div>
            )}
          </div>
        </div>
      </div>

      {/* Mobile responsive */}
      <style>{`
        @media (max-width: 900px) {
          .shop-layout { grid-template-columns: 1fr !important; }
        }
      `}</style>
    </main>
  );
}
