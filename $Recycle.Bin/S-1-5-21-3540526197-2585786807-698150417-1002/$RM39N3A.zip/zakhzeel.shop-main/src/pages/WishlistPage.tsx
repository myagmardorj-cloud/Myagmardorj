import React from 'react';
import { useStore } from '../store';
import { t } from '../i18n';
import { PRODUCTS } from '../lib/data';
import ProductCard from '../components/product/ProductCard';

interface WishlistPageProps {
  onNavigate: (page: string, data?: unknown) => void;
}

export default function WishlistPage({ onNavigate }: WishlistPageProps) {
  const { lang, wishlist } = useStore();
  const items = PRODUCTS.filter((p) => wishlist.includes(p.id));

  return (
    <main style={{ minHeight: '70vh' }}>
      <div className="container" style={{ paddingTop: '2rem', paddingBottom: '4rem' }}>
        <h1 style={{
          fontFamily: 'var(--font-heading)',
          fontSize: '2rem',
          marginBottom: '0.5rem',
        }}>
          {t(lang, 'wishlist')} ❤️
        </h1>
        <p style={{ color: 'var(--gray-500)', marginBottom: '2rem', fontSize: '0.9rem' }}>
          {items.length} {lang === 'mn' ? 'бүтээгдэхүүн хадгалагдсан' : 'products saved'}
        </p>

        {items.length === 0 ? (
          <div style={{
            textAlign: 'center',
            padding: '5rem 2rem',
            background: 'white',
            borderRadius: 'var(--radius)',
          }}>
            <div style={{ fontSize: '5rem', marginBottom: '1rem' }}>🤍</div>
            <h2 style={{ fontFamily: 'var(--font-heading)', marginBottom: '0.75rem' }}>
              {lang === 'mn' ? 'Хадгалсан бараа байхгүй' : 'No saved items yet'}
            </h2>
            <p style={{ color: 'var(--gray-500)', marginBottom: '2rem' }}>
              {lang === 'mn'
                ? 'Бүтээгдэхүүн дээрх ❤️ дарж хадгалаарай'
                : 'Press ❤️ on any product to save it here'}
            </p>
            <button className="btn btn-primary" onClick={() => onNavigate('shop')}>
              {t(lang, 'shop')} →
            </button>
          </div>
        ) : (
          <div className="product-grid">
            {items.map((p) => (
              <ProductCard
                key={p.id}
                product={p}
                onClick={() => onNavigate('product', p)}
              />
            ))}
          </div>
        )}
      </div>
    </main>
  );
}
