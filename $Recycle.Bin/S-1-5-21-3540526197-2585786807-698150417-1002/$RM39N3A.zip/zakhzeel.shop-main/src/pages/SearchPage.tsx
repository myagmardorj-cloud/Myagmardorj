import React, { useMemo } from 'react';
import { useStore } from '../store';
import { PRODUCTS } from '../lib/data';
import ProductCard from '../components/product/ProductCard';

interface SearchPageProps {
  onNavigate: (page: string, data?: unknown) => void;
}

export default function SearchPage({ onNavigate }: SearchPageProps) {
  const { lang, searchQuery, setSearchQuery } = useStore();

  const results = useMemo(() => {
    if (!searchQuery.trim()) return [];
    const q = searchQuery.toLowerCase();
    return PRODUCTS.filter(
      (p) =>
        p.name.mn.toLowerCase().includes(q) ||
        p.name.en.toLowerCase().includes(q) ||
        p.brand.toLowerCase().includes(q) ||
        p.tags.some((t) => t.toLowerCase().includes(q)) ||
        p.description.mn.toLowerCase().includes(q)
    );
  }, [searchQuery]);

  return (
    <main style={{ minHeight: '70vh' }}>
      <div className="container" style={{ paddingTop: '2rem', paddingBottom: '4rem' }}>
        <div style={{ marginBottom: '2rem' }}>
          <h1 style={{ fontFamily: 'var(--font-heading)', fontSize: '1.6rem', marginBottom: '0.5rem' }}>
            {lang === 'mn' ? '🔍 Хайлтын үр дүн' : '🔍 Search Results'}
          </h1>
          {searchQuery && (
            <p style={{ color: 'var(--gray-500)' }}>
              {lang === 'mn' ? `"${searchQuery}" — ` : `"${searchQuery}" — `}
              <strong>{results.length}</strong> {lang === 'mn' ? 'бүтээгдэхүүн олдлоо' : 'products found'}
            </p>
          )}
        </div>

        {/* Search bar */}
        <div style={{ position: 'relative', maxWidth: '500px', marginBottom: '2rem' }}>
          <span style={{
            position: 'absolute', left: '1rem', top: '50%',
            transform: 'translateY(-50%)', color: 'var(--gray-400)', pointerEvents: 'none',
          }}>🔍</span>
          <input
            className="input"
            style={{ paddingLeft: '2.5rem', fontSize: '1rem' }}
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            autoFocus
            placeholder={lang === 'mn' ? 'Хайх...' : 'Search...'}
          />
          {searchQuery && (
            <button
              onClick={() => setSearchQuery('')}
              style={{
                position: 'absolute', right: '0.75rem', top: '50%',
                transform: 'translateY(-50%)', color: 'var(--gray-400)', fontSize: '1rem',
              }}
            >✕</button>
          )}
        </div>

        {results.length === 0 && searchQuery ? (
          <div style={{
            textAlign: 'center',
            padding: '4rem 2rem',
            background: 'white',
            borderRadius: 'var(--radius)',
          }}>
            <div style={{ fontSize: '4rem', marginBottom: '1rem' }}>😕</div>
            <h2 style={{ fontFamily: 'var(--font-heading)', marginBottom: '0.75rem' }}>
              {lang === 'mn' ? 'Бүтээгдэхүүн олдсонгүй' : 'No products found'}
            </h2>
            <p style={{ color: 'var(--gray-500)' }}>
              {lang === 'mn' ? 'Өөр нэрээр хайж үзнэ үү' : 'Try a different search term'}
            </p>
          </div>
        ) : results.length > 0 ? (
          <div className="product-grid">
            {results.map((p) => (
              <ProductCard key={p.id} product={p} onClick={() => onNavigate('product', p)} />
            ))}
          </div>
        ) : (
          <div style={{
            textAlign: 'center',
            padding: '4rem 2rem',
            color: 'var(--gray-400)',
          }}>
            <div style={{ fontSize: '4rem', marginBottom: '1rem' }}>🔍</div>
            <p>{lang === 'mn' ? 'Хайх зүйлээ оруулна уу' : 'Enter a search term'}</p>
          </div>
        )}
      </div>
    </main>
  );
}
