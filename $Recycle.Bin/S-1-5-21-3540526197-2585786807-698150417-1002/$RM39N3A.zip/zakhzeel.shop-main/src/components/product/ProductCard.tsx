import React, { useState } from 'react';
import { Product } from '../../types';
import { useStore } from '../../store';
import { t } from '../../i18n';
import { formatPrice, getDiscountPercent } from '../../lib/data';

interface ProductCardProps {
  product: Product;
  onClick?: () => void;
}

export default function ProductCard({ product, onClick }: ProductCardProps) {
  const { lang, addToCart, toggleWishlist, isInWishlist, setCartOpen } = useStore();
  const [imgLoaded, setImgLoaded] = useState(false);
  const [adding, setAdding] = useState(false);
  const inWishlist = isInWishlist(product.id);
  const discount = product.originalPrice
    ? getDiscountPercent(product.price, product.originalPrice)
    : 0;

  const handleAddToCart = (e: React.MouseEvent) => {
    e.stopPropagation();
    if (!product.inStock) return;
    setAdding(true);
    addToCart(product);
    setTimeout(() => {
      setAdding(false);
      setCartOpen(true);
    }, 600);
  };

  const handleWishlist = (e: React.MouseEvent) => {
    e.stopPropagation();
    toggleWishlist(product.id);
  };

  return (
    <div
      className="card"
      onClick={onClick}
      style={{ cursor: 'pointer', position: 'relative' }}
    >
      {/* Image */}
      <div style={{
        position: 'relative',
        aspectRatio: '1',
        overflow: 'hidden',
        background: 'var(--gray-100)',
      }}>
        {!imgLoaded && (
          <div style={{
            position: 'absolute',
            inset: 0,
            background: 'linear-gradient(90deg, var(--gray-100) 0%, var(--gray-200) 50%, var(--gray-100) 100%)',
            backgroundSize: '200% 100%',
            animation: 'shimmer 1.5s infinite',
          }} />
        )}
        <img
          src={product.images[0]}
          alt={product.name[lang]}
          style={{
            width: '100%',
            height: '100%',
            objectFit: 'cover',
            opacity: imgLoaded ? 1 : 0,
            transition: 'opacity 0.3s ease, transform 0.4s ease',
          }}
          onLoad={() => setImgLoaded(true)}
          onMouseOver={(e) => {
            (e.currentTarget as HTMLImageElement).style.transform = 'scale(1.05)';
          }}
          onMouseOut={(e) => {
            (e.currentTarget as HTMLImageElement).style.transform = 'scale(1)';
          }}
        />

        {/* Badges */}
        <div style={{
          position: 'absolute',
          top: '0.75rem',
          left: '0.75rem',
          display: 'flex',
          flexDirection: 'column',
          gap: '0.3rem',
        }}>
          {discount > 0 && (
            <span className="badge badge-red">-{discount}%</span>
          )}
          {product.isNew && (
            <span className="badge badge-green">
              {lang === 'mn' ? 'Шинэ' : 'New'}
            </span>
          )}
          {product.isBestSeller && (
            <span className="badge badge-gold">
              {lang === 'mn' ? 'Шилдэг' : 'Top'}
            </span>
          )}
        </div>

        {/* Wishlist button */}
        <button
          onClick={handleWishlist}
          style={{
            position: 'absolute',
            top: '0.75rem',
            right: '0.75rem',
            width: '36px',
            height: '36px',
            borderRadius: '50%',
            background: 'rgba(255,255,255,0.9)',
            backdropFilter: 'blur(4px)',
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'center',
            fontSize: '1rem',
            boxShadow: 'var(--shadow-sm)',
            transition: 'all var(--transition)',
            transform: inWishlist ? 'scale(1.1)' : 'scale(1)',
          }}
        >
          {inWishlist ? '❤️' : '🤍'}
        </button>

        {/* Out of stock overlay */}
        {!product.inStock && (
          <div style={{
            position: 'absolute',
            inset: 0,
            background: 'rgba(255,255,255,0.7)',
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'center',
          }}>
            <span className="badge badge-gray" style={{ fontSize: '0.85rem', padding: '0.4rem 0.8rem' }}>
              {t(lang, 'outOfStock')}
            </span>
          </div>
        )}
      </div>

      {/* Info */}
      <div style={{ padding: '1rem' }}>
        <p style={{
          fontSize: '0.75rem',
          color: 'var(--gray-400)',
          textTransform: 'uppercase',
          letterSpacing: '0.05em',
          fontWeight: 600,
          marginBottom: '0.3rem',
        }}>
          {product.brand}
        </p>
        <h3 style={{
          fontSize: '0.95rem',
          fontWeight: 600,
          fontFamily: 'var(--font-body)',
          marginBottom: '0.5rem',
          overflow: 'hidden',
          display: '-webkit-box',
          WebkitLineClamp: 2,
          WebkitBoxOrient: 'vertical',
          lineHeight: 1.4,
          minHeight: '2.8em',
          color: 'var(--gray-800)',
        }}>
          {product.name[lang]}
        </h3>

        {/* Rating */}
        <div style={{
          display: 'flex',
          alignItems: 'center',
          gap: '0.4rem',
          marginBottom: '0.75rem',
        }}>
          <div className="stars">
            {[1,2,3,4,5].map((s) => (
              <span key={s} style={{ opacity: s <= Math.round(product.rating) ? 1 : 0.25 }}>★</span>
            ))}
          </div>
          <span style={{ fontSize: '0.78rem', color: 'var(--gray-500)' }}>
            ({product.reviewCount})
          </span>
        </div>

        {/* Price */}
        <div style={{
          display: 'flex',
          alignItems: 'baseline',
          gap: '0.5rem',
          marginBottom: '0.75rem',
        }}>
          <span style={{
            fontWeight: 800,
            fontSize: '1.05rem',
            color: 'var(--brand-red)',
          }}>
            {formatPrice(product.price)}
          </span>
          {product.originalPrice && (
            <span style={{
              fontSize: '0.82rem',
              color: 'var(--gray-400)',
              textDecoration: 'line-through',
            }}>
              {formatPrice(product.originalPrice)}
            </span>
          )}
        </div>

        {/* Add to cart */}
        <button
          className={`btn btn-primary`}
          onClick={handleAddToCart}
          disabled={!product.inStock}
          style={{
            width: '100%',
            opacity: product.inStock ? 1 : 0.5,
            background: adding ? '#10B981' : undefined,
            borderColor: adding ? '#10B981' : undefined,
            transition: 'all 0.3s ease',
          }}
        >
          {adding ? (lang === 'mn' ? '✓ Нэмлээ!' : '✓ Added!') : (
            product.inStock ? t(lang, 'addToCart') : t(lang, 'outOfStock')
          )}
        </button>
      </div>

      <style>{`
        @keyframes shimmer {
          0% { background-position: -200% 0; }
          100% { background-position: 200% 0; }
        }
      `}</style>
    </div>
  );
}
