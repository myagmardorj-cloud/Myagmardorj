import React, { useEffect, useState } from 'react';

interface Toast {
  id: string;
  message: string;
  type: 'success' | 'error' | 'info';
}

let addToastFn: ((msg: string, type?: Toast['type']) => void) | null = null;

export function toast(message: string, type: Toast['type'] = 'success') {
  addToastFn?.(message, type);
}

export default function ToastContainer() {
  const [toasts, setToasts] = useState<Toast[]>([]);

  useEffect(() => {
    addToastFn = (message, type = 'success') => {
      const id = Math.random().toString(36).slice(2);
      setToasts((t) => [...t, { id, message, type }]);
      setTimeout(() => {
        setToasts((t) => t.filter((x) => x.id !== id));
      }, 3000);
    };
    return () => { addToastFn = null; };
  }, []);

  const colors = {
    success: '#10B981',
    error: 'var(--brand-red)',
    info: '#3B82F6',
  };

  const icons = { success: '✅', error: '❌', info: 'ℹ️' };

  return (
    <div style={{
      position: 'fixed',
      bottom: '1.5rem',
      left: '50%',
      transform: 'translateX(-50%)',
      zIndex: 999,
      display: 'flex',
      flexDirection: 'column',
      gap: '0.5rem',
      alignItems: 'center',
      pointerEvents: 'none',
    }}>
      {toasts.map((t) => (
        <div
          key={t.id}
          className="animate-fade-in"
          style={{
            display: 'flex',
            alignItems: 'center',
            gap: '0.75rem',
            padding: '0.75rem 1.25rem',
            background: 'white',
            borderRadius: '100px',
            boxShadow: '0 8px 24px rgba(0,0,0,0.15)',
            borderLeft: `4px solid ${colors[t.type]}`,
            fontWeight: 600,
            fontSize: '0.9rem',
            whiteSpace: 'nowrap',
          }}
        >
          <span>{icons[t.type]}</span>
          <span>{t.message}</span>
        </div>
      ))}
    </div>
  );
}
