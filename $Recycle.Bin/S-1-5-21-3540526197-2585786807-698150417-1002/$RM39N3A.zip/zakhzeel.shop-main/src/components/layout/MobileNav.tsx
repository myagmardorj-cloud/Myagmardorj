import React from 'react';
import { useStore } from '../../store';
import { t } from '../../i18n';

interface MobileNavProps {
  onNavigate: (page: string) => void;
  currentPage: string;
}

export default function MobileNav({ onNavigate, currentPage }: MobileNavProps) {
  const { lang, cartCount, wishlist } = useStore();
  const count = cartCount();

  const items = [
    { id: 'home', icon: '🏠', label: t(lang, 'home') },
    { id: 'shop', icon: '🛍️', label: t(lang, 'shop') },
    { id: 'search', icon: '🔍', label: lang === 'mn' ? 'Хайх' : 'Search' },
    { id: 'wishlist', icon: '❤️', label: t(lang, 'wishlist'), badge: wishlist.length },
    { id: 'cart', icon: '🛒', label: t(lang, 'cart'), badge: count },
  ];

  return (
    <nav style={{
      position: 'fixed',
      bottom: 0,
      left: 0,
      right: 0,
      background: 'white',
      borderTop: '1px solid var(--gray-200)',
      display: 'flex',
      zIndex: 80,
      boxShadow: '0 -4px 20px rgba(0,0,0,0.08)',
    }}>
      {items.map((item) => {
        const active = currentPage === item.id;
        return (
          <button
            key={item.id}
            onClick={() => {
              if (item.id === 'cart') {
                useStore.getState().setCartOpen(true);
              } else {
                onNavigate(item.id);
              }
            }}
            style={{
              flex: 1,
              display: 'flex',
              flexDirection: 'column',
              alignItems: 'center',
              gap: '0.2rem',
              padding: '0.6rem 0.25rem',
              position: 'relative',
              color: active ? 'var(--brand-red)' : 'var(--gray-400)',
              transition: 'color var(--transition)',
            }}
          >
            <span style={{ fontSize: '1.25rem', position: 'relative' }}>
              {item.icon}
              {item.badge && item.badge > 0 ? (
                <span style={{
                  position: 'absolute',
                  top: '-6px',
                  right: '-8px',
                  background: 'var(--brand-red)',
                  color: 'white',
                  borderRadius: '100px',
                  minWidth: '16px',
                  height: '16px',
                  fontSize: '0.6rem',
                  fontWeight: 800,
                  display: 'flex',
                  alignItems: 'center',
                  justifyContent: 'center',
                  padding: '0 2px',
                }}>
                  {item.badge}
                </span>
              ) : null}
            </span>
            <span style={{ fontSize: '0.65rem', fontWeight: active ? 700 : 400 }}>
              {item.label}
            </span>
            {active && (
              <div style={{
                position: 'absolute',
                top: 0,
                left: '50%',
                transform: 'translateX(-50%)',
                width: '32px',
                height: '3px',
                background: 'var(--brand-red)',
                borderRadius: '0 0 3px 3px',
              }} />
            )}
          </button>
        );
      })}
    </nav>
  );
}
