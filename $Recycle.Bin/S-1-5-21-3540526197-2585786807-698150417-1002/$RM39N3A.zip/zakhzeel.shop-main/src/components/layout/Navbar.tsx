import React, { useState, useEffect } from 'react';
import { useStore } from '../../store';
import { t } from '../../i18n';

interface NavbarProps {
  onNavigate: (page: string) => void;
  currentPage: string;
}

export default function Navbar({ onNavigate, currentPage }: NavbarProps) {
  const { lang, setLang, cartCount, setCartOpen, cartOpen, searchQuery, setSearchQuery } = useStore();
  const count = cartCount();
  const [scrolled, setScrolled] = useState(false);
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  useEffect(() => {
    const handleScroll = () => setScrolled(window.scrollY > 20);
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const navItems = [
    { id: 'home', label: t(lang, 'home') },
    { id: 'shop', label: t(lang, 'shop') },
    { id: 'wishlist', label: t(lang, 'wishlist') },
  ];

  return (
    <header style={{
      position: 'sticky',
      top: 0,
      zIndex: 90,
      background: scrolled ? 'rgba(255,255,255,0.97)' : 'white',
      backdropFilter: 'blur(12px)',
      borderBottom: `1px solid ${scrolled ? 'var(--gray-200)' : 'transparent'}`,
      boxShadow: scrolled ? 'var(--shadow-sm)' : 'none',
      transition: 'all 0.3s ease',
    }}>
      {/* Top bar */}
      <div style={{
        background: 'var(--brand-red)',
        color: 'white',
        textAlign: 'center',
        padding: '0.4rem',
        fontSize: '0.8rem',
        fontWeight: 500,
      }}>
        {lang === 'mn'
          ? '🚀 50,000₮-аас дээш захиалгад үнэгүй хүргэлт!'
          : '🚀 Free shipping on orders over 50,000₮!'}
      </div>

      <div className="container" style={{
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'space-between',
        gap: '1.5rem',
        height: '64px',
      }}>
        {/* Logo */}
        <button
          onClick={() => onNavigate('home')}
          style={{
            fontFamily: 'var(--font-heading)',
            fontSize: '1.6rem',
            fontWeight: 800,
            color: 'var(--brand-red)',
            letterSpacing: '-0.02em',
            flexShrink: 0,
          }}
        >
          Zarlaa
          <span style={{ color: 'var(--brand-gold)', fontSize: '1rem' }}>.mn</span>
        </button>

        {/* Search */}
        <div style={{ flex: 1, maxWidth: '480px', position: 'relative', display: 'flex', alignItems: 'center' }}>
          <span style={{
            position: 'absolute',
            left: '1rem',
            color: 'var(--gray-400)',
            fontSize: '1rem',
            pointerEvents: 'none',
          }}>🔍</span>
          <input
            className="input"
            style={{ paddingLeft: '2.5rem', background: 'var(--gray-50)' }}
            placeholder={t(lang, 'search')}
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            onFocus={() => onNavigate('shop')}
          />
        </div>

        {/* Right actions */}
        <div style={{ display: 'flex', alignItems: 'center', gap: '0.5rem', flexShrink: 0 }}>
          {/* Desktop nav */}
          <nav style={{ display: 'flex', gap: '0.25rem', marginRight: '0.5rem' }}>
            {navItems.map((item) => (
              <button
                key={item.id}
                onClick={() => onNavigate(item.id)}
                style={{
                  padding: '0.5rem 0.75rem',
                  borderRadius: 'var(--radius-sm)',
                  fontSize: '0.88rem',
                  fontWeight: currentPage === item.id ? 600 : 400,
                  color: currentPage === item.id ? 'var(--brand-red)' : 'var(--gray-600)',
                  background: currentPage === item.id ? '#FEF2F2' : 'transparent',
                  transition: 'all var(--transition)',
                }}
              >
                {item.label}
              </button>
            ))}
          </nav>

          {/* Language toggle */}
          <div style={{
            display: 'flex',
            background: 'var(--gray-100)',
            borderRadius: '100px',
            padding: '2px',
          }}>
            {(['mn', 'en'] as const).map((l) => (
              <button
                key={l}
                onClick={() => setLang(l)}
                style={{
                  padding: '0.25rem 0.6rem',
                  borderRadius: '100px',
                  fontSize: '0.75rem',
                  fontWeight: 700,
                  background: lang === l ? 'white' : 'transparent',
                  color: lang === l ? 'var(--brand-red)' : 'var(--gray-500)',
                  boxShadow: lang === l ? 'var(--shadow-sm)' : 'none',
                  transition: 'all var(--transition)',
                }}
              >
                {l.toUpperCase()}
              </button>
            ))}
          </div>

          {/* Cart button */}
          <button
            onClick={() => setCartOpen(!cartOpen)}
            style={{
              position: 'relative',
              padding: '0.6rem',
              borderRadius: 'var(--radius-sm)',
              background: count > 0 ? 'var(--brand-red)' : 'var(--gray-100)',
              color: count > 0 ? 'white' : 'var(--gray-700)',
              fontSize: '1.1rem',
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'center',
              transition: 'all var(--transition)',
            }}
          >
            🛒
            {count > 0 && (
              <span style={{
                position: 'absolute',
                top: '-6px',
                right: '-6px',
                background: 'var(--brand-gold)',
                color: 'white',
                borderRadius: '100px',
                width: '20px',
                height: '20px',
                fontSize: '0.7rem',
                fontWeight: 800,
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'center',
                boxShadow: '0 2px 6px rgba(0,0,0,0.2)',
              }}>
                {count}
              </span>
            )}
          </button>
        </div>
      </div>
    </header>
  );
}
