import React from 'react';
import { useStore } from '../../store';
import { t } from '../../i18n';
import { formatPrice } from '../../lib/data';

interface CartSidebarProps {
  onNavigate?: (page: string) => void;
}

export default function CartSidebar({ onNavigate }: CartSidebarProps) {
  const { lang, cart, cartOpen, setCartOpen, removeFromCart, updateQuantity, cartTotal, cartCount } = useStore();
  const total = cartTotal();
  const count = cartCount();
  const shippingFree = total >= 50000;

  if (!cartOpen) return null;

  return (
    <>
      <div className="overlay" onClick={() => setCartOpen(false)} />
      <div className="animate-slide-right" style={{
        position: 'fixed',
        right: 0,
        top: 0,
        bottom: 0,
        width: 'min(420px, 100vw)',
        background: 'white',
        zIndex: 200,
        display: 'flex',
        flexDirection: 'column',
        boxShadow: '-8px 0 40px rgba(0,0,0,0.15)',
      }}>
        {/* Header */}
        <div style={{
          padding: '1.5rem',
          borderBottom: '1px solid var(--gray-200)',
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'space-between',
        }}>
          <div>
            <h2 style={{ fontFamily: 'var(--font-heading)', fontSize: '1.4rem' }}>
              {t(lang, 'yourCart')}
            </h2>
            {count > 0 && (
              <p style={{ fontSize: '0.85rem', color: 'var(--gray-500)', marginTop: '0.2rem' }}>
                {count} {lang === 'mn' ? 'бүтээгдэхүүн' : 'items'}
              </p>
            )}
          </div>
          <button
            onClick={() => setCartOpen(false)}
            style={{
              width: '36px',
              height: '36px',
              borderRadius: '50%',
              background: 'var(--gray-100)',
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'center',
              fontSize: '1.1rem',
              color: 'var(--gray-600)',
            }}
          >
            ✕
          </button>
        </div>

        {/* Shipping progress */}
        {total > 0 && (
          <div style={{
            padding: '1rem 1.5rem',
            background: shippingFree ? '#F0FDF4' : '#FEF9F0',
            borderBottom: '1px solid var(--gray-100)',
          }}>
            <div style={{
              display: 'flex',
              justifyContent: 'space-between',
              fontSize: '0.82rem',
              color: shippingFree ? '#10B981' : 'var(--gray-600)',
              fontWeight: 600,
              marginBottom: '0.5rem',
            }}>
              {shippingFree
                ? (lang === 'mn' ? '✅ Үнэгүй хүргэлт авлаа!' : '✅ Free shipping unlocked!')
                : (lang === 'mn'
                  ? `🚚 Үнэгүй хүргэлтэд ${formatPrice(50000 - total)} дутуу байна`
                  : `🚚 ${formatPrice(50000 - total)} away from free shipping`)}
            </div>
            <div style={{
              height: '4px',
              background: 'var(--gray-200)',
              borderRadius: '2px',
              overflow: 'hidden',
            }}>
              <div style={{
                height: '100%',
                width: `${Math.min(100, (total / 50000) * 100)}%`,
                background: shippingFree ? '#10B981' : 'var(--brand-gold)',
                borderRadius: '2px',
                transition: 'width 0.5s ease',
              }} />
            </div>
          </div>
        )}

        {/* Items */}
        <div style={{ flex: 1, overflowY: 'auto', padding: '1rem 1.5rem' }}>
          {cart.length === 0 ? (
            <div style={{
              textAlign: 'center',
              padding: '3rem 0',
              color: 'var(--gray-400)',
            }}>
              <div style={{ fontSize: '4rem', marginBottom: '1rem' }}>🛒</div>
              <p style={{ fontWeight: 600, marginBottom: '0.5rem' }}>{t(lang, 'emptyCart')}</p>
              <button
                className="btn btn-outline btn-sm"
                onClick={() => setCartOpen(false)}
                style={{ marginTop: '1rem' }}
              >
                {t(lang, 'continueShopping')}
              </button>
            </div>
          ) : (
            <div style={{ display: 'flex', flexDirection: 'column', gap: '1rem' }}>
              {cart.map((item) => (
                <div key={item.product.id} style={{
                  display: 'flex',
                  gap: '1rem',
                  padding: '1rem',
                  background: 'var(--gray-50)',
                  borderRadius: 'var(--radius-sm)',
                }}>
                  <img
                    src={item.product.images[0]}
                    alt={item.product.name[lang]}
                    style={{
                      width: '72px',
                      height: '72px',
                      objectFit: 'cover',
                      borderRadius: 'var(--radius-sm)',
                      flexShrink: 0,
                    }}
                  />
                  <div style={{ flex: 1, minWidth: 0 }}>
                    <p style={{
                      fontWeight: 600,
                      fontSize: '0.9rem',
                      marginBottom: '0.25rem',
                      overflow: 'hidden',
                      textOverflow: 'ellipsis',
                      whiteSpace: 'nowrap',
                    }}>
                      {item.product.name[lang]}
                    </p>
                    <p style={{ color: 'var(--brand-red)', fontWeight: 700, fontSize: '0.9rem' }}>
                      {formatPrice(item.product.price)}
                    </p>
                    <div style={{
                      display: 'flex',
                      alignItems: 'center',
                      justifyContent: 'space-between',
                      marginTop: '0.5rem',
                    }}>
                      {/* Qty controls */}
                      <div style={{
                        display: 'flex',
                        alignItems: 'center',
                        background: 'white',
                        borderRadius: '100px',
                        border: '1px solid var(--gray-200)',
                        overflow: 'hidden',
                      }}>
                        <button
                          onClick={() => updateQuantity(item.product.id, item.quantity - 1)}
                          style={{
                            width: '28px',
                            height: '28px',
                            display: 'flex',
                            alignItems: 'center',
                            justifyContent: 'center',
                            fontSize: '1rem',
                            color: 'var(--gray-600)',
                          }}
                        >−</button>
                        <span style={{ padding: '0 0.5rem', fontSize: '0.85rem', fontWeight: 700 }}>
                          {item.quantity}
                        </span>
                        <button
                          onClick={() => updateQuantity(item.product.id, item.quantity + 1)}
                          style={{
                            width: '28px',
                            height: '28px',
                            display: 'flex',
                            alignItems: 'center',
                            justifyContent: 'center',
                            fontSize: '1rem',
                            color: 'var(--gray-600)',
                          }}
                        >+</button>
                      </div>
                      <button
                        onClick={() => removeFromCart(item.product.id)}
                        style={{ color: 'var(--gray-400)', fontSize: '0.8rem', fontWeight: 600 }}
                      >
                        {t(lang, 'remove')}
                      </button>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>

        {/* Footer */}
        {cart.length > 0 && (
          <div style={{
            padding: '1.5rem',
            borderTop: '1px solid var(--gray-200)',
            background: 'white',
          }}>
            <div style={{
              display: 'flex',
              justifyContent: 'space-between',
              marginBottom: '0.5rem',
              fontSize: '0.9rem',
              color: 'var(--gray-600)',
            }}>
              <span>{t(lang, 'subtotal')}</span>
              <span>{formatPrice(total)}</span>
            </div>
            <div style={{
              display: 'flex',
              justifyContent: 'space-between',
              marginBottom: '1rem',
              fontSize: '0.9rem',
              color: 'var(--gray-600)',
            }}>
              <span>{t(lang, 'shipping')}</span>
              <span style={{ color: shippingFree ? '#10B981' : 'inherit' }}>
                {shippingFree ? t(lang, 'free') : formatPrice(5000)}
              </span>
            </div>
            <div style={{
              display: 'flex',
              justifyContent: 'space-between',
              marginBottom: '1.25rem',
              fontWeight: 700,
              fontSize: '1.1rem',
            }}>
              <span>{t(lang, 'total')}</span>
              <span style={{ color: 'var(--brand-red)' }}>
                {formatPrice(shippingFree ? total : total + 5000)}
              </span>
            </div>
            <button
              className="btn btn-primary"
              style={{ width: '100%', fontSize: '1rem' }}
              onClick={() => { setCartOpen(false); onNavigate?.('checkout'); }}
            >
              {t(lang, 'checkout')} →
            </button>
          </div>
        )}
      </div>
    </>
  );
}
