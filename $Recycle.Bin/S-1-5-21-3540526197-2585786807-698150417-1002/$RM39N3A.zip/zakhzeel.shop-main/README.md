# Zarlaa.mn — E-Commerce вэбсайт

Монгол/Англи хэлтэй бүрэн E-commerce вэбсайт. React + TypeScript + Vite ашигласан.

## 🚀 Суулгах заавар

```bash
# 1. Хавтас руу орох
cd zarlaa-ecommerce

# 2. Package суулгах
npm install

# 3. Dev server ажиллуулах
npm run dev

# 4. http://localhost:5173 хаягаар нээнэ
```

## 📁 Файлын бүтэц

```
src/
├── App.tsx                     # Root component + routing
├── main.tsx                    # Entry point
├── i18n.ts                     # Монгол/Англи орчуулга
├── types/index.ts              # TypeScript types
├── store/index.ts              # Zustand state (cart, wishlist, lang)
├── lib/data.ts                 # 12 бүтээгдэхүүний mock дата
├── styles/globals.css          # Design system + CSS variables
├── components/
│   ├── layout/
│   │   ├── Navbar.tsx          # Header + хайлт + хэлний тохируулга
│   │   └── MobileNav.tsx       # Mobile bottom navigation
│   ├── cart/
│   │   └── CartSidebar.tsx     # Slide-in cart
│   ├── product/
│   │   └── ProductCard.tsx     # Бүтээгдэхүүний карт
│   └── ui/
│       └── Toast.tsx           # Toast notification
└── pages/
    ├── HomePage.tsx            # Нүүр: hero, ангилал, бүтээгдэхүүн
    ├── ShopPage.tsx            # Дэлгүүр: шүүлт, эрэмбэ
    ├── ProductPage.tsx         # Бүтээгдэхүүний дэлгэрэнгүй
    ├── WishlistPage.tsx        # Хадгалсан бараа
    ├── CheckoutPage.tsx        # 3-алхамт захиалга
    └── SearchPage.tsx          # Хайлт
```

## ✨ Боломжууд

| Боломж | Тайлбар |
|--------|---------|
| 🌐 2 хэл | Монгол / Англи дэмжлэг |
| 🛒 Сагс | Нэмэх, хасах, тоог өөрчлөх |
| ❤️ Wishlist | LocalStorage-д хадгалагдана |
| 🔍 Хайлт | Нэр, брэнд, тэгээр хайна |
| 🗂️ Шүүлт | Ангилал, үнэ, байгаа эсэх |
| 📊 Эрэмбэлэлт | Үнэ, үнэлгээ, шинэ, онцлох |
| 💳 Checkout | 3-алхамт: мэдээлэл, хаяг, төлбөр |
| 📱 Mobile | Responsive + доорх navigation |
| 🔔 Toast | Хэрэглэгчийн мэдэгдэл |
| 💾 LocalStorage | Сагс болон wishlist хадгалагдана |

## 🎨 Design систем

```css
/* Үндсэн өнгөнүүд */
--brand-red: #E63946      /* Гол өнгө */
--brand-gold: #F4A261     /* Accent */

/* Фонт */
--font-heading: 'Playfair Display'
--font-body: 'DM Sans'
```

## 🔧 Хэрхэн өргөтгөх вэ

### Бодит API холбох
`src/lib/data.ts` файлыг API дуудалтаар солих:

```ts
// Жишээ:
export async function fetchProducts() {
  const res = await fetch('/api/products');
  return res.json();
}
```

### Шинэ бүтээгдэхүүн нэмэх
`src/lib/data.ts`-д `PRODUCTS` массив руу нэмнэ:

```ts
{
  id: '13',
  name: { mn: 'Монгол нэр', en: 'English Name' },
  price: 99000,
  // ...
}
```

### Шинэ хэл нэмэх
`src/i18n.ts`-д шинэ `Lang` утга болон орчуулгын объект нэмнэ.
