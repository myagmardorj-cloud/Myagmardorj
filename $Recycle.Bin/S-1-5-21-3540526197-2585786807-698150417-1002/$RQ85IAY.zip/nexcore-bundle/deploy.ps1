# Nexcore Platforms — Auto Deploy Script
# Энэ файлыг nexcore-admin.zip болон workplace-clone.zip-тэй ИЖИЛ folder-д хадгал
# Дараа нь PowerShell-аас right-click → Run with PowerShell

$ErrorActionPreference = "Stop"

# Энэ скриптийн folder
$scriptDir = Split-Path -Parent $MyInvocation.MyCommand.Path

Write-Host ""
Write-Host "===========================================" -ForegroundColor Cyan
Write-Host "  Nexcore Platforms — Auto Deploy" -ForegroundColor Cyan
Write-Host "===========================================" -ForegroundColor Cyan
Write-Host ""

# ZIP файлуудыг шалгах
$mainZip = Join-Path $scriptDir "workplace-clone.zip"
$adminZip = Join-Path $scriptDir "nexcore-admin.zip"

if (-not (Test-Path $mainZip)) {
    Write-Host "❌ workplace-clone.zip олдсонгүй: $mainZip" -ForegroundColor Red
    Read-Host "Гарахын тулд Enter дар"
    exit
}

if (-not (Test-Path $adminZip)) {
    Write-Host "❌ nexcore-admin.zip олдсонгүй: $adminZip" -ForegroundColor Red
    Read-Host "Гарахын тулд Enter дар"
    exit
}

Write-Host "✅ ZIP файлууд олдлоо" -ForegroundColor Green
Write-Host ""

# Цэс
Write-Host "Юуг хийх вэ?" -ForegroundColor Yellow
Write-Host "  1) Зөвхөн үндсэн сайтыг шинэчлэх (workplace-clone)"
Write-Host "  2) Зөвхөн admin repo бэлдэх (nexcore-admin)"
Write-Host "  3) Хоёуланг хийх"
Write-Host "  4) Гарах"
Write-Host ""
$choice = Read-Host "Сонголтоо оруулна уу (1-4)"

# ==========================
# 1. Үндсэн сайт шинэчлэх
# ==========================
function Update-MainSite {
    Write-Host ""
    Write-Host "🟢 Үндсэн сайт шинэчилж байна..." -ForegroundColor Green

    $codePath = "C:\Workplace.com\code"
    if (-not (Test-Path $codePath)) {
        Write-Host "❌ $codePath folder олдсонгүй!" -ForegroundColor Red
        return
    }

    # Хуучин admin файлууд устгах
    Remove-Item "$codePath\src\pages\Admin.jsx" -Force -ErrorAction SilentlyContinue
    Remove-Item "$codePath\src\pages\SuperAdmin.jsx" -Force -ErrorAction SilentlyContinue
    Write-Host "  ✓ Хуучин Admin файлууд устгагдлаа" -ForegroundColor Gray

    # ZIP нээх
    $tempPath = "C:\temp_main_$(Get-Random)"
    Expand-Archive -Path $mainZip -DestinationPath $tempPath -Force
    Copy-Item "$tempPath\workplace-clone\*" $codePath -Recurse -Force
    Copy-Item "$tempPath\workplace-clone\.gitignore" $codePath -Force -ErrorAction SilentlyContinue
    Remove-Item $tempPath -Recurse -Force
    Write-Host "  ✓ Шинэ файлууд хуулагдлаа" -ForegroundColor Gray

    # Git push
    Set-Location $codePath
    git add .
    git commit -m "refactor: separate admin into own repo"
    git push origin main
    Write-Host "✅ Үндсэн сайт push хийгдлээ!" -ForegroundColor Green
}

# ==========================
# 2. Admin repo бэлдэх
# ==========================
function Setup-AdminRepo {
    Write-Host ""
    Write-Host "🔵 Admin repo бэлдэж байна..." -ForegroundColor Cyan
    Write-Host ""
    Write-Host "⚠️  АНХААРУУЛГА:" -ForegroundColor Yellow
    Write-Host "   Эхлээд GitHub дээр nexcore-admin private repo үүсгэсэн байх ёстой!" -ForegroundColor Yellow
    Write-Host "   👉 https://github.com/new" -ForegroundColor Yellow
    Write-Host "   - Repository name: nexcore-admin"
    Write-Host "   - 🔒 Private сонгох"
    Write-Host "   - 'Add README' ХЭРЭГГҮЙ"
    Write-Host ""
    $confirm = Read-Host "GitHub дээр repo үүсгэсэн үү? (y/n)"
    if ($confirm -ne "y") {
        Write-Host "Эхлээд GitHub дээр repo үүсгэнэ үү" -ForegroundColor Yellow
        return
    }

    $githubUser = Read-Host "GitHub username (default: myagmardorj-cloud)"
    if ([string]::IsNullOrWhiteSpace($githubUser)) {
        $githubUser = "myagmardorj-cloud"
    }

    $adminPath = "C:\nexcore-admin"

    # Хуучин folder арилгах
    if (Test-Path $adminPath) {
        Write-Host "  ⚠️  $adminPath аль хэдийн байна" -ForegroundColor Yellow
        $del = Read-Host "  Устгаад дахин үүсгэх үү? (y/n)"
        if ($del -eq "y") {
            Remove-Item $adminPath -Recurse -Force
        } else {
            return
        }
    }

    # Шинэ folder + ZIP нээх
    New-Item -ItemType Directory -Path $adminPath -Force | Out-Null
    $tempPath = "C:\temp_admin_$(Get-Random)"
    Expand-Archive -Path $adminZip -DestinationPath $tempPath -Force
    Copy-Item "$tempPath\nexcore-admin\*" $adminPath -Recurse -Force
    Copy-Item "$tempPath\nexcore-admin\.gitignore" $adminPath -Force -ErrorAction SilentlyContinue
    Remove-Item $tempPath -Recurse -Force
    Write-Host "  ✓ Файлууд $adminPath-д хуулагдлаа" -ForegroundColor Gray

    # Git init + push
    Set-Location $adminPath
    git init | Out-Null
    git add .
    git commit -m "feat: initial admin console" | Out-Null
    git branch -M main
    git remote add origin "https://github.com/$githubUser/nexcore-admin.git"
    Write-Host "  ✓ Git тохируулагдлаа" -ForegroundColor Gray
    Write-Host ""
    Write-Host "  📤 GitHub-руу push хийж байна..." -ForegroundColor Cyan
    git push -u origin main

    if ($LASTEXITCODE -eq 0) {
        Write-Host ""
        Write-Host "✅ Admin repo амжилттай push хийгдлээ!" -ForegroundColor Green
        Write-Host ""
        Write-Host "📌 Дараагийн алхам:" -ForegroundColor Yellow
        Write-Host "  1. https://vercel.com/new руу очно"
        Write-Host "  2. nexcore-admin repo-г import хийнэ"
        Write-Host "  3. Settings → Domains → admin.nexcoreplatforms.mn"
        Write-Host ""
    } else {
        Write-Host ""
        Write-Host "❌ Push хийхэд алдаа гарлаа" -ForegroundColor Red
        Write-Host "GitHub дээр $githubUser/nexcore-admin repo үүссэн эсэхийг шалгана уу" -ForegroundColor Yellow
    }
}

# Main
switch ($choice) {
    "1" { Update-MainSite }
    "2" { Setup-AdminRepo }
    "3" {
        Update-MainSite
        Setup-AdminRepo
    }
    "4" {
        Write-Host "Гарлаа" -ForegroundColor Gray
        exit
    }
    default {
        Write-Host "Буруу сонголт" -ForegroundColor Red
    }
}

Write-Host ""
Write-Host "🔑 Master password: Md98HcogxPCVrG" -ForegroundColor Cyan
Write-Host ""
Read-Host "Гарахын тулд Enter дар"
