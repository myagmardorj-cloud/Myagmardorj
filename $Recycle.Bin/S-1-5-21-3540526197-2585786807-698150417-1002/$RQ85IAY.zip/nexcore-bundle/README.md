# Nexcore Platforms — Deploy Bundle

Энэ багц нь 2 ZIP файлтай:

| ZIP файл | Юу хийдэг |
|---|---|
| `workplace-clone.zip` | Үндсэн сайт (nexcoreplatforms.mn) |
| `nexcore-admin.zip` | Админ консол (admin.nexcoreplatforms.mn) |

---

## ⚡ Хурдан deploy 3 алхам

### 🟢 Алхам 1 — Үндсэн сайтыг шинэчлэх (workplace-clone)

```powershell
# Аль хэдийн байгаа repo-г шинэчлэх
cd C:\Workplace.com\code

# Хуучин Admin файлуудыг устгах (одоо тусдаа repo-д шилжсэн)
Remove-Item C:\Workplace.com\code\src\pages\Admin.jsx -Force -ErrorAction SilentlyContinue
Remove-Item C:\Workplace.com\code\src\pages\SuperAdmin.jsx -Force -ErrorAction SilentlyContinue

# Шинэ ZIP-аас файлуудыг хуулах
Expand-Archive -Path "$env:USERPROFILE\Downloads\workplace-clone.zip" -DestinationPath C:\temp_main -Force
Copy-Item C:\temp_main\workplace-clone\* C:\Workplace.com\code\ -Recurse -Force
Copy-Item C:\temp_main\workplace-clone\.gitignore C:\Workplace.com\code\ -Force
Remove-Item C:\temp_main -Recurse -Force

# Push
git add .
git commit -m "refactor: separate admin into own repo"
git push origin main
```

---

### 🔵 Алхам 2 — GitHub дээр шинэ admin repo үүсгэх

**Browser-аар:**

1. https://github.com/new руу очно
2. Маягт бөглөнө:
   - **Repository name:** `nexcore-admin`
   - **🔒 Private** ← заавал!
   - **❌ Add README сонгохгүй** (хоосон үүсгэе)
3. **"Create repository"** ногоон товч дарна

⚠️ Энэ алхам байхгүй бол Алхам 3 ажиллахгүй!

---

### 🟣 Алхам 3 — Admin repo-г push хийх

```powershell
# Username тохируулах
$user = "myagmardorj-cloud"  # GitHub username

# Admin folder бэлдэх
cd C:\
New-Item -ItemType Directory -Path C:\nexcore-admin -Force
cd C:\nexcore-admin

# ZIP нээх
Expand-Archive -Path "$env:USERPROFILE\Downloads\nexcore-admin.zip" -DestinationPath C:\temp_admin -Force
Copy-Item C:\temp_admin\nexcore-admin\* C:\nexcore-admin\ -Recurse -Force
Copy-Item C:\temp_admin\nexcore-admin\.gitignore C:\nexcore-admin\ -Force -ErrorAction SilentlyContinue
Remove-Item C:\temp_admin -Recurse -Force

# Git init + push
git init
git add .
git commit -m "feat: initial admin console"
git branch -M main
git remote add origin https://github.com/$user/nexcore-admin.git
git push -u origin main
```

---

### 🟠 Алхам 4 — Vercel дээр deploy

1. **vercel.com/new** → **Import Git Repository** → `nexcore-admin` сонго
2. **Framework:** Vite (autodetect)
3. **Deploy** товч
4. Дууссаны дараа: **Settings → Domains** → `admin.nexcoreplatforms.mn` нэмэх

---

## 🔑 Master password

```
Md98HcogxPCVrG
```

`/admin` болон `/super-admin` хоёрт ажиллана.
