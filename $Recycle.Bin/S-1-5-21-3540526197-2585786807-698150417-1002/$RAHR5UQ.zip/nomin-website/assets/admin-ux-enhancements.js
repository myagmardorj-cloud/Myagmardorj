/**
 * NOMIN Silver Admin — UX Enhancements
 * Phase 3: Dark mode, Global search, Keyboard shortcuts, Mobile responsive, Notifications
 * Nexcore LTD © 2026
 */
(function(){
  'use strict';

  // ═══════════════════════════════════════════════════════════════════
  // 1. DARK MODE
  // ═══════════════════════════════════════════════════════════════════
  function initDarkMode(){
    // CSS variables-ыг шинэчлэх
    var darkStyles = document.createElement('style');
    darkStyles.id = 'darkModeStyles';
    darkStyles.textContent = `
      :root.dark {
        --navy: #e2e8f0 !important;
        --text: #e2e8f0 !important;
        --text-sec: #94a3b8 !important;
        --border: #334155 !important;
        --bg: #0f172a !important;
        --bg2: #1e293b !important;
        --white: #1e293b !important;
        --blue-light: #1e3a8a !important;
      }
      :root.dark body { background: #0f172a !important; color: #e2e8f0 !important; }
      :root.dark .card,
      :root.dark .panel,
      :root.dark .modal > div,
      :root.dark .form-control,
      :root.dark .sb { background: #1e293b !important; border-color: #334155 !important; color: #e2e8f0 !important; }
      :root.dark .nav-lnk { color: #cbd5e1 !important; }
      :root.dark .nav-lnk:hover,
      :root.dark .nav-lnk.active { background: rgba(77,104,239,.15) !important; color: #93c5fd !important; }
      :root.dark table { color: #e2e8f0 !important; }
      :root.dark th { background: #1e293b !important; color: #cbd5e1 !important; }
      :root.dark td { border-color: #334155 !important; }
      :root.dark tr:hover td { background: rgba(77,104,239,.1) !important; }
      :root.dark input, 
      :root.dark select, 
      :root.dark textarea { background: #0f172a !important; color: #e2e8f0 !important; border-color: #334155 !important; }
      :root.dark .btn-outline { background: #1e293b !important; color: #cbd5e1 !important; border-color: #475569 !important; }
      :root.dark .btn-xs { background: #1e293b !important; color: #cbd5e1 !important; border-color: #475569 !important; }
      :root.dark h1, :root.dark h2, :root.dark h3, :root.dark h4 { color: #f1f5f9 !important; }
      
      /* Dark mode toggle button */
      .dark-mode-toggle {
        position: fixed;
        bottom: 24px;
        right: 24px;
        width: 48px;
        height: 48px;
        border-radius: 50%;
        background: #4D68EF;
        color: white;
        border: none;
        cursor: pointer;
        box-shadow: 0 4px 16px rgba(77,104,239,.4);
        font-size: 20px;
        z-index: 9998;
        transition: transform .2s, box-shadow .2s;
      }
      .dark-mode-toggle:hover {
        transform: scale(1.1);
        box-shadow: 0 6px 20px rgba(77,104,239,.6);
      }
    `;
    document.head.appendChild(darkStyles);

    // Toggle button үүсгэх
    var btn = document.createElement('button');
    btn.className = 'dark-mode-toggle';
    btn.title = 'Dark mode (Ctrl+Shift+D)';
    btn.setAttribute('aria-label', 'Toggle dark mode');
    btn.innerHTML = '🌙';
    btn.onclick = toggleDarkMode;
    document.body.appendChild(btn);

    // LocalStorage-оос сэргээх
    if(localStorage.getItem('nm_admin_dark') === '1'){
      document.documentElement.classList.add('dark');
      btn.innerHTML = '☀️';
    }
  }

  function toggleDarkMode(){
    var isDark = document.documentElement.classList.toggle('dark');
    localStorage.setItem('nm_admin_dark', isDark ? '1' : '0');
    var btn = document.querySelector('.dark-mode-toggle');
    if(btn) btn.innerHTML = isDark ? '☀️' : '🌙';
    if(typeof toast === 'function'){
      toast(isDark ? '🌙 Dark mode идэвхжлээ' : '☀️ Light mode идэвхжлээ', 'success');
    }
  }
  
  window.toggleDarkMode = toggleDarkMode;

  // ═══════════════════════════════════════════════════════════════════
  // 2. GLOBAL SEARCH (Cmd+K / Ctrl+K)
  // ═══════════════════════════════════════════════════════════════════
  var _searchOpen = false;
  
  function initGlobalSearch(){
    var searchStyles = document.createElement('style');
    searchStyles.textContent = `
      .global-search-overlay {
        position: fixed;
        inset: 0;
        background: rgba(15,23,42,.7);
        backdrop-filter: blur(4px);
        z-index: 10001;
        display: none;
        align-items: flex-start;
        justify-content: center;
        padding-top: 10vh;
      }
      .global-search-overlay.active { display: flex; }
      .global-search-box {
        background: #fff;
        border-radius: 14px;
        width: 90%;
        max-width: 640px;
        box-shadow: 0 20px 60px rgba(0,0,0,.3);
        overflow: hidden;
      }
      :root.dark .global-search-box { background: #1e293b; }
      .global-search-input {
        width: 100%;
        padding: 1.2rem 1.5rem;
        border: none;
        outline: none;
        font-size: 1.05rem;
        background: transparent;
        color: #0f172a;
        border-bottom: 1px solid #e2e8f0;
      }
      :root.dark .global-search-input { color: #e2e8f0; border-color: #334155; }
      .global-search-results {
        max-height: 400px;
        overflow-y: auto;
      }
      .global-search-item {
        padding: .75rem 1.5rem;
        display: flex;
        align-items: center;
        gap: .75rem;
        cursor: pointer;
        border-left: 3px solid transparent;
        transition: all .15s;
      }
      .global-search-item:hover,
      .global-search-item.active {
        background: #f1f5f9;
        border-left-color: #4D68EF;
      }
      :root.dark .global-search-item:hover,
      :root.dark .global-search-item.active { background: #334155; }
      .global-search-icon {
        font-size: 1.1rem;
        flex-shrink: 0;
      }
      .global-search-text {
        flex: 1;
        min-width: 0;
      }
      .global-search-title {
        font-weight: 600;
        color: #0f172a;
        font-size: .92rem;
      }
      :root.dark .global-search-title { color: #e2e8f0; }
      .global-search-sub {
        font-size: .72rem;
        color: #64748b;
        margin-top: .1rem;
      }
      .global-search-hint {
        padding: .6rem 1.5rem;
        font-size: .72rem;
        color: #94a3b8;
        background: #f8fafc;
        border-top: 1px solid #e2e8f0;
        display: flex;
        justify-content: space-between;
      }
      :root.dark .global-search-hint { background: #0f172a; border-color: #334155; }
      .gs-kbd {
        background: rgba(100,116,139,.15);
        padding: 1px 6px;
        border-radius: 3px;
        font-family: monospace;
        font-size: .68rem;
      }
    `;
    document.head.appendChild(searchStyles);

    // Search UI үүсгэх
    var overlay = document.createElement('div');
    overlay.className = 'global-search-overlay';
    overlay.id = 'globalSearchOverlay';
    overlay.innerHTML = `
      <div class="global-search-box" onclick="event.stopPropagation()">
        <input type="search" class="global-search-input" id="globalSearchInput" 
               placeholder="🔍 Модуль, үйлдэл хайх..." autocomplete="off">
        <div class="global-search-results" id="globalSearchResults"></div>
        <div class="global-search-hint">
          <span><span class="gs-kbd">↑↓</span> Навигац · <span class="gs-kbd">Enter</span> Сонгох</span>
          <span><span class="gs-kbd">Esc</span> Хаах</span>
        </div>
      </div>
    `;
    overlay.onclick = closeGlobalSearch;
    document.body.appendChild(overlay);

    // Input event handlers
    var input = document.getElementById('globalSearchInput');
    input.addEventListener('input', function(){ renderSearchResults(this.value); });
    input.addEventListener('keydown', handleSearchKeyboard);
  }

  // Бүх модулиудыг индекс хэлбэрт оруулах
  var _searchIndex = [
    {icon:'📊', title:'Хяналтын самбар', sub:'Ерөнхий статистик', panel:'dashboard', keywords:'dashboard хяналт самбар'},
    {icon:'🩺', title:'Аудит & Оношлогоо', sub:'Системийн шалгалт', panel:'audit', keywords:'audit аудит шалгалт'},
    {icon:'🏪', title:'Салбарын удирдлага', sub:'Дэлгүүр, байршил', panel:'stores-mgr', keywords:'store салбар дэлгүүр'},
    {icon:'👥', title:'Удирдлагын баг', sub:'Leadership team', panel:'leadership-mgr', keywords:'leadership удирдлага баг'},
    {icon:'📚', title:'Группын танилцуулга', sub:'PDF каталог', panel:'catalogue-mgr', keywords:'catalogue pdf каталог'},
    {icon:'🏢', title:'Компанийн бүтэц', sub:'Parent-child, JV', panel:'structure-mgr', keywords:'structure бүтэц компани'},
    {icon:'💬', title:'Сэтгэгдэл', sub:'Testimonials', panel:'testimonials-mgr', keywords:'testimonial сэтгэгдэл'},
    {icon:'🤝', title:'CRM — Хүсэлтүүд', sub:'Leads, messages', panel:'leads-mgr', keywords:'crm lead хүсэлт'},
    {icon:'🤖', title:'AI Чат аналитик', sub:'NomiBot analytics', panel:'chat-analytics', keywords:'ai chat analytics'},
    {icon:'📚', title:'Мэдлэгийн бааз', sub:'FAQ удирдлага', panel:'knowledge-base', keywords:'faq knowledge мэдлэг'},
    {icon:'📰', title:'Мэдээ', sub:'News CRUD', panel:'news', keywords:'news мэдээ'},
    {icon:'🖼', title:'Баннер', sub:'Hero slider', panel:'banners', keywords:'banner баннер slider hero'},
    {icon:'📄', title:'Хуудасны агуулга', sub:'Static pages', panel:'pages', keywords:'pages хуудас'},
    {icon:'🗂', title:'Медиа сан', sub:'File storage', panel:'media', keywords:'media файл зураг'},
    {icon:'💼', title:'Ажлын байр', sub:'Careers', panel:'careers', keywords:'career job ажлын байр'},
    {icon:'📋', title:'Тендер', sub:'Tender management', panel:'tender', keywords:'tender тендер'},
    {icon:'🚚', title:'Нийлүүлэгч', sub:'Suppliers', panel:'suppliers', keywords:'supplier нийлүүлэгч'},
    {icon:'✉️', title:'Холбоо барих', sub:'Contact messages', panel:'contacts', keywords:'contact холбоо'},
    {icon:'🏗', title:'Layout Builder', sub:'Drag & drop', panel:'builder', keywords:'builder layout'},
    {icon:'🧩', title:'Блок систем', sub:'Page blocks', panel:'blocks', keywords:'block блок'},
    {icon:'📱', title:'Device Preview', sub:'Responsive test', panel:'preview', keywords:'preview device'},
    {icon:'🕐', title:'Revision History', sub:'Snapshots', panel:'history', keywords:'history revision'},
    {icon:'🌐', title:'Орчуулга', sub:'i18n translations', panel:'translations', keywords:'translation орчуулга'},
    {icon:'🎨', title:'Дизайн систем', sub:'Colors, tokens', panel:'design', keywords:'design дизайн өнгө'},
    {icon:'✏️', title:'Бичгийн загвар', sub:'Typography', panel:'typography', keywords:'typography font'},
    {icon:'📊', title:'Stats & Ticker', sub:'Numbers display', panel:'statsedit', keywords:'stats ticker'},
    {icon:'📊', title:'Тайлангийн самбар', sub:'Reports dashboard', panel:'rpt-overview', keywords:'report тайлан'},
    {icon:'📧', title:'Сарын тайлан', sub:'Monthly reports', panel:'reports', keywords:'monthly report сарын'},
    {icon:'📅', title:'Тайлангийн архив', sub:'Report history', panel:'report-history', keywords:'archive тайлан'},
    {icon:'🗂', title:'Меню удирдлага', sub:'Navigation', panel:'menu', keywords:'menu меню'},
    {icon:'👤', title:'Хэрэглэгч', sub:'Users & roles', panel:'users', keywords:'user хэрэглэгч'},
    {icon:'📥', title:'Import', sub:'Data import', panel:'nomin-import', keywords:'import импорт'},
    {icon:'⚙️', title:'Тохиргоо', sub:'Settings', panel:'settings', keywords:'settings тохиргоо'},
    {icon:'🔍', title:'SEO', sub:'Meta tags', panel:'seo', keywords:'seo meta'},
    {icon:'📈', title:'Аналитик', sub:'Analytics', panel:'analytics', keywords:'analytics аналитик'},
    // Үйлдэл
    {icon:'🌙', title:'Dark mode toggle', sub:'Харанхуй/гэрэлтэй', action:'toggleDark', keywords:'dark light theme mode'},
    {icon:'🔄', title:'Хуудас дахин ачаалах', sub:'Page refresh', action:'reload', keywords:'reload refresh'},
    {icon:'🌐', title:'Сайт харах', sub:'silver.nomin.io', action:'viewSite', keywords:'site view сайт'},
    {icon:'🔒', title:'Гарах', sub:'Logout', action:'logout', keywords:'logout гарах'},
  ];

  var _searchSelectedIdx = 0;
  
  function openGlobalSearch(){
    var overlay = document.getElementById('globalSearchOverlay');
    if(!overlay) return;
    overlay.classList.add('active');
    _searchOpen = true;
    setTimeout(function(){
      var input = document.getElementById('globalSearchInput');
      if(input){ input.value = ''; input.focus(); }
      renderSearchResults('');
    }, 50);
  }

  function closeGlobalSearch(){
    var overlay = document.getElementById('globalSearchOverlay');
    if(overlay) overlay.classList.remove('active');
    _searchOpen = false;
  }

  function renderSearchResults(query){
    var results = document.getElementById('globalSearchResults');
    if(!results) return;
    
    var q = (query || '').toLowerCase().trim();
    var items = q 
      ? _searchIndex.filter(function(i){
          return i.title.toLowerCase().includes(q) ||
                 i.sub.toLowerCase().includes(q) ||
                 (i.keywords || '').toLowerCase().includes(q);
        })
      : _searchIndex.slice(0, 12);
    
    _searchSelectedIdx = 0;
    
    if(items.length === 0){
      results.innerHTML = '<div style="padding:2rem;text-align:center;color:#94a3b8">Илэрц олдсонгүй</div>';
      return;
    }
    
    results.innerHTML = items.map(function(item, i){
      return '<div class="global-search-item' + (i === 0 ? ' active' : '') + '" ' +
             'data-panel="' + (item.panel || '') + '" ' +
             'data-action="' + (item.action || '') + '" ' +
             'onmousedown="__globalSearchSelect(event)">' +
             '<span class="global-search-icon">' + item.icon + '</span>' +
             '<div class="global-search-text">' +
             '<div class="global-search-title">' + item.title + '</div>' +
             '<div class="global-search-sub">' + item.sub + '</div>' +
             '</div>' +
             '</div>';
    }).join('');
  }

  window.__globalSearchSelect = function(ev){
    var item = ev.currentTarget;
    var panel = item.getAttribute('data-panel');
    var action = item.getAttribute('data-action');
    
    if(panel && typeof window.gotoPanel === 'function'){
      window.gotoPanel(panel);
      closeGlobalSearch();
    } else if(action){
      switch(action){
        case 'toggleDark': toggleDarkMode(); break;
        case 'reload': location.reload(); break;
        case 'viewSite': window.open('/', '_blank'); break;
        case 'logout': if(typeof window.doLogout === 'function') window.doLogout(); break;
      }
      closeGlobalSearch();
    }
  };

  function handleSearchKeyboard(e){
    var items = document.querySelectorAll('.global-search-item');
    if(items.length === 0) return;

    if(e.key === 'Escape'){
      closeGlobalSearch();
      e.preventDefault();
    } else if(e.key === 'ArrowDown'){
      e.preventDefault();
      _searchSelectedIdx = Math.min(_searchSelectedIdx + 1, items.length - 1);
      updateSearchSelection(items);
    } else if(e.key === 'ArrowUp'){
      e.preventDefault();
      _searchSelectedIdx = Math.max(_searchSelectedIdx - 1, 0);
      updateSearchSelection(items);
    } else if(e.key === 'Enter'){
      e.preventDefault();
      var selected = items[_searchSelectedIdx];
      if(selected){
        var panel = selected.getAttribute('data-panel');
        var action = selected.getAttribute('data-action');
        if(panel && typeof window.gotoPanel === 'function'){
          window.gotoPanel(panel);
          closeGlobalSearch();
        } else if(action){
          switch(action){
            case 'toggleDark': toggleDarkMode(); break;
            case 'reload': location.reload(); break;
            case 'viewSite': window.open('/', '_blank'); break;
            case 'logout': if(typeof window.doLogout === 'function') window.doLogout(); break;
          }
          closeGlobalSearch();
        }
      }
    }
  }
  
  function updateSearchSelection(items){
    items.forEach(function(item, i){
      item.classList.toggle('active', i === _searchSelectedIdx);
    });
    // Scroll into view
    var selected = items[_searchSelectedIdx];
    if(selected) selected.scrollIntoView({block: 'nearest'});
  }

  window.openGlobalSearch = openGlobalSearch;

  // ═══════════════════════════════════════════════════════════════════
  // 3. KEYBOARD SHORTCUTS
  // ═══════════════════════════════════════════════════════════════════
  function initKeyboardShortcuts(){
    document.addEventListener('keydown', function(e){
      var isMod = e.ctrlKey || e.metaKey;
      
      // Cmd/Ctrl + K — Global search
      if(isMod && e.key.toLowerCase() === 'k'){
        e.preventDefault();
        openGlobalSearch();
        return;
      }
      
      // Cmd/Ctrl + Shift + D — Dark mode
      if(isMod && e.shiftKey && e.key.toLowerCase() === 'd'){
        e.preventDefault();
        toggleDarkMode();
        return;
      }
      
      // Cmd/Ctrl + S — Save active modal
      if(isMod && e.key.toLowerCase() === 's'){
        var activeModal = document.querySelector('.modal[style*="flex"], .modal-ov[style*="flex"]');
        if(activeModal){
          e.preventDefault();
          var saveBtn = activeModal.querySelector('[onclick*="save"], .btn-primary');
          if(saveBtn) saveBtn.click();
        }
      }
      
      // Escape — Modal close / search close
      if(e.key === 'Escape'){
        if(_searchOpen){
          closeGlobalSearch();
          e.preventDefault();
          return;
        }
        var openModal = document.querySelector('.modal[style*="flex"], .modal-ov[style*="flex"]');
        if(openModal){
          var closeBtn = openModal.querySelector('[onclick*="display=\'none\'"], [onclick*="close"]');
          if(closeBtn) closeBtn.click();
          else openModal.style.display = 'none';
        }
      }
      
      // Cmd/Ctrl + / — Show shortcuts hint
      if(isMod && e.key === '/'){
        e.preventDefault();
        showShortcutsHint();
      }
    });
  }

  function showShortcutsHint(){
    if(typeof toast !== 'function') return;
    var hint = '⌨️ ШОРТКАТУУД\n' +
               'Ctrl+K — Хайх\n' +
               'Ctrl+Shift+D — Dark mode\n' +
               'Ctrl+S — Хадгалах (modal-д)\n' +
               'Esc — Хаах';
    alert(hint);
  }

  // ═══════════════════════════════════════════════════════════════════
  // 4. MOBILE RESPONSIVE
  // ═══════════════════════════════════════════════════════════════════
  function initMobileResponsive(){
    var mobileStyles = document.createElement('style');
    mobileStyles.textContent = `
      /* Mobile menu toggle button */
      .mobile-menu-toggle {
        display: none;
        position: fixed;
        top: 16px;
        left: 16px;
        width: 44px;
        height: 44px;
        border-radius: 10px;
        background: #4D68EF;
        color: white;
        border: none;
        cursor: pointer;
        box-shadow: 0 4px 12px rgba(77,104,239,.4);
        font-size: 20px;
        z-index: 100;
      }
      
      @media (max-width: 768px) {
        .mobile-menu-toggle { display: flex; align-items: center; justify-content: center; }
        
        .sb {
          transform: translateX(-100%);
          transition: transform .3s ease;
          position: fixed !important;
          top: 0;
          left: 0;
          height: 100vh;
          z-index: 99;
          box-shadow: 4px 0 20px rgba(0,0,0,.2);
        }
        .sb.mobile-open {
          transform: translateX(0);
        }
        
        .mobile-overlay {
          display: none;
          position: fixed;
          inset: 0;
          background: rgba(0,0,0,.5);
          z-index: 98;
        }
        .mobile-overlay.active { display: block; }
        
        /* Main content-ийг full width */
        body > *:not(.sb):not(.mobile-menu-toggle):not(.mobile-overlay):not(.dark-mode-toggle):not(.global-search-overlay):not(.toast-container) {
          margin-left: 0 !important;
          padding-left: 1rem !important;
          padding-top: 70px !important;
        }
        
        /* Panels — full width */
        .panel {
          padding: 1rem !important;
        }
        
        /* Grids — single column */
        [style*="grid-template-columns"] {
          grid-template-columns: 1fr !important;
        }
        
        /* Tables — scrollable */
        table {
          font-size: .8rem !important;
        }
        
        /* Forms wider inputs */
        .form-control {
          font-size: 16px !important; /* iOS zoom fix */
        }
        
        /* Modals */
        .modal > div, .modal-ov > div {
          max-width: 95vw !important;
          max-height: 95vh !important;
        }
        
        /* Dashboard cards stack */
        h2 { font-size: .95rem !important; }
        
        /* Dark mode toggle — lower position */
        .dark-mode-toggle {
          bottom: 80px !important;
        }
      }
      
      /* Tablet */
      @media (min-width: 769px) and (max-width: 1024px) {
        .sb { width: 200px !important; }
      }
    `;
    document.head.appendChild(mobileStyles);

    // Mobile menu toggle button
    var btn = document.createElement('button');
    btn.className = 'mobile-menu-toggle';
    btn.setAttribute('aria-label', 'Toggle menu');
    btn.innerHTML = '☰';
    btn.onclick = toggleMobileMenu;
    document.body.appendChild(btn);
    
    // Overlay
    var overlay = document.createElement('div');
    overlay.className = 'mobile-overlay';
    overlay.id = 'mobileOverlay';
    overlay.onclick = closeMobileMenu;
    document.body.appendChild(overlay);
    
    // Nav links click-д menu хаах
    document.addEventListener('click', function(e){
      if(window.innerWidth <= 768 && e.target.closest('.nav-lnk')){
        setTimeout(closeMobileMenu, 100);
      }
    });
  }

  function toggleMobileMenu(){
    var sb = document.querySelector('.sb');
    var overlay = document.getElementById('mobileOverlay');
    if(sb){
      var isOpen = sb.classList.toggle('mobile-open');
      if(overlay) overlay.classList.toggle('active', isOpen);
    }
  }
  
  function closeMobileMenu(){
    var sb = document.querySelector('.sb');
    var overlay = document.getElementById('mobileOverlay');
    if(sb) sb.classList.remove('mobile-open');
    if(overlay) overlay.classList.remove('active');
  }

  // ═══════════════════════════════════════════════════════════════════
  // 5. LIVE NOTIFICATIONS (polling based)
  // ═══════════════════════════════════════════════════════════════════
  function initLiveNotifications(){
    var lastLeadCount = 0;
    var lastCheckedAt = new Date().toISOString();
    
    function checkNewLeads(){
      var SB = window.__NM_SB_URL__ || 'https://hunygqumohxinhndrcph.supabase.co';
      var KEY = window.__NM_SB_KEY__ || 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6Imh1bnlncXVtb2h4aW5obmRyY3BoIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NzQzNTA4NjMsImV4cCI6MjA4OTkyNjg2M30.2eFxPABgxosblHajh85txP_yrv0VsDCbhxSVIcO3T88';
      
      fetch(SB + '/rest/v1/leads?status=eq.new&select=id,name,created_at&order=created_at.desc&limit=5', {
        headers: { 'apikey': KEY, 'Authorization': 'Bearer ' + KEY }
      })
      .then(function(r){ return r.ok ? r.json() : []; })
      .then(function(leads){
        if(!Array.isArray(leads)) return;
        
        // Анх удаа
        if(lastLeadCount === 0 && leads.length > 0){
          lastLeadCount = leads.length;
          updateBadge('leads-mgr', leads.length);
          return;
        }
        
        // Шинэ lead ирсэн бол notification
        var newLeads = leads.filter(function(l){ return l.created_at > lastCheckedAt; });
        if(newLeads.length > 0){
          showNotification('🔔 ' + newLeads.length + ' шинэ хүсэлт', 
            newLeads.map(function(l){ return l.name || '(нэргүй)'; }).join(', '),
            'leads-mgr');
          updateBadge('leads-mgr', leads.length);
          lastCheckedAt = new Date().toISOString();
        }
        lastLeadCount = leads.length;
      })
      .catch(function(e){ /* silent fail */ });
    }

    function updateBadge(panelName, count){
      var navLinks = document.querySelectorAll('[data-panel="' + panelName + '"]');
      navLinks.forEach(function(link){
        var badge = link.querySelector('.nav-badge');
        if(count > 0){
          if(!badge){
            badge = document.createElement('span');
            badge.className = 'nav-badge';
            badge.style.cssText = 'background:#ef4444;color:white;font-size:.68rem;font-weight:700;padding:1px 6px;border-radius:10px;margin-left:6px;min-width:20px;display:inline-block;text-align:center';
            link.appendChild(badge);
          }
          badge.textContent = count;
        } else if(badge){
          badge.remove();
        }
      });
    }

    // Анхны шалгалт + interval
    setTimeout(checkNewLeads, 2000);
    setInterval(checkNewLeads, 30000); // 30 секунд тутамд
  }

  function showNotification(title, body, panelName){
    // Toast
    if(typeof toast === 'function') toast(title + ': ' + body, 'info');
    
    // Browser notification (permission-тэй бол)
    if('Notification' in window && Notification.permission === 'granted'){
      var n = new Notification(title, { 
        body: body,
        icon: '/favicon.png',
        tag: 'nomin-' + panelName
      });
      n.onclick = function(){
        window.focus();
        if(typeof window.gotoPanel === 'function') window.gotoPanel(panelName);
        n.close();
      };
    }
  }

  // Notification permission асуух
  function requestNotificationPermission(){
    if('Notification' in window && Notification.permission === 'default'){
      setTimeout(function(){
        if(confirm('🔔 Шинэ хүсэлт ирэхэд мэдэгдэл авах уу?')){
          Notification.requestPermission();
        }
      }, 5000);
    }
  }

  // ═══════════════════════════════════════════════════════════════════
  // 6. PERFORMANCE MONITORING
  // ═══════════════════════════════════════════════════════════════════
  function initPerformanceMonitoring(){
    // Console-д performance metrics харуулах
    if(window.performance && performance.timing){
      window.addEventListener('load', function(){
        setTimeout(function(){
          var t = performance.timing;
          var loadTime = t.loadEventEnd - t.navigationStart;
          var domReady = t.domContentLoadedEventEnd - t.navigationStart;
          console.log('%c⚡ NOMIN Admin Performance', 'color:#4D68EF;font-weight:bold;font-size:14px');
          console.log('  DOM Ready: ' + domReady + 'ms');
          console.log('  Full Load: ' + loadTime + 'ms');
          if(loadTime > 3000){
            console.warn('⚠️  Load time удаан байна (' + loadTime + 'ms). Code splitting шаардлагатай.');
          }
        }, 0);
      });
    }
  }

  // ═══════════════════════════════════════════════════════════════════
  // INIT бүгд
  // ═══════════════════════════════════════════════════════════════════
  function init(){
    try {
      initDarkMode();
      initGlobalSearch();
      initKeyboardShortcuts();
      initMobileResponsive();
      initLiveNotifications();
      initPerformanceMonitoring();
      
      // Notification permission 5 секундын дараа
      requestNotificationPermission();
      
      console.log('%c✨ Admin UX Enhancements loaded', 'color:#10b981;font-weight:bold');
      console.log('   Keyboard: Ctrl+K (search), Ctrl+Shift+D (dark), Esc, Ctrl+S');
    } catch(e){
      console.error('UX init error:', e);
    }
  }

  // DOM ready дараа init
  if(document.readyState === 'loading'){
    document.addEventListener('DOMContentLoaded', init);
  } else {
    init();
  }

})();
