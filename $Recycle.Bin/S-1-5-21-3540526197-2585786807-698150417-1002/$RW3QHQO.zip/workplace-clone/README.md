# Nexcore Platforms

Nexcore Platforms — Монгол хэл дээрх ажлын байрны бүх нэг дор платформ. React + Vite + Tailwind CSS.

## Хэрхэн ажиллуулах вэ

### 1. Сангуудыг суулгах
```bash
npm install
```

### 2. Хөгжүүлэлтийн сервер ажиллуулах
```bash
npm run dev
```
Browser-т `http://localhost:5173` нээгдэнэ.

### 3. Production-д бэлдэх
```bash
npm run build
```

## Хуудаснууд

- `/` — Үндсэн хуудас (Landing)
- `/admin` — Админ панель
- `/apps` — Бүх програм
- `/apps/chat` — Чат
- `/apps/meet` — Видео уулзалт
- `/apps/learn` — Сургалт
- `/apps/mail` — Имэйл
- `/apps/docs` — Баримт
- `/apps/ai` — AI Туслах
- `/apps/calendar` — Хуанли
- `/apps/whiteboard` — Самбар

## Vercel-д deploy хийх

GitHub repo үүсгээд push хийсний дараа [vercel.com](https://vercel.com)-руу орж тухайн repo-г сонгож "Deploy" дарна. 30 секундад онлайн орно.
