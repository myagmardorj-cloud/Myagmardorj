import { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { motion } from 'framer-motion';
import MigrationBanner from '../components/MigrationBanner.jsx';
import {
  MessageSquare, Video, Mail, FileText, Sparkles, Calendar,
  Layers, BookOpen, PenSquare, Search, Bell, Menu, X,
  ArrowRight, Check, Star, Play, ShoppingCart, Heart,
  TrendingUp, Zap, Award, Shield, Globe, Lock, ChevronRight, ChevronDown, ExternalLink
} from 'lucide-react';

/* ==================== CATEGORY CHIPS ==================== */
const CATEGORIES = [
  { id: 'all', label: 'Бүгд', icon: '🔷' },
  { id: 'comm', label: 'Холбоо', icon: '💬' },
  { id: 'collab', label: 'Хамтран ажиллах', icon: '🤝' },
  { id: 'productivity', label: 'Бүтээмж', icon: '⚡' },
  { id: 'ai', label: 'AI', icon: '✨' },
];

/* ==================== APPS DATA ==================== */
const APPS = [
  { id: 1, icon: '💬', name: 'Чат', emoji: '💬', desc: '1-on-1, групп, threads, voice notes', color: '#10B981', tag: 'Үндсэн', tagColor: '#10B981', cat: 'comm', rating: 4.9, users: '12K+' },
  { id: 2, icon: '📹', name: 'Meet', emoji: '📹', desc: 'HD видео уулзалт, AI Recap, Interpreter', color: '#F59E0B', tag: '🔥 Trending', tagColor: '#F59E0B', cat: 'comm', rating: 4.9, users: '8.5K+' },
  { id: 3, icon: '📧', name: 'Mail', emoji: '📧', desc: 'Шуурхай имэйл, schedule, AI summary', color: '#EF4444', tag: 'Шинэ', tagColor: '#EC4899', cat: 'comm', rating: 4.8, users: '6K+' },
  { id: 4, icon: '✨', name: 'AI туслах', emoji: '✨', desc: 'GPT-4 hэмийн чанартай, Монгол хэлээр', color: '#8B5CF6', tag: '⭐ Pro', tagColor: '#A855F7', cat: 'ai', rating: 4.9, users: '15K+' },
  { id: 5, icon: '📄', name: 'Docs', emoji: '📄', desc: 'Live document collaboration, AI заавар', color: '#EC4899', tag: 'Үндсэн', tagColor: '#10B981', cat: 'productivity', rating: 4.7, users: '9K+' },
  { id: 6, icon: '🗓️', name: 'Календарь', emoji: '🗓️', desc: 'Smart scheduling, meeting рекомендацууд', color: '#06B6D4', tag: 'Үндсэн', tagColor: '#10B981', cat: 'productivity', rating: 4.8, users: '7K+' },
  { id: 7, icon: '🎨', name: 'Whiteboard', emoji: '🎨', desc: 'Live drawing + sticky notes + templates', color: '#F97316', tag: 'Шинэ', tagColor: '#EC4899', cat: 'collab', rating: 4.7, users: '4K+' },
  { id: 8, icon: '📚', name: 'Knowledge', emoji: '📚', desc: 'Internal wiki, AI search, версия удирдлага', color: '#A855F7', tag: '⭐ Pro', tagColor: '#A855F7', cat: 'productivity', rating: 4.8, users: '5K+' },
  { id: 9, icon: '📰', name: 'News Feed', emoji: '📰', desc: 'Компанийн соёл, мэдэгдэл, gamification', color: '#1877F2', tag: '🔥 Trending', tagColor: '#F59E0B', cat: 'collab', rating: 4.9, users: '11K+' },
];

/* ==================== CUSTOMER LOGOS ==================== */
const CUSTOMERS = [
  { name: 'Walmart', emoji: '🏪', country: 'US' },
  { name: 'MCS Group', emoji: '🏢', country: 'MN' },
  { name: 'Хаан Банк', emoji: '🏦', country: 'MN' },
  { name: 'Mobicom', emoji: '📱', country: 'MN' },
  { name: 'Coca-Cola', emoji: '🥤', country: 'MN' },
  { name: 'APU', emoji: '🍺', country: 'MN' },
  { name: 'Unitel', emoji: '📡', country: 'MN' },
  { name: 'Gobi', emoji: '🐪', country: 'MN' },
  { name: 'Shangri-La', emoji: '🏨', country: 'MN' },
  { name: 'ХХБ', emoji: '💳', country: 'MN' },
];

/* ==================== SITE SWITCHER ==================== */
function SiteSwitcher({ current = 'workplace' }) {
  const [open, setOpen] = useState(false);

  const sites = [
    {
      id: 'corporate',
      title: 'Nexcore Корпорейт',
      desc: 'Бид хэн бэ?',
      url: 'https://www.nexcore.ltd',
      icon: '🏢',
      gradient: 'linear-gradient(135deg, #06B6D4, #3B82F6)',
    },
    {
      id: 'workplace',
      title: 'Nexcore Workplace',
      desc: '9 ажлын апп нэг газарт',
      url: 'https://np.nexcore.ltd',
      icon: '💼',
      gradient: 'linear-gradient(135deg, #10B981, #06B6D4)',
    },
    {
      id: 'softmarket',
      title: 'SoftMarket',
      desc: 'Програм хангамжийн дэлгүүр',
      url: 'https://softmaerket.vercel.app',
      icon: '🛍️',
      gradient: 'linear-gradient(135deg, #F59E0B, #EC4899)',
    },
  ];

  return (
    <div className="relative">
      <button
        onClick={() => setOpen(!open)}
        onBlur={() => setTimeout(() => setOpen(false), 200)}
        className="flex items-center gap-1.5 px-3 py-1.5 rounded-full bg-white/5 border border-white/10 text-white/80 text-xs font-medium hover:bg-white/10 hover:border-cyan-400/40 transition"
      >
        <span>Бүтээгдэхүүн</span>
        <ChevronDown className={`w-3 h-3 transition-transform ${open ? 'rotate-180' : ''}`} />
      </button>

      {open && (
        <div className="absolute top-full mt-2 left-0 min-w-[300px] bg-[#131829] border border-white/10 rounded-2xl p-2 shadow-2xl z-50">
          {sites.map(s => (
            <a
              key={s.id}
              href={s.url}
              target={s.id === current ? '_self' : '_blank'}
              rel="noopener noreferrer"
              className={`flex items-center gap-3 p-3 rounded-xl transition ${current === s.id ? 'bg-cyan-500/10 border border-cyan-500/30' : 'hover:bg-white/5'}`}
            >
              <div className="w-10 h-10 rounded-lg flex items-center justify-center text-xl flex-shrink-0" style={{ background: s.gradient }}>
                {s.icon}
              </div>
              <div className="flex-1 min-w-0">
                <div className="text-sm font-semibold text-white flex items-center gap-1.5">
                  {s.title}
                  {current === s.id && <span className="text-[9px] px-1.5 py-0.5 bg-cyan-500/20 text-cyan-400 rounded font-bold">ОДОО</span>}
                </div>
                <div className="text-[11px] text-white/50">{s.desc}</div>
              </div>
              {current !== s.id && <ExternalLink className="w-3.5 h-3.5 text-white/30" />}
            </a>
          ))}
        </div>
      )}
    </div>
  );
}

export default function Landing() {
  const [scrolled, setScrolled] = useState(false);
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [billing, setBilling] = useState('monthly');
  const [activeCat, setActiveCat] = useState('all');

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 20);
    window.addEventListener('scroll', onScroll);
    return () => window.removeEventListener('scroll', onScroll);
  }, []);

  const filteredApps = activeCat === 'all' ? APPS : APPS.filter(a => a.cat === activeCat);

  const plans = [
    { name: 'Үнэгүй', price: '0', subtitle: '/ сар', desc: 'Эхлэгчдэд тохиромжтой', features: ['5 хэрэглэгч хүртэл', 'Бүх үндсэн апп', '5GB файл хадгалалт', 'Чат & Видео уулзалт', 'Олон нийтийн дэмжлэг', '✗ Premium апп', '✗ Админ панель', '✗ 24/7 дэмжлэг'], badge: '🆓 Эхлэгчид', cta: 'Үнэгүй бүртгүүлэх', highlight: false, link: '/signup' },
    { name: 'Pro', price: '9,900', subtitle: '₮ / сар', desc: 'Идэвхтэй компаниудад', features: ['Үнэгүйн бүх давуу тал', 'News Feed & Groups', 'Nexcore Chat', '1TB файл хадгалалт', 'Multi-Company Groups', 'Имэйл дэмжлэг', 'Жилээр төлбөл 20% хямд', '✗ Ажлын байрны лиценз'], badge: '🔥 Хамгийн алдартай', cta: '14 хоног үнэгүй туршиж эхлэх →', highlight: true, link: '/signup' },
    { name: 'Бизнес', price: '28,800', subtitle: '₮ / сар', desc: '50+ ажилтантай байгууллагад', features: ['Pro-гийн бүх давуу тал', 'SSO & SCIM', 'Live Video 1080p', 'Knowledge Library', 'Админ панель + аналитик', 'Тусгайлсан менежер', '24/7 дэмжлэг', 'API хандалт'], badge: '🏢 Корпорейт', cta: 'Бизнес захиалах →', highlight: false, link: '/signup' },
  ];

  return (
    <div className="min-h-screen bg-[#0A0E1F] text-white overflow-x-hidden relative">
      {/* Animated mesh blobs */}
      <div className="blob-1" />
      <div className="blob-2" />
      <div className="blob-3" />

      {/* ========== NAVBAR ========== */}
      <div className="sticky top-0 z-50">
        <MigrationBanner />
        <header className={`transition-all ${scrolled ? 'bg-[#0A0E1F]/90 backdrop-blur-lg border-b border-white/10' : 'bg-transparent'}`}>
          <div className="max-w-7xl mx-auto px-6 lg:px-8 h-16 flex items-center justify-between">
            <Link to="/" className="flex items-center gap-2.5">
              <div className="w-9 h-9 rounded-xl flex items-center justify-center text-white font-bold" style={{ background: 'linear-gradient(135deg, #06B6D4, #3B82F6)' }}>N</div>
              <div>
                <div className="font-bold text-lg leading-none">Nexcore <span className="text-cyan-400">Platforms</span></div>
                <div className="text-[10px] text-white/40 leading-none mt-0.5">from Mongolia 🇲🇳</div>
              </div>
            </Link>

            <nav className="hidden lg:flex items-center gap-8 text-sm">
              <SiteSwitcher current="workplace" />
              <a href="#apps" className="text-white/70 hover:text-white transition">Аппууд</a>
              <a href="#features" className="text-white/70 hover:text-white transition">Боломжууд</a>
              <a href="#customers" className="text-white/70 hover:text-white transition">Хэрэглэгчид</a>
              <a href="#pricing" className="text-white/70 hover:text-white transition">Үнэ</a>
              <Link to="/about" className="text-white/70 hover:text-white transition">Бидний тухай</Link>
            </nav>

            <div className="hidden lg:flex items-center gap-3">
              <button className="w-9 h-9 rounded-lg hover:bg-white/5 flex items-center justify-center" title="Хайлт" aria-label="Хайлт">
                <Search className="w-4 h-4" />
              </button>
              <Link to="/login" className="text-sm text-white/80 hover:text-white px-3 py-2">Нэвтрэх</Link>
              <Link to="/signup" className="text-sm bg-gradient-to-r from-cyan-500 to-blue-500 text-white px-4 py-2 rounded-full font-semibold hover:scale-105 transition shadow-lg shadow-cyan-500/30">Үнэгүй эхлэх</Link>
            </div>

            <button className="lg:hidden" onClick={() => setMobileMenuOpen(!mobileMenuOpen)} aria-label={mobileMenuOpen ? "Цэс хаах" : "Цэс нээх"}>
              {mobileMenuOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
            </button>
          </div>

          {/* Mobile menu */}
          {mobileMenuOpen && (
            <div className="lg:hidden bg-[#0A0E1F] border-t border-white/10 px-6 py-5">
              <nav className="flex flex-col gap-4 text-sm mb-4">
                <a href="#apps" onClick={() => setMobileMenuOpen(false)}>Аппууд</a>
                <a href="#features" onClick={() => setMobileMenuOpen(false)}>Боломжууд</a>
                <a href="#pricing" onClick={() => setMobileMenuOpen(false)}>Үнэ</a>
                <Link to="/about" onClick={() => setMobileMenuOpen(false)}>Бидний тухай</Link>
              </nav>
              <div className="flex gap-2">
                <Link to="/login" className="flex-1 text-center py-2 rounded-full border border-white/20">Нэвтрэх</Link>
                <Link to="/signup" className="flex-1 text-center py-2 rounded-full bg-gradient-to-r from-cyan-500 to-blue-500 font-semibold">Эхлэх</Link>
              </div>
            </div>
          )}
        </header>
      </div>

      {/* ========== HERO ========== */}
      <section className="relative pt-12 pb-20 lg:pt-20 lg:pb-28 px-6">
        <div className="absolute inset-0 grid-bg opacity-20 pointer-events-none" />
        {/* Particles */}
        {[...Array(15)].map((_, i) => (
          <div key={i} className="particle" style={{ left: `${Math.random() * 100}%`, bottom: '-10px', animationDelay: `${Math.random() * 15}s`, animationDuration: `${10 + Math.random() * 10}s`, opacity: Math.random() * 0.5 + 0.2 }} />
        ))}

        <div className="relative max-w-7xl mx-auto z-10">
          {/* Top badge */}
          <motion.div
            initial={{ opacity: 0, y: -20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6 }}
            className="flex justify-center mb-8"
          >
            <div className="inline-flex items-center gap-2 px-4 py-1.5 rounded-full bg-cyan-500/10 border border-cyan-500/30 text-xs font-semibold backdrop-blur">
              <span>🇲🇳</span>
              <span className="bg-gradient-to-r from-cyan-400 to-blue-400 bg-clip-text text-transparent font-bold">2,400+ компанийн сонголт</span>
              <span className="text-white/40">·</span>
              <span className="text-white/60">Монголд бүтсэн</span>
            </div>
          </motion.div>

          {/* Headline */}
          <div className="text-center max-w-4xl mx-auto mb-12">
            <motion.h1
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.7, delay: 0.2 }}
              className="font-display text-5xl sm:text-6xl lg:text-7xl font-bold tracking-tight mb-6 leading-[0.95]"
            >
              9 ажлын апп <span className="gradient-shine">нэг газарт</span>
            </motion.h1>
            <motion.p
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.7, delay: 0.4 }}
              className="text-lg lg:text-xl text-white/60 max-w-2xl mx-auto"
            >
              Чат, видео уулзалт, имэйл, AI туслах, документ, календарь. Бүгд <strong className="text-cyan-400">Монгол хэл дээр</strong>, бүгд нэг бүртгэлтэй, бүгд монгол төгрөгөөр.
            </motion.p>

            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.7, delay: 0.6 }}
              className="flex flex-wrap items-center justify-center gap-4 mt-10"
            >
              <Link to="/signup" className="bg-gradient-to-r from-cyan-500 to-blue-500 text-white px-7 py-3.5 rounded-full font-semibold flex items-center gap-2 hover:scale-105 transition shadow-2xl shadow-cyan-500/40 glow-cyan">
                Үнэгүй эхлэх
                <ArrowRight className="w-4 h-4" />
              </Link>
              <a href="#apps" className="px-6 py-3.5 rounded-full font-medium flex items-center gap-2 border border-white/20 hover:bg-white/5 transition">
                <Play className="w-4 h-4" fill="currentColor" />
                Аппуудыг үзэх
              </a>
            </motion.div>
          </div>

          {/* Hero stats grid (SoftMarket style) */}
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8, delay: 0.8 }}
            className="grid grid-cols-2 lg:grid-cols-4 gap-4 mt-16 max-w-5xl mx-auto"
          >
            {[
              { num: '2,400+', label: 'Идэвхтэй компани', color: '#06B6D4' },
              { num: '48K+', label: 'Хэрэглэгч', color: '#3B82F6' },
              { num: '4.9★', label: 'Дундаж үнэлгээ', color: '#F59E0B' },
              { num: '9', label: 'Бүх ажлын апп', color: '#A855F7' },
            ].map((s, i) => (
              <motion.div
                key={i}
                whileHover={{ y: -4 }}
                className="bg-white/5 border border-white/10 rounded-2xl p-5 text-center backdrop-blur hover:border-cyan-400/30 transition"
              >
                <div className="font-display text-3xl lg:text-4xl font-bold mb-1" style={{ color: s.color }}>{s.num}</div>
                <div className="text-xs text-white/60">{s.label}</div>
              </motion.div>
            ))}
          </motion.div>

          {/* Hero featured cards (SoftMarket style — 3 product highlights) */}
          <motion.div
            initial={{ opacity: 0, y: 40 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8, delay: 1.0 }}
            className="grid sm:grid-cols-2 lg:grid-cols-3 gap-5 mt-12 max-w-5xl mx-auto"
          >
            {[
              { icon: '💬', name: 'Nexcore Chat', desc: '1-on-1, групп, voice notes', color: '#10B981', tag: 'Үндсэн', tagColor: '#10B981' },
              { icon: '📹', name: 'Nexcore Meet', desc: 'AI Recap + Live Interpreter', color: '#F59E0B', tag: '🔥 Trending', tagColor: '#F59E0B' },
              { icon: '✨', name: 'Nexcore AI', desc: 'GPT-4 hэмийн ухаалаг туслах', color: '#8B5CF6', tag: '⭐ Pro', tagColor: '#A855F7' },
            ].map((p, i) => (
              <motion.div
                key={i}
                whileHover={{ y: -8, scale: 1.02 }}
                className="bg-white/[0.06] border border-white/10 rounded-2xl p-5 backdrop-blur cursor-pointer hover:border-cyan-400/40 transition relative overflow-hidden group"
              >
                <div className="absolute top-3 right-3 px-2.5 py-1 rounded-full text-[10px] font-bold" style={{ background: `${p.tagColor}30`, color: p.tagColor, border: `1px solid ${p.tagColor}60` }}>{p.tag}</div>
                <div className="w-14 h-14 rounded-2xl flex items-center justify-center text-3xl mb-3 group-hover:scale-110 transition" style={{ background: `linear-gradient(135deg, ${p.color}aa, ${p.color}66)` }}>
                  {p.icon}
                </div>
                <div className="font-bold text-lg mb-1">{p.name}</div>
                <div className="text-xs text-white/60">{p.desc}</div>
                <div className="flex items-center justify-between mt-3 pt-3 border-t border-white/5">
                  <div className="flex items-center gap-1 text-amber-400 text-xs">
                    {[0,1,2,3,4].map(k => <Star key={k} className="w-3 h-3" fill="currentColor" />)}
                    <span className="text-white/60 ml-1">4.9</span>
                  </div>
                  <ArrowRight className="w-4 h-4 text-cyan-400 group-hover:translate-x-1 transition" />
                </div>
              </motion.div>
            ))}
          </motion.div>
        </div>
      </section>

      {/* ========== APPS SHOWCASE (SoftMarket grid) ========== */}
      <section id="apps" className="relative py-24 px-6 scroll-mt-20">
        <div className="max-w-7xl mx-auto">
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.7 }}
            className="text-center max-w-2xl mx-auto mb-12"
          >
            <div className="text-xs font-semibold uppercase tracking-[0.2em] text-cyan-400 mb-4">— Аппууд</div>
            <h2 className="font-display text-4xl lg:text-5xl font-bold tracking-tight mb-5">
              🛍️ Бүх ажлын <span className="gradient-shine">хэрэгсэл</span>
            </h2>
            <p className="text-lg text-white/60">Microsoft 365, Google Workspace-ыг орлох 9 апп — бүгд нэг бүртгэлтэй</p>
          </motion.div>

          {/* Category filter chips */}
          <div className="flex flex-wrap items-center justify-center gap-2 mb-10">
            {CATEGORIES.map(c => (
              <button
                key={c.id}
                onClick={() => setActiveCat(c.id)}
                className={`px-4 py-2 rounded-full text-sm font-medium transition flex items-center gap-2 ${activeCat === c.id ? 'bg-gradient-to-r from-cyan-500 to-blue-500 text-white shadow-lg shadow-cyan-500/30' : 'bg-white/5 border border-white/10 text-white/70 hover:bg-white/10 hover:text-white'}`}
              >
                <span>{c.icon}</span>
                {c.label}
              </button>
            ))}
          </div>

          {/* Apps grid */}
          <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-5">
            {filteredApps.map((a, i) => (
              <motion.div
                key={a.id}
                initial={{ opacity: 0, y: 40 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true, margin: '-50px' }}
                transition={{ duration: 0.5, delay: i * 0.05, ease: [0.16, 1, 0.3, 1] }}
                whileHover={{ y: -8 }}
                className="bg-white/[0.04] border border-white/10 rounded-3xl p-6 hover:border-cyan-400/40 transition cursor-pointer relative overflow-hidden group tilt-card"
              >
                {/* Tag */}
                <div className="absolute top-4 right-4 px-2.5 py-1 rounded-full text-[10px] font-bold" style={{ background: `${a.tagColor}30`, color: a.tagColor, border: `1px solid ${a.tagColor}60` }}>
                  {a.tag}
                </div>

                {/* Big icon */}
                <div className="w-16 h-16 rounded-2xl flex items-center justify-center text-4xl mb-4 group-hover:scale-110 transition shadow-2xl" style={{ background: `linear-gradient(135deg, ${a.color}, ${a.color}99)`, boxShadow: `0 12px 30px ${a.color}40` }}>
                  {a.emoji}
                </div>

                {/* Title + desc */}
                <div className="font-display text-2xl font-bold mb-1.5">{a.name}</div>
                <p className="text-sm text-white/60 mb-4 leading-relaxed">{a.desc}</p>

                {/* Stats row */}
                <div className="flex items-center justify-between mb-4 text-xs text-white/50">
                  <div className="flex items-center gap-1 text-amber-400">
                    {[0,1,2,3,4].map(k => <Star key={k} className="w-3 h-3" fill="currentColor" />)}
                    <span className="text-white/70 ml-1 font-semibold">{a.rating}</span>
                  </div>
                  <div>{a.users} хэрэглэгч</div>
                </div>

                {/* Action */}
                <Link to="/apps" className="w-full bg-gradient-to-r from-cyan-500 to-blue-500 text-white py-2.5 rounded-xl text-sm font-semibold flex items-center justify-center gap-2 hover:scale-[1.02] transition press-effect">
                  <Play className="w-3.5 h-3.5" fill="currentColor" />
                  Туршиж үзэх
                </Link>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* ========== CUSTOMER LOGOS (SoftMarket "Тэдэнтэй хамт ашигладаг" style) ========== */}
      <section id="customers" className="py-20 px-6 border-y border-white/5">
        <div className="max-w-7xl mx-auto">
          <motion.div
            initial={{ opacity: 0 }}
            whileInView={{ opacity: 1 }}
            viewport={{ once: true }}
            transition={{ duration: 0.7 }}
            className="text-center mb-12"
          >
            <div className="text-xs font-semibold uppercase tracking-[0.2em] text-cyan-400 mb-3">— Хэрэглэгчид</div>
            <h2 className="font-display text-3xl lg:text-4xl font-bold mb-3">Тэдэнтэй хамт <span className="gradient-shine">ашигладаг</span></h2>
            <p className="text-white/60">Монголын тэргүүлэх компаниуд Nexcore Platforms-аар ажилладаг</p>
          </motion.div>

          <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-5 gap-3">
            {CUSTOMERS.map((c, i) => (
              <motion.div
                key={i}
                initial={{ opacity: 0, scale: 0.9 }}
                whileInView={{ opacity: 1, scale: 1 }}
                viewport={{ once: true }}
                transition={{ duration: 0.4, delay: i * 0.04 }}
                whileHover={{ y: -4, scale: 1.05 }}
                className="bg-white/[0.04] border border-white/10 rounded-2xl px-4 py-5 text-center hover:border-cyan-400/40 transition cursor-default"
              >
                <div className="text-3xl mb-2">{c.emoji}</div>
                <div className="font-semibold text-sm">{c.name}</div>
                <div className="text-[10px] text-white/40 mt-0.5">🇲🇳 {c.country}</div>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* ========== FEATURES (3 columns SoftMarket style) ========== */}
      <section id="features" className="py-24 px-6 scroll-mt-20">
        <div className="max-w-7xl mx-auto">
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.7 }}
            className="text-center max-w-2xl mx-auto mb-16"
          >
            <div className="text-xs font-semibold uppercase tracking-[0.2em] text-cyan-400 mb-4">— Боломжууд</div>
            <h2 className="font-display text-4xl lg:text-5xl font-bold tracking-tight mb-5">
              Яагаад <span className="gradient-shine">Nexcore?</span>
            </h2>
          </motion.div>

          <div className="grid lg:grid-cols-3 gap-6">
            {[
              { icon: '🇲🇳', title: 'Монгол брэнд', desc: 'Монгол хэл дээр бүх UI, Монгол хөгжүүлэгчид, Монгол төгрөгөөр төлбөр', color: '#06B6D4' },
              { icon: '⚡', title: 'Бүгд нэгдсэн', desc: 'Чат, видео, имэйл, документ — нэг бүртгэлтэй, нэг үнэтэй, нэг сайт', color: '#10B981' },
              { icon: '✨', title: 'AI суурилсан', desc: 'AI recap, interpreter, AI summary — бусад платформ-аас илүү ухаалаг', color: '#A855F7' },
              { icon: '🔄', title: 'Meta migration', desc: 'Meta Workplace-аас 15 минутад автомат шилжүүлэх tool', color: '#F59E0B' },
              { icon: '🔒', title: 'Хамгаалалт', desc: 'SSO, SCIM, 2FA, end-to-end encryption, GDPR compliance', color: '#EF4444' },
              { icon: '💰', title: 'Хямдхан үнэ', desc: 'Microsoft Teams, Zoom, Google Workspace-оос 30-60% хямд', color: '#3B82F6' },
            ].map((f, i) => (
              <motion.div
                key={i}
                initial={{ opacity: 0, y: 30 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.5, delay: i * 0.08 }}
                whileHover={{ y: -8 }}
                className="bg-white/[0.04] border border-white/10 rounded-3xl p-7 hover:border-cyan-400/40 transition group"
              >
                <div className="w-14 h-14 rounded-2xl flex items-center justify-center text-3xl mb-4 group-hover:scale-110 transition" style={{ background: `linear-gradient(135deg, ${f.color}aa, ${f.color}55)` }}>
                  {f.icon}
                </div>
                <div className="font-display text-xl font-bold mb-2">{f.title}</div>
                <p className="text-sm text-white/60 leading-relaxed">{f.desc}</p>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* ========== COMPARISON TABLE ========== */}
      <section className="py-24 px-6">
        <div className="max-w-6xl mx-auto">
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.7 }}
            className="text-center max-w-2xl mx-auto mb-12"
          >
            <div className="text-xs font-semibold uppercase tracking-[0.2em] text-cyan-400 mb-4">— Харьцуулалт</div>
            <h2 className="font-display text-4xl lg:text-5xl font-bold tracking-tight mb-5">
              Бусдаас <span className="gradient-shine">илүү</span>
            </h2>
            <p className="text-lg text-white/60">Microsoft Teams, Google Workspace, Zoom, Meta Workplace бүгдтэй харьцуулалт</p>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.7 }}
            className="bg-white/[0.04] border border-white/10 rounded-3xl overflow-hidden"
          >
            <div className="overflow-x-auto">
              <table className="w-full text-sm">
                <thead>
                  <tr className="bg-white/5">
                    <th className="text-left px-6 py-4 text-white/60 font-medium">Онцлог</th>
                    <th className="px-4 py-4 text-cyan-400 font-bold">Nexcore</th>
                    <th className="px-4 py-4 text-white/60 font-medium">Meta</th>
                    <th className="px-4 py-4 text-white/60 font-medium">Zoom</th>
                    <th className="px-4 py-4 text-white/60 font-medium">Teams</th>
                    <th className="px-4 py-4 text-white/60 font-medium">Google</th>
                  </tr>
                </thead>
                <tbody>
                  {[
                    ['Бүх нэг газар', '✓', '✗', '✗', '✗', '✗'],
                    ['Видео+Чат+Feed', '✓', '✓', '~', '~', '✗'],
                    ['AI туслах', '✓', '✗', '~', '✓', '~'],
                    ['Meta migration', '✓', '—', '~', '✗', '✗'],
                    ['Монгол хэл', '✓', '~', '✗', '~', '✗'],
                    ['Үнэ (₮/сар)', '9,900', '—', '21,600', '14,400', '23,400'],
                  ].map((row, ri) => (
                    <tr key={ri} className="border-t border-white/5 hover:bg-white/[0.02]">
                      <td className="px-6 py-4 font-medium text-white/80">{row[0]}</td>
                      {row.slice(1).map((cell, ci) => (
                        <td key={ci} className={`px-4 py-4 text-center font-bold ${ci === 0 ? 'bg-cyan-500/10' : ''}`}>
                          {cell === '✓' ? <span className="text-green-400">✓</span> :
                           cell === '✗' ? <span className="text-white/30">✗</span> :
                           cell === '~' ? <span className="text-amber-400">~</span> :
                           cell === '—' ? <span className="text-white/30">—</span> :
                           <span className={ci === 0 ? 'text-cyan-400' : 'text-white/70'}>{cell}</span>}
                        </td>
                      ))}
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </motion.div>
        </div>
      </section>

      {/* ========== PRICING (SoftMarket Pro/Бизнес style) ========== */}
      <section id="pricing" className="py-24 px-6 scroll-mt-20">
        <div className="max-w-6xl mx-auto">
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.7 }}
            className="text-center max-w-2xl mx-auto mb-12"
          >
            <div className="text-xs font-semibold uppercase tracking-[0.2em] text-cyan-400 mb-4">— Үнэ</div>
            <h2 className="font-display text-4xl lg:text-6xl font-bold tracking-tight mb-5">
              Энгийн, <span className="gradient-shine">шударга</span> үнэ
            </h2>
            <p className="text-lg text-white/60">
              <strong className="text-cyan-400">5 хэрэглэгч хүртэл үнэгүй.</strong> Нуугдсан төлбөр байхгүй. Хүссэн үедээ цуцлах боломжтой.
            </p>
          </motion.div>

          {/* Billing toggle */}
          <div className="flex justify-center mb-12">
            <div className="inline-flex items-center bg-white/5 border border-white/10 rounded-full p-1.5 relative">
              <button
                onClick={() => setBilling('monthly')}
                className={`relative z-10 px-5 sm:px-7 py-2.5 text-sm font-semibold rounded-full transition-colors ${billing === 'monthly' ? 'text-white' : 'text-white/60'}`}
              >
                Сар бүр
              </button>
              <button
                onClick={() => setBilling('yearly')}
                className={`relative z-10 px-5 sm:px-7 py-2.5 text-sm font-semibold rounded-full transition-colors flex items-center gap-2 ${billing === 'yearly' ? 'text-white' : 'text-white/60'}`}
              >
                Жилээр
                <span className="text-[10px] bg-green-500/20 text-green-400 px-2 py-0.5 rounded-full font-bold">-20%</span>
              </button>
              <div
                className={`absolute top-1.5 bottom-1.5 bg-gradient-to-r from-cyan-500 to-blue-500 rounded-full transition-all duration-300 shadow-lg shadow-cyan-500/30`}
                style={{
                  left: billing === 'monthly' ? '6px' : 'calc(50% + 0px)',
                  right: billing === 'monthly' ? 'calc(50% + 0px)' : '6px',
                }}
              />
            </div>
          </div>

          <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-5">
            {plans.map((p, i) => (
              <motion.div
                key={i}
                initial={{ opacity: 0, y: 40 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.6, delay: i * 0.1, ease: [0.16, 1, 0.3, 1] }}
                whileHover={{ y: -10 }}
                className={`relative rounded-3xl p-7 border transition tilt-card ${
                  p.highlight
                    ? 'bg-gradient-to-br from-cyan-500/20 to-blue-500/20 border-cyan-400/40 lg:scale-105 shadow-2xl shadow-cyan-500/20 glow-cyan'
                    : 'bg-white/[0.04] border-white/10 hover:border-cyan-400/30'
                }`}
              >
                {/* Badge */}
                <div className="inline-flex items-center px-3 py-1 rounded-full text-[10px] font-bold mb-4" style={{ background: p.highlight ? 'linear-gradient(135deg, #06B6D4, #3B82F6)' : 'rgba(255,255,255,0.05)', color: p.highlight ? '#fff' : 'rgba(255,255,255,0.6)', border: p.highlight ? 'none' : '1px solid rgba(255,255,255,0.1)' }}>
                  {p.badge}
                </div>

                <div className="font-display text-2xl font-bold mb-1">{p.name}</div>
                <div className="text-sm text-white/60 mb-5">{p.desc}</div>

                {/* Price */}
                <div className="flex items-baseline gap-1 mb-6">
                  <span className="font-display text-5xl font-bold">
                    {billing === 'yearly' && p.price !== '0' && p.price !== '28,800'
                      ? Math.round(parseInt(p.price.replace(',', '')) * 0.8).toLocaleString()
                      : billing === 'yearly' && p.price === '28,800'
                      ? '23,040'
                      : p.price}
                  </span>
                  <span className="text-white/60 text-sm">{p.subtitle}</span>
                </div>

                <Link
                  to={p.link}
                  className={`w-full block text-center py-3 rounded-xl font-semibold mb-6 transition ${
                    p.highlight
                      ? 'bg-gradient-to-r from-cyan-500 to-blue-500 text-white hover:scale-[1.02]'
                      : 'bg-white/5 border border-white/10 hover:bg-white/10'
                  }`}
                >
                  {p.cta}
                </Link>

                {/* Features */}
                <div className="space-y-2.5">
                  {p.features.map((f, fi) => (
                    <div key={fi} className="flex items-start gap-2 text-sm">
                      {f.startsWith('✗') ? (
                        <>
                          <X className="w-4 h-4 text-white/30 mt-0.5 flex-shrink-0" />
                          <span className="text-white/30">{f.slice(2)}</span>
                        </>
                      ) : (
                        <>
                          <Check className={`w-4 h-4 mt-0.5 flex-shrink-0 ${p.highlight ? 'text-cyan-400' : 'text-green-400'}`} />
                          <span className="text-white/80">{f}</span>
                        </>
                      )}
                    </div>
                  ))}
                </div>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* ========== FINAL CTA ========== */}
      <section className="py-24 px-6">
        <div className="max-w-5xl mx-auto">
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.8 }}
            className="relative bg-gradient-to-br from-cyan-500/20 to-blue-500/20 border border-cyan-400/30 rounded-3xl p-12 lg:p-16 text-center overflow-hidden glow-cyan"
          >
            <div className="blob-1" style={{ width: '300px', height: '300px', top: '-50px', left: '-50px' }} />
            <div className="blob-2" style={{ width: '300px', height: '300px', bottom: '-50px', right: '-50px' }} />

            <div className="relative z-10">
              <div className="inline-flex items-center gap-2 px-4 py-1.5 rounded-full bg-cyan-500/20 border border-cyan-400/40 text-xs font-semibold mb-6">
                ⏰ Meta Workplace 2026.05.31-нд хаагдана
              </div>

              <h2 className="font-display text-4xl lg:text-6xl font-bold tracking-tight mb-5">
                Шилжих <span className="gradient-shine">цаг боллоо</span>
              </h2>
              <p className="text-lg text-white/70 max-w-2xl mx-auto mb-8">
                Migration tool ашиглаж 15 минутад бүх дата шилжүүлж аваарай. 5 хэрэглэгч хүртэл бүрэн үнэгүй.
              </p>
              <div className="flex flex-wrap items-center justify-center gap-3">
                <Link to="/migrate" className="bg-gradient-to-r from-cyan-500 to-blue-500 text-white px-7 py-3.5 rounded-full font-semibold flex items-center gap-2 hover:scale-105 transition shadow-2xl shadow-cyan-500/40">
                  Шилжих туслалцаа →
                </Link>
                <Link to="/signup" className="bg-white/10 backdrop-blur border border-white/20 px-7 py-3.5 rounded-full font-semibold hover:bg-white/15 transition">
                  Үнэгүй эхлэх
                </Link>
              </div>
            </div>
          </motion.div>
        </div>
      </section>

      {/* ========== FOOTER ========== */}
      <footer className="border-t border-white/10 py-16 px-6">
        <div className="max-w-7xl mx-auto">
          <div className="grid lg:grid-cols-5 gap-8 mb-12">
            <div className="lg:col-span-2">
              <div className="flex items-center gap-2.5 mb-4">
                <div className="w-9 h-9 rounded-xl flex items-center justify-center text-white font-bold" style={{ background: 'linear-gradient(135deg, #06B6D4, #3B82F6)' }}>N</div>
                <div className="font-bold text-lg">Nexcore <span className="text-cyan-400">Platforms</span></div>
              </div>
              <p className="text-sm text-white/60 max-w-sm">
                Монголын ажлын платформын хамгийн найдвартай сонголт. 2026 оноос хойш компаниудыг холбож байна.
              </p>
            </div>

            <div>
              <div className="font-semibold mb-3 text-sm">Бүтээгдэхүүн</div>
              <div className="space-y-2 text-sm text-white/60">
                <a href="https://www.nexcore.ltd" target="_blank" rel="noopener" className="block hover:text-white">🏢 Корпорейт</a>
                <a href="https://np.nexcore.ltd" className="block hover:text-cyan-400">💼 Workplace <span className="text-[10px] text-cyan-500">(ОДОО)</span></a>
                <a href="https://softmaerket.vercel.app" target="_blank" rel="noopener" className="block hover:text-white">🛍️ SoftMarket</a>
                <Link to="/apps" className="block hover:text-white">📱 Бүх апп</Link>
                <Link to="/migrate" className="block hover:text-white">🔄 Migration</Link>
              </div>
            </div>

            <div>
              <div className="font-semibold mb-3 text-sm">Компани</div>
              <div className="space-y-2 text-sm text-white/60">
                <Link to="/about" className="block hover:text-white">Бидний тухай</Link>
                <Link to="/contact" className="block hover:text-white">Холбоо барих</Link>
                <Link to="/faq" className="block hover:text-white">FAQ</Link>
              </div>
            </div>

            <div>
              <div className="font-semibold mb-3 text-sm">Тусламж</div>
              <div className="space-y-2 text-sm text-white/60">
                <Link to="/contact" className="block hover:text-white">Холбоо барих</Link>
                <a href="#" className="block hover:text-white">Нөхцөл</a>
                <a href="#" className="block hover:text-white">Нууцлал</a>
                <Link to="/faq" className="block hover:text-white">FAQ</Link>
              </div>
            </div>
          </div>

          <div className="pt-8 border-t border-white/10 flex flex-col sm:flex-row items-center justify-between gap-4 text-sm text-white/40">
            <div>© 2026 Nexcore Platforms. Бүх эрх хуулиар хамгаалагдсан.</div>
            <div className="flex items-center gap-2">
              🇲🇳 Монголд бүтсэн
            </div>
          </div>
        </div>
      </footer>
    </div>
  );
}
