import { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { useTenant } from '../contexts/TenantContext.jsx';
import {
  Building2, Globe, CreditCard, User, ArrowRight, ArrowLeft,
  CheckCircle2, Check, X, Mail, Lock, Sparkles, Shield, Zap
} from 'lucide-react';

export default function Signup() {
  const { tenants, addTenant } = useTenant();
  const navigate = useNavigate();
  const [step, setStep] = useState(1);
  const [loading, setLoading] = useState(false);
  const [data, setData] = useState({
    name: '',
    country: 'MN',
    subdomain: '',
    plan: 'Premium',
    adminName: '',
    adminEmail: '',
    password: '',
  });

  const subdomainAvailable = data.subdomain.length >= 3 &&
    !tenants.find(t => t.subdomain === data.subdomain);

  function next() { setStep(s => Math.min(4, s + 1)); }
  function back() { setStep(s => Math.max(1, s - 1)); }

  function handleSubmit() {
    setLoading(true);
    setTimeout(() => {
      const newTenant = {
        id: data.subdomain,
        name: data.name,
        subdomain: data.subdomain,
        logo: data.name[0].toUpperCase(),
        color: ['#6366F1', '#10B981', '#F59E0B', '#EC4899', '#A855F7'][Math.floor(Math.random() * 5)],
        users: 1,
        plan: data.plan,
        revenue: data.plan === 'Core' ? 4 : data.plan === 'Premium' ? 8 : 0,
        status: 'active',
        country: data.country,
        joined: new Date().toISOString().split('T')[0],
      };
      addTenant(newTenant);
      setLoading(false);
      navigate('/apps');
    }, 1500);
  }

  return (
    <div className="min-h-screen bg-[#FAFAFC] flex flex-col" style={{ fontFamily: "'Geist', system-ui, sans-serif" }}>
      <style>{`
        @import url('https://fonts.googleapis.com/css2?family=Bricolage+Grotesque:opsz,wght@12..96,500;12..96,600;12..96,700&family=Geist:wght@400;500;600;700&family=JetBrains+Mono:wght@400;500&display=swap');
        .font-display { font-family: 'Bricolage Grotesque', sans-serif; letter-spacing: -0.02em; }
        .font-mono { font-family: 'JetBrains Mono', monospace; }
        @keyframes slideIn { from { opacity: 0; transform: translateX(20px) } to { opacity: 1; transform: translateX(0) } }
        .anim-slide { animation: slideIn 0.4s cubic-bezier(0.22, 1, 0.36, 1); }
      `}</style>

      {/* Header */}
      <header className="border-b border-black/5 px-6 py-4 flex items-center justify-between">
        <Link to="/" className="flex items-center gap-2.5">
          <div className="w-9 h-9 rounded-xl bg-[#1877F2] flex items-center justify-center text-white font-display font-bold">N</div>
          <span className="font-display font-bold text-xl">Nexcore Platforms</span>
        </Link>
        <Link to="/login" className="text-sm text-black/60 hover:text-black">Бүртгэлтэй юу? <span className="text-[#1877F2] font-medium">Нэвтрэх →</span></Link>
      </header>

      {/* Progress */}
      <div className="px-6 py-6 max-w-3xl mx-auto w-full">
        <div className="flex items-center gap-3">
          {[1, 2, 3, 4].map((n) => (
            <div key={n} className="flex-1">
              <div className={`h-1.5 rounded-full transition-colors ${n <= step ? 'bg-[#1877F2]' : 'bg-black/10'}`} />
              <div className="mt-2 text-xs flex items-center gap-1.5">
                {n < step ? <CheckCircle2 className="w-3 h-3 text-[#1877F2]" /> : <div className={`w-3 h-3 rounded-full flex items-center justify-center text-[8px] font-bold ${n === step ? 'bg-[#1877F2] text-white' : 'bg-black/10 text-black/40'}`}>{n}</div>}
                <span className={`${n === step ? 'font-semibold text-black' : 'text-black/50'}`}>
                  {['Компани', 'Subdomain', 'Багц', 'Админ'][n-1]}
                </span>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Content */}
      <div className="flex-1 flex items-center justify-center p-6">
        <div className="w-full max-w-xl">
          {step === 1 && <Step1 data={data} setData={setData} onNext={next} />}
          {step === 2 && <Step2 data={data} setData={setData} onNext={next} onBack={back} available={subdomainAvailable} />}
          {step === 3 && <Step3 data={data} setData={setData} onNext={next} onBack={back} />}
          {step === 4 && <Step4 data={data} setData={setData} onSubmit={handleSubmit} onBack={back} loading={loading} />}
        </div>
      </div>
    </div>
  );
}

function Step1({ data, setData, onNext }) {
  return (
    <div className="anim-slide">
      <div className="text-center mb-8">
        <div className="w-14 h-14 rounded-2xl bg-[#1877F2]/10 flex items-center justify-center mx-auto mb-4">
          <Building2 className="w-6 h-6 text-[#1877F2]" />
        </div>
        <h2 className="font-display text-3xl font-bold mb-2">Танай компанийн нэр</h2>
        <p className="text-black/60">Workplace орчин үүсгэх эхний алхам</p>
      </div>

      <div className="bg-white rounded-2xl border border-black/5 p-6 space-y-5">
        <div>
          <label className="text-xs font-medium text-black/60 block mb-2">Компанийн албан ёсны нэр</label>
          <input
            value={data.name}
            onChange={(e) => setData({ ...data, name: e.target.value })}
            autoFocus
            placeholder="Жишээ: MCS Group"
            className="w-full px-4 py-3.5 bg-[#FAFAFC] border border-black/10 rounded-xl text-sm focus:outline-none focus:border-[#1877F2] focus:ring-4 focus:ring-[#1877F2]/10 transition"
          />
        </div>
        <div>
          <label className="text-xs font-medium text-black/60 block mb-2">Үндсэн улс</label>
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
            {[
              { code: 'MN', flag: '🇲🇳', name: 'Монгол' },
              { code: 'US', flag: '🇺🇸', name: 'United States' },
            ].map((c) => (
              <button
                key={c.code}
                onClick={() => setData({ ...data, country: c.code })}
                className={`p-3 rounded-xl border text-left flex items-center gap-2 transition ${data.country === c.code ? 'border-[#1877F2] bg-[#1877F2]/5' : 'border-black/10 hover:border-black/20'}`}
              >
                <span className="text-xl">{c.flag}</span>
                <span className="text-sm font-medium">{c.name}</span>
                {data.country === c.code && <CheckCircle2 className="w-4 h-4 text-[#1877F2] ml-auto" />}
              </button>
            ))}
          </div>
        </div>
      </div>

      <button
        onClick={onNext}
        disabled={data.name.length < 2}
        className="w-full mt-6 bg-[#1877F2] hover:bg-[#0866FF] text-white py-3.5 rounded-xl font-semibold flex items-center justify-center gap-2 disabled:opacity-50 disabled:cursor-not-allowed transition"
      >
        Үргэлжлүүлэх <ArrowRight className="w-4 h-4" />
      </button>
    </div>
  );
}

function Step2({ data, setData, onNext, onBack, available }) {
  // Auto-suggest subdomain from name
  const suggested = data.name.toLowerCase().replace(/[^a-z0-9]/g, '').slice(0, 12);

  return (
    <div className="anim-slide">
      <div className="text-center mb-8">
        <div className="w-14 h-14 rounded-2xl bg-[#1877F2]/10 flex items-center justify-center mx-auto mb-4">
          <Globe className="w-6 h-6 text-[#1877F2]" />
        </div>
        <h2 className="font-display text-3xl font-bold mb-2">Танай хаягийг сонгоно уу</h2>
        <p className="text-black/60">Энэ хаяг нь <strong>{data.name}</strong>-ын Workplace-д орох цонх</p>
      </div>

      <div className="bg-white rounded-2xl border border-black/5 p-6">
        <label className="text-xs font-medium text-black/60 block mb-2">Subdomain</label>
        <div className="flex items-center bg-[#FAFAFC] border border-black/10 rounded-xl focus-within:border-[#1877F2] focus-within:ring-4 focus-within:ring-[#1877F2]/10 transition">
          <span className="pl-4 text-sm text-black/40 font-mono">https://</span>
          <input
            value={data.subdomain}
            onChange={(e) => setData({ ...data, subdomain: e.target.value.toLowerCase().replace(/[^a-z0-9-]/g, '') })}
            autoFocus
            placeholder={suggested || 'танай-нэр'}
            className="flex-1 min-w-0 py-3.5 px-1 bg-transparent text-sm font-mono font-semibold focus:outline-none"
          />
          <span className="pr-4 text-sm text-black/40 font-mono">.nexcoreplatforms.mn</span>
        </div>

        {data.subdomain && (
          <div className={`mt-3 flex items-center gap-2 text-sm ${available ? 'text-[#10B981]' : 'text-[#EF4444]'}`}>
            {available ? <CheckCircle2 className="w-4 h-4" /> : <X className="w-4 h-4" />}
            <span>
              {available
                ? `${data.subdomain}.nexcoreplatforms.mn боломжтой!`
                : data.subdomain.length < 3
                  ? '3-аас дээш үсэг хэрэгтэй'
                  : 'Энэ хаяг аль хэдийн авагдсан байна'}
            </span>
          </div>
        )}

        {!data.subdomain && suggested && (
          <button
            onClick={() => setData({ ...data, subdomain: suggested })}
            className="mt-3 text-xs text-[#1877F2] font-medium hover:underline"
          >
            <Sparkles className="w-3 h-3 inline mr-1" />
            Санал болгох: <span className="font-mono">{suggested}</span>
          </button>
        )}

        <div className="mt-5 p-4 bg-[#FAFAFC] rounded-xl border border-black/5">
          <div className="text-[10px] uppercase tracking-wider text-black/40 font-semibold mb-2">Жишээ хэрэглээ</div>
          <div className="text-xs text-black/70 leading-relaxed font-mono space-y-0.5">
            <div>{data.subdomain || suggested || 'танай'}.nexcoreplatforms.mn/<span className="text-[#1877F2]">apps</span></div>
            <div>{data.subdomain || suggested || 'танай'}.nexcoreplatforms.mn/<span className="text-[#1877F2]">admin</span></div>
            <div>...@{data.subdomain || suggested || 'танай'}.com</div>
          </div>
        </div>
      </div>

      <div className="flex gap-3 mt-6">
        <button onClick={onBack} className="px-6 py-3.5 border border-black/10 rounded-xl font-semibold flex items-center gap-2 hover:bg-black/5">
          <ArrowLeft className="w-4 h-4" /> Буцах
        </button>
        <button
          onClick={onNext}
          disabled={!available}
          className="flex-1 bg-[#1877F2] hover:bg-[#0866FF] text-white py-3.5 rounded-xl font-semibold flex items-center justify-center gap-2 disabled:opacity-50 disabled:cursor-not-allowed"
        >
          Үргэлжлүүлэх <ArrowRight className="w-4 h-4" />
        </button>
      </div>
    </div>
  );
}

function Step3({ data, setData, onNext, onBack }) {
  const plans = [
    { id: 'Starter', name: 'Starter', price: 'Үнэгүй', desc: '5 хүртэл хэрэглэгч', features: ['Үндсэн апп', 'Чат + Видео', '5GB файл'], color: '#A855F7', badge: 'Шинэ' },
    { id: 'Core', name: 'Core', price: '9,900₮', desc: 'Жижиг багт', features: ['Бүх Starter', 'News Feed', '1TB файл', 'Email дэмжлэг'], color: '#94A3B8' },
    { id: 'Premium', name: 'Premium', price: '28,800₮', desc: 'Хамгийн алдартай', features: ['Бүх Core + SSO', 'Live Video 1080p', 'AI туслах', '24/7 дэмжлэг'], color: '#1877F2', popular: true },
    { id: 'Enterprise', name: 'Enterprise', price: 'Тусгай', desc: '500+ ажилтан', features: ['Бүх Premium', 'SLA', 'Dedicated CSM', 'Custom развитие'], color: '#A855F7' },
  ];

  return (
    <div className="anim-slide">
      <div className="text-center mb-8">
        <div className="w-14 h-14 rounded-2xl bg-[#1877F2]/10 flex items-center justify-center mx-auto mb-4">
          <CreditCard className="w-6 h-6 text-[#1877F2]" />
        </div>
        <h2 className="font-display text-3xl font-bold mb-2">Багцаа сонгоно уу</h2>
        <p className="text-black/60">14 хоногийн үнэгүй туршилт. Карт шаардахгүй.</p>
      </div>

      <div className="space-y-3">
        {plans.map((p) => (
          <button
            key={p.id}
            onClick={() => setData({ ...data, plan: p.id })}
            className={`w-full text-left p-5 rounded-2xl border-2 transition relative ${data.plan === p.id ? 'border-[#1877F2] bg-[#1877F2]/[0.03] shadow-md' : 'border-black/10 bg-white hover:border-black/20'}`}
          >
            {p.popular && (
              <div className="absolute -top-2 left-5 px-2 py-0.5 bg-[#10B981] text-white text-[10px] font-bold rounded-full">
                ХАМГИЙН АЛДАРТАЙ
              </div>
            )}
            <div className="flex items-start gap-4">
              <div className="w-5 h-5 rounded-full border-2 flex-shrink-0 mt-0.5 flex items-center justify-center" style={{ borderColor: data.plan === p.id ? '#1877F2' : '#0001' }}>
                {data.plan === p.id && <div className="w-2.5 h-2.5 rounded-full bg-[#1877F2]" />}
              </div>
              <div className="flex-1 min-w-0">
                <div className="flex items-center justify-between mb-1">
                  <div>
                    <span className="font-display font-bold text-lg">{p.name}</span>
                    <span className="text-xs text-black/50 ml-2">{p.desc}</span>
                  </div>
                  <div className="font-display text-xl font-bold">{p.price}<span className="text-xs text-black/40 font-normal">/хэрэглэгч/сар</span></div>
                </div>
                <div className="flex flex-wrap gap-x-4 gap-y-1 mt-2">
                  {p.features.map((f, i) => (
                    <div key={i} className="flex items-center gap-1.5 text-xs text-black/70">
                      <Check className="w-3 h-3 text-[#10B981] flex-shrink-0" /> {f}
                    </div>
                  ))}
                </div>
              </div>
            </div>
          </button>
        ))}
      </div>

      <div className="flex gap-3 mt-6">
        <button onClick={onBack} className="px-6 py-3.5 border border-black/10 rounded-xl font-semibold flex items-center gap-2 hover:bg-black/5">
          <ArrowLeft className="w-4 h-4" /> Буцах
        </button>
        <button
          onClick={onNext}
          className="flex-1 bg-[#1877F2] hover:bg-[#0866FF] text-white py-3.5 rounded-xl font-semibold flex items-center justify-center gap-2"
        >
          Үргэлжлүүлэх <ArrowRight className="w-4 h-4" />
        </button>
      </div>
    </div>
  );
}

function Step4({ data, setData, onSubmit, onBack, loading }) {
  return (
    <div className="anim-slide">
      <div className="text-center mb-8">
        <div className="w-14 h-14 rounded-2xl bg-[#1877F2]/10 flex items-center justify-center mx-auto mb-4">
          <User className="w-6 h-6 text-[#1877F2]" />
        </div>
        <h2 className="font-display text-3xl font-bold mb-2">Эхний админ</h2>
        <p className="text-black/60">Та өөрөө эсвэл өөр хүн</p>
      </div>

      <div className="bg-white rounded-2xl border border-black/5 p-6 space-y-5">
        <div>
          <label className="text-xs font-medium text-black/60 block mb-2">Бүтэн нэр</label>
          <input
            value={data.adminName}
            onChange={(e) => setData({ ...data, adminName: e.target.value })}
            placeholder="Бат-Эрдэнэ Доржийн"
            className="w-full px-4 py-3.5 bg-[#FAFAFC] border border-black/10 rounded-xl text-sm focus:outline-none focus:border-[#1877F2] focus:ring-4 focus:ring-[#1877F2]/10"
          />
        </div>
        <div>
          <label className="text-xs font-medium text-black/60 block mb-2">Имэйл</label>
          <div className="relative">
            <Mail className="absolute left-4 top-1/2 -translate-y-1/2 w-4 h-4 text-black/40" />
            <input
              type="email"
              value={data.adminEmail}
              onChange={(e) => setData({ ...data, adminEmail: e.target.value })}
              placeholder={`admin@${data.subdomain}.com`}
              className="w-full pl-11 pr-4 py-3.5 bg-[#FAFAFC] border border-black/10 rounded-xl text-sm focus:outline-none focus:border-[#1877F2] focus:ring-4 focus:ring-[#1877F2]/10"
            />
          </div>
        </div>
        <div>
          <label className="text-xs font-medium text-black/60 block mb-2">Нууц үг</label>
          <div className="relative">
            <Lock className="absolute left-4 top-1/2 -translate-y-1/2 w-4 h-4 text-black/40" />
            <input
              type="password"
              value={data.password}
              onChange={(e) => setData({ ...data, password: e.target.value })}
              placeholder="•••••• (хамгийн багадаа 8 тэмдэгт)"
              className="w-full pl-11 pr-4 py-3.5 bg-[#FAFAFC] border border-black/10 rounded-xl text-sm focus:outline-none focus:border-[#1877F2] focus:ring-4 focus:ring-[#1877F2]/10"
            />
          </div>
        </div>
      </div>

      {/* Summary */}
      <div className="mt-5 p-4 bg-[#1877F2]/5 border border-[#1877F2]/20 rounded-2xl">
        <div className="text-xs uppercase tracking-wider text-[#1877F2] font-semibold mb-3">Бүртгэлийн тойм</div>
        <div className="space-y-1.5 text-sm">
          <div className="flex justify-between"><span className="text-black/60">Компани:</span><span className="font-semibold">{data.name}</span></div>
          <div className="flex justify-between"><span className="text-black/60">Хаяг:</span><span className="font-mono text-xs">{data.subdomain}.nexcoreplatforms.mn</span></div>
          <div className="flex justify-between"><span className="text-black/60">Багц:</span><span className="font-semibold">{data.plan}</span></div>
        </div>
      </div>

      <div className="flex gap-3 mt-6">
        <button onClick={onBack} disabled={loading} className="px-6 py-3.5 border border-black/10 rounded-xl font-semibold flex items-center gap-2 hover:bg-black/5 disabled:opacity-50">
          <ArrowLeft className="w-4 h-4" /> Буцах
        </button>
        <button
          onClick={onSubmit}
          disabled={!data.adminName || !data.adminEmail || data.password.length < 8 || loading}
          className="flex-1 bg-[#1877F2] hover:bg-[#0866FF] text-white py-3.5 rounded-xl font-semibold flex items-center justify-center gap-2 disabled:opacity-50"
        >
          {loading ? (
            <>
              <div className="w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin" />
              Бүртгэж байна...
            </>
          ) : (
            <><Sparkles className="w-4 h-4" /> Workplace үүсгэх</>
          )}
        </button>
      </div>

      <div className="mt-4 flex items-center justify-center gap-4 text-xs text-black/50">
        <div className="flex items-center gap-1"><Shield className="w-3 h-3" /> 14 хоног үнэгүй</div>
        <div className="flex items-center gap-1"><Zap className="w-3 h-3" /> 5 минут</div>
        <div className="flex items-center gap-1"><CheckCircle2 className="w-3 h-3" /> Карт хэрэггүй</div>
      </div>
    </div>
  );
}
