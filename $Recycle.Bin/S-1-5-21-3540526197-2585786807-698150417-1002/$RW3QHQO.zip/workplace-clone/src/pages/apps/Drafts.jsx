import { useState } from 'react';
import { useTenant } from '../../contexts/TenantContext.jsx';
import {
  FileText, MessageSquare, Mail, Search, Trash2, Send, Edit3,
  Clock, Filter, Hash, AtSign, Calendar, Sparkles, X
} from 'lucide-react';

export default function Drafts() {
  const { currentTenant } = useTenant();
  const [filter, setFilter] = useState('all');
  const [search, setSearch] = useState('');

  const drafts = [
    {
      id: 1,
      type: 'mail',
      to: 'sarah@walmart.com',
      subject: 'Re: Q4 кампанит ажлын тойм',
      preview: 'Сайн уу Сараа, тайланг үзлээ. Хэдэн санал байна:\n\n1. Influencer marketing-ийн ROI...',
      lastEdit: '5 мин өмнө',
      tenant: 'walmart',
      progress: 65,
    },
    {
      id: 2,
      type: 'chat',
      to: '#маркетинг',
      subject: 'маркетинг сувагт',
      preview: 'Хүмүүс ээ, маргаашийн уулзалтанд орох',
      lastEdit: '12 мин өмнө',
      tenant: 'mcs',
      progress: 30,
    },
    {
      id: 3,
      type: 'doc',
      to: 'Engineering RFC: API v2',
      subject: 'Engineering RFC: API v2',
      preview: '## Зорилго\n\nManai API-ийн v2 хувилбарт дараах өөрчлөлтүүдийг хийх...',
      lastEdit: '34 мин өмнө',
      tenant: 'mcs',
      progress: 80,
    },
    {
      id: 4,
      type: 'mail',
      to: 'team@company.com',
      subject: '(Гарчиг байхгүй)',
      preview: '',
      lastEdit: '1 цаг өмнө',
      tenant: 'mcs',
      progress: 5,
    },
    {
      id: 5,
      type: 'chat',
      to: '@Дорж А.',
      subject: 'Хувийн чат',
      preview: 'Бүтэн өдөр болоход санааны үг хэрэгтэй болсон. Боломжтой',
      lastEdit: '2 цаг өмнө',
      tenant: 'apu',
      progress: 50,
    },
    {
      id: 6,
      type: 'doc',
      to: 'OKR Q1 2026',
      subject: 'OKR Q1 2026',
      preview: '# Зорилго 1: Хэрэглэгчийн өсөлт\n\n- Шинэ хэрэглэгч 25%-аар нэмэгдүүлэх...',
      lastEdit: 'Өчигдөр',
      tenant: 'mcs',
      progress: 90,
    },
  ];

  const filtered = drafts.filter(d =>
    (filter === 'all' || d.type === filter) &&
    (!search || d.subject.toLowerCase().includes(search.toLowerCase()) || d.preview.toLowerCase().includes(search.toLowerCase()))
  );

  function getIcon(type) {
    switch(type) {
      case 'mail': return Mail;
      case 'chat': return MessageSquare;
      case 'doc': return FileText;
      default: return FileText;
    }
  }

  function getColor(type) {
    switch(type) {
      case 'mail': return '#EF4444';
      case 'chat': return '#6366F1';
      case 'doc': return '#3B82F6';
      default: return '#94A3B8';
    }
  }

  return (
    <div className="p-8 max-w-6xl anim-fade">
      <div className="flex flex-col sm:flex-row sm:items-end sm:justify-between gap-4 mb-8">
        <div>
          <div className="text-xs uppercase tracking-[0.2em] text-[#6366F1] font-semibold mb-2">— Drafts</div>
          <h1 className="font-display text-4xl font-bold tracking-tight mb-2">Бичээгүй <span className="font-serif italic">ноорог</span></h1>
          <p className="text-black/60">Бүх апп дотор бэлдэж буй зурвас, имэйл, документ нэг газар</p>
        </div>
        <div className="flex items-center gap-2">
          <button className="px-4 py-2 text-sm bg-white border border-black/10 rounded-full hover:border-black/30 flex items-center gap-2">
            <Trash2 className="w-3.5 h-3.5" /> Цэвэрлэх
          </button>
        </div>
      </div>

      {/* Stats */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 mb-6">
        {[
          { label: 'Нийт ноорог', value: drafts.length, icon: FileText, color: '#6366F1' },
          { label: 'Имэйл', value: drafts.filter(d => d.type === 'mail').length, icon: Mail, color: '#EF4444' },
          { label: 'Чат', value: drafts.filter(d => d.type === 'chat').length, icon: MessageSquare, color: '#10B981' },
          { label: 'Документ', value: drafts.filter(d => d.type === 'doc').length, icon: FileText, color: '#3B82F6' },
        ].map((s, i) => {
          const Icon = s.icon;
          return (
            <div key={i} className="bg-white rounded-2xl p-5 border border-black/5">
              <Icon className="w-4 h-4 mb-3" style={{ color: s.color }} />
              <div className="font-display text-3xl font-bold tracking-tight">{s.value}</div>
              <div className="text-xs text-black/50 mt-1">{s.label}</div>
            </div>
          );
        })}
      </div>

      {/* Search & filter */}
      <div className="flex flex-col sm:flex-row gap-3 mb-5">
        <div className="flex-1 relative">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-black/40" />
          <input
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            placeholder="Ноорог дотор хайх..."
            className="w-full pl-10 pr-4 py-2.5 bg-white border border-black/10 rounded-xl text-sm focus:outline-none focus:border-[#6366F1] focus:ring-4 focus:ring-[#6366F1]/10"
          />
        </div>
        <div className="flex bg-white border border-black/10 rounded-xl p-0.5">
          {[
            { id: 'all', label: 'Бүгд' },
            { id: 'mail', label: 'Имэйл' },
            { id: 'chat', label: 'Чат' },
            { id: 'doc', label: 'Документ' },
          ].map(f => (
            <button
              key={f.id}
              onClick={() => setFilter(f.id)}
              className={`px-3 py-2 text-xs rounded-lg transition ${filter === f.id ? 'bg-[#6366F1] text-white font-semibold' : 'text-black/60'}`}
            >
              {f.label}
            </button>
          ))}
        </div>
      </div>

      {/* Drafts list */}
      <div className="space-y-3">
        {filtered.length === 0 ? (
          <div className="bg-white rounded-2xl p-12 text-center border border-black/5">
            <FileText className="w-10 h-10 text-black/20 mx-auto mb-3" />
            <div className="font-medium text-black/60">Ноорог олдсонгүй</div>
            <div className="text-sm text-black/40 mt-1">Шинэ зурвас, имэйл, документ эхлүүлээрэй</div>
          </div>
        ) : filtered.map(d => {
          const Icon = getIcon(d.type);
          const color = getColor(d.type);
          return (
            <div key={d.id} className="bg-white rounded-2xl p-5 border border-black/5 hover:border-black/15 hover:shadow-md transition group cursor-pointer">
              <div className="flex items-start gap-4">
                <div className="w-11 h-11 rounded-xl flex items-center justify-center flex-shrink-0" style={{ background: `${color}15`, color }}>
                  <Icon className="w-5 h-5" />
                </div>
                <div className="flex-1 min-w-0">
                  <div className="flex items-center gap-2 mb-1">
                    <span className="text-[10px] uppercase font-bold tracking-wider px-2 py-0.5 rounded" style={{ background: `${color}15`, color }}>
                      {d.type === 'mail' ? 'Имэйл' : d.type === 'chat' ? 'Чат' : 'Документ'}
                    </span>
                    <span className="text-xs text-black/50">{d.to}</span>
                  </div>
                  <div className="font-semibold mb-1 truncate">{d.subject}</div>
                  <div className="text-sm text-black/60 line-clamp-2 whitespace-pre-line">{d.preview || '(Хоосон)'}</div>
                  <div className="flex items-center gap-3 mt-3">
                    <div className="flex items-center gap-1.5 text-[10px] text-black/50">
                      <Clock className="w-3 h-3" /> {d.lastEdit}
                    </div>
                    <div className="flex items-center gap-2 flex-1 max-w-[200px]">
                      <div className="flex-1 h-1 bg-black/5 rounded-full overflow-hidden">
                        <div className="h-full rounded-full transition-all" style={{ width: `${d.progress}%`, background: color }} />
                      </div>
                      <span className="text-[10px] text-black/50">{d.progress}%</span>
                    </div>
                  </div>
                </div>
                <div className="flex items-center gap-1 opacity-0 group-hover:opacity-100 transition flex-shrink-0">
                  <button className="px-3 py-1.5 text-xs bg-[#6366F1] text-white rounded-lg flex items-center gap-1 hover:bg-[#5455E0]">
                    <Edit3 className="w-3 h-3" /> Үргэлжлүүлэх
                  </button>
                  <button className="w-7 h-7 rounded-lg hover:bg-[#EF4444]/10 hover:text-[#EF4444] flex items-center justify-center"><Trash2 className="w-3.5 h-3.5" /></button>
                </div>
              </div>
            </div>
          );
        })}
      </div>

      {/* AI tip */}
      <div className="mt-6 p-4 bg-gradient-to-br from-[#6366F1]/5 to-[#A855F7]/5 border border-[#6366F1]/20 rounded-2xl flex items-start gap-3">
        <Sparkles className="w-5 h-5 text-[#A855F7] flex-shrink-0 mt-0.5" />
        <div className="flex-1">
          <div className="text-sm font-semibold mb-1">AI санал</div>
          <div className="text-xs text-black/70 leading-relaxed">3 өдрийн өмнө бэлдэж эхэлсэн "OKR Q1 2026" документ 90% бэлэн боллоо. Дуусгаж илгээх боломжтой юу? <button className="text-[#6366F1] font-medium hover:underline">Үзэх →</button></div>
        </div>
      </div>
    </div>
  );
}
