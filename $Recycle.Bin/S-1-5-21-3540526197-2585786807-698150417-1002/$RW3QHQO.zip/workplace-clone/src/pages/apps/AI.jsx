import { useState } from 'react';
import {
  Sparkles, Send, Plus, MessageSquare, Lightbulb, FileText, Mail,
  BarChart3, Zap, ArrowRight, Bookmark, Copy, ThumbsUp, ThumbsDown,
  RefreshCw, Mic
} from 'lucide-react';

export default function AI() {
  const [input, setInput] = useState('');
  const [conversation, setConversation] = useState([
    { role: 'user', text: 'Q4 маркетингийн тайланд оруулах KPI санал болго' },
    { role: 'ai', text: 'Q4 маркетингийн тайланд оруулах гол KPI-уудын санал:\n\n• **Customer Acquisition Cost (CAC)** — Шинэ хэрэглэгч татахад зарцуулсан зардал\n• **ROI by channel** — Сошиал, имэйл, paid ads-ын тус бүрийн өгөөж\n• **Engagement rate** — Идэвхтэй хэрэглэгчийн харьцаа\n• **Brand awareness lift** — Brand mention, search volume өсөлт\n• **Conversion funnel метрикүүд** — Awareness → Consideration → Purchase\n\nЭнэ KPI-ууд нь маркетингийн гүйцэтгэлийг бүх талаас нь үнэлэх боломж олгоно. Дэлгэрэнгүй framework хэрэгтэй юу?' },
  ]);

  const suggestions = [
    { icon: Mail, text: 'Имэйл бичиж тус олго', color: '#EF4444' },
    { icon: FileText, text: 'Тайлан хураангуйлах', color: '#3B82F6' },
    { icon: BarChart3, text: 'Дата задлан шинжлэх', color: '#10B981' },
    { icon: Lightbulb, text: 'Шинэ санаа гаргах', color: '#F59E0B' },
  ];

  const recent = [
    'Q4 KPI санал болгох',
    'Сараагийн имэйлд хариу бичих',
    'Дизайн review зөвлөгөө',
    'OKR template гаргах',
  ];

  const handleSend = () => {
    if (!input.trim()) return;
    setConversation([...conversation, { role: 'user', text: input }, { role: 'ai', text: 'Бодож байна... 🤔' }]);
    setInput('');
  };

  return (
    <div className="flex h-full bg-white">
      {/* Conversation history sidebar */}
      <div className="w-64 bg-[#FAFAFC] border-r border-black/5 flex flex-col flex-shrink-0">
        <div className="p-3">
          <button className="w-full bg-gradient-to-r from-[#6366F1] to-[#A855F7] text-white rounded-xl px-4 py-2.5 text-sm font-semibold flex items-center justify-center gap-2 hover:scale-[1.02] transition">
            <Plus className="w-4 h-4" /> Шинэ харилцаа
          </button>
        </div>
        <div className="px-3 pt-2 pb-1 text-[10px] uppercase tracking-wider text-black/40 font-semibold">Сүүлийн</div>
        <div className="flex-1 px-2 space-y-0.5 overflow-y-auto scrollbar-thin">
          {recent.map((r, i) => (
            <button key={i} className={`w-full flex items-center gap-2 px-3 py-2 rounded-lg text-xs text-left transition ${i === 0 ? 'bg-black/5 font-medium' : 'hover:bg-black/[0.03] text-black/70'}`}>
              <MessageSquare className="w-3 h-3 flex-shrink-0 opacity-50" />
              <span className="truncate">{r}</span>
            </button>
          ))}
        </div>
        <div className="p-3 border-t border-black/5">
          <div className="bg-gradient-to-br from-[#A855F7]/10 to-[#6366F1]/10 rounded-xl p-3 border border-[#A855F7]/20">
            <div className="flex items-center gap-1.5 mb-1.5">
              <Zap className="w-3 h-3 text-[#A855F7]" />
              <span className="text-[10px] font-semibold text-[#A855F7] uppercase tracking-wider">Pro боломж</span>
            </div>
            <div className="text-xs font-medium mb-1">Хязгааргүй асуулт</div>
            <div className="text-[10px] text-black/50">Файл, зураг хавсаргах</div>
          </div>
        </div>
      </div>

      {/* Chat */}
      <div className="flex-1 flex flex-col min-w-0">
        <div className="h-14 border-b border-black/5 px-5 flex items-center gap-3 flex-shrink-0">
          <div className="w-8 h-8 rounded-xl bg-gradient-to-br from-[#6366F1] to-[#A855F7] flex items-center justify-center">
            <Sparkles className="w-4 h-4 text-white" />
          </div>
          <div>
            <div className="font-semibold text-sm">Nexcore AI</div>
            <div className="text-[10px] text-black/50">Powered by Claude · Бэлэн</div>
          </div>
          <div className="ml-auto flex items-center gap-2">
            <select className="text-xs px-2 py-1 bg-black/5 border-0 rounded-md focus:outline-none">
              <option>Sonnet 4.5</option>
              <option>Opus 4.7</option>
              <option>Haiku 4.5</option>
            </select>
          </div>
        </div>

        <div className="flex-1 overflow-y-auto scrollbar-thin">
          <div className="max-w-3xl mx-auto px-6 py-8">
            {conversation.length === 0 ? (
              <div className="text-center py-16">
                <div className="w-16 h-16 rounded-2xl bg-gradient-to-br from-[#6366F1] to-[#A855F7] flex items-center justify-center mx-auto mb-5">
                  <Sparkles className="w-7 h-7 text-white" />
                </div>
                <h2 className="font-display text-3xl font-bold mb-3">Юунд тус болохуу?</h2>
                <p className="text-black/60 mb-8">Хүссэн зүйлээ асуу — текст, файл, зурвас, документ — би бүхнийг боловсруулж чадна.</p>
                <div className="grid grid-cols-2 gap-3 max-w-xl mx-auto">
                  {suggestions.map((s, i) => {
                    const Icon = s.icon;
                    return (
                      <button key={i} className="p-4 bg-white border border-black/10 rounded-xl text-left hover:border-black/20 hover:shadow-md transition group">
                        <Icon className="w-4 h-4 mb-2" style={{ color: s.color }} />
                        <div className="text-sm font-medium">{s.text}</div>
                      </button>
                    );
                  })}
                </div>
              </div>
            ) : (
              <div className="space-y-6">
                {conversation.map((m, i) => (
                  <div key={i} className={`flex gap-3 ${m.role === 'user' ? 'justify-end' : ''}`}>
                    {m.role === 'ai' && (
                      <div className="w-8 h-8 rounded-xl bg-gradient-to-br from-[#6366F1] to-[#A855F7] flex items-center justify-center flex-shrink-0">
                        <Sparkles className="w-4 h-4 text-white" />
                      </div>
                    )}
                    <div className={`max-w-2xl ${m.role === 'user' ? 'bg-[#6366F1] text-white' : 'bg-[#FAFAFC]'} rounded-2xl px-4 py-3`}>
                      <div className={`text-sm leading-relaxed whitespace-pre-line ${m.role === 'user' ? '' : 'text-black/85'}`}>
                        {m.text}
                      </div>
                      {m.role === 'ai' && (
                        <div className="flex items-center gap-1 mt-3 pt-3 border-t border-black/5">
                          <button className="w-6 h-6 rounded hover:bg-black/5 flex items-center justify-center"><Copy className="w-3 h-3 text-black/50" /></button>
                          <button className="w-6 h-6 rounded hover:bg-black/5 flex items-center justify-center"><RefreshCw className="w-3 h-3 text-black/50" /></button>
                          <button className="w-6 h-6 rounded hover:bg-black/5 flex items-center justify-center"><ThumbsUp className="w-3 h-3 text-black/50" /></button>
                          <button className="w-6 h-6 rounded hover:bg-black/5 flex items-center justify-center"><ThumbsDown className="w-3 h-3 text-black/50" /></button>
                          <button className="ml-auto w-6 h-6 rounded hover:bg-black/5 flex items-center justify-center"><Bookmark className="w-3 h-3 text-black/50" /></button>
                        </div>
                      )}
                    </div>
                    {m.role === 'user' && (
                      <div className="w-8 h-8 rounded-full bg-gradient-to-br from-[#EC4899] to-[#A855F7] flex-shrink-0" />
                    )}
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>

        {/* Input */}
        <div className="p-4 border-t border-black/5">
          <div className="max-w-3xl mx-auto">
            <div className="border border-black/10 rounded-2xl focus-within:border-[#6366F1]/40 transition bg-white">
              <textarea
                value={input}
                onChange={(e) => setInput(e.target.value)}
                onKeyDown={(e) => e.key === 'Enter' && !e.shiftKey && (e.preventDefault(), handleSend())}
                placeholder="Юу хийх вэ?"
                rows={1}
                className="w-full px-4 py-3 bg-transparent text-sm focus:outline-none resize-none"
              />
              <div className="flex items-center justify-between px-2 py-1.5 border-t border-black/5">
                <div className="flex items-center gap-0.5">
                  <button className="w-7 h-7 rounded hover:bg-black/5 flex items-center justify-center text-black/50"><Plus className="w-3.5 h-3.5" /></button>
                  <button className="w-7 h-7 rounded hover:bg-black/5 flex items-center justify-center text-black/50"><Mic className="w-3.5 h-3.5" /></button>
                </div>
                <button onClick={handleSend} disabled={!input.trim()} className="px-3 py-1.5 bg-gradient-to-r from-[#6366F1] to-[#A855F7] text-white text-xs font-medium rounded-md disabled:opacity-30 hover:scale-[1.02] transition flex items-center gap-1.5">
                  <Send className="w-3 h-3" /> Илгээх
                </button>
              </div>
            </div>
            <div className="text-[10px] text-black/40 mt-2 text-center">
              AI алдаа гаргаж болно. Чухал мэдээллийг шалгах
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
