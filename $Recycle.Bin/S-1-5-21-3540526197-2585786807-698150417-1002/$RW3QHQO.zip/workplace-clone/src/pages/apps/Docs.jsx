import { useState } from 'react';
import {
  FileText, Plus, Search, Star, Folder, Clock, Users, Share2,
  MoreHorizontal, Bold, Italic, Underline, List, ListOrdered,
  AlignLeft, Image as ImageIcon, Link2, Sparkles, MessageSquare,
  Download, Grid3x3, Filter
} from 'lucide-react';

export default function Docs() {
  const [view, setView] = useState('list');
  const [active, setActive] = useState(null);

  const docs = [
    { title: 'Q4 стратеги документ', folder: 'Маркетинг', edited: '5 мин өмнө', authors: 3, color: '#6366F1' },
    { title: 'Шинэ ажилтны гарын авлага', folder: 'HR', edited: '1 цагийн өмнө', authors: 2, color: '#10B981' },
    { title: 'Брэнд гарын авлага 2026', folder: 'Дизайн', edited: 'Өчигдөр', authors: 5, color: '#EC4899' },
    { title: 'Engineering RFC: API v2', folder: 'Engineering', edited: '2 хоног өмнө', authors: 8, color: '#F59E0B' },
    { title: 'OKR Q1 2026', folder: 'Удирдлага', edited: '3 хоног өмнө', authors: 12, color: '#A855F7', starred: true },
    { title: 'Customer feedback summary', folder: 'Маркетинг', edited: '1 долоо хоног', authors: 4, color: '#06B6D4' },
  ];

  if (active !== null) {
    return <DocEditor doc={docs[active]} onBack={() => setActive(null)} />;
  }

  return (
    <div className="p-8 max-w-7xl anim-fade">
      <div className="flex flex-col lg:flex-row lg:items-center lg:justify-between gap-4 mb-8">
        <div>
          <h1 className="font-display text-4xl font-bold tracking-tight mb-2">Docs</h1>
          <p className="text-black/60">Хамтын баримт бичиг — бодит цагт</p>
        </div>
        <div className="flex items-center gap-2">
          <button className="px-4 py-2 text-sm bg-white border border-black/10 rounded-full hover:border-black/30 flex items-center gap-2">
            <Filter className="w-3.5 h-3.5" /> Шүүлт
          </button>
          <button className="px-4 py-2 text-sm bg-gradient-to-r from-[#3B82F6] to-[#2563EB] text-white rounded-full flex items-center gap-2 hover:scale-[1.02] transition">
            <Plus className="w-3.5 h-3.5" /> Шинэ документ
          </button>
        </div>
      </div>

      {/* Templates */}
      <div className="mb-8">
        <h2 className="text-sm font-semibold text-black/60 mb-3">Загвараас эхлэх</h2>
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
          {[
            { name: 'Хоосон', icon: FileText, color: '#94A3B8' },
            { name: 'Хурлын тэмдэглэл', icon: MessageSquare, color: '#6366F1' },
            { name: 'OKR төлөвлөгөө', icon: Star, color: '#F59E0B' },
            { name: 'AI төсөл', icon: Sparkles, color: '#A855F7' },
          ].map((t, i) => {
            const Icon = t.icon;
            return (
              <button key={i} className="bg-white rounded-2xl p-4 border border-black/5 hover:border-black/15 hover:shadow-md transition group text-left">
                <div className="aspect-[4/3] rounded-lg flex items-center justify-center mb-3" style={{ background: `${t.color}15` }}>
                  <Icon className="w-8 h-8" style={{ color: t.color }} />
                </div>
                <div className="text-sm font-medium">{t.name}</div>
              </button>
            );
          })}
        </div>
      </div>

      {/* Recent files */}
      <div className="bg-white rounded-2xl border border-black/5 overflow-hidden">
        <div className="p-5 border-b border-black/5 flex items-center justify-between">
          <h2 className="font-display text-lg font-semibold">Сүүлийн баримтууд</h2>
          <div className="flex items-center gap-1">
            <button onClick={() => setView('grid')} className={`w-8 h-8 rounded-lg flex items-center justify-center ${view === 'grid' ? 'bg-black/5' : 'hover:bg-black/5'}`}><Grid3x3 className="w-4 h-4" /></button>
            <button onClick={() => setView('list')} className={`w-8 h-8 rounded-lg flex items-center justify-center ${view === 'list' ? 'bg-black/5' : 'hover:bg-black/5'}`}><List className="w-4 h-4" /></button>
          </div>
        </div>
        <table className="w-full text-sm">
          <thead className="bg-[#FAFAFC] text-xs uppercase tracking-wider text-black/50">
            <tr>
              <th className="px-5 py-3 text-left font-medium">Нэр</th>
              <th className="px-5 py-3 text-left font-medium">Хавтас</th>
              <th className="px-5 py-3 text-left font-medium">Засагдсан</th>
              <th className="px-5 py-3 text-left font-medium">Хамтрагч</th>
              <th className="px-5 py-3"></th>
            </tr>
          </thead>
          <tbody className="divide-y divide-black/5">
            {docs.map((d, i) => (
              <tr key={i} onClick={() => setActive(i)} className="hover:bg-black/[0.02] cursor-pointer transition">
                <td className="px-5 py-3">
                  <div className="flex items-center gap-3">
                    <div className="w-8 h-8 rounded-lg flex items-center justify-center" style={{ background: `${d.color}15`, color: d.color }}>
                      <FileText className="w-4 h-4" />
                    </div>
                    <span className="font-medium">{d.title}</span>
                    {d.starred && <Star className="w-3.5 h-3.5 fill-[#F59E0B] text-[#F59E0B]" />}
                  </div>
                </td>
                <td className="px-5 py-3 text-black/60">{d.folder}</td>
                <td className="px-5 py-3 text-black/60">{d.edited}</td>
                <td className="px-5 py-3">
                  <div className="flex -space-x-2">
                    {[...Array(Math.min(d.authors, 3))].map((_, j) => (
                      <div key={j} className="w-6 h-6 rounded-full border-2 border-white" style={{ background: ['#6366F1', '#10B981', '#F59E0B'][j] }} />
                    ))}
                    {d.authors > 3 && <div className="w-6 h-6 rounded-full bg-black/5 border-2 border-white flex items-center justify-center text-[10px] font-semibold">+{d.authors - 3}</div>}
                  </div>
                </td>
                <td className="px-5 py-3 text-right">
                  <button className="w-7 h-7 rounded-lg hover:bg-black/5 flex items-center justify-center"><MoreHorizontal className="w-3.5 h-3.5" /></button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}

function DocEditor({ doc, onBack }) {
  return (
    <div className="h-full bg-[#FAFAFC] flex flex-col">
      {/* Doc header */}
      <div className="bg-white border-b border-black/5 px-6 py-3 flex items-center justify-between flex-shrink-0">
        <div className="flex items-center gap-3">
          <button onClick={onBack} className="text-sm text-[#6366F1] hover:underline">← Буцах</button>
          <div className="w-px h-5 bg-black/10" />
          <FileText className="w-4 h-4 text-[#3B82F6]" />
          <input defaultValue={doc.title} className="font-medium text-sm bg-transparent border-0 focus:outline-none focus:bg-black/5 px-2 py-1 rounded" />
          <Star className="w-4 h-4 text-black/30 cursor-pointer hover:text-[#F59E0B]" />
        </div>
        <div className="flex items-center gap-2">
          <div className="flex -space-x-2">
            <div className="w-7 h-7 rounded-full border-2 border-white bg-[#6366F1]" />
            <div className="w-7 h-7 rounded-full border-2 border-white bg-[#10B981]" />
            <div className="w-7 h-7 rounded-full border-2 border-white bg-[#F59E0B]" />
          </div>
          <button className="px-3 py-1.5 text-xs bg-[#3B82F6] text-white rounded-full font-medium flex items-center gap-1.5">
            <Share2 className="w-3 h-3" /> Хуваалцах
          </button>
        </div>
      </div>

      {/* Toolbar */}
      <div className="bg-white border-b border-black/5 px-6 py-2 flex items-center gap-1 flex-shrink-0">
        <select className="text-xs px-2 py-1 rounded hover:bg-black/5 bg-transparent border-0 focus:outline-none">
          <option>Энгийн текст</option>
          <option>Гарчиг 1</option>
          <option>Гарчиг 2</option>
        </select>
        <div className="w-px h-5 bg-black/10 mx-1" />
        <ToolBtn icon={Bold} />
        <ToolBtn icon={Italic} />
        <ToolBtn icon={Underline} />
        <div className="w-px h-5 bg-black/10 mx-1" />
        <ToolBtn icon={AlignLeft} />
        <ToolBtn icon={List} />
        <ToolBtn icon={ListOrdered} />
        <div className="w-px h-5 bg-black/10 mx-1" />
        <ToolBtn icon={Link2} />
        <ToolBtn icon={ImageIcon} />
        <div className="ml-auto">
          <button className="px-3 py-1.5 text-xs bg-gradient-to-r from-[#6366F1] to-[#A855F7] text-white rounded-full font-medium flex items-center gap-1.5">
            <Sparkles className="w-3 h-3" /> AI туслах
          </button>
        </div>
      </div>

      {/* Document */}
      <div className="flex-1 overflow-y-auto py-10">
        <div className="max-w-3xl mx-auto bg-white rounded-lg shadow-sm p-16 min-h-[800px]">
          <h1 className="font-display text-4xl font-bold mb-2">{doc.title}</h1>
          <div className="flex items-center gap-3 text-xs text-black/50 mb-8 pb-4 border-b border-black/10">
            <Clock className="w-3 h-3" />
            <span>Сүүлд засагдсан: {doc.edited}</span>
            <span>·</span>
            <span>{doc.authors} хүн ажиллаж байна</span>
          </div>

          <h2 className="font-display text-2xl font-bold mt-8 mb-3">Зорилго</h2>
          <p className="text-base leading-relaxed text-black/85 mb-4">
            Q4 кампанит ажлын дотор Влин ажилтан, гадны түншүүдтэй хамтран ажиллах стратегийн чиглэлийг тодорхойлох. Бид нийт 4 чиглэлд анхаарал хандуулж буюу:
          </p>

          <ul className="space-y-2 text-base text-black/85 mb-6 ml-4">
            <li>• <strong>Brand awareness</strong> — Манай брэндийн танигдалтыг 35% өсгөх</li>
            <li>• <strong>Шинэ хэрэглэгч</strong> — 15,000 шинэ бүртгэлтэй хэрэглэгч татах</li>
            <li>• <strong>Engagement</strong> — Идэвхтэй хэрэглэгчийн харьцааг 80% болгох</li>
            <li>• <strong>Revenue</strong> — Q4 орлогыг 2.5x нэмэгдүүлэх</li>
          </ul>

          <h2 className="font-display text-2xl font-bold mt-8 mb-3">Цаг хугацаа</h2>
          <p className="text-base leading-relaxed text-black/85 mb-4">
            Кампанит ажил <strong>10-р сарын 1-нээс 12-р сарын 31</strong> хүртэл үргэлжилнэ. Сар бүрийн төгсгөлд үр дүнгийн уулзалт хийж дүгнэлт гаргана.
          </p>

          <div className="my-8 p-4 bg-[#FFFBEB] border-l-4 border-[#F59E0B] rounded-r">
            <div className="flex items-start gap-2">
              <Sparkles className="w-4 h-4 text-[#F59E0B] mt-0.5" />
              <div>
                <div className="text-xs font-semibold text-[#92400E] mb-1">AI санал</div>
                <p className="text-sm text-black/75">Зорилгоо илүү тодорхой болгохын тулд KPI бүрд measurement framework нэмэхийг зөвлөж байна. Жишээ: brand awareness-ийг хэрхэн хэмжих вэ?</p>
              </div>
            </div>
          </div>

          <p className="text-base leading-relaxed text-black/40 italic">[Үргэлжлүүлж бичнэ үү...]</p>
        </div>
      </div>
    </div>
  );
}

function ToolBtn({ icon: Icon }) {
  return <button className="w-7 h-7 rounded hover:bg-black/5 flex items-center justify-center"><Icon className="w-3.5 h-3.5" /></button>;
}
