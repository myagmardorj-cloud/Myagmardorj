import { useState } from 'react';
import {
  Inbox, Send, FileText, Star, Trash2, Tag, Plus, Search, Reply,
  Forward, Paperclip, Archive, MoreHorizontal, Sparkles, ChevronRight,
  Mail as MailIcon
} from 'lucide-react';

export default function Mail() {
  const [active, setActive] = useState(0);

  const folders = [
    { name: 'Ирсэн', count: 23, icon: Inbox },
    { name: 'Одтой', count: 8, icon: Star },
    { name: 'Илгээсэн', count: 0, icon: Send },
    { name: 'Ноорог', count: 3, icon: FileText },
    { name: 'Архив', count: 0, icon: Archive },
    { name: 'Хогийн сав', count: 0, icon: Trash2 },
  ];

  const labels = [
    { name: 'Чухал', color: '#EF4444' },
    { name: 'Ажил', color: '#6366F1' },
    { name: 'Маркетинг', color: '#10B981' },
    { name: 'Хувийн', color: '#F59E0B' },
  ];

  const emails = [
    { from: 'Сараа Болд', email: 'saraa@company.mn', subject: 'Q4 кампанит ажлын тойм - дөрөвдүгээр сар', preview: 'Сайн уу! Манай Q4 марказтай холбоотой шинэ нэлэлэмжүүдийг хавсаргалаа...', time: '10:24', unread: true, starred: true, label: 'Маркетинг', avatar: '#10B981', hasAttachment: true },
    { from: 'GitHub', email: 'noreply@github.com', subject: '[nexcore-platforms/code] Pull request #42 needs review', preview: 'A new pull request has been opened by @myagmardorj-cloud. The changes...', time: '09:51', unread: true, label: 'Ажил', avatar: '#0F0F1A' },
    { from: 'Дорж А.', email: 'dorj@company.mn', subject: 'Маргаашийн хурлын agenda', preview: '14:00 цагт CEO Town Hall болно. Дараах асуудлууд яригдана...', time: '09:30', unread: true, starred: true, label: 'Чухал', avatar: '#F59E0B' },
    { from: 'Vercel', email: 'team@vercel.com', subject: 'Your deployment is live', preview: 'Successfully deployed nexcore-platforms to production...', time: 'Өчигдөр', label: 'Ажил', avatar: '#000' },
    { from: 'Туяа М.', email: 'tuya@company.mn', subject: 'Re: Дизайн шинэчлэлийн санал', preview: 'Зураг хавсаргасан байгаа болохоор үзээрэй. Шинэ Figma file дээр...', time: 'Өчигдөр', avatar: '#EC4899', hasAttachment: true },
    { from: 'LinkedIn', email: 'jobs@linkedin.com', subject: 'Танд тохирох 5 шинэ ажлын байр', preview: 'Senior Frontend Engineer at Apple, Senior PM at Google...', time: '2 хоногийн өмнө', avatar: '#0077B5' },
    { from: 'Болд Г.', email: 'bold@company.mn', subject: 'Budget approval хүсэлт', preview: 'Q1 2026-ийн budget хувиарлалт дээр гарын үсэг хэрэгтэй байна...', time: '3 хоног өмнө', label: 'Чухал', avatar: '#A855F7' },
  ];

  return (
    <div className="flex h-full bg-white">
      {/* Folder sidebar */}
      <div className="w-56 bg-[#FAFAFC] border-r border-black/5 flex flex-col flex-shrink-0">
        <div className="p-3">
          <button className="w-full bg-gradient-to-r from-[#EF4444] to-[#DC2626] text-white rounded-xl px-4 py-2.5 text-sm font-semibold flex items-center justify-center gap-2 hover:scale-[1.02] transition">
            <Plus className="w-4 h-4" /> Шинэ имэйл
          </button>
        </div>
        <nav className="flex-1 px-2 space-y-0.5 overflow-y-auto scrollbar-thin">
          {folders.map((f, i) => {
            const Icon = f.icon;
            const isActive = i === 0;
            return (
              <button key={i} className={`w-full flex items-center gap-3 px-3 py-2 rounded-lg text-sm transition ${isActive ? 'bg-[#EF4444]/10 text-[#EF4444] font-medium' : 'hover:bg-black/5'}`}>
                <Icon className="w-4 h-4 flex-shrink-0" />
                <span className="flex-1 text-left">{f.name}</span>
                {f.count > 0 && <span className="text-xs font-semibold">{f.count}</span>}
              </button>
            );
          })}
        </nav>
        <div className="px-3 pt-4 pb-2 text-[10px] uppercase tracking-wider text-black/40 font-semibold">Шошго</div>
        <nav className="px-2 space-y-0.5 mb-3">
          {labels.map((l, i) => (
            <button key={i} className="w-full flex items-center gap-3 px-3 py-1.5 rounded-lg text-sm hover:bg-black/5 transition">
              <div className="w-2.5 h-2.5 rounded-sm flex-shrink-0" style={{ background: l.color }} />
              <span className="flex-1 text-left">{l.name}</span>
            </button>
          ))}
        </nav>
      </div>

      {/* Email list */}
      <div className="w-96 border-r border-black/5 flex flex-col flex-shrink-0">
        <div className="h-14 border-b border-black/5 px-4 flex items-center gap-2 flex-shrink-0">
          <div className="flex-1 relative">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-3.5 h-3.5 text-black/40" />
            <input placeholder="Имэйл хайх..." className="w-full pl-9 pr-3 py-1.5 bg-[#FAFAFC] border border-black/5 rounded-md text-sm focus:outline-none focus:border-[#6366F1]/30" />
          </div>
        </div>
        <div className="flex-1 overflow-y-auto scrollbar-thin">
          {emails.map((e, i) => (
            <button
              key={i}
              onClick={() => setActive(i)}
              className={`w-full flex items-start gap-3 p-4 border-b border-black/5 text-left transition ${active === i ? 'bg-[#6366F1]/5 border-l-2 border-l-[#6366F1]' : 'hover:bg-black/[0.02]'} ${e.unread ? 'bg-white' : ''}`}
            >
              <div className="w-9 h-9 rounded-full flex-shrink-0 flex items-center justify-center text-white text-xs font-bold" style={{ background: e.avatar }}>
                {e.from[0]}
              </div>
              <div className="flex-1 min-w-0">
                <div className="flex items-center gap-2 mb-0.5">
                  <span className={`text-sm truncate flex-1 ${e.unread ? 'font-bold' : 'font-medium'}`}>{e.from}</span>
                  <span className="text-[10px] text-black/50 flex-shrink-0">{e.time}</span>
                </div>
                <div className={`text-xs mb-0.5 truncate ${e.unread ? 'font-semibold' : ''}`}>{e.subject}</div>
                <div className="text-xs text-black/50 truncate">{e.preview}</div>
                <div className="flex items-center gap-1.5 mt-1.5">
                  {e.starred && <Star className="w-3 h-3 fill-[#F59E0B] text-[#F59E0B]" />}
                  {e.hasAttachment && <Paperclip className="w-3 h-3 text-black/40" />}
                  {e.label && (
                    <span className="text-[9px] px-1.5 py-0.5 rounded font-semibold" style={{ background: `${labels.find(l => l.name === e.label)?.color}20`, color: labels.find(l => l.name === e.label)?.color }}>
                      {e.label}
                    </span>
                  )}
                  {e.unread && <div className="w-1.5 h-1.5 rounded-full bg-[#6366F1] ml-auto" />}
                </div>
              </div>
            </button>
          ))}
        </div>
      </div>

      {/* Email view */}
      <div className="flex-1 flex flex-col min-w-0">
        <div className="h-14 border-b border-black/5 px-5 flex items-center justify-between flex-shrink-0">
          <div className="flex items-center gap-1">
            <button className="w-8 h-8 rounded-lg hover:bg-black/5 flex items-center justify-center"><Archive className="w-4 h-4" /></button>
            <button className="w-8 h-8 rounded-lg hover:bg-black/5 flex items-center justify-center"><Trash2 className="w-4 h-4" /></button>
            <button className="w-8 h-8 rounded-lg hover:bg-black/5 flex items-center justify-center"><Tag className="w-4 h-4" /></button>
            <div className="w-px h-5 bg-black/10 mx-1" />
            <button className="w-8 h-8 rounded-lg hover:bg-black/5 flex items-center justify-center"><Star className="w-4 h-4" /></button>
            <button className="w-8 h-8 rounded-lg hover:bg-black/5 flex items-center justify-center"><MoreHorizontal className="w-4 h-4" /></button>
          </div>
          <div className="text-xs text-black/50">1 of 23</div>
        </div>

        <div className="flex-1 overflow-y-auto p-6 scrollbar-thin">
          <div className="max-w-3xl">
            <h1 className="font-display text-2xl font-bold mb-4">{emails[active].subject}</h1>
            <div className="flex items-start gap-3 mb-5 pb-5 border-b border-black/5">
              <div className="w-10 h-10 rounded-full flex items-center justify-center text-white text-sm font-bold flex-shrink-0" style={{ background: emails[active].avatar }}>
                {emails[active].from[0]}
              </div>
              <div className="flex-1 min-w-0">
                <div className="flex items-baseline gap-2">
                  <span className="font-semibold text-sm">{emails[active].from}</span>
                  <span className="text-xs text-black/50">&lt;{emails[active].email}&gt;</span>
                </div>
                <div className="text-xs text-black/50 mt-0.5">Хүлээн авагч: миний имэйл · {emails[active].time}</div>
              </div>
              <div className="flex items-center gap-1">
                <button className="px-3 py-1.5 text-xs bg-black/5 hover:bg-black/10 rounded-lg flex items-center gap-1.5"><Reply className="w-3 h-3" /> Хариу</button>
                <button className="px-3 py-1.5 text-xs bg-black/5 hover:bg-black/10 rounded-lg flex items-center gap-1.5"><Forward className="w-3 h-3" /> Дамжуулах</button>
              </div>
            </div>

            {/* AI Summary */}
            <div className="mb-5 p-4 bg-gradient-to-br from-[#6366F1]/5 to-[#A855F7]/5 border border-[#6366F1]/20 rounded-xl">
              <div className="flex items-center gap-2 mb-2">
                <Sparkles className="w-3.5 h-3.5 text-[#A855F7]" />
                <span className="text-xs font-semibold text-[#A855F7]">AI хураангуй</span>
              </div>
              <p className="text-sm text-black/80 leading-relaxed">
                Q4 маркетингийн кампанит ажлын дөрөвдүгээр сарын үр дүн хавсралтад. Influencer marketing-ийн ROI 3.2x, нийт engagement 47%-аар өссөн. Дараагийн алхам — Q1 2026 төлөвлөгөө хийх.
              </p>
              <div className="flex gap-2 mt-3">
                <button className="text-xs px-3 py-1 bg-white border border-[#6366F1]/20 rounded-full hover:bg-[#6366F1]/5">Action items гаргах</button>
                <button className="text-xs px-3 py-1 bg-white border border-[#6366F1]/20 rounded-full hover:bg-[#6366F1]/5">Хариу үг бичих</button>
              </div>
            </div>

            <div className="prose prose-sm max-w-none text-sm leading-relaxed text-black/85 space-y-4">
              <p>Сайн уу!</p>
              <p>Манай Q4 кампанит ажлын дөрөвдүгээр сарын үр дүнг хавсаргаж байна. Хамгийн чухал тоонууд:</p>
              <ul className="space-y-1">
                <li>• Influencer marketing ROI: <strong>3.2x</strong> (өмнөх сараас 28% өсөлт)</li>
                <li>• Нийт engagement: <strong>47% өссөн</strong></li>
                <li>• Шинэ хэрэглэгчийн тоо: <strong>12,847</strong></li>
                <li>• Cost per acquisition: 18% буурсан</li>
              </ul>
              <p>Дэлгэрэнгүйг файлд харна уу. Маргаашийн уулзалтаар Q1 2026 төлөвлөгөө хэлэлцэе.</p>
              <p>Хүндэтгэсэн,<br />Сараа</p>
            </div>

            {/* Attachment */}
            {emails[active].hasAttachment && (
              <div className="mt-6 inline-flex items-center gap-3 p-3 border border-black/10 rounded-lg max-w-md">
                <div className="w-10 h-10 rounded bg-[#EF4444] text-white text-xs font-bold flex items-center justify-center">PDF</div>
                <div className="flex-1 min-w-0">
                  <div className="text-sm font-medium">Q4_Report_April.pdf</div>
                  <div className="text-xs text-black/50">2.4 MB · 24 хуудас</div>
                </div>
                <button className="text-xs text-[#6366F1] font-medium px-3 py-1.5 rounded-lg hover:bg-[#6366F1]/10">Татах</button>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
