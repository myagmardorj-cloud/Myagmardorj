import { useState } from 'react';
import { ChevronLeft, ChevronRight, Plus, Calendar as CalIcon, Clock, MapPin, Users, Video, Search } from 'lucide-react';

export default function Calendar() {
  const [view, setView] = useState('week');

  const events = [
    { day: 1, start: 9, duration: 1, title: '1:1 Сараатай', color: '#EC4899', type: 'video' },
    { day: 1, start: 14, duration: 1, title: 'Q4 Marketing', color: '#6366F1', type: 'video' },
    { day: 2, start: 10, duration: 1.5, title: 'Engineering sync', color: '#10B981', type: 'video' },
    { day: 3, start: 11, duration: 2, title: 'Strategy uulzalt', color: '#F59E0B', type: 'office' },
    { day: 3, start: 15, duration: 1, title: 'Дизайн review', color: '#A855F7', type: 'video' },
    { day: 4, start: 9, duration: 0.5, title: 'Daily standup', color: '#06B6D4', type: 'video' },
    { day: 4, start: 13, duration: 2, title: 'Customer interview', color: '#EF4444', type: 'office' },
    { day: 5, start: 10, duration: 1, title: 'CEO Town Hall', color: '#6366F1', type: 'video' },
  ];

  const days = ['Дав', 'Мяг', 'Лха', 'Пүр', 'Баа', 'Бям', 'Ням'];
  const dates = [21, 22, 23, 24, 25, 26, 27];
  const today = 25;
  const hours = Array.from({ length: 11 }, (_, i) => i + 8);

  return (
    <div className="h-full flex flex-col bg-white">
      <div className="flex items-center justify-between px-6 py-4 border-b border-black/5">
        <div className="flex items-center gap-3">
          <h1 className="font-display text-2xl font-bold">4-р сар 2026</h1>
          <div className="flex items-center gap-1 ml-3">
            <button className="w-8 h-8 rounded-lg hover:bg-black/5 flex items-center justify-center"><ChevronLeft className="w-4 h-4" /></button>
            <button className="px-3 py-1.5 text-xs bg-black/5 rounded-lg font-medium">Өнөөдөр</button>
            <button className="w-8 h-8 rounded-lg hover:bg-black/5 flex items-center justify-center"><ChevronRight className="w-4 h-4" /></button>
          </div>
        </div>
        <div className="flex items-center gap-2">
          <div className="flex bg-black/5 rounded-lg p-0.5">
            {['day', 'week', 'month'].map((v) => (
              <button
                key={v}
                onClick={() => setView(v)}
                className={`px-3 py-1 text-xs rounded-md transition ${view === v ? 'bg-white shadow-sm font-semibold' : 'text-black/60'}`}
              >
                {v === 'day' ? 'Өдөр' : v === 'week' ? 'Долоо' : 'Сар'}
              </button>
            ))}
          </div>
          <button className="px-4 py-2 bg-gradient-to-r from-[#EC4899] to-[#DB2777] text-white text-xs font-semibold rounded-full flex items-center gap-1.5 hover:scale-[1.02] transition">
            <Plus className="w-3.5 h-3.5" /> Шинэ үйл явдал
          </button>
        </div>
      </div>

      <div className="flex-1 overflow-auto scrollbar-thin">
        {/* Day headers */}
        <div className="grid grid-cols-8 border-b border-black/5 sticky top-0 bg-white z-10">
          <div className="p-3 text-xs text-black/40">GMT+8</div>
          {days.map((d, i) => (
            <div key={i} className="p-3 text-center border-l border-black/5">
              <div className="text-xs text-black/50 mb-1">{d}</div>
              <div className={`inline-flex w-8 h-8 rounded-full items-center justify-center font-semibold ${dates[i] === today ? 'bg-[#EC4899] text-white' : ''}`}>
                {dates[i]}
              </div>
            </div>
          ))}
        </div>

        {/* Time grid */}
        <div className="grid grid-cols-8 relative">
          <div className="border-r border-black/5">
            {hours.map(h => (
              <div key={h} className="h-16 px-2 text-[10px] text-black/40 text-right pt-1">{h}:00</div>
            ))}
          </div>
          {days.map((_, dayIdx) => (
            <div key={dayIdx} className="border-l border-black/5 relative">
              {hours.map(h => (
                <div key={h} className="h-16 border-b border-black/5 hover:bg-black/[0.02] transition" />
              ))}
              {events.filter(e => e.day === dayIdx).map((e, i) => {
                const top = (e.start - 8) * 64;
                const height = e.duration * 64 - 4;
                return (
                  <div
                    key={i}
                    className="absolute left-1 right-1 rounded-md p-2 text-white text-[10px] cursor-pointer hover:scale-[1.02] transition"
                    style={{ top, height, background: e.color }}
                  >
                    <div className="font-semibold truncate">{e.title}</div>
                    <div className="opacity-80">{e.start}:00</div>
                    {e.type === 'video' && <Video className="w-3 h-3 mt-1 opacity-80" />}
                  </div>
                );
              })}

              {/* Current time indicator */}
              {dayIdx === 4 && (
                <div className="absolute left-0 right-0 z-20 pointer-events-none" style={{ top: (13.25 - 8) * 64 }}>
                  <div className="flex items-center">
                    <div className="w-2 h-2 rounded-full bg-[#EF4444] -ml-1" />
                    <div className="flex-1 h-0.5 bg-[#EF4444]" />
                  </div>
                </div>
              )}
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
