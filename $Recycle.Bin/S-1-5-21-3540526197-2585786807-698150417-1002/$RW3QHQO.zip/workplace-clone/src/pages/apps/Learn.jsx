import { GraduationCap, Play, BookOpen, Award, Clock, Users, ChevronRight, Star, CheckCircle2, Lock, Trophy, Flame, Target } from 'lucide-react';

export default function Learn() {
  const myCourses = [
    { title: 'TypeScript бүрэн хичээл', instructor: 'Б. Эрдэнэ', progress: 72, modules: '12/16 module', color: '#3B82F6', cover: 'gradient1' },
    { title: 'UX/UI дизайн үндэс', instructor: 'С. Туяа', progress: 45, modules: '7/15 module', color: '#EC4899', cover: 'gradient2' },
    { title: 'Manager 101', instructor: 'Д. Аюуш', progress: 100, modules: 'Дууссан', color: '#10B981', cover: 'gradient3', completed: true },
  ];

  const recommended = [
    { title: 'AI хэрэглээ ажилдаа', duration: '4 цаг', students: 1247, rating: 4.8, level: 'Дунд', color: '#A855F7' },
    { title: 'Public Speaking', duration: '2.5 цаг', students: 892, rating: 4.9, level: 'Эхлэн', color: '#F59E0B' },
    { title: 'SQL практик', duration: '6 цаг', students: 2341, rating: 4.7, level: 'Дунд', color: '#06B6D4' },
    { title: 'Leadership Skills', duration: '3 цаг', students: 678, rating: 4.9, level: 'Ахлах', color: '#EF4444' },
  ];

  return (
    <div className="p-8 max-w-7xl anim-fade">
      <div className="mb-8 flex flex-col lg:flex-row lg:items-end lg:justify-between gap-4">
        <div>
          <h1 className="font-display text-4xl font-bold tracking-tight mb-2">Learn</h1>
          <p className="text-black/60">Дотоод сургалт, ур чадварын сертификат</p>
        </div>
        <div className="flex items-center gap-4">
          <div className="flex items-center gap-2 px-4 py-2 bg-[#F59E0B]/10 rounded-full">
            <Flame className="w-4 h-4 text-[#F59E0B]" />
            <span className="text-sm font-semibold">7 өдөр streak</span>
          </div>
          <div className="flex items-center gap-2 px-4 py-2 bg-[#A855F7]/10 rounded-full">
            <Trophy className="w-4 h-4 text-[#A855F7]" />
            <span className="text-sm font-semibold">2,847 XP</span>
          </div>
        </div>
      </div>

      {/* Progress overview */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 mb-8">
        {[
          { label: 'Идэвхтэй курс', value: '3', icon: BookOpen, color: '#F59E0B' },
          { label: 'Дууссан', value: '12', icon: CheckCircle2, color: '#10B981' },
          { label: 'Сертификат', value: '7', icon: Award, color: '#A855F7' },
          { label: 'Сурсан цаг', value: '47.5', icon: Clock, color: '#06B6D4' },
        ].map((s, i) => {
          const Icon = s.icon;
          return (
            <div key={i} className="bg-white rounded-2xl p-5 border border-black/5">
              <Icon className="w-4 h-4 mb-3" style={{ color: s.color }} />
              <div className="font-display text-3xl font-bold tracking-tight">{s.value}</div>
              <div className="text-xs text-black/50 mt-1">{s.label}</div>
            </div>
          );
        })}
      </div>

      {/* Continue learning */}
      <h2 className="font-display text-2xl font-bold mb-4">Үргэлжлүүлэх</h2>
      <div className="grid lg:grid-cols-3 gap-5 mb-10">
        {myCourses.map((c, i) => (
          <div key={i} className="bg-white rounded-2xl border border-black/5 overflow-hidden hover:shadow-lg transition group">
            <div className="aspect-video relative" style={{ background: `linear-gradient(135deg, ${c.color}, ${c.color}80)` }}>
              <div className="absolute inset-0 flex items-center justify-center">
                <button className="w-14 h-14 rounded-full bg-white/95 flex items-center justify-center group-hover:scale-110 transition">
                  <Play className="w-5 h-5 text-black ml-0.5" fill="currentColor" />
                </button>
              </div>
              {c.completed && (
                <div className="absolute top-3 left-3 inline-flex items-center gap-1 px-2 py-1 bg-[#10B981] text-white text-xs font-bold rounded-full">
                  <CheckCircle2 className="w-3 h-3" /> Дууссан
                </div>
              )}
              <div className="absolute bottom-0 left-0 right-0 h-1.5 bg-black/20">
                <div className="h-full bg-white" style={{ width: `${c.progress}%` }} />
              </div>
            </div>
            <div className="p-4">
              <h3 className="font-display font-semibold mb-1 line-clamp-1">{c.title}</h3>
              <div className="text-xs text-black/50 mb-3">Багш: {c.instructor}</div>
              <div className="flex items-center justify-between text-xs">
                <span className="text-black/60">{c.modules}</span>
                <span className="font-semibold" style={{ color: c.color }}>{c.progress}%</span>
              </div>
            </div>
          </div>
        ))}
      </div>

      {/* Recommended */}
      <h2 className="font-display text-2xl font-bold mb-4">Танд тохирох курсүүд</h2>
      <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-4 mb-8">
        {recommended.map((c, i) => (
          <div key={i} className="bg-white rounded-2xl border border-black/5 overflow-hidden hover:shadow-md transition cursor-pointer group">
            <div className="aspect-video relative flex items-center justify-center" style={{ background: `linear-gradient(135deg, ${c.color}30, ${c.color}10)` }}>
              <GraduationCap className="w-10 h-10" style={{ color: c.color }} />
              <div className="absolute top-2 right-2 px-1.5 py-0.5 bg-white/90 rounded text-[10px] font-semibold">{c.level}</div>
            </div>
            <div className="p-3">
              <h3 className="font-medium text-sm mb-2 line-clamp-2 min-h-[2.5rem]">{c.title}</h3>
              <div className="flex items-center justify-between text-[10px] text-black/50 mb-2">
                <div className="flex items-center gap-1"><Clock className="w-3 h-3" /> {c.duration}</div>
                <div className="flex items-center gap-1"><Users className="w-3 h-3" /> {c.students}</div>
              </div>
              <div className="flex items-center gap-1 text-[10px]">
                {[1,2,3,4,5].map(s => <Star key={s} className="w-3 h-3 fill-[#F59E0B] text-[#F59E0B]" />)}
                <span className="ml-1 font-semibold">{c.rating}</span>
              </div>
            </div>
          </div>
        ))}
      </div>

      {/* Learning path */}
      <div className="bg-gradient-to-br from-[#F59E0B] to-[#EA580C] rounded-2xl p-6 text-white relative overflow-hidden">
        <Target className="absolute -top-6 -right-6 w-40 h-40 text-white/10" />
        <div className="relative">
          <div className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full bg-white/20 text-[10px] uppercase tracking-wider font-semibold mb-3">
            Career Path
          </div>
          <h3 className="font-display text-2xl font-bold mb-2">Senior Manager болох замдаа</h3>
          <p className="text-sm text-white/80 mb-5 max-w-xl">5 курс дуусгаж сертификат авснаар компанийн ахисан түвшний боломжид өргөдөл өгч болно.</p>
          <div className="flex items-center gap-2">
            <div className="flex -space-x-1">
              {['#FFF', '#F59E0B', '#FFF', '#FFF', '#FFF'].map((c, i) => (
                <div key={i} className={`w-7 h-7 rounded-full border-2 border-[#F59E0B] flex items-center justify-center text-[10px] font-bold ${i < 2 ? 'bg-white text-[#F59E0B]' : 'bg-white/20 text-white/60'}`}>
                  {i < 2 ? <CheckCircle2 className="w-3 h-3" /> : i + 1}
                </div>
              ))}
            </div>
            <span className="text-xs font-medium ml-2">2/5 алхам дууссан</span>
          </div>
        </div>
      </div>
    </div>
  );
}
