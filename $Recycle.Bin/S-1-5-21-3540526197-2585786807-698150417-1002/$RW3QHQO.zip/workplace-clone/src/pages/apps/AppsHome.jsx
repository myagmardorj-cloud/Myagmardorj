import { Link } from 'react-router-dom';
import { apps } from './AppsLayout.jsx';
import { Sparkles, ArrowRight, Clock, TrendingUp, Activity, Zap } from 'lucide-react';

export default function AppsHome() {
  const recent = [
    { app: 'docs', title: 'Q4 стратеги документ', time: '5 мин өмнө' },
    { app: 'meet', title: 'Багийн weekly hurлын хураангуй', time: '1 цагийн өмнө' },
    { app: 'mail', title: 'Холбогдох талаар мэйл', time: '3 цаг өмнө' },
    { app: 'learn', title: 'TypeScript курс - Module 4', time: 'Өчигдөр' },
  ];

  return (
    <div className="p-8 max-w-7xl anim-fade">
      <div className="mb-10">
        <div className="text-xs uppercase tracking-[0.2em] text-[#6366F1] font-semibold mb-3">— Сайн байна уу</div>
        <h1 className="font-display text-5xl font-bold tracking-tight mb-3">
          Өнөөдөр юу <span className="bg-gradient-to-r from-[#6366F1] to-[#A855F7] bg-clip-text text-transparent">бүтээх</span> вэ?
        </h1>
        <p className="text-lg text-black/60 max-w-2xl">
          Чат, видео, сургалт, AI — танай бүх ажлын хэрэгсэл нэг газарт. Хүссэн аппаа сонгож эхлээрэй.
        </p>
      </div>

      {/* Quick stats */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 mb-10">
        {[
          { label: 'Уулзалт өнөөдөр', value: '4', icon: Clock, color: '#6366F1' },
          { label: 'Шинэ зурвас', value: '23', icon: Activity, color: '#10B981' },
          { label: 'Хийгдээгүй', value: '12', icon: TrendingUp, color: '#F59E0B' },
          { label: 'AI асуулт', value: '∞', icon: Sparkles, color: '#A855F7' },
        ].map((s, i) => {
          const Icon = s.icon;
          return (
            <div key={i} className="bg-white rounded-2xl p-5 border border-black/5 hover:shadow-md transition">
              <Icon className="w-4 h-4 mb-3" style={{ color: s.color }} />
              <div className="font-display text-3xl font-bold tracking-tight">{s.value}</div>
              <div className="text-xs text-black/50 mt-1">{s.label}</div>
            </div>
          );
        })}
      </div>

      {/* Voice enrollment card */}
      <div className="bg-white rounded-2xl border border-black/5 overflow-hidden mb-10 relative">
        <div className="absolute -right-10 -top-10 w-48 h-48 rounded-full bg-gradient-to-br from-[#6366F1]/10 to-[#A855F7]/10 blur-2xl" />
        <div className="relative p-6 flex flex-col sm:flex-row items-start sm:items-center gap-5">
          <div className="w-16 h-16 rounded-2xl bg-gradient-to-br from-[#6366F1] to-[#A855F7] flex items-center justify-center flex-shrink-0 relative">
            {/* Mic with pulse */}
            <svg className="w-7 h-7 text-white" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
              <path d="M12 2a3 3 0 0 0-3 3v7a3 3 0 0 0 6 0V5a3 3 0 0 0-3-3Z" />
              <path d="M19 10v2a7 7 0 0 1-14 0v-2" />
              <line x1="12" x2="12" y1="19" y2="22" />
            </svg>
            <div className="absolute inset-0 rounded-2xl bg-[#A855F7] opacity-30 blur-xl animate-pulse" />
          </div>
          <div className="flex-1">
            <div className="flex items-center gap-2 mb-1">
              <span className="text-[10px] uppercase tracking-wider font-bold text-[#A855F7] bg-[#A855F7]/10 px-2 py-0.5 rounded">ШИНЭ</span>
              <span className="text-[10px] uppercase tracking-wider font-semibold text-black/40">3 минут</span>
            </div>
            <h3 className="font-display text-xl font-bold mb-1">Дууны профайл үүсгэх</h3>
            <p className="text-sm text-black/60 leading-relaxed max-w-2xl">
              Express Voice Enrollment — танай дууг бүртгэснээр уулзалтад автомат таних, дуу тусгаарлах, орчуулга илүү нарийвчтай болно.
            </p>
            <div className="flex flex-wrap items-center gap-2 mt-3">
              {[
                { label: 'Speaker recognition', color: '#10B981' },
                { label: 'Voice isolation', color: '#6366F1' },
                { label: 'Improved transcripts', color: '#F59E0B' },
              ].map((b, i) => (
                <span key={i} className="text-[10px] px-2 py-1 rounded-full font-medium" style={{ background: `${b.color}15`, color: b.color }}>
                  ✓ {b.label}
                </span>
              ))}
            </div>
          </div>
          <div className="flex items-center gap-2 sm:flex-col w-full sm:w-auto">
            <button className="flex-1 sm:flex-initial px-5 py-2.5 bg-gradient-to-r from-[#6366F1] to-[#A855F7] text-white text-sm font-semibold rounded-full hover:scale-[1.02] transition flex items-center justify-center gap-2 whitespace-nowrap">
              <Sparkles className="w-3.5 h-3.5" />
              Бүртгүүлэх
            </button>
            <button className="text-xs text-black/50 hover:text-black/70 px-3 py-2">
              Дараа
            </button>
          </div>
        </div>
      </div>

      {/* Apps grid */}
      <div className="mb-10">
        <h2 className="font-display text-2xl font-bold mb-5">Бүх програм</h2>
        <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
          {apps.map((a, i) => {
            const Icon = a.icon;
            return (
              <Link
                key={a.id}
                to={`/apps/${a.id}`}
                className="group bg-white rounded-2xl p-5 border border-black/5 hover:border-black/15 hover:shadow-lg transition-all anim-slide"
                style={{ animationDelay: `${i * 0.05}s` }}
              >
                <div className="w-12 h-12 rounded-2xl flex items-center justify-center mb-4 transition-transform group-hover:scale-110" style={{ background: `${a.color}18`, color: a.color }}>
                  <Icon className="w-5 h-5" />
                </div>
                <div className="font-display font-semibold text-lg mb-1">{a.label}</div>
                <div className="text-xs text-black/50 mb-4">{a.desc}</div>
                <div className="flex items-center gap-1 text-xs font-medium opacity-0 group-hover:opacity-100 transition" style={{ color: a.color }}>
                  Нээх <ArrowRight className="w-3 h-3" />
                </div>
              </Link>
            );
          })}
        </div>
      </div>

      {/* Recent activity */}
      <div className="grid lg:grid-cols-3 gap-6">
        <div className="lg:col-span-2 bg-white rounded-2xl border border-black/5 overflow-hidden">
          <div className="p-5 border-b border-black/5 flex items-center justify-between">
            <h3 className="font-display text-lg font-semibold">Сүүлд ашигласан</h3>
            <button className="text-xs text-[#6366F1] font-medium">Бүгдийг харах</button>
          </div>
          <div className="divide-y divide-black/5">
            {recent.map((r, i) => {
              const app = apps.find(a => a.id === r.app);
              const Icon = app.icon;
              return (
                <Link key={i} to={`/apps/${r.app}`} className="p-4 flex items-center gap-3 hover:bg-black/[0.02] transition">
                  <div className="w-9 h-9 rounded-lg flex items-center justify-center" style={{ background: `${app.color}15`, color: app.color }}>
                    <Icon className="w-4 h-4" />
                  </div>
                  <div className="flex-1 min-w-0">
                    <div className="text-sm font-medium truncate">{r.title}</div>
                    <div className="text-xs text-black/50">{app.label} · {r.time}</div>
                  </div>
                  <ArrowRight className="w-4 h-4 text-black/30" />
                </Link>
              );
            })}
          </div>
        </div>

        <div className="bg-gradient-to-br from-[#6366F1] to-[#A855F7] rounded-2xl p-6 text-white relative overflow-hidden">
          <Sparkles className="absolute -top-4 -right-4 w-32 h-32 text-white/10" />
          <div className="relative">
            <div className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full bg-white/20 backdrop-blur text-[10px] font-medium uppercase tracking-wider mb-4">
              <Zap className="w-3 h-3" /> AI Pro
            </div>
            <h3 className="font-display text-2xl font-bold leading-tight mb-3">
              Nexcore AI чамд тусална
            </h3>
            <p className="text-sm text-white/80 mb-5 leading-relaxed">
              Имэйл бичих, хурлын хураангуй, документ нэгтгэх — бүх жижиг ажлыг AI-д даатга.
            </p>
            <Link to="/apps/ai" className="inline-flex items-center gap-1.5 bg-white text-[#6366F1] px-4 py-2 rounded-full text-sm font-semibold hover:scale-105 transition">
              Туршаад үзэх <ArrowRight className="w-3.5 h-3.5" />
            </Link>
          </div>
        </div>
      </div>
    </div>
  );
}
