import { Outlet, NavLink, Link, useLocation } from 'react-router-dom';
import {
  Home, MessageSquare, Video, GraduationCap, Mail, FileText,
  Sparkles, Calendar, Pencil, Search, Bell, Settings, Grid3x3,
  ChevronLeft, Globe, Inbox
} from 'lucide-react';
import { useState } from 'react';
import { useTenant } from '../../contexts/TenantContext.jsx';
import NotificationCenter from '../../components/NotificationCenter.jsx';

export const apps = [
  { id: 'chat', label: 'Чат', icon: MessageSquare, color: '#6366F1', desc: 'Багийн харилцаа' },
  { id: 'meet', label: 'Уулзалт', icon: Video, color: '#10B981', desc: 'Видео уулзалт' },
  { id: 'learn', label: 'Сургалт', icon: GraduationCap, color: '#F59E0B', desc: 'Сургалт, курс' },
  { id: 'mail', label: 'Имэйл', icon: Mail, color: '#EF4444', desc: 'Имэйл' },
  { id: 'docs', label: 'Баримт', icon: FileText, color: '#3B82F6', desc: 'Баримт бичиг' },
  { id: 'ai', label: 'AI', icon: Sparkles, color: '#A855F7', desc: 'AI туслах' },
  { id: 'calendar', label: 'Хуанли', icon: Calendar, color: '#EC4899', desc: 'Хуанли' },
  { id: 'whiteboard', label: 'Самбар', icon: Pencil, color: '#14B8A6', desc: 'Whiteboard' },
  { id: 'drafts', label: 'Ноорог', icon: Inbox, color: '#94A3B8', desc: 'Бүх ноорог' },
];

export default function AppsLayout() {
  const [collapsed, setCollapsed] = useState(false);
  const [notifOpen, setNotifOpen] = useState(false);
  const location = useLocation();
  const isHome = location.pathname === '/apps';
  const { currentTenant } = useTenant();

  return (
    <div className="h-screen flex bg-[#FAFAFC] overflow-hidden" style={{ fontFamily: "'Geist', system-ui, sans-serif" }}>
      <style>{`
        @import url('https://fonts.googleapis.com/css2?family=Bricolage+Grotesque:opsz,wght@12..96,500;12..96,600;12..96,700&family=Geist:wght@400;500;600;700&family=JetBrains+Mono:wght@400;500&display=swap');
        .font-display { font-family: 'Bricolage Grotesque', sans-serif; letter-spacing: -0.02em; }
        .font-mono { font-family: 'JetBrains Mono', monospace; }
        @keyframes fadeIn { from { opacity: 0; transform: translateY(8px) } to { opacity: 1; transform: translateY(0) } }
        .anim-fade { animation: fadeIn 0.3s ease-out; }
        @keyframes slideRight { from { transform: translateX(-12px); opacity: 0 } to { transform: translateX(0); opacity: 1 } }
        .anim-slide { animation: slideRight 0.4s cubic-bezier(0.22, 1, 0.36, 1) backwards; }
        .scrollbar-thin::-webkit-scrollbar { width: 6px }
        .scrollbar-thin::-webkit-scrollbar-thumb { background: rgba(0,0,0,0.1); border-radius: 3px }
        .scrollbar-thin::-webkit-scrollbar-track { background: transparent }
      `}</style>

      {/* App rail */}
      <aside className={`${collapsed ? 'w-16' : 'w-64'} bg-white border-r border-black/5 flex flex-col transition-all duration-300 flex-shrink-0`}>
        <div className="p-4 flex items-center justify-between border-b border-black/5">
          <Link to="/" className="flex items-center gap-2">
            <NexcoreLogo />
            {!collapsed && (
              <div>
                <div className="font-display font-bold text-sm tracking-tight">Nexcore</div>
                <div className="text-[10px] text-black/40 -mt-0.5">Платформ</div>
              </div>
            )}
          </Link>
          {!collapsed && (
            <button onClick={() => setCollapsed(true)} className="w-7 h-7 rounded-lg hover:bg-black/5 flex items-center justify-center">
              <ChevronLeft className="w-3.5 h-3.5" />
            </button>
          )}
          {collapsed && (
            <button onClick={() => setCollapsed(false)} className="absolute left-12 mt-0.5 w-6 h-6 rounded-full bg-white border border-black/10 shadow flex items-center justify-center hover:bg-black/5">
              <ChevronLeft className="w-3 h-3 rotate-180" />
            </button>
          )}
        </div>

        <NavLink to="/apps" end className={({ isActive }) => `mx-3 mt-4 mb-2 flex items-center gap-3 px-3 py-2 rounded-lg text-sm transition ${isActive ? 'bg-[#6366F1] text-white' : 'hover:bg-black/5'}`}>
          <Grid3x3 className="w-4 h-4 flex-shrink-0" />
          {!collapsed && <span className="font-medium">Бүх апп</span>}
        </NavLink>

        {!collapsed && <div className="px-6 pt-3 pb-1.5 text-[10px] uppercase tracking-wider text-black/40 font-semibold">Ажлын орчин</div>}

        <nav className="flex-1 px-3 space-y-0.5 overflow-y-auto scrollbar-thin">
          {apps.map((a) => {
            const Icon = a.icon;
            return (
              <NavLink
                key={a.id}
                to={`/apps/${a.id}`}
                className={({ isActive }) => `flex items-center gap-3 px-3 py-2 rounded-lg text-sm transition group ${isActive ? 'bg-black/5 font-medium' : 'hover:bg-black/[0.03]'}`}
              >
                {({ isActive }) => (
                  <>
                    <div className={`w-7 h-7 rounded-lg flex items-center justify-center flex-shrink-0 transition`} style={{ background: isActive ? a.color : `${a.color}15`, color: isActive ? 'white' : a.color }}>
                      <Icon className="w-3.5 h-3.5" />
                    </div>
                    {!collapsed && (
                      <>
                        <span className="flex-1">{a.label}</span>
                        {isActive && <div className="w-1 h-1 rounded-full" style={{ background: a.color }} />}
                      </>
                    )}
                  </>
                )}
              </NavLink>
            );
          })}
        </nav>

        {!collapsed && (
          <div className="p-3 border-t border-black/5">
            <div className="bg-gradient-to-br from-[#6366F1] to-[#A855F7] rounded-2xl p-4 text-white relative overflow-hidden">
              <Sparkles className="absolute -top-2 -right-2 w-12 h-12 text-white/10" />
              <div className="relative">
                <div className="text-xs font-medium opacity-90">Pro багц</div>
                <div className="text-[10px] opacity-70 mt-0.5 mb-3">Бүх боломж нээгдсэн</div>
                <button className="text-[10px] bg-white/20 backdrop-blur px-2.5 py-1 rounded-full font-medium hover:bg-white/30 transition">Удирдах →</button>
              </div>
            </div>
          </div>
        )}
      </aside>

      {/* Main */}
      <div className="flex-1 flex flex-col min-w-0">
        {/* Subdomain indicator */}
        <div className="bg-gradient-to-r from-[#6366F1]/10 to-transparent border-b border-[#6366F1]/10 px-5 py-1.5 flex items-center gap-2 text-[10px]">
          <Globe className="w-3 h-3 text-[#6366F1]" />
          <span className="font-mono text-black/50">https://</span>
          <span className="font-mono font-semibold text-[#6366F1]">{currentTenant.subdomain}</span>
          <span className="font-mono text-black/50">.nexcoreplatforms.mn/apps</span>
          <span className="hidden sm:inline ml-2 text-black/40">·</span>
          <div className="hidden sm:flex items-center gap-1.5">
            <div className="w-3.5 h-3.5 rounded flex items-center justify-center text-white text-[8px] font-bold" style={{ background: currentTenant.color }}>{currentTenant.logo}</div>
            <span className="text-black/60">{currentTenant.name}</span>
          </div>
        </div>

        {/* Top bar */}
        <header className="h-14 bg-white border-b border-black/5 flex items-center px-5 gap-4 flex-shrink-0">
          <div className="flex-1 max-w-xl relative">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-black/40" />
            <input
              type="text"
              placeholder={`${currentTenant.name} дотор хайх...`}
              className="w-full pl-10 pr-16 py-2 bg-[#FAFAFC] border border-black/5 rounded-lg text-sm focus:outline-none focus:border-[#6366F1]/30 focus:ring-2 focus:ring-[#6366F1]/10"
            />
            <kbd className="absolute right-2 top-1/2 -translate-y-1/2 text-[10px] px-1.5 py-0.5 bg-white border border-black/10 rounded text-black/40 font-mono">⌘K</kbd>
          </div>
          <div className="flex items-center gap-1 relative">
            <button onClick={() => setNotifOpen(!notifOpen)} className={`w-9 h-9 rounded-lg flex items-center justify-center relative transition ${notifOpen ? 'bg-[#6366F1]/10 text-[#6366F1]' : 'hover:bg-black/5'}`}>
              <Bell className="w-4 h-4" />
              <div className="absolute top-2 right-2 w-1.5 h-1.5 rounded-full bg-[#EF4444]" />
            </button>
            {notifOpen && <NotificationCenter onClose={() => setNotifOpen(false)} />}
            <Link to="/admin" className="w-9 h-9 rounded-lg hover:bg-black/5 flex items-center justify-center" title="Админ">
              <Settings className="w-4 h-4" />
            </Link>
            <div className="w-9 h-9 rounded-full bg-gradient-to-br from-[#6366F1] to-[#A855F7] ml-1" />
          </div>
        </header>

        <main className="flex-1 overflow-y-auto">
          <Outlet />
        </main>
      </div>
    </div>
  );
}

export function NexcoreLogo({ size = 32 }) {
  return (
    <svg width={size} height={size} viewBox="0 0 32 32" className="flex-shrink-0">
      <defs>
        <linearGradient id="nx-grad" x1="0" y1="0" x2="1" y2="1">
          <stop offset="0%" stopColor="#6366F1" />
          <stop offset="100%" stopColor="#A855F7" />
        </linearGradient>
      </defs>
      <rect width="32" height="32" rx="8" fill="url(#nx-grad)" />
      <path d="M9 22 L9 10 L13 10 L19 18 L19 10 L23 10 L23 22 L19 22 L13 14 L13 22 Z" fill="white" />
    </svg>
  );
}
