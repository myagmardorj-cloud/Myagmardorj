import { useState } from 'react';
import {
  MousePointer2, Square, Circle, Triangle, Type, Pencil, Eraser,
  StickyNote, Image as ImageIcon, ArrowRight, Hand, Undo2, Redo2,
  Trash2, Download, Share2, Users, Plus, Minus, Sparkles
} from 'lucide-react';

export default function Whiteboard() {
  const [tool, setTool] = useState('pen');

  const tools = [
    { id: 'select', icon: MousePointer2, label: 'Сонгох' },
    { id: 'hand', icon: Hand, label: 'Хөдөлгөх' },
    { id: 'pen', icon: Pencil, label: 'Зурах' },
    { id: 'eraser', icon: Eraser, label: 'Арилгах' },
    { id: 'rect', icon: Square, label: 'Дөрвөлжин' },
    { id: 'circle', icon: Circle, label: 'Тойрог' },
    { id: 'arrow', icon: ArrowRight, label: 'Сум' },
    { id: 'text', icon: Type, label: 'Текст' },
    { id: 'sticky', icon: StickyNote, label: 'Sticky note' },
    { id: 'image', icon: ImageIcon, label: 'Зураг' },
  ];

  const colors = ['#0F0F1A', '#EF4444', '#F59E0B', '#10B981', '#3B82F6', '#A855F7', '#EC4899'];

  return (
    <div className="h-full flex flex-col bg-[#FAFAFC]">
      {/* Top bar */}
      <div className="bg-white border-b border-black/5 px-5 py-3 flex items-center justify-between flex-shrink-0">
        <div className="flex items-center gap-3">
          <input defaultValue="Q4 Санааны хурал" className="font-medium text-sm bg-transparent border-0 focus:outline-none focus:bg-black/5 px-2 py-1 rounded" />
          <span className="text-xs text-black/50">Хадгалагдсан</span>
        </div>
        <div className="flex items-center gap-2">
          <div className="flex -space-x-2">
            <div className="w-7 h-7 rounded-full border-2 border-white bg-[#14B8A6]" />
            <div className="w-7 h-7 rounded-full border-2 border-white bg-[#F59E0B]" />
            <div className="w-7 h-7 rounded-full border-2 border-white bg-[#A855F7]" />
            <div className="w-7 h-7 rounded-full border-2 border-white bg-black/10 flex items-center justify-center text-[10px] font-semibold">+2</div>
          </div>
          <button className="px-3 py-1.5 text-xs bg-[#14B8A6] text-white rounded-full font-medium flex items-center gap-1.5">
            <Share2 className="w-3 h-3" /> Хуваалцах
          </button>
        </div>
      </div>

      {/* Canvas area */}
      <div className="flex-1 relative overflow-hidden">
        {/* Grid pattern */}
        <div
          className="absolute inset-0"
          style={{
            backgroundImage: 'radial-gradient(circle, rgba(0,0,0,0.06) 1px, transparent 1px)',
            backgroundSize: '24px 24px',
          }}
        />

        {/* Sample canvas content */}
        <div className="absolute inset-0 p-12">
          {/* Sticky notes */}
          <div className="absolute top-20 left-20 w-44 h-44 bg-[#FFEB3B] rounded-md shadow-lg p-4 transform -rotate-2">
            <div className="text-xs font-bold mb-2 text-black/60">Идея 1</div>
            <div className="text-sm">Influencer marketing-аа TikTok-руу шилжүүлж 3x ROI авах боломжтой</div>
          </div>
          <div className="absolute top-32 left-72 w-44 h-44 bg-[#FF80AB] rounded-md shadow-lg p-4 transform rotate-1">
            <div className="text-xs font-bold mb-2 text-black/60">Идея 2</div>
            <div className="text-sm">B2B podcast эхлүүлж enterprise client-уудтай харилцах</div>
          </div>
          <div className="absolute top-12 left-[28rem] w-44 h-44 bg-[#80DEEA] rounded-md shadow-lg p-4 transform -rotate-1">
            <div className="text-xs font-bold mb-2 text-black/60">Идея 3</div>
            <div className="text-sm">AI-powered case studies — клиент бүрд автомат тайлан</div>
          </div>

          {/* Connecting arrows */}
          <svg className="absolute inset-0 pointer-events-none" style={{ width: '100%', height: '100%' }}>
            <defs>
              <marker id="arrowhead" markerWidth="10" markerHeight="7" refX="9" refY="3.5" orient="auto">
                <polygon points="0 0, 10 3.5, 0 7" fill="#A855F7" />
              </marker>
            </defs>
            <path d="M 240 200 Q 280 160 320 180" stroke="#A855F7" strokeWidth="2" fill="none" markerEnd="url(#arrowhead)" strokeDasharray="6 3" />
            <path d="M 460 200 Q 500 170 540 160" stroke="#A855F7" strokeWidth="2" fill="none" markerEnd="url(#arrowhead)" strokeDasharray="6 3" />
          </svg>

          {/* Title box */}
          <div className="absolute bottom-32 left-1/2 -translate-x-1/2 bg-white rounded-2xl shadow-lg px-6 py-4 border-2 border-[#14B8A6]">
            <div className="text-xs text-[#14B8A6] font-bold uppercase tracking-wider mb-1">Гол асуулт</div>
            <div className="font-display text-xl font-bold">Q4-д хамгийн их нөлөөтэй чиглэл аль нь вэ?</div>
          </div>

          {/* Live cursor */}
          <div className="absolute top-1/3 right-1/3 pointer-events-none">
            <MousePointer2 className="w-5 h-5 text-[#A855F7] fill-[#A855F7]" />
            <div className="ml-3 -mt-1 px-2 py-0.5 bg-[#A855F7] text-white text-[10px] rounded">Сараа</div>
          </div>
        </div>

        {/* AI suggestion banner */}
        <div className="absolute top-4 right-4 bg-white shadow-xl rounded-xl p-4 border border-black/5 max-w-xs">
          <div className="flex items-center gap-2 mb-2">
            <Sparkles className="w-4 h-4 text-[#A855F7]" />
            <span className="text-xs font-semibold text-[#A855F7]">AI санал</span>
          </div>
          <p className="text-xs text-black/80 leading-relaxed mb-3">3 идэйг нэгтгэж нэг стратеги болгож байгаа. Бүтэцлэх help хэрэгтэй юу?</p>
          <div className="flex gap-2">
            <button className="text-[10px] px-2 py-1 bg-[#A855F7] text-white rounded">Тийм</button>
            <button className="text-[10px] px-2 py-1 bg-black/5 rounded">Үгүй</button>
          </div>
        </div>

        {/* Zoom controls */}
        <div className="absolute bottom-4 right-4 bg-white rounded-xl shadow-md border border-black/5 flex items-center">
          <button className="w-8 h-8 hover:bg-black/5 flex items-center justify-center"><Minus className="w-3.5 h-3.5" /></button>
          <div className="text-xs px-2 font-mono">100%</div>
          <button className="w-8 h-8 hover:bg-black/5 flex items-center justify-center"><Plus className="w-3.5 h-3.5" /></button>
        </div>
      </div>

      {/* Toolbar */}
      <div className="absolute left-1/2 -translate-x-1/2 bottom-6 bg-white rounded-2xl shadow-xl border border-black/5 p-2 flex items-center gap-1">
        {tools.map((t) => {
          const Icon = t.icon;
          return (
            <button
              key={t.id}
              onClick={() => setTool(t.id)}
              title={t.label}
              className={`w-9 h-9 rounded-lg flex items-center justify-center transition ${tool === t.id ? 'bg-[#14B8A6] text-white' : 'hover:bg-black/5'}`}
            >
              <Icon className="w-4 h-4" />
            </button>
          );
        })}
        <div className="w-px h-6 bg-black/10 mx-1" />
        {colors.map((c, i) => (
          <button
            key={i}
            className="w-7 h-7 rounded-full hover:scale-110 transition border-2 border-white"
            style={{ background: c, outline: i === 0 ? `2px solid ${c}40` : '' }}
          />
        ))}
        <div className="w-px h-6 bg-black/10 mx-1" />
        <button className="w-9 h-9 rounded-lg hover:bg-black/5 flex items-center justify-center"><Undo2 className="w-4 h-4" /></button>
        <button className="w-9 h-9 rounded-lg hover:bg-black/5 flex items-center justify-center"><Redo2 className="w-4 h-4" /></button>
      </div>
    </div>
  );
}
