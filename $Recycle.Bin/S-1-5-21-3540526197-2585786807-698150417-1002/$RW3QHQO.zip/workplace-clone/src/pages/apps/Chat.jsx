import { useState } from 'react';
import {
  Hash, Lock, Plus, Search, Send, Smile, Paperclip, AtSign, Star,
  Bell, Pin, Phone, Video, MoreHorizontal, Bookmark, ThumbsUp,
  MessageSquare, Reply
} from 'lucide-react';

export default function Chat() {
  const [activeChannel, setActiveChannel] = useState('маркетинг');
  const [message, setMessage] = useState('');

  const channels = [
    { name: 'general', members: 247, unread: 0 },
    { name: 'announcements', members: 247, unread: 3, badge: true },
    { name: 'маркетинг', members: 47, unread: 12, active: true },
    { name: 'engineering', members: 89, unread: 0 },
    { name: 'random', members: 198, unread: 4 },
    { name: 'дизайн', members: 23, unread: 0 },
  ];

  const dms = [
    { name: 'Сараа Б.', status: 'online', color: '#10B981', unread: 2 },
    { name: 'Дорж А.', status: 'away', color: '#F59E0B', unread: 0 },
    { name: 'Болд Г.', status: 'offline', color: '#94A3B8', unread: 0 },
    { name: 'Туяа М.', status: 'online', color: '#EC4899', unread: 5 },
  ];

  const messages = [
    { author: 'Сараа Болд', avatar: '#10B981', time: '10:24', text: 'Сайн уу хүмүүс! Q4 кампанит ажлын төлөвлөгөө бэлэн боллоо 🎉', reactions: [{ emoji: '🎉', count: 8 }, { emoji: '👍', count: 5 }] },
    { author: 'Сараа Болд', avatar: '#10B981', time: '10:24', text: 'Файлыг хавсаргалаа. Танай саналыг хүлээж байна.', file: { name: 'Q4_Marketing_Plan.pdf', size: '2.4 MB' } },
    { author: 'Дорж Аюуш', avatar: '#F59E0B', time: '10:31', text: 'Гайхалтай ажил! @Сараа budget хэсэг дээр асуулт байна — slide 12 дээр зарцуулалт өсч байгаа шалтгаан юу вэ?' },
    { author: 'Туяа Мөнх', avatar: '#EC4899', time: '10:35', text: 'Influencer marketing хэсгийг 30% нэмэгдүүлэхээр болсон, тэр болохоор. Гүйцэтгэл өндөр гарч байгаа учир.', reactions: [{ emoji: '💡', count: 3 }] },
    { author: 'Сараа Болд', avatar: '#10B981', time: '10:38', text: 'Тэгээд 2026 Q1-д бид TikTok-руу шилжих санал гарч байгаа. Маргааш 14:00-д уулзалт хийе үү?', isReplyChain: true },
  ];

  return (
    <div className="flex h-full bg-white">
      {/* Channel sidebar */}
      <div className="w-60 bg-[#FAFAFC] border-r border-black/5 flex flex-col flex-shrink-0">
        <div className="p-4 border-b border-black/5">
          <div className="flex items-center justify-between mb-3">
            <div className="font-display font-bold">Ажлын орчин</div>
            <button className="w-6 h-6 rounded hover:bg-black/5 flex items-center justify-center">
              <Plus className="w-3.5 h-3.5" />
            </button>
          </div>
          <div className="relative">
            <Search className="absolute left-2.5 top-1/2 -translate-y-1/2 w-3.5 h-3.5 text-black/40" />
            <input placeholder="Хайх..." className="w-full pl-8 pr-3 py-1.5 bg-white border border-black/5 rounded-md text-xs focus:outline-none focus:border-[#6366F1]/30" />
          </div>
        </div>

        <div className="flex-1 overflow-y-auto py-2 scrollbar-thin">
          <div className="px-4 pt-2 pb-1 flex items-center justify-between">
            <span className="text-[10px] uppercase tracking-wider text-black/50 font-semibold">Сувгууд</span>
            <Plus className="w-3 h-3 text-black/40 cursor-pointer hover:text-black/70" />
          </div>
          {channels.map((c, i) => (
            <button
              key={i}
              onClick={() => setActiveChannel(c.name)}
              className={`w-full flex items-center gap-2 px-4 py-1.5 text-sm transition ${activeChannel === c.name ? 'bg-[#6366F1] text-white' : 'hover:bg-black/5'}`}
            >
              <Hash className="w-3.5 h-3.5 flex-shrink-0 opacity-60" />
              <span className="flex-1 text-left truncate">{c.name}</span>
              {c.unread > 0 && (
                <span className={`text-[10px] font-bold px-1.5 py-0.5 rounded-full ${activeChannel === c.name ? 'bg-white/20' : 'bg-[#6366F1] text-white'}`}>
                  {c.unread}
                </span>
              )}
            </button>
          ))}

          <div className="px-4 pt-5 pb-1 flex items-center justify-between">
            <span className="text-[10px] uppercase tracking-wider text-black/50 font-semibold">Хувийн чат</span>
            <Plus className="w-3 h-3 text-black/40 cursor-pointer hover:text-black/70" />
          </div>
          {dms.map((d, i) => (
            <button key={i} className="w-full flex items-center gap-2 px-4 py-1.5 text-sm hover:bg-black/5 transition">
              <div className="relative flex-shrink-0">
                <div className="w-5 h-5 rounded" style={{ background: d.color }} />
                <div className={`absolute -bottom-0.5 -right-0.5 w-2 h-2 rounded-full border-2 border-[#FAFAFC] ${d.status === 'online' ? 'bg-[#10B981]' : d.status === 'away' ? 'bg-[#F59E0B]' : 'bg-black/30'}`} />
              </div>
              <span className="flex-1 text-left truncate">{d.name}</span>
              {d.unread > 0 && <span className="text-[10px] font-bold bg-[#6366F1] text-white px-1.5 py-0.5 rounded-full">{d.unread}</span>}
            </button>
          ))}
        </div>

        <div className="p-3 border-t border-black/5 flex items-center gap-2">
          <div className="relative">
            <div className="w-7 h-7 rounded bg-gradient-to-br from-[#6366F1] to-[#A855F7]" />
            <div className="absolute -bottom-0.5 -right-0.5 w-2.5 h-2.5 rounded-full bg-[#10B981] border-2 border-[#FAFAFC]" />
          </div>
          <div className="flex-1 min-w-0">
            <div className="text-xs font-medium truncate">Н. Мягмардорж</div>
            <div className="text-[10px] text-black/50">Идэвхтэй</div>
          </div>
        </div>
      </div>

      {/* Messages */}
      <div className="flex-1 flex flex-col min-w-0">
        <div className="h-14 border-b border-black/5 px-5 flex items-center justify-between flex-shrink-0">
          <div className="flex items-center gap-2.5">
            <Hash className="w-4 h-4 text-black/40" />
            <div>
              <div className="font-semibold text-sm">{activeChannel}</div>
              <div className="text-[10px] text-black/50">47 гишүүн · Q4 кампанит ажлын талаар</div>
            </div>
          </div>
          <div className="flex items-center gap-1">
            <button className="w-8 h-8 rounded-lg hover:bg-black/5 flex items-center justify-center"><Phone className="w-4 h-4" /></button>
            <button className="w-8 h-8 rounded-lg hover:bg-black/5 flex items-center justify-center"><Video className="w-4 h-4" /></button>
            <button className="w-8 h-8 rounded-lg hover:bg-black/5 flex items-center justify-center"><Pin className="w-4 h-4" /></button>
            <button className="w-8 h-8 rounded-lg hover:bg-black/5 flex items-center justify-center"><MoreHorizontal className="w-4 h-4" /></button>
          </div>
        </div>

        <div className="flex-1 overflow-y-auto px-5 py-4 space-y-1 scrollbar-thin">
          <div className="text-center py-3">
            <div className="inline-flex items-center gap-2 px-3 py-1 bg-black/5 rounded-full text-[10px] text-black/50">
              <div className="w-1 h-1 rounded-full bg-black/30" />
              Өчигдөр
              <div className="w-1 h-1 rounded-full bg-black/30" />
            </div>
          </div>

          {messages.map((m, i) => (
            <div key={i} className="flex gap-3 hover:bg-black/[0.02] rounded-lg p-2 -mx-2 group">
              <div className="w-9 h-9 rounded-lg flex-shrink-0" style={{ background: m.avatar }} />
              <div className="flex-1 min-w-0">
                <div className="flex items-baseline gap-2">
                  <span className="font-semibold text-sm">{m.author}</span>
                  <span className="text-[10px] text-black/40">{m.time}</span>
                </div>
                <div className="text-sm text-black/85 leading-relaxed mt-0.5">{m.text}</div>

                {m.file && (
                  <div className="mt-2 inline-flex items-center gap-3 p-3 border border-black/10 rounded-lg max-w-md">
                    <div className="w-9 h-9 rounded bg-[#EF4444] text-white text-[10px] font-bold flex items-center justify-center">PDF</div>
                    <div className="flex-1 min-w-0">
                      <div className="text-sm font-medium truncate">{m.file.name}</div>
                      <div className="text-xs text-black/50">{m.file.size}</div>
                    </div>
                    <button className="text-xs text-[#6366F1] font-medium">Татах</button>
                  </div>
                )}

                {m.reactions && (
                  <div className="flex items-center gap-1 mt-1.5">
                    {m.reactions.map((r, j) => (
                      <div key={j} className="flex items-center gap-1 px-1.5 py-0.5 bg-[#6366F1]/10 border border-[#6366F1]/20 rounded-full text-xs">
                        <span>{r.emoji}</span>
                        <span className="text-[10px] font-medium text-[#6366F1]">{r.count}</span>
                      </div>
                    ))}
                    <button className="opacity-0 group-hover:opacity-100 transition w-5 h-5 rounded-full bg-black/5 flex items-center justify-center">
                      <Smile className="w-3 h-3 text-black/50" />
                    </button>
                  </div>
                )}
              </div>
              <div className="opacity-0 group-hover:opacity-100 flex items-start gap-0.5 transition">
                <button className="w-7 h-7 rounded hover:bg-black/5 flex items-center justify-center"><Smile className="w-3.5 h-3.5" /></button>
                <button className="w-7 h-7 rounded hover:bg-black/5 flex items-center justify-center"><Reply className="w-3.5 h-3.5" /></button>
                <button className="w-7 h-7 rounded hover:bg-black/5 flex items-center justify-center"><Bookmark className="w-3.5 h-3.5" /></button>
              </div>
            </div>
          ))}
        </div>

        {/* Composer */}
        <div className="p-4 border-t border-black/5">
          <div className="border border-black/10 rounded-xl focus-within:border-[#6366F1]/40 transition">
            <textarea
              value={message}
              onChange={(e) => setMessage(e.target.value)}
              placeholder={`Зурвас илгээх #${activeChannel}-руу`}
              rows={1}
              className="w-full px-4 py-3 bg-transparent text-sm focus:outline-none resize-none"
            />
            <div className="flex items-center justify-between px-2 py-1.5 border-t border-black/5">
              <div className="flex items-center gap-0.5">
                <button className="w-7 h-7 rounded hover:bg-black/5 flex items-center justify-center"><Paperclip className="w-3.5 h-3.5" /></button>
                <button className="w-7 h-7 rounded hover:bg-black/5 flex items-center justify-center"><AtSign className="w-3.5 h-3.5" /></button>
                <button className="w-7 h-7 rounded hover:bg-black/5 flex items-center justify-center"><Smile className="w-3.5 h-3.5" /></button>
              </div>
              <button disabled={!message.trim()} className="px-3 py-1.5 bg-[#6366F1] text-white text-xs font-medium rounded-md disabled:opacity-30 hover:bg-[#5455E0] transition flex items-center gap-1.5">
                <Send className="w-3 h-3" />
                Илгээх
              </button>
            </div>
          </div>
          <div className="text-[10px] text-black/40 mt-1.5 px-1">
            <span className="font-mono">⏎</span> илгээх · <span className="font-mono">⇧⏎</span> мөр шилжих · <span className="font-mono">/</span> командууд
          </div>
        </div>
      </div>
    </div>
  );
}
