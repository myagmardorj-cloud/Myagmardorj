import { useState } from 'react';
import {
  Mic, MicOff, Video, VideoOff, ScreenShare, MessageSquare, Users,
  PhoneOff, MoreHorizontal, Hand, Smile, Sparkles, Settings,
  Plus, Calendar, Link2, Copy, Shield, Volume2
} from 'lucide-react';

export default function Meet() {
  const [inMeeting, setInMeeting] = useState(false);
  const [muted, setMuted] = useState(false);
  const [videoOn, setVideoOn] = useState(true);

  if (!inMeeting) {
    return <MeetLobby onJoin={() => setInMeeting(true)} />;
  }

  return <MeetRoom muted={muted} setMuted={setMuted} videoOn={videoOn} setVideoOn={setVideoOn} onLeave={() => setInMeeting(false)} />;
}

function MeetLobby({ onJoin }) {
  const upcoming = [
    { title: 'Q4 Marketing Sync', time: 'Одоо · 10:30 - 11:00', members: 8, color: '#10B981', live: true },
    { title: 'Engineering Weekly', time: '14:00 - 15:00', members: 12, color: '#6366F1' },
    { title: '1:1 with Сараа', time: '16:00 - 16:30', members: 2, color: '#EC4899' },
    { title: 'All Hands', time: 'Маргааш 10:00', members: 247, color: '#F59E0B' },
  ];

  return (
    <div className="p-8 max-w-7xl anim-fade">
      <div className="mb-8">
        <h1 className="font-display text-4xl font-bold tracking-tight mb-2">Meet</h1>
        <p className="text-black/60">Видео уулзалт, дуу дуудлага, AI хураангуй</p>
      </div>

      <div className="grid lg:grid-cols-3 gap-5 mb-8">
        <button onClick={onJoin} className="group bg-gradient-to-br from-[#10B981] to-[#059669] rounded-2xl p-6 text-white text-left relative overflow-hidden hover:scale-[1.02] transition">
          <Video className="absolute -top-2 -right-2 w-24 h-24 text-white/10" />
          <div className="relative">
            <div className="w-12 h-12 rounded-2xl bg-white/20 backdrop-blur flex items-center justify-center mb-4">
              <Video className="w-5 h-5" />
            </div>
            <div className="font-display text-xl font-bold mb-1">Шинэ уулзалт</div>
            <div className="text-sm text-white/80">Шууд эхлүүлэх</div>
          </div>
        </button>

        <button className="group bg-white border border-black/10 rounded-2xl p-6 text-left hover:border-black/30 transition">
          <div className="w-12 h-12 rounded-2xl bg-[#6366F1]/10 text-[#6366F1] flex items-center justify-center mb-4">
            <Calendar className="w-5 h-5" />
          </div>
          <div className="font-display text-xl font-bold mb-1">Уулзалт төлөвлөх</div>
          <div className="text-sm text-black/60">Хуанлид нэмэх</div>
        </button>

        <button className="group bg-white border border-black/10 rounded-2xl p-6 text-left hover:border-black/30 transition">
          <div className="w-12 h-12 rounded-2xl bg-[#A855F7]/10 text-[#A855F7] flex items-center justify-center mb-4">
            <Link2 className="w-5 h-5" />
          </div>
          <div className="font-display text-xl font-bold mb-1">Холбоосоор нэгдэх</div>
          <div className="text-sm text-black/60">Урилгын код оруулах</div>
        </button>
      </div>

      {/* Upcoming meetings */}
      <div className="bg-white rounded-2xl border border-black/5 overflow-hidden mb-6">
        <div className="p-5 border-b border-black/5 flex items-center justify-between">
          <h2 className="font-display text-lg font-semibold">Удахгүй уулзалт</h2>
          <button className="text-xs text-[#6366F1] font-medium">Бүгд</button>
        </div>
        <div className="divide-y divide-black/5">
          {upcoming.map((m, i) => (
            <div key={i} className="p-4 flex items-center gap-4 hover:bg-black/[0.02] transition">
              <div className="w-1 h-12 rounded-full" style={{ background: m.color }} />
              <div className="flex-1 min-w-0">
                <div className="flex items-center gap-2">
                  <span className="font-semibold text-sm">{m.title}</span>
                  {m.live && (
                    <span className="inline-flex items-center gap-1 px-1.5 py-0.5 bg-[#10B981]/10 text-[#10B981] rounded text-[10px] font-bold">
                      <span className="w-1 h-1 rounded-full bg-[#10B981] animate-pulse" />
                      LIVE
                    </span>
                  )}
                </div>
                <div className="text-xs text-black/50 mt-0.5">{m.time} · {m.members} оролцогч</div>
              </div>
              {m.live ? (
                <button onClick={i === 0 ? () => {} : null} className="px-4 py-1.5 bg-[#10B981] text-white text-xs font-semibold rounded-full hover:bg-[#059669]">Нэгдэх</button>
              ) : (
                <button className="px-4 py-1.5 bg-black/5 text-xs font-medium rounded-full hover:bg-black/10">Үзэх</button>
              )}
            </div>
          ))}
        </div>
      </div>

      {/* AI features */}
      <div className="bg-gradient-to-br from-[#6366F1] to-[#A855F7] rounded-2xl p-6 text-white relative overflow-hidden mb-6">
        <Sparkles className="absolute -top-4 -right-4 w-32 h-32 text-white/10" />
        <div className="relative">
          <div className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full bg-white/20 text-[10px] uppercase tracking-wider font-semibold mb-3">
            <Sparkles className="w-3 h-3" /> AI Туслах
          </div>
          <h3 className="font-display text-2xl font-bold mb-2">Уулзалтыг тэмдэглэх ажил AI-д орхи</h3>
          <p className="text-sm text-white/80 max-w-xl">
            Автомат хураангуй, action items, transcript — бүх уулзалтын үр дүнг бэлэн авна.
          </p>
        </div>
      </div>

      {/* Copilot Recap - Recent meetings with AI summary */}
      <div className="bg-white rounded-2xl border border-black/5 overflow-hidden mb-6">
        <div className="p-5 border-b border-black/5 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Sparkles className="w-4 h-4 text-[#A855F7]" />
            <h2 className="font-display text-lg font-semibold">Сүүлийн уулзалтын Copilot хураангуй</h2>
          </div>
          <span className="text-[10px] px-2 py-0.5 bg-[#A855F7]/10 text-[#A855F7] rounded-full font-bold uppercase tracking-wider">AI</span>
        </div>
        <div className="p-5 space-y-4">
          <div className="flex items-start gap-3 pb-4 border-b border-black/5">
            <div className="w-10 h-10 rounded-xl bg-[#10B981]/10 text-[#10B981] flex items-center justify-center flex-shrink-0">
              <Video className="w-4 h-4" />
            </div>
            <div className="flex-1 min-w-0">
              <div className="flex items-center gap-2 mb-1">
                <span className="font-semibold text-sm">Q4 Marketing Sync</span>
                <span className="text-[10px] text-black/50">Өчигдөр · 45 минут · 8 оролцогч</span>
              </div>
              <p className="text-sm text-black/70 leading-relaxed mb-3">
                Q4-ийн influencer marketing ROI 3.2x хүрсэн, Q1 2026-д TikTok-руу шилжих санал хэлэлцсэн. Brand awareness 35% өсгөх зорилт батлагдлаа.
              </p>
              <div className="space-y-1.5">
                <div className="text-[10px] uppercase tracking-wider text-black/40 font-semibold">Action items</div>
                {[
                  { who: 'Сараа', task: 'TikTok стратегийн брифт боловсруулах', due: 'Энэ долоо хоног' },
                  { who: 'Дорж', task: 'Budget approval-д CFO-той уулзах', due: 'Маргааш' },
                  { who: 'Туяа', task: 'Influencer жагсаалт шинэчлэх', due: '2 хоног' },
                ].map((a, i) => (
                  <div key={i} className="flex items-center gap-2 text-xs">
                    <input type="checkbox" className="rounded" />
                    <span className="font-medium" style={{ color: '#A855F7' }}>{a.who}:</span>
                    <span className="flex-1 text-black/70">{a.task}</span>
                    <span className="text-[10px] text-black/40">{a.due}</span>
                  </div>
                ))}
              </div>
              <div className="flex items-center gap-2 mt-3">
                <button className="text-[10px] px-2.5 py-1 bg-[#6366F1] text-white rounded-full font-medium">Бүтэн тэмдэглэл</button>
                <button className="text-[10px] px-2.5 py-1 bg-black/5 rounded-full font-medium">Видео</button>
                <button className="text-[10px] px-2.5 py-1 bg-black/5 rounded-full font-medium">Transcript</button>
              </div>
            </div>
          </div>

          <div className="flex items-start gap-3">
            <div className="w-10 h-10 rounded-xl bg-[#6366F1]/10 text-[#6366F1] flex items-center justify-center flex-shrink-0">
              <Video className="w-4 h-4" />
            </div>
            <div className="flex-1 min-w-0">
              <div className="flex items-center gap-2 mb-1">
                <span className="font-semibold text-sm">Engineering Weekly</span>
                <span className="text-[10px] text-black/50">2 хоногийн өмнө · 60 минут · 12 оролцогч</span>
              </div>
              <p className="text-sm text-black/70 leading-relaxed">
                API v2-ийн архитектур хэлэлцсэн, microservices migration-ийг Q2-д дуусгах төлөвлөгөө...
              </p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

function MeetRoom({ muted, setMuted, videoOn, setVideoOn, onLeave }) {
  const [showNotes, setShowNotes] = useState(false);
  const [language, setLanguage] = useState('mn');
  const participants = [
    { name: 'Н. Мягмардорж (Та)', color: '#6366F1', muted: muted, speaking: false, you: true },
    { name: 'Сараа Болд', color: '#10B981', muted: false, speaking: true, video: true },
    { name: 'Дорж Аюуш', color: '#F59E0B', muted: false, speaking: false },
    { name: 'Туяа Мөнх', color: '#EC4899', muted: true, speaking: false },
    { name: 'Болд Ган', color: '#A855F7', muted: false, speaking: false },
    { name: 'Энхтуяа', color: '#14B8A6', muted: true, speaking: false },
  ];

  return (
    <div className="h-full bg-[#0F0F1A] flex flex-col">
      {/* Header */}
      <div className="px-5 py-3 flex items-center justify-between text-white border-b border-white/5">
        <div className="flex items-center gap-3">
          <div className="flex items-center gap-1.5 px-2 py-0.5 bg-[#10B981]/20 rounded text-[10px] font-bold uppercase">
            <span className="w-1 h-1 rounded-full bg-[#10B981] animate-pulse" />
            Recording
          </div>
          <div className="text-sm font-medium">Q4 Marketing Sync</div>
          <div className="text-xs text-white/50 font-mono">23:14</div>
        </div>
        <div className="flex items-center gap-3">
          {/* Interpreter language selector */}
          <div className="hidden md:flex items-center gap-2 px-3 py-1 bg-white/5 border border-white/10 rounded-full text-xs">
            <Sparkles className="w-3 h-3 text-[#A855F7]" />
            <span className="text-white/60">Хэл:</span>
            <select value={language} onChange={(e) => setLanguage(e.target.value)} className="bg-transparent border-0 focus:outline-none text-white text-xs">
              <option value="mn" className="bg-[#0F0F1A]">🇲🇳 Монгол</option>
              <option value="en" className="bg-[#0F0F1A]">🇺🇸 English</option>
              <option value="ja" className="bg-[#0F0F1A]">🇯🇵 日本語</option>
              <option value="zh" className="bg-[#0F0F1A]">🇨🇳 中文</option>
            </select>
          </div>
          <div className="flex items-center gap-2 text-sm">
            <Shield className="w-4 h-4 text-[#10B981]" />
            <span className="text-xs text-white/60 hidden sm:inline">Шифрлэгдсэн холбоо</span>
          </div>
        </div>
      </div>

      {/* Participant grid */}
      <div className="flex-1 p-4 grid grid-cols-2 lg:grid-cols-3 gap-3 overflow-auto">
        {participants.map((p, i) => (
          <div key={i} className={`relative aspect-video rounded-xl overflow-hidden border-2 transition ${p.speaking ? 'border-[#10B981]' : 'border-transparent'}`} style={{ background: `linear-gradient(135deg, ${p.color}90, ${p.color}40)` }}>
            <div className="absolute inset-0 flex items-center justify-center">
              <div className="w-24 h-24 rounded-full flex items-center justify-center text-white font-display text-3xl font-bold" style={{ background: p.color }}>
                {p.name[0]}
              </div>
            </div>
            <div className="absolute bottom-2 left-2 right-2 flex items-center justify-between">
              <div className="flex items-center gap-1.5 px-2 py-1 bg-black/60 backdrop-blur rounded text-white text-xs">
                {p.muted ? <MicOff className="w-3 h-3 text-[#EF4444]" /> : <Mic className="w-3 h-3" />}
                <span className="truncate max-w-[120px]">{p.name}</span>
              </div>
              {p.you && <div className="px-2 py-1 bg-[#6366F1] text-white text-[10px] font-bold rounded">ТА</div>}
            </div>
            {p.speaking && (
              <div className="absolute top-2 right-2 flex items-end gap-0.5 h-4">
                <div className="w-0.5 bg-[#10B981] animate-pulse" style={{ height: '40%', animationDelay: '0s' }} />
                <div className="w-0.5 bg-[#10B981] animate-pulse" style={{ height: '80%', animationDelay: '0.1s' }} />
                <div className="w-0.5 bg-[#10B981] animate-pulse" style={{ height: '60%', animationDelay: '0.2s' }} />
              </div>
            )}
          </div>
        ))}
      </div>

      {/* AI live caption with translation */}
      <div className="mx-4 mb-2 px-4 py-2.5 bg-white/5 backdrop-blur border border-white/10 rounded-xl flex items-center gap-3">
        <Sparkles className="w-4 h-4 text-[#A855F7] flex-shrink-0" />
        <div className="flex-1 text-sm text-white/90 truncate">
          <span className="text-[#A855F7] font-semibold">Сараа:</span>{' '}
          {language === 'mn' && 'Q4-ийн influencer marketing-д 30% илүү budget хуваарилахаар болсон...'}
          {language === 'en' && 'We decided to allocate 30% more budget to Q4 influencer marketing...'}
          {language === 'ja' && 'Q4のインフルエンサーマーケティングに30%多く予算を配分することにしました...'}
          {language === 'zh' && '我们决定将Q4影响者营销的预算增加30%...'}
        </div>
        <div className="text-[10px] text-white/40 uppercase tracking-wider hidden sm:block">
          {language === 'mn' ? 'AI Шууд орчуулга' : language === 'en' ? 'AI Live Translation' : language === 'ja' ? 'AI 翻訳' : 'AI 翻译'}
        </div>
      </div>

      {/* Controls */}
      <div className="px-5 py-4 border-t border-white/5 flex items-center justify-between">
        <div className="flex items-center gap-2 text-white/60 text-xs">
          <Users className="w-3.5 h-3.5" />
          <span>{participants.length} оролцогч</span>
        </div>

        <div className="flex items-center gap-2">
          <ControlBtn icon={muted ? MicOff : Mic} active={!muted} danger={muted} onClick={() => setMuted(!muted)} />
          <ControlBtn icon={videoOn ? Video : VideoOff} active={videoOn} danger={!videoOn} onClick={() => setVideoOn(!videoOn)} />
          <ControlBtn icon={ScreenShare} active />
          <ControlBtn icon={Hand} active />
          <ControlBtn icon={Smile} active />
          <ControlBtn icon={Sparkles} active highlight />
          <button
            onClick={() => setShowNotes(!showNotes)}
            className={`w-11 h-11 rounded-full flex items-center justify-center transition ${showNotes ? 'bg-[#A855F7] text-white' : 'bg-white/10 text-white hover:bg-white/20'}`}
            title="Loop тэмдэглэл"
          >
            <FileText className="w-4 h-4" />
          </button>
          <ControlBtn icon={MoreHorizontal} active />
          <button onClick={onLeave} className="ml-2 px-5 py-2.5 bg-[#EF4444] hover:bg-[#DC2626] text-white text-xs font-semibold rounded-full flex items-center gap-2">
            <PhoneOff className="w-3.5 h-3.5" />
            Уулзалт орхих
          </button>
        </div>

        <div className="text-white/60 text-xs">
          <Settings className="w-4 h-4" />
        </div>
      </div>
    </div>
  );
}

function ControlBtn({ icon: Icon, active, danger, highlight, onClick }) {
  return (
    <button
      onClick={onClick}
      className={`w-11 h-11 rounded-full flex items-center justify-center transition ${
        danger ? 'bg-[#EF4444] text-white hover:bg-[#DC2626]' :
        highlight ? 'bg-gradient-to-br from-[#6366F1] to-[#A855F7] text-white' :
        active ? 'bg-white/10 text-white hover:bg-white/20' :
        'bg-white/5 text-white/40'
      }`}
    >
      <Icon className="w-4 h-4" />
    </button>
  );
}
