import { useState, useEffect } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { useTenant } from '../contexts/TenantContext.jsx';
import {
  ArrowRight, ArrowLeft, CheckCircle2, AlertTriangle, Database,
  Users, MessageSquare, FileText, UsersRound, Image as ImageIcon,
  Video, Calendar, Shield, Sparkles, Zap, Clock, Check, X,
  Building2, Lock, Loader2, ExternalLink, Download, Upload,
  RefreshCw, ChevronRight
} from 'lucide-react';

export default function Migrate() {
  const navigate = useNavigate();
  const { addTenant } = useTenant();
  const [step, setStep] = useState(1);
  const [credentials, setCredentials] = useState({ workspace: '', adminEmail: '' });
  const [selected, setSelected] = useState({
    users: true, groups: true, posts: true, files: true, knowledge: true, comments: false, reactions: false
  });

  return (
    <div className="min-h-screen bg-[#FAFAFC] flex flex-col" style={{ fontFamily: "'Geist', system-ui, sans-serif" }}>
      <style>{`
        @import url('https://fonts.googleapis.com/css2?family=Bricolage+Grotesque:opsz,wght@12..96,500;12..96,600;12..96,700&family=Geist:wght@400;500;600;700&family=JetBrains+Mono:wght@400;500&display=swap');
        .font-display { font-family: 'Bricolage Grotesque', sans-serif; letter-spacing: -0.02em; }
        .font-mono { font-family: 'JetBrains Mono', monospace; }
        @keyframes slideIn { from { opacity: 0; transform: translateX(20px) } to { opacity: 1; transform: translateX(0) } }
        .anim-slide { animation: slideIn 0.4s cubic-bezier(0.22, 1, 0.36, 1); }
      `}</style>

      {/* Header */}
      <header className="border-b border-black/5 px-6 py-4 flex items-center justify-between">
        <Link to="/" className="flex items-center gap-2.5">
          <div className="w-9 h-9 rounded-xl bg-[#1877F2] flex items-center justify-center text-white font-display font-bold">N</div>
          <span className="font-display font-bold text-xl">Nexcore Platforms</span>
        </Link>
        <div className="flex items-center gap-3">
          <a href="https://www.workplace.com/help/work/1167689491269151" target="_blank" rel="noreferrer" className="hidden sm:flex items-center gap-1 text-xs text-black/60 hover:text-black">
            Meta-ийн заавар <ExternalLink className="w-3 h-3" />
          </a>
          <Link to="/" className="text-sm text-black/60 hover:text-black">← Буцах</Link>
        </div>
      </header>

      {/* Hero banner */}
      <div className="bg-gradient-to-r from-[#1877F2] via-[#0866FF] to-[#0052CC] text-white">
        <div className="max-w-5xl mx-auto px-6 py-8">
          <div className="flex items-start gap-4">
            <div className="w-14 h-14 rounded-2xl bg-white/20 backdrop-blur flex items-center justify-center flex-shrink-0">
              <RefreshCw className="w-6 h-6" />
            </div>
            <div className="flex-1">
              <div className="text-xs uppercase tracking-wider text-white/70 mb-1">Migration Tool</div>
              <h1 className="font-display text-3xl font-bold mb-2">Meta Workplace-ээс Nexcore руу шилжих</h1>
              <p className="text-white/80 max-w-2xl">
                Танай бүх дата (хэрэглэгч, групп, пост, файл) автоматаар шилжүүлэх. Дундаж <strong>15 минут</strong> шаардагдана.
              </p>
            </div>
          </div>
        </div>
      </div>

      {/* Progress */}
      <div className="px-6 py-6 max-w-5xl mx-auto w-full">
        <div className="flex items-center gap-3">
          {[
            { n: 1, label: 'Холбох' },
            { n: 2, label: 'Сонгох' },
            { n: 3, label: 'Тойм' },
            { n: 4, label: 'Шилжүүлж байна' },
            { n: 5, label: 'Дууссан' },
          ].map((s, i) => (
            <div key={s.n} className="flex-1">
              <div className={`h-1.5 rounded-full transition-colors ${s.n <= step ? 'bg-[#1877F2]' : 'bg-black/10'}`} />
              <div className="mt-2 text-xs flex items-center gap-1.5">
                {s.n < step ? <CheckCircle2 className="w-3 h-3 text-[#1877F2]" /> : <div className={`w-3 h-3 rounded-full flex items-center justify-center text-[8px] font-bold ${s.n === step ? 'bg-[#1877F2] text-white' : 'bg-black/10 text-black/40'}`}>{s.n}</div>}
                <span className={`${s.n === step ? 'font-semibold text-black' : 'text-black/50'}`}>{s.label}</span>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Content */}
      <div className="flex-1 px-6 pb-12">
        <div className="max-w-3xl mx-auto">
          {step === 1 && <ConnectStep credentials={credentials} setCredentials={setCredentials} onNext={() => setStep(2)} />}
          {step === 2 && <SelectStep selected={selected} setSelected={setSelected} onNext={() => setStep(3)} onBack={() => setStep(1)} />}
          {step === 3 && <ReviewStep credentials={credentials} selected={selected} onStart={() => setStep(4)} onBack={() => setStep(2)} />}
          {step === 4 && <ProgressStep onComplete={() => setStep(5)} selected={selected} />}
          {step === 5 && <SuccessStep onFinish={() => navigate('/apps')} />}
        </div>
      </div>
    </div>
  );
}

/* ============== STEP 1: Connect ============== */
function ConnectStep({ credentials, setCredentials, onNext }) {
  const [connecting, setConnecting] = useState(false);

  function handleConnect() {
    if (!credentials.workspace) return;
    setConnecting(true);
    setTimeout(() => onNext(), 1200);
  }

  return (
    <div className="anim-slide">
      <div className="text-center mb-8">
        <div className="w-14 h-14 rounded-2xl bg-[#1877F2]/10 flex items-center justify-center mx-auto mb-4">
          <Building2 className="w-6 h-6 text-[#1877F2]" />
        </div>
        <h2 className="font-display text-3xl font-bold mb-2">Meta Workplace дансаа холбоно уу</h2>
        <p className="text-black/60">Зөвхөн Workplace админ нэвтрэх боломжтой</p>
      </div>

      <div className="bg-white rounded-2xl border border-black/5 p-6 space-y-4">
        <div>
          <label className="text-xs font-medium text-black/60 block mb-2">Workplace домэйн</label>
          <div className="flex items-center bg-[#FAFAFC] border border-black/10 rounded-xl focus-within:border-[#1877F2] transition">
            <span className="pl-4 text-sm text-black/40 font-mono">https://</span>
            <input
              value={credentials.workspace}
              onChange={(e) => setCredentials({ ...credentials, workspace: e.target.value.toLowerCase() })}
              autoFocus
              placeholder="танай-компани"
              className="flex-1 min-w-0 py-3 px-1 bg-transparent text-sm font-mono font-semibold focus:outline-none"
            />
            <span className="pr-4 text-sm text-black/40 font-mono">.workplace.com</span>
          </div>
        </div>

        <div>
          <label className="text-xs font-medium text-black/60 block mb-2">Админ имэйл</label>
          <input
            type="email"
            value={credentials.adminEmail}
            onChange={(e) => setCredentials({ ...credentials, adminEmail: e.target.value })}
            placeholder={`admin@${credentials.workspace || 'танай-компани'}.com`}
            className="w-full px-4 py-3 bg-[#FAFAFC] border border-black/10 rounded-xl text-sm focus:outline-none focus:border-[#1877F2] transition"
          />
        </div>

        <button
          onClick={handleConnect}
          disabled={!credentials.workspace || !credentials.adminEmail || connecting}
          className="w-full bg-[#1877F2] hover:bg-[#0866FF] text-white py-3.5 rounded-xl font-semibold flex items-center justify-center gap-2 disabled:opacity-50 transition"
        >
          {connecting ? (
            <>
              <Loader2 className="w-4 h-4 animate-spin" />
              Workplace-тай холбогдож байна...
            </>
          ) : (
            <>
              <Lock className="w-4 h-4" />
              Workplace-аар нэвтрэх
            </>
          )}
        </button>
      </div>

      {/* Why connect */}
      <div className="mt-5 p-4 bg-[#1877F2]/5 border border-[#1877F2]/20 rounded-xl flex items-start gap-3">
        <Shield className="w-5 h-5 text-[#1877F2] flex-shrink-0 mt-0.5" />
        <div className="text-xs text-black/70 leading-relaxed">
          <strong className="text-black">Аюулгүй холболт.</strong> Бид Meta-гийн албан ёсны Graph API ашиглан зөвхөн уншина. Танай нууц үг хадгалагдахгүй. Шилжүүлсний дараа холбоо автоматаар таслагдана.
        </div>
      </div>
    </div>
  );
}

/* ============== STEP 2: Select Data ============== */
function SelectStep({ selected, setSelected, onNext, onBack }) {
  const items = [
    { id: 'users', icon: Users, label: 'Хэрэглэгчид', count: '12,847', size: '~2 MB', required: true },
    { id: 'groups', icon: UsersRound, label: 'Группүүд', count: '247', size: '~12 MB' },
    { id: 'posts', icon: MessageSquare, label: 'Постууд & Чат', count: '847,392', size: '~840 MB' },
    { id: 'files', icon: FileText, label: 'Файл & Зураг', count: '234,891', size: '~24.7 GB' },
    { id: 'knowledge', icon: ImageIcon, label: 'Knowledge Library', count: '1,247', size: '~120 MB' },
    { id: 'comments', icon: MessageSquare, label: 'Сэтгэгдлүүд', count: '2.3M', size: '~520 MB' },
    { id: 'reactions', icon: CheckCircle2, label: 'Реакцууд (lik, love...)', count: '8.7M', size: '~180 MB' },
  ];

  const toggle = (id) => setSelected(s => ({ ...s, [id]: !s[id] }));

  const totalCount = items.filter(i => selected[i.id]).length;

  return (
    <div className="anim-slide">
      <div className="text-center mb-8">
        <div className="w-14 h-14 rounded-2xl bg-[#1877F2]/10 flex items-center justify-center mx-auto mb-4">
          <Database className="w-6 h-6 text-[#1877F2]" />
        </div>
        <h2 className="font-display text-3xl font-bold mb-2">Юу шилжүүлэх вэ?</h2>
        <p className="text-black/60">Шилжүүлэхийг хүсэж буй дата сонгоно уу</p>
      </div>

      <div className="bg-white rounded-2xl border border-black/5 overflow-hidden">
        {items.map((item) => {
          const Icon = item.icon;
          const isSelected = selected[item.id];
          return (
            <button
              key={item.id}
              onClick={() => !item.required && toggle(item.id)}
              className={`w-full flex items-center gap-4 p-4 border-b border-black/5 last:border-0 transition ${item.required ? 'cursor-default' : 'hover:bg-black/[0.02] cursor-pointer'}`}
            >
              <div className={`w-5 h-5 rounded-md border-2 flex items-center justify-center flex-shrink-0 transition ${isSelected ? 'bg-[#1877F2] border-[#1877F2]' : 'border-black/20'}`}>
                {isSelected && <Check className="w-3 h-3 text-white" />}
              </div>
              <div className={`w-10 h-10 rounded-xl flex items-center justify-center flex-shrink-0 ${isSelected ? 'bg-[#1877F2]/10 text-[#1877F2]' : 'bg-black/5 text-black/40'}`}>
                <Icon className="w-4 h-4" />
              </div>
              <div className="flex-1 min-w-0 text-left">
                <div className="flex items-center gap-2">
                  <span className="font-medium text-sm">{item.label}</span>
                  {item.required && <span className="text-[10px] bg-[#F59E0B]/10 text-[#B88500] px-1.5 py-0.5 rounded font-bold">Заавал</span>}
                </div>
                <div className="text-xs text-black/50 mt-0.5">
                  <span className="font-mono">{item.count}</span> ширхэг · <span className="font-mono">{item.size}</span>
                </div>
              </div>
            </button>
          );
        })}
      </div>

      <div className="mt-4 p-4 bg-[#42B72A]/5 border border-[#42B72A]/20 rounded-xl flex items-center gap-3">
        <Sparkles className="w-4 h-4 text-[#42B72A] flex-shrink-0" />
        <div className="text-xs text-black/70">
          <strong>{totalCount}</strong> категори сонгосон. AI бүх контентийг автоматаар Nexcore-ын шинэ форматтай тохируулж шилжүүлнэ.
        </div>
      </div>

      <div className="flex gap-3 mt-6">
        <button onClick={onBack} className="px-6 py-3.5 border border-black/10 rounded-xl font-semibold flex items-center gap-2 hover:bg-black/5">
          <ArrowLeft className="w-4 h-4" /> Буцах
        </button>
        <button
          onClick={onNext}
          disabled={totalCount === 0}
          className="flex-1 bg-[#1877F2] hover:bg-[#0866FF] text-white py-3.5 rounded-xl font-semibold flex items-center justify-center gap-2 disabled:opacity-50"
        >
          Үргэлжлүүлэх <ArrowRight className="w-4 h-4" />
        </button>
      </div>
    </div>
  );
}

/* ============== STEP 3: Review ============== */
function ReviewStep({ credentials, selected, onStart, onBack }) {
  const counts = {
    users: 12847, groups: 247, posts: 847392, files: 234891, knowledge: 1247, comments: 2300000, reactions: 8700000
  };
  const totalItems = Object.keys(selected).filter(k => selected[k]).reduce((s, k) => s + (counts[k] || 0), 0);

  return (
    <div className="anim-slide">
      <div className="text-center mb-8">
        <div className="w-14 h-14 rounded-2xl bg-[#1877F2]/10 flex items-center justify-center mx-auto mb-4">
          <CheckCircle2 className="w-6 h-6 text-[#1877F2]" />
        </div>
        <h2 className="font-display text-3xl font-bold mb-2">Бүгд бэлэн</h2>
        <p className="text-black/60">Шилжилт эхлүүлэхээс өмнө сүүлчийн шалгалт</p>
      </div>

      <div className="space-y-4">
        {/* From → To */}
        <div className="bg-white rounded-2xl border border-black/5 p-5">
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 items-center">
            <div className="text-center">
              <div className="text-xs uppercase tracking-wider text-black/40 mb-2">Эх үүсвэр</div>
              <div className="w-12 h-12 rounded-xl bg-[#1877F2]/10 flex items-center justify-center mx-auto mb-2">
                <span className="font-display font-bold text-[#1877F2]">M</span>
              </div>
              <div className="font-mono text-xs">{credentials.workspace}.workplace.com</div>
            </div>
            <div className="text-center relative">
              <div className="text-xs uppercase tracking-wider text-black/40 mb-2">Зорилго</div>
              <div className="w-12 h-12 rounded-xl bg-gradient-to-br from-[#6366F1] to-[#A855F7] flex items-center justify-center mx-auto mb-2">
                <span className="font-display font-bold text-white">N</span>
              </div>
              <div className="font-mono text-xs">{credentials.workspace || 'танай'}.nexcoreplatforms.mn</div>
            </div>
          </div>
          <div className="mt-4 flex items-center justify-center">
            <div className="flex items-center gap-2 px-3 py-1.5 bg-[#42B72A]/10 text-[#42B72A] rounded-full text-xs font-semibold">
              <ArrowRight className="w-3 h-3" />
              {totalItems.toLocaleString()} ширхэг шилжих
            </div>
          </div>
        </div>

        {/* Estimated time */}
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
          <div className="bg-white rounded-xl border border-black/5 p-4 text-center">
            <Clock className="w-4 h-4 text-[#F59E0B] mx-auto mb-2" />
            <div className="font-display font-bold text-lg">~15 мин</div>
            <div className="text-[10px] text-black/50">Үргэлжлэх хугацаа</div>
          </div>
          <div className="bg-white rounded-xl border border-black/5 p-4 text-center">
            <Database className="w-4 h-4 text-[#6366F1] mx-auto mb-2" />
            <div className="font-display font-bold text-lg">~26 GB</div>
            <div className="text-[10px] text-black/50">Нийт хэмжээ</div>
          </div>
          <div className="bg-white rounded-xl border border-black/5 p-4 text-center">
            <Shield className="w-4 h-4 text-[#42B72A] mx-auto mb-2" />
            <div className="font-display font-bold text-lg">E2E</div>
            <div className="text-[10px] text-black/50">Шифрлэлт</div>
          </div>
        </div>

        {/* Warnings */}
        <div className="p-4 bg-[#F59E0B]/5 border border-[#F59E0B]/20 rounded-xl flex items-start gap-3">
          <AlertTriangle className="w-5 h-5 text-[#F59E0B] flex-shrink-0 mt-0.5" />
          <div className="text-xs text-black/70 leading-relaxed">
            <strong>Анхааруулга:</strong> Шилжилтийн явцад Meta Workplace-ээс <strong>зөвхөн уншина</strong>. Танай Workplace-д ямар нэг өөрчлөлт орохгүй. Шилжилт амжилттай дууссаны дараа Meta Workplace дансаа аюулгүй цуцалж болно.
          </div>
        </div>
      </div>

      <div className="flex gap-3 mt-6">
        <button onClick={onBack} className="px-6 py-3.5 border border-black/10 rounded-xl font-semibold flex items-center gap-2 hover:bg-black/5">
          <ArrowLeft className="w-4 h-4" /> Буцах
        </button>
        <button
          onClick={onStart}
          className="flex-1 bg-gradient-to-r from-[#42B72A] to-[#2D8E1F] hover:scale-[1.02] text-white py-3.5 rounded-xl font-semibold flex items-center justify-center gap-2 transition"
        >
          <Zap className="w-4 h-4" /> Шилжилт эхлүүлэх
        </button>
      </div>
    </div>
  );
}

/* ============== STEP 4: Progress ============== */
function ProgressStep({ onComplete, selected }) {
  const [progress, setProgress] = useState(0);
  const [currentTask, setCurrentTask] = useState(0);

  const tasks = [
    { name: 'Хэрэглэгчдийг шилжүүлж байна', icon: Users, count: '12,847' },
    { name: 'Группүүдийг үүсгэж байна', icon: UsersRound, count: '247' },
    { name: 'Постуудыг шилжүүлж байна', icon: MessageSquare, count: '847,392' },
    { name: 'Файлуудыг хуулж байна', icon: FileText, count: '234,891' },
    { name: 'Knowledge Library-г бүтээж байна', icon: ImageIcon, count: '1,247' },
    { name: 'Эрх, тохиргоог тохируулж байна', icon: Shield, count: '—' },
  ].filter((_, i) => Object.values(selected)[i]);

  useEffect(() => {
    const interval = setInterval(() => {
      setProgress(p => {
        const newP = p + 1.5;
        if (newP >= 100) {
          clearInterval(interval);
          setTimeout(onComplete, 800);
          return 100;
        }
        setCurrentTask(Math.min(tasks.length - 1, Math.floor((newP / 100) * tasks.length)));
        return newP;
      });
    }, 80);
    return () => clearInterval(interval);
  }, []);

  return (
    <div className="anim-slide">
      <div className="text-center mb-8">
        <div className="relative w-20 h-20 mx-auto mb-4">
          <div className="absolute inset-0 rounded-full bg-[#1877F2]/20 animate-ping" />
          <div className="relative w-20 h-20 rounded-full bg-gradient-to-br from-[#1877F2] to-[#0866FF] flex items-center justify-center">
            <RefreshCw className="w-8 h-8 text-white animate-spin" style={{ animationDuration: '2s' }} />
          </div>
        </div>
        <h2 className="font-display text-3xl font-bold mb-2">Шилжүүлж байна</h2>
        <p className="text-black/60">Энэ цонхыг хаахгүйгээр түр хүлээгээрэй</p>
      </div>

      <div className="bg-white rounded-2xl border border-black/5 p-6">
        {/* Big progress */}
        <div className="mb-6">
          <div className="flex items-baseline justify-between mb-2">
            <span className="font-display text-4xl font-bold tracking-tight">{Math.floor(progress)}%</span>
            <span className="text-xs text-black/50 font-mono">{Math.floor(progress * 60 / 100)} / 60 секунд</span>
          </div>
          <div className="h-3 bg-black/5 rounded-full overflow-hidden">
            <div className="h-full bg-gradient-to-r from-[#1877F2] to-[#0866FF] rounded-full transition-all duration-200" style={{ width: `${progress}%` }} />
          </div>
        </div>

        {/* Task list */}
        <div className="space-y-2">
          {tasks.map((t, i) => {
            const Icon = t.icon;
            const isDone = i < currentTask;
            const isCurrent = i === currentTask;
            return (
              <div key={i} className={`flex items-center gap-3 p-3 rounded-lg transition ${isCurrent ? 'bg-[#1877F2]/5' : ''}`}>
                <div className="flex-shrink-0">
                  {isDone ? (
                    <div className="w-7 h-7 rounded-full bg-[#42B72A] flex items-center justify-center">
                      <Check className="w-4 h-4 text-white" />
                    </div>
                  ) : isCurrent ? (
                    <div className="w-7 h-7 rounded-full bg-[#1877F2] flex items-center justify-center">
                      <Loader2 className="w-3.5 h-3.5 text-white animate-spin" />
                    </div>
                  ) : (
                    <div className="w-7 h-7 rounded-full bg-black/5 flex items-center justify-center">
                      <Icon className="w-3.5 h-3.5 text-black/30" />
                    </div>
                  )}
                </div>
                <div className="flex-1 min-w-0">
                  <div className={`text-sm ${isCurrent ? 'font-semibold' : isDone ? 'text-black/60' : 'text-black/40'}`}>
                    {t.name}
                  </div>
                </div>
                <div className={`text-xs font-mono ${isDone ? 'text-[#42B72A]' : isCurrent ? 'text-[#1877F2]' : 'text-black/30'}`}>
                  {isDone ? '✓ ' + t.count : isCurrent ? '...' : t.count}
                </div>
              </div>
            );
          })}
        </div>
      </div>

      <div className="mt-4 text-center text-xs text-black/40">
        🔒 End-to-end encrypted · Meta Workplace-аас зөвхөн уншиж байна
      </div>
    </div>
  );
}

/* ============== STEP 5: Success ============== */
function SuccessStep({ onFinish }) {
  return (
    <div className="anim-slide">
      <div className="text-center mb-8">
        <div className="relative w-24 h-24 mx-auto mb-6">
          <div className="absolute inset-0 rounded-full bg-[#42B72A]/30 blur-xl" />
          <div className="relative w-24 h-24 rounded-full bg-gradient-to-br from-[#42B72A] to-[#2D8E1F] flex items-center justify-center">
            <CheckCircle2 className="w-10 h-10 text-white" />
          </div>
        </div>
        <h2 className="font-display text-4xl font-bold mb-3">🎉 Амжилттай шилжлээ!</h2>
        <p className="text-black/60 max-w-md mx-auto">
          Танай Workplace орчин Nexcore-д бүрэн нэвтэрсэн. Одоо ажилтнуудаа урьж эхлүүлэх боломжтой.
        </p>
      </div>

      <div className="bg-white rounded-2xl border border-black/5 p-6 mb-6">
        <h3 className="font-display text-lg font-semibold mb-4">Шилжсэн зүйлс</h3>
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
          {[
            { label: 'Хэрэглэгч', value: '12,847', color: '#6366F1' },
            { label: 'Групп', value: '247', color: '#10B981' },
            { label: 'Пост', value: '847,392', color: '#F59E0B' },
            { label: 'Файл', value: '234,891', color: '#EC4899' },
          ].map((s, i) => (
            <div key={i} className="p-4 bg-[#FAFAFC] rounded-xl">
              <div className="font-display text-2xl font-bold tracking-tight" style={{ color: s.color }}>
                {s.value}
              </div>
              <div className="text-xs text-black/50 mt-0.5">{s.label}</div>
            </div>
          ))}
        </div>
      </div>

      <div className="bg-gradient-to-br from-[#1877F2]/5 to-[#A855F7]/5 border border-[#1877F2]/20 rounded-2xl p-5 mb-6">
        <div className="text-xs uppercase tracking-wider text-[#1877F2] font-semibold mb-3">Дараагийн алхмууд</div>
        <div className="space-y-2 text-sm">
          {[
            'Танай ажилтнуудыг шинэ Nexcore хаягаар нэвтрэхийг урих',
            'SSO холболтыг тохируулах (Step 2 минут шаардана)',
            'Meta Workplace дансаа эцэст нь устгах (заавал биш)',
          ].map((s, i) => (
            <div key={i} className="flex items-start gap-2">
              <div className="w-5 h-5 rounded-full bg-[#1877F2]/10 text-[#1877F2] text-[10px] font-bold flex items-center justify-center flex-shrink-0 mt-0.5">{i + 1}</div>
              <span className="text-black/80">{s}</span>
            </div>
          ))}
        </div>
      </div>

      <button
        onClick={onFinish}
        className="w-full bg-[#1877F2] hover:bg-[#0866FF] text-white py-3.5 rounded-xl font-semibold flex items-center justify-center gap-2 transition"
      >
        Nexcore Admin руу очих <ArrowRight className="w-4 h-4" />
      </button>
    </div>
  );
}
