import { Link } from 'react-router-dom';
import {
  ArrowRight, Sparkles, Target, Heart, Users, Globe,
  TrendingUp, Award, Rocket, Mail
} from 'lucide-react';

export default function About() {
  return (
    <div className="min-h-screen bg-white" style={{ fontFamily: "'Geist', system-ui, sans-serif" }}>
      <style>{`
        @import url('https://fonts.googleapis.com/css2?family=Bricolage+Grotesque:opsz,wght@12..96,500;12..96,600;12..96,700;12..96,800&family=Geist:wght@400;500;600;700&family=Instrument+Serif:ital@1&display=swap');
        .font-display { font-family: 'Bricolage Grotesque', sans-serif; letter-spacing: -0.02em; }
        .font-serif-italic { font-family: 'Instrument Serif', serif; font-style: italic; }
      `}</style>

      {/* Header */}
      <header className="border-b border-black/5 px-6 py-4 flex items-center justify-between max-w-7xl mx-auto">
        <Link to="/" className="flex items-center gap-2.5">
          <div className="w-9 h-9 rounded-xl bg-[#1877F2] flex items-center justify-center text-white font-display font-bold">N</div>
          <span className="font-display font-bold text-xl">Nexcore Platforms</span>
        </Link>
        <Link to="/" className="text-sm text-black/60 hover:text-black">← Нүүр</Link>
      </header>

      {/* Hero */}
      <section className="py-20 lg:py-28 px-6">
        <div className="max-w-4xl mx-auto text-center">
          <div className="text-xs font-semibold uppercase tracking-[0.3em] text-[#1877F2] mb-5">— Бидний тухай</div>
          <h1 className="font-display text-5xl lg:text-7xl font-bold tracking-tight mb-6">
            Монголын анхны <span className="font-serif-italic font-normal">бүх нэг бүхний</span><br />
            ажлын платформ
          </h1>
          <p className="text-xl text-black/60 leading-relaxed max-w-2xl mx-auto">
            Бид Монголын компаниудад дэлхийн хэмжээний хэрэглэгчийн туршлагыг — Монгол хэлээр, Монгол төгрөгөөр санал болгож байна.
          </p>
        </div>
      </section>

      {/* Mission */}
      <section className="py-16 px-6 bg-[#FAFAFC]">
        <div className="max-w-5xl mx-auto grid lg:grid-cols-2 gap-12 items-center">
          <div>
            <div className="text-xs font-semibold uppercase tracking-[0.2em] text-[#1877F2] mb-3">— Эрхэм зорилго</div>
            <h2 className="font-display text-4xl font-bold tracking-tight mb-5">
              Ажлын байрны хил хязгаарыг арилгах
            </h2>
            <p className="text-lg text-black/70 leading-relaxed mb-4">
              Meta Workplace 2026 оны 5-р сард хаагдаж буй нь нэг үе дуусч, шинэ боломж нээгдэж буй гэдгийг бид харсан.
            </p>
            <p className="text-lg text-black/70 leading-relaxed">
              30,000+ компани шилжих газар хайж байна. Бид Монголын зах зээлд шинэ үеийн платформ бүтээж, дэлхийн хэмжээний өрсөлдөгчтэй ижил түвшинд гарахаар ажиллаж байна.
            </p>
          </div>
          <div className="grid grid-cols-2 gap-4">
            {[
              { icon: Users, value: '30,000+', label: 'Компани шилжих хүлээж буй', color: '#1877F2' },
              { icon: Globe, value: '7M+', label: 'Хэрэглэгч', color: '#10B981' },
              { icon: TrendingUp, value: '$50B', label: 'Дэлхийн зах зээл', color: '#F59E0B' },
              { icon: Award, value: '#1', label: 'Монголд', color: '#A855F7' },
            ].map((s, i) => {
              const Icon = s.icon;
              return (
                <div key={i} className="bg-white rounded-2xl p-5 border border-black/5">
                  <Icon className="w-5 h-5 mb-3" style={{ color: s.color }} />
                  <div className="font-display text-3xl font-bold tracking-tight">{s.value}</div>
                  <div className="text-xs text-black/50 mt-1">{s.label}</div>
                </div>
              );
            })}
          </div>
        </div>
      </section>

      {/* Values */}
      <section className="py-20 px-6">
        <div className="max-w-6xl mx-auto">
          <div className="text-center mb-14">
            <div className="text-xs font-semibold uppercase tracking-[0.2em] text-[#1877F2] mb-3">— Үнэт зүйлс</div>
            <h2 className="font-display text-4xl font-bold tracking-tight">
              Бид юунд итгэдэг вэ?
            </h2>
          </div>

          <div className="grid md:grid-cols-3 gap-6">
            {[
              {
                icon: Heart,
                title: 'Хэрэглэгч төв',
                desc: 'Бүх шийдвэр хэрэглэгчийн туршлагаас эхэлдэг. Compromise хийхгүй.',
                color: '#EC4899'
              },
              {
                icon: Sparkles,
                title: 'Чанар',
                desc: 'Дэлхийн хэмжээний чанар, Apple/Stripe/Linear-аас дутуугүй.',
                color: '#A855F7'
              },
              {
                icon: Target,
                title: 'Шударга',
                desc: 'Нуугдсан төлбөр байхгүй. Үнэ ил тод. Дата танай мэдэлд.',
                color: '#10B981'
              },
            ].map((v, i) => {
              const Icon = v.icon;
              return (
                <div key={i} className="bg-white border border-black/5 rounded-2xl p-7 hover:border-black/15 hover:shadow-md transition">
                  <div className="w-12 h-12 rounded-2xl flex items-center justify-center mb-5" style={{ background: `${v.color}15`, color: v.color }}>
                    <Icon className="w-5 h-5" />
                  </div>
                  <h3 className="font-display text-xl font-bold mb-2">{v.title}</h3>
                  <p className="text-sm text-black/60 leading-relaxed">{v.desc}</p>
                </div>
              );
            })}
          </div>
        </div>
      </section>

      {/* Story */}
      <section className="py-20 px-6 bg-[#FAFAFC]">
        <div className="max-w-3xl mx-auto">
          <div className="text-xs font-semibold uppercase tracking-[0.2em] text-[#1877F2] mb-3 text-center">— Түүх</div>
          <h2 className="font-display text-4xl font-bold tracking-tight mb-10 text-center">
            Хэрхэн эхэлсэн бэ?
          </h2>

          <div className="space-y-8">
            {[
              {
                year: '2025',
                title: 'Эх санаа',
                desc: 'Meta Workplace хаагдах мэдээ ирмэгц, Монголын компаниудын хэрэгцээг ойлгож, шинэ платформ хийхээр шийдсэн.'
              },
              {
                year: '2026 / 1-р улирал',
                title: 'Прототайп',
                desc: 'Анхны UI прототайп бэлэн боллоо. Microsoft Teams 2026-ын шилдэг feature-уудыг нэгтгэсэн.'
              },
              {
                year: '2026 / 2-р улирал',
                title: 'Beta launch',
                desc: 'Анхны 5-10 Монгол компанид pilot тестлэх. Бодит дата дээр feedback цуглуулах.'
              },
              {
                year: '2026 / 3-4-р улирал',
                title: 'Public launch',
                desc: 'Бүх Монгол компанид нээлттэй болох. Meta Workplace migration tool ашиглан 100+ компани шилжих.'
              },
            ].map((s, i) => (
              <div key={i} className="flex gap-5">
                <div className="flex-shrink-0">
                  <div className="w-12 h-12 rounded-full bg-[#1877F2] text-white flex items-center justify-center font-display font-bold text-sm">
                    {i + 1}
                  </div>
                </div>
                <div className="flex-1 pb-3">
                  <div className="text-xs uppercase tracking-wider text-[#1877F2] font-bold mb-1">{s.year}</div>
                  <h3 className="font-display text-xl font-bold mb-2">{s.title}</h3>
                  <p className="text-black/70 leading-relaxed">{s.desc}</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* CTA */}
      <section className="py-20 px-6 bg-black text-white">
        <div className="max-w-3xl mx-auto text-center">
          <h2 className="font-display text-4xl lg:text-5xl font-bold tracking-tight mb-5">
            Бидэнтэй <span className="font-serif-italic font-normal">хамтар</span>
          </h2>
          <p className="text-lg text-white/70 mb-8">
            Та компанийн админ уу? Эсвэл хөрөнгө оруулагч? Хамтран ажиллах боломжуудыг ярилцая.
          </p>
          <div className="flex flex-col sm:flex-row gap-3 justify-center">
            <Link to="/contact" className="px-7 py-3.5 bg-white text-black rounded-full font-semibold flex items-center justify-center gap-2 hover:scale-[1.02] transition">
              <Mail className="w-4 h-4" />
              Холбогдох
            </Link>
            <Link to="/signup" className="px-7 py-3.5 bg-[#1877F2] hover:bg-[#0866FF] text-white rounded-full font-semibold flex items-center justify-center gap-2 transition">
              Үнэгүй эхлэх
              <ArrowRight className="w-4 h-4" />
            </Link>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="border-t border-black/5 py-8 px-6">
        <div className="max-w-7xl mx-auto flex items-center justify-between text-xs text-black/50">
          <div>© 2026 Nexcore Platforms. Бүх эрх хуулиар хамгаалагдсан.</div>
          <div className="flex gap-5">
            <Link to="/about" className="hover:text-black">Бидний тухай</Link>
            <Link to="/contact" className="hover:text-black">Холбоо барих</Link>
            <Link to="/faq" className="hover:text-black">FAQ</Link>
          </div>
        </div>
      </footer>
    </div>
  );
}
