import { useState } from 'react';
import { Link } from 'react-router-dom';
import { ChevronDown, Search, Mail, MessageSquare, ArrowRight } from 'lucide-react';

const FAQS = [
  {
    cat: 'Ерөнхий',
    items: [
      { q: 'Nexcore Platforms гэж юу вэ?', a: 'Nexcore Platforms бол Монгол улсад зориулагдсан бүх нэг бүхний ажлын платформ. Чат, видео уулзалт, имэйл, документ, сургалт, AI туслах гэх мэт 8+ хэрэгслийг нэг газар цуглуулсан. Meta Workplace-ийн орлогч.' },
      { q: 'Хэн ашиглах вэ?', a: '5-аас 10,000+ ажилтантай аливаа компани, байгууллага. Жижиг бизнес (Starter — үнэгүй), дунд (Core/Premium), том корпорат (Enterprise) бүгд тохирно.' },
      { q: 'Meta Workplace хаагдсаны дараа надад юу хийх ёстой вэ?', a: '2026.05.31-нээс өмнө шинэ платформ руу шилжих хэрэгтэй. Бид Meta Workplace migration tool-той — бүх дата (хэрэглэгч, групп, пост, файл) автомат шилжүүлнэ. /migrate хуудаснаас эхэлж болно.' },
    ]
  },
  {
    cat: 'Үнэ ба төлбөр',
    items: [
      { q: 'Үнэгүй багц байдаг уу?', a: 'Тийм. Starter багц нь 5 хүртэл хэрэглэгчтэй компанид үргэлж үнэгүй. Картын мэдээлэл шаардахгүй. Хязгааргүй хугацаатай.' },
      { q: 'Жилээр төлвөл хэр хямд орох вэ?', a: 'Бүх төлбөртэй багцад жилээр төлбөл 20% хямдрал авна. Жишээ нь Premium 28,800₮/сар → жилээр 276,480₮ (хэмнэлт 69,120₮).' },
      { q: 'НӨАТ багтсан уу?', a: 'Тийм. Бүх үнэ Монголын НӨАТ-ыг (10%) багтаасан эцсийн үнэ. Нэмэлт төлбөр байхгүй.' },
      { q: 'Төлбөр хэрхэн хийх вэ?', a: 'QPay, eMongolia, банкны шилжүүлэг, картаар (Visa, Mastercard) төлж болно. Enterprise багцад хувийн нэхэмжлэхээр төлбөр хийх боломжтой.' },
      { q: 'Хүссэн үедээ цуцлах боломжтой юу?', a: 'Тийм. Хэзээ ч цуцалж болно. Үнэгүй migration data export хийж дата-гаа авч явах боломжтой.' },
    ]
  },
  {
    cat: 'Аюулгүй байдал',
    items: [
      { q: 'Манай компанийн дата хаана хадгалагдах вэ?', a: 'Дата нь AWS Singapore эсвэл хэрэглэгчийн сонгосон бүсэд (EU, US) шифрлэгдэн хадгалагдана. Enterprise багцад Mongolia дотроо дата хадгалах боломжтой (захиалгат).' },
      { q: 'End-to-end шифрлэлт байгаа юу?', a: 'Тийм. Бүх чат, имэйл, видео уулзалт E2E шифрлэгдсэн. Уулзалтын бичлэг, файлын хадгалалт AES-256-аар шифрлэгдсэн.' },
      { q: 'SSO дэмждэг үү?', a: 'Тийм. Premium болон Enterprise багцад SAML 2.0, OAuth 2.0, SCIM provisioning ажиллана. Microsoft Azure AD, Google Workspace, Okta-тэй холбогдоно.' },
      { q: 'GDPR/HIPAA-д нийцэх үү?', a: 'GDPR-д бүрэн нийцэж байна. HIPAA, SOC 2 Type II сертификат 2026 оны 4-р улирал гарах болно.' },
    ]
  },
  {
    cat: 'Шилжилт',
    items: [
      { q: 'Meta Workplace-аас хичнээн хугацаанд шилждэг вэ?', a: 'Дунджаар 15-30 минут. Бүх дата (хэрэглэгч, пост, файл) автомат шилжинэ. Том компани (10,000+ ажилтан) тохиолдолд 1-2 цаг.' },
      { q: 'Шилжих явцад Meta Workplace-руу нөлөө орох уу?', a: 'Үгүй. Бид зөвхөн уншихгүйгээс гадуур ямар нэг өөрчлөлт хийхгүй. Та шилжсэний дараа Meta Workplace дансаа аюулгүй цуцалж болно.' },
      { q: 'Slack/Teams-ээс шилжих боломжтой юу?', a: 'Slack миграцийн tool 2026 оны 2-р улиралд гарна. Microsoft Teams миграц 3-р улиралд төлөвлөгдсөн.' },
    ]
  },
  {
    cat: 'Техникийн дэмжлэг',
    items: [
      { q: 'Дэмжлэг хэрхэн авах вэ?', a: 'Starter — олон нийтийн форум. Core — имэйл (24 цаг). Premium — 24/7 чат + утас. Enterprise — dedicated CSM + SLA.' },
      { q: 'Mobile апп байгаа юу?', a: 'iOS болон Android апп бэлэн. App Store, Google Play-аас "Nexcore Platforms" гэж хайж татна.' },
      { q: 'Open API-той юу?', a: 'Тийм. REST API + Webhooks Premium багцаас эхлэн ашиглах боломжтой. GraphQL API Enterprise багцад нэмэгдсэн.' },
    ]
  },
];

export default function FAQ() {
  const [open, setOpen] = useState({ 0: true });
  const [search, setSearch] = useState('');

  function toggle(key) {
    setOpen(o => ({ ...o, [key]: !o[key] }));
  }

  const filtered = FAQS.map(cat => ({
    ...cat,
    items: cat.items.filter(item =>
      !search ||
      item.q.toLowerCase().includes(search.toLowerCase()) ||
      item.a.toLowerCase().includes(search.toLowerCase())
    )
  })).filter(cat => cat.items.length > 0);

  return (
    <div className="min-h-screen bg-white" style={{ fontFamily: "'Geist', system-ui, sans-serif" }}>
      <style>{`
        @import url('https://fonts.googleapis.com/css2?family=Bricolage+Grotesque:opsz,wght@12..96,500;12..96,600;12..96,700&family=Geist:wght@400;500;600;700&family=Instrument+Serif:ital@1&display=swap');
        .font-display { font-family: 'Bricolage Grotesque', sans-serif; letter-spacing: -0.02em; }
        .font-serif-italic { font-family: 'Instrument Serif', serif; font-style: italic; }
      `}</style>

      <header className="border-b border-black/5 px-6 py-4 flex items-center justify-between max-w-7xl mx-auto">
        <Link to="/" className="flex items-center gap-2.5">
          <div className="w-9 h-9 rounded-xl bg-[#1877F2] flex items-center justify-center text-white font-display font-bold">N</div>
          <span className="font-display font-bold text-xl">Nexcore Platforms</span>
        </Link>
        <Link to="/" className="text-sm text-black/60 hover:text-black">← Нүүр</Link>
      </header>

      <section className="py-16 px-6">
        <div className="max-w-3xl mx-auto">
          <div className="text-center mb-10">
            <div className="text-xs font-semibold uppercase tracking-[0.3em] text-[#1877F2] mb-4">— FAQ</div>
            <h1 className="font-display text-5xl lg:text-6xl font-bold tracking-tight mb-5">
              Түгээмэл <span className="font-serif-italic font-normal">асуултууд</span>
            </h1>
            <p className="text-lg text-black/60">
              Хариулт олдоогүй бол <Link to="/contact" className="text-[#1877F2] font-medium hover:underline">холбогдоно уу</Link>.
            </p>
          </div>

          {/* Search */}
          <div className="relative mb-8">
            <Search className="absolute left-4 top-1/2 -translate-y-1/2 w-4 h-4 text-black/40" />
            <input
              type="text"
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              placeholder="Асуулт хайх..."
              className="w-full pl-12 pr-4 py-4 bg-[#FAFAFC] border border-black/10 rounded-2xl text-sm focus:outline-none focus:border-[#1877F2] focus:ring-4 focus:ring-[#1877F2]/10"
            />
          </div>

          {/* FAQs */}
          <div className="space-y-8">
            {filtered.map((cat, ci) => (
              <div key={ci}>
                <h2 className="font-display text-xl font-bold mb-4 text-black/70">{cat.cat}</h2>
                <div className="space-y-2">
                  {cat.items.map((item, i) => {
                    const key = `${ci}-${i}`;
                    const isOpen = open[key];
                    return (
                      <div key={i} className={`bg-white border rounded-2xl transition ${isOpen ? 'border-[#1877F2]/30 shadow-sm' : 'border-black/5'}`}>
                        <button
                          onClick={() => toggle(key)}
                          className="w-full text-left px-5 py-4 flex items-center gap-4"
                        >
                          <span className="font-medium flex-1">{item.q}</span>
                          <ChevronDown className={`w-4 h-4 text-black/40 flex-shrink-0 transition ${isOpen ? 'rotate-180' : ''}`} />
                        </button>
                        {isOpen && (
                          <div className="px-5 pb-4 text-sm text-black/70 leading-relaxed border-t border-black/5 pt-4">
                            {item.a}
                          </div>
                        )}
                      </div>
                    );
                  })}
                </div>
              </div>
            ))}
            {filtered.length === 0 && (
              <div className="text-center py-12 text-black/40">
                "{search}"-тай тохирох асуулт олдсонгүй
              </div>
            )}
          </div>

          {/* Need help */}
          <div className="mt-12 p-6 bg-gradient-to-br from-[#1877F2]/5 to-[#A855F7]/5 border border-[#1877F2]/20 rounded-3xl flex flex-col sm:flex-row items-center gap-5 text-center sm:text-left">
            <div className="w-12 h-12 rounded-2xl bg-white flex items-center justify-center flex-shrink-0">
              <MessageSquare className="w-5 h-5 text-[#1877F2]" />
            </div>
            <div className="flex-1">
              <div className="font-display text-lg font-bold mb-1">Хариулт олдсонгүй юу?</div>
              <div className="text-sm text-black/60">Бидэнтэй холбогдоорой — 24 цагт хариу өгөх болно.</div>
            </div>
            <div className="flex gap-2">
              <Link to="/contact" className="px-5 py-2.5 bg-[#1877F2] hover:bg-[#0866FF] text-white text-sm font-semibold rounded-full flex items-center gap-2 transition">
                <Mail className="w-3.5 h-3.5" /> Холбогдох
              </Link>
            </div>
          </div>
        </div>
      </section>

      <footer className="border-t border-black/5 py-8 px-6">
        <div className="max-w-7xl mx-auto flex items-center justify-between text-xs text-black/50">
          <div>© 2026 Nexcore Platforms.</div>
          <div className="flex gap-5">
            <Link to="/about" className="hover:text-black">Бидний тухай</Link>
            <Link to="/contact" className="hover:text-black">Холбогдох</Link>
            <Link to="/faq" className="hover:text-black">FAQ</Link>
          </div>
        </div>
      </footer>
    </div>
  );
}
