import { useState } from 'react';
import { Link } from 'react-router-dom';
import { useTenant } from '../contexts/TenantContext.jsx';
import { getUsersForTenant, getGroupsForTenant, getStatsForTenant } from '../contexts/TenantContext.jsx';
import TenantSwitcher from '../components/TenantSwitcher.jsx';
import {
  LayoutDashboard, Users, UsersRound, FileText, BarChart3, Shield, Settings,
  Search, Bell, ChevronDown, MoreHorizontal, TrendingUp, TrendingDown,
  ArrowUpRight, Plus, Filter, Download, MessageSquare, Heart, Eye, EyeOff,
  AlertTriangle, CheckCircle2, XCircle, Clock, Globe, Lock, Mail,
  Edit3, Trash2, Ban, UserCheck, Activity, Zap, Award, Building2,
  ExternalLink, ChevronRight, X, ArrowLeft, LogOut
} from 'lucide-react';
import {
  LineChart, Line, BarChart, Bar, PieChart, Pie, Cell, AreaChart, Area,
  XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, Legend
} from 'recharts';

export default function Admin() {
  const [activeTab, setActiveTab] = useState('dashboard');
  const [sidebarOpen, setSidebarOpen] = useState(false);
  const { currentTenant } = useTenant();
  const [authed, setAuthed] = useState(() => sessionStorage.getItem('admin_auth') === 'ok');

  if (!authed) {
    return <AdminLock onUnlock={() => { sessionStorage.setItem('admin_auth', 'ok'); setAuthed(true); }} tenant={currentTenant} />;
  }

  const tabs = [
    { id: 'dashboard', label: 'Dashboard', icon: LayoutDashboard },
    { id: 'users', label: 'Хэрэглэгчид', icon: Users },
    { id: 'groups', label: 'Групп', icon: UsersRound },
    { id: 'content', label: 'Контент', icon: FileText },
    { id: 'analytics', label: 'Аналитик', icon: BarChart3 },
    { id: 'security', label: 'Аюулгүй байдал', icon: Shield },
    { id: 'settings', label: 'Тохиргоо', icon: Settings },
  ];

  return (
    <div className="min-h-screen bg-[#F7F8FA] flex" style={{ fontFamily: "'Geist', system-ui, sans-serif" }}>
      <style>{`
        @import url('https://fonts.googleapis.com/css2?family=Bricolage+Grotesque:opsz,wght@12..96,500;12..96,600;12..96,700&family=Geist:wght@400;500;600;700&display=swap');
        .font-display { font-family: 'Bricolage Grotesque', sans-serif; letter-spacing: -0.02em; }
        @keyframes fadeUp { from { opacity: 0; transform: translateY(8px) } to { opacity: 1; transform: translateY(0) } }
        .anim-fade { animation: fadeUp 0.4s ease-out; }
      `}</style>

      {/* ============== SIDEBAR ============== */}
      <aside className={`fixed lg:sticky top-0 left-0 h-screen w-64 bg-white border-r border-black/5 z-40 flex flex-col transition-transform ${sidebarOpen ? 'translate-x-0' : '-translate-x-full lg:translate-x-0'}`}>
        <div className="px-6 py-5 border-b border-black/5 flex items-center justify-between">
          <Link to="/" className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-lg flex items-center justify-center text-white font-display font-bold text-sm" style={{ background: currentTenant.color }}>{currentTenant.logo}</div>
            <div>
              <div className="font-display font-bold text-sm truncate max-w-[140px]">{currentTenant.name}</div>
              <div className="text-[10px] text-black/50 -mt-0.5">Админ панель</div>
            </div>
          </Link>
          <button onClick={() => setSidebarOpen(false)} className="lg:hidden">
            <X className="w-5 h-5" />
          </button>
        </div>

        <nav className="flex-1 px-3 py-5 space-y-1 overflow-y-auto">
          {tabs.map((t) => {
            const Icon = t.icon;
            const active = activeTab === t.id;
            return (
              <button
                key={t.id}
                onClick={() => { setActiveTab(t.id); setSidebarOpen(false); }}
                className={`w-full flex items-center gap-3 px-3 py-2.5 rounded-lg text-sm transition ${active ? 'text-white' : 'text-black/70 hover:bg-black/5'}`}
                style={active ? { background: currentTenant.color } : {}}
              >
                <Icon className="w-4 h-4" />
                <span className="font-medium">{t.label}</span>
                {active && <ChevronRight className="w-3 h-3 ml-auto" />}
              </button>
            );
          })}
        </nav>

        <div className="p-3 border-t border-black/5">
          <Link to="/" className="flex items-center gap-3 px-3 py-2.5 rounded-lg text-sm text-black/70 hover:bg-black/5 transition">
            <ArrowLeft className="w-4 h-4" />
            <span>Сайт руу буцах</span>
          </Link>
          <div className="mt-2 p-3 bg-[#F7F8FA] rounded-xl flex items-center gap-3">
            <div className="w-9 h-9 rounded-full bg-gradient-to-br from-[#1877F2] to-[#0866FF] flex-shrink-0 flex items-center justify-center text-white text-xs font-bold">НМ</div>
            <div className="flex-1 min-w-0">
              <div className="text-sm font-medium truncate">Н. Мягмардорж</div>
              <div className="text-xs text-black/50 truncate flex items-center gap-1">
                <Shield className="w-2.5 h-2.5" />
                Гол Админ
              </div>
            </div>
            <button
              onClick={() => {
                sessionStorage.removeItem('admin_auth');
                setAuthed(false);
              }}
              className="w-7 h-7 rounded-lg hover:bg-[#EF4444]/10 hover:text-[#EF4444] flex items-center justify-center transition"
              title="Гарах"
            >
              <LogOut className="w-4 h-4 text-black/40" />
            </button>
          </div>
        </div>
      </aside>

      {sidebarOpen && <div className="fixed inset-0 bg-black/40 z-30 lg:hidden" onClick={() => setSidebarOpen(false)} />}

      {/* ============== MAIN ============== */}
      <main className="flex-1 min-w-0">
        {/* Subdomain bar (URL indicator) */}
        <div className="border-b px-6 py-2 flex items-center gap-2 text-xs" style={{ background: `${currentTenant.color}10`, borderColor: `${currentTenant.color}20` }}>
          <Globe className="w-3.5 h-3.5" style={{ color: currentTenant.color }} />
          <span className="font-mono text-black/60">https://</span>
          <span className="font-mono font-semibold" style={{ color: currentTenant.color }}>{currentTenant.subdomain}</span>
          <span className="font-mono text-black/60">.nexcoreplatforms.mn/admin</span>
          <span className="hidden sm:inline ml-2 text-black/40">·</span>
          <span className="hidden sm:inline text-black/60">Та одоо <strong className="text-black/80">{currentTenant.name}</strong>-ын админ панелд байна</span>
          <Link to="/super-admin" className="ml-auto flex items-center gap-1 hover:underline font-medium" style={{ color: currentTenant.color }}>
            <Shield className="w-3 h-3" /> Super Admin
          </Link>
        </div>

        {/* Top bar */}
        <header className="sticky top-0 bg-white/80 backdrop-blur border-b border-black/5 z-20 px-6 py-3 flex items-center gap-4">
          <button onClick={() => setSidebarOpen(true)} className="lg:hidden">
            <LayoutDashboard className="w-5 h-5" />
          </button>
          {/* Read-only company badge — NO tenant switching for company admins */}
          <div className="flex items-center gap-2.5 px-3 py-1.5 bg-[#F7F8FA] rounded-lg" title="Танай компани">
            <div className="w-7 h-7 rounded-md flex items-center justify-center text-white font-bold text-xs" style={{ background: currentTenant.color }}>
              {currentTenant.logo}
            </div>
            <div className="flex flex-col">
              <div className="text-sm font-semibold leading-tight">{currentTenant.name}</div>
              <div className="text-[10px] text-black/50 font-mono leading-tight">{currentTenant.subdomain}.nexcoreplatforms.mn</div>
            </div>
            {currentTenant.verified && (
              <div className="ml-1 w-4 h-4 rounded-full bg-[#1877F2] flex items-center justify-center" title="Баталгаажсан">
                <CheckCircle2 className="w-3 h-3 text-white" />
              </div>
            )}
          </div>
          <div className="flex-1 max-w-md relative">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-black/40" />
            <input
              type="text"
              placeholder={`${currentTenant.name} дотор хайх...`}
              className="w-full pl-10 pr-4 py-2 bg-[#F7F8FA] border-0 rounded-full text-sm focus:outline-none focus:ring-2 focus:ring-[#1877F2]/20"
            />
          </div>
          <div className="flex items-center gap-2">
            <button className="w-9 h-9 rounded-full hover:bg-black/5 flex items-center justify-center relative">
              <Bell className="w-4 h-4" />
              <div className="absolute top-1.5 right-1.5 w-2 h-2 rounded-full bg-[#E4405F]" />
            </button>
            <button
              onClick={() => {
                sessionStorage.removeItem('admin_auth');
                setAuthed(false);
              }}
              className="w-9 h-9 rounded-full hover:bg-[#EF4444]/10 hover:text-[#EF4444] flex items-center justify-center transition"
              title="Гарах"
            >
              <LogOut className="w-4 h-4" />
            </button>
            <div className="w-9 h-9 rounded-full bg-gradient-to-br from-[#1877F2] to-[#0866FF]" />
          </div>
        </header>

        {/* Content */}
        <div className="p-6 lg:p-8 anim-fade" key={activeTab}>
          {activeTab === 'dashboard' && <DashboardSection />}
          {activeTab === 'users' && <UsersSection />}
          {activeTab === 'groups' && <GroupsSection />}
          {activeTab === 'content' && <ContentSection />}
          {activeTab === 'analytics' && <AnalyticsSection />}
          {activeTab === 'security' && <SecuritySection />}
          {activeTab === 'settings' && <SettingsSection />}
        </div>
      </main>
    </div>
  );
}

/* ============== DASHBOARD ============== */
function DashboardSection() {
  const { currentTenant } = useTenant();
  const tenantStats = getStatsForTenant(currentTenant);
  const stats = [
    { label: 'Нийт хэрэглэгч', value: tenantStats.totalUsers.toLocaleString(), change: '+12.4%', up: true, icon: Users, color: currentTenant.color },
    { label: 'Идэвхтэй (өнөөдөр)', value: tenantStats.activeToday.toLocaleString(), change: '+5.2%', up: true, icon: Activity, color: '#42B72A' },
    { label: 'Шинэ постууд', value: tenantStats.newPosts.toLocaleString(), change: '+18.7%', up: true, icon: FileText, color: '#F7B928' },
    { label: 'Тайлан', value: tenantStats.reports.toString(), change: '-8.3%', up: false, icon: AlertTriangle, color: '#E4405F' },
  ];

  const activityData = [
    { day: 'Дав', users: 7200, posts: 320 },
    { day: 'Мяг', users: 7800, posts: 410 },
    { day: 'Лха', users: 8100, posts: 380 },
    { day: 'Пүр', users: 8500, posts: 450 },
    { day: 'Баа', users: 9200, posts: 520 },
    { day: 'Бям', users: 5400, posts: 180 },
    { day: 'Ням', users: 4800, posts: 150 },
  ];

  const departmentData = [
    { name: 'Инженер', value: 4200, color: '#1877F2' },
    { name: 'Маркетинг', value: 2100, color: '#42B72A' },
    { name: 'Борлуулалт', value: 3400, color: '#F7B928' },
    { name: 'HR', value: 800, color: '#E4405F' },
    { name: 'Бусад', value: 2347, color: '#8B5CF6' },
  ];

  return (
    <div className="space-y-6 max-w-7xl">
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-3">
          <div className="w-12 h-12 rounded-2xl flex items-center justify-center text-white font-display font-bold text-xl flex-shrink-0" style={{ background: currentTenant.color }}>
            {currentTenant.logo}
          </div>
          <div>
            <h1 className="font-display text-3xl font-bold tracking-tight">{currentTenant.name}</h1>
            <p className="text-sm text-black/60">{currentTenant.plan} багц · {currentTenant.users.toLocaleString()} ажилтан · <span className="font-mono">{currentTenant.subdomain}.nexcoreplatforms.mn</span></p>
          </div>
        </div>
        <div className="flex items-center gap-2">
          <button className="px-4 py-2 text-sm bg-white border border-black/10 rounded-full hover:border-black/30 transition flex items-center gap-2">
            <Download className="w-3.5 h-3.5" /> Татах
          </button>
          <button className="px-4 py-2 text-sm text-white rounded-full flex items-center gap-2 transition" style={{ background: currentTenant.color }}>
            <Plus className="w-3.5 h-3.5" /> Шинэ зарлал
          </button>
        </div>
      </div>

      {/* Stat cards */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        {stats.map((s, i) => {
          const Icon = s.icon;
          return (
            <div key={i} className="bg-white rounded-2xl p-5 border border-black/5 hover:shadow-lg transition">
              <div className="flex items-start justify-between mb-3">
                <div className="w-10 h-10 rounded-xl flex items-center justify-center" style={{ background: `${s.color}15`, color: s.color }}>
                  <Icon className="w-4 h-4" />
                </div>
                <div className={`flex items-center gap-1 text-xs font-medium ${s.up ? 'text-[#42B72A]' : 'text-[#E4405F]'}`}>
                  {s.up ? <TrendingUp className="w-3 h-3" /> : <TrendingDown className="w-3 h-3" />}
                  {s.change}
                </div>
              </div>
              <div className="font-display text-3xl font-bold tracking-tight">{s.value}</div>
              <div className="text-xs text-black/50 mt-1">{s.label}</div>
            </div>
          );
        })}
      </div>

      {/* Charts */}
      <div className="grid lg:grid-cols-3 gap-4">
        <div className="lg:col-span-2 bg-white rounded-2xl p-5 border border-black/5">
          <div className="flex items-center justify-between mb-4">
            <div>
              <h3 className="font-display text-lg font-semibold">Долоо хоногийн идэвх</h3>
              <p className="text-xs text-black/50">Хэрэглэгч ба пост</p>
            </div>
            <div className="flex items-center gap-3 text-xs">
              <span className="flex items-center gap-1.5"><div className="w-2 h-2 rounded-full bg-[#1877F2]" /> Хэрэглэгч</span>
              <span className="flex items-center gap-1.5"><div className="w-2 h-2 rounded-full bg-[#42B72A]" /> Пост</span>
            </div>
          </div>
          <ResponsiveContainer width="100%" height={260}>
            <AreaChart data={activityData} margin={{ left: -20 }}>
              <defs>
                <linearGradient id="g1" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="0%" stopColor="#1877F2" stopOpacity={0.3} />
                  <stop offset="100%" stopColor="#1877F2" stopOpacity={0} />
                </linearGradient>
                <linearGradient id="g2" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="0%" stopColor="#42B72A" stopOpacity={0.3} />
                  <stop offset="100%" stopColor="#42B72A" stopOpacity={0} />
                </linearGradient>
              </defs>
              <CartesianGrid strokeDasharray="3 3" stroke="#00000010" />
              <XAxis dataKey="day" stroke="#00000060" fontSize={11} />
              <YAxis stroke="#00000060" fontSize={11} />
              <Tooltip contentStyle={{ borderRadius: 12, border: '1px solid #00000010', fontSize: 12 }} />
              <Area type="monotone" dataKey="users" stroke="#1877F2" strokeWidth={2} fill="url(#g1)" />
              <Area type="monotone" dataKey="posts" stroke="#42B72A" strokeWidth={2} fill="url(#g2)" />
            </AreaChart>
          </ResponsiveContainer>
        </div>

        <div className="bg-white rounded-2xl p-5 border border-black/5">
          <h3 className="font-display text-lg font-semibold mb-1">Хэлтсээр</h3>
          <p className="text-xs text-black/50 mb-4">Ажилтны тоо</p>
          <ResponsiveContainer width="100%" height={180}>
            <PieChart>
              <Pie data={departmentData} dataKey="value" innerRadius={45} outerRadius={75} paddingAngle={2}>
                {departmentData.map((d, i) => <Cell key={i} fill={d.color} />)}
              </Pie>
              <Tooltip contentStyle={{ borderRadius: 12, border: '1px solid #00000010', fontSize: 12 }} />
            </PieChart>
          </ResponsiveContainer>
          <div className="space-y-2 mt-3">
            {departmentData.map((d, i) => (
              <div key={i} className="flex items-center justify-between text-xs">
                <div className="flex items-center gap-2">
                  <div className="w-2 h-2 rounded-full" style={{ background: d.color }} />
                  <span>{d.name}</span>
                </div>
                <span className="font-medium">{d.value.toLocaleString()}</span>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Recent activity */}
      <div className="bg-white rounded-2xl border border-black/5 overflow-hidden">
        <div className="p-5 flex items-center justify-between border-b border-black/5">
          <h3 className="font-display text-lg font-semibold">Сүүлийн үйлдэл</h3>
          <button className="text-xs text-[#1877F2] hover:underline">Бүгдийг үзэх →</button>
        </div>
        <div className="divide-y divide-black/5">
          {[
            { user: 'Сараа Б.', action: 'шинэ групп үүсгэв', target: 'Маркетингийн баг 2026', time: '2 минутын өмнө', color: '#42B72A' },
            { user: 'Дорж А.', action: 'Live эхлүүлэв', target: 'CEO Town Hall · Q4', time: '15 минут өмнө', color: '#1877F2' },
            { user: 'Болд Г.', action: 'хэрэглэгч идэвхгүй болгов', target: 'old.user@company.mn', time: '1 цагийн өмнө', color: '#E4405F' },
            { user: 'Туяа М.', action: 'Knowledge Library нэмэв', target: 'Шинэ HR Policy 2026', time: '3 цагийн өмнө', color: '#F7B928' },
            { user: 'System', action: 'нөөцлөлт амжилттай', target: 'Database backup #4821', time: '6 цагийн өмнө', color: '#8B5CF6' },
          ].map((a, i) => (
            <div key={i} className="p-4 flex items-center gap-3 hover:bg-black/[0.02] transition">
              <div className="w-9 h-9 rounded-full flex-shrink-0" style={{ background: a.color }} />
              <div className="flex-1 min-w-0">
                <div className="text-sm">
                  <span className="font-medium">{a.user}</span>
                  <span className="text-black/60"> {a.action} </span>
                  <span className="font-medium text-[#1877F2]">{a.target}</span>
                </div>
                <div className="text-xs text-black/40 mt-0.5">{a.time}</div>
              </div>
              <MoreHorizontal className="w-4 h-4 text-black/40" />
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}

/* ============== USERS ============== */
function UsersSection() {
  const { currentTenant } = useTenant();
  const users = getUsersForTenant(currentTenant);
  const tenantStats = getStatsForTenant(currentTenant);

  return (
    <div className="space-y-6 max-w-7xl">
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3">
        <div>
          <h1 className="font-display text-3xl font-bold tracking-tight">{currentTenant.name} ажилтнууд</h1>
          <p className="text-sm text-black/60 mt-1">Нийт {tenantStats.totalUsers.toLocaleString()} ажилтан · {tenantStats.activeUsers.toLocaleString()} идэвхтэй</p>
        </div>
        <div className="flex items-center gap-2">
          <button className="px-4 py-2 text-sm bg-white border border-black/10 rounded-full flex items-center gap-2">
            <Filter className="w-3.5 h-3.5" /> Шүүлт
          </button>
          <button className="px-4 py-2 text-sm text-white rounded-full flex items-center gap-2" style={{ background: currentTenant.color }}>
            <Plus className="w-3.5 h-3.5" /> Хэрэглэгч урих
          </button>
        </div>
      </div>

      {/* Quick stats */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        {[
          { label: 'Идэвхтэй', value: tenantStats.activeUsers.toLocaleString(), color: '#42B72A' },
          { label: 'Идэвхгүй', value: tenantStats.inactiveUsers.toLocaleString(), color: '#94A3B8' },
          { label: 'Хүлээгдэж буй', value: tenantStats.pendingUsers.toLocaleString(), color: '#F7B928' },
          { label: 'Хориглосон', value: tenantStats.blockedUsers.toLocaleString(), color: '#E4405F' },
        ].map((s, i) => (
          <div key={i} className="bg-white rounded-2xl p-4 border border-black/5">
            <div className="flex items-center gap-2 mb-1">
              <div className="w-2 h-2 rounded-full" style={{ background: s.color }} />
              <span className="text-xs text-black/60">{s.label}</span>
            </div>
            <div className="font-display text-2xl font-bold">{s.value}</div>
          </div>
        ))}
      </div>

      {/* Users table */}
      <div className="bg-white rounded-2xl border border-black/5 overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead className="bg-[#F7F8FA] text-black/50 text-xs uppercase tracking-wider">
              <tr>
                <th className="px-5 py-3 text-left font-medium">Нэр</th>
                <th className="px-5 py-3 text-left font-medium">Эрх</th>
                <th className="px-5 py-3 text-left font-medium">Хэлтэс</th>
                <th className="px-5 py-3 text-left font-medium">Төлөв</th>
                <th className="px-5 py-3 text-right font-medium">Үйлдэл</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-black/5">
              {users.map((u, i) => (
                <tr key={i} className="hover:bg-black/[0.02] transition">
                  <td className="px-5 py-3">
                    <div className="flex items-center gap-3">
                      <div className="w-9 h-9 rounded-full flex-shrink-0" style={{ background: u.avatar }} />
                      <div>
                        <div className="font-medium">{u.name}</div>
                        <div className="text-xs text-black/50">{u.email}</div>
                      </div>
                    </div>
                  </td>
                  <td className="px-5 py-3">
                    <span className={`inline-flex px-2.5 py-1 rounded-full text-xs font-medium ${u.role === 'Admin' || u.role === 'CEO' ? 'bg-[#1877F2]/10 text-[#1877F2]' : u.role === 'Manager' ? 'bg-[#F7B928]/10 text-[#B88500]' : 'bg-black/5 text-black/60'}`}>
                      {u.role}
                    </span>
                  </td>
                  <td className="px-5 py-3 text-black/70">{u.dept}</td>
                  <td className="px-5 py-3">
                    <div className="flex items-center gap-2">
                      <div className={`w-2 h-2 rounded-full ${u.status === 'active' ? 'bg-[#42B72A]' : u.status === 'pending' ? 'bg-[#F7B928]' : 'bg-black/30'}`} />
                      <span className="text-xs">{u.status === 'active' ? 'Идэвхтэй' : u.status === 'pending' ? 'Хүлээгдэж буй' : 'Идэвхгүй'}</span>
                    </div>
                  </td>
                  <td className="px-5 py-3">
                    <div className="flex items-center justify-end gap-1">
                      <button className="w-7 h-7 rounded-lg hover:bg-black/5 flex items-center justify-center"><Edit3 className="w-3.5 h-3.5" /></button>
                      <button className="w-7 h-7 rounded-lg hover:bg-black/5 flex items-center justify-center"><Mail className="w-3.5 h-3.5" /></button>
                      <button className="w-7 h-7 rounded-lg hover:bg-[#E4405F]/10 hover:text-[#E4405F] flex items-center justify-center"><Trash2 className="w-3.5 h-3.5" /></button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
        <div className="p-4 flex items-center justify-between text-xs text-black/50 border-t border-black/5">
          <div>Харуулж байна 1-8 of 12,847</div>
          <div className="flex items-center gap-1">
            <button className="px-3 py-1.5 rounded-lg hover:bg-black/5">Өмнөх</button>
            <button className="px-3 py-1.5 rounded-lg bg-[#1877F2] text-white">1</button>
            <button className="px-3 py-1.5 rounded-lg hover:bg-black/5">2</button>
            <button className="px-3 py-1.5 rounded-lg hover:bg-black/5">3</button>
            <span className="px-2">...</span>
            <button className="px-3 py-1.5 rounded-lg hover:bg-black/5">1,605</button>
            <button className="px-3 py-1.5 rounded-lg hover:bg-black/5">Дараах</button>
          </div>
        </div>
      </div>
    </div>
  );
}

/* ============== GROUPS ============== */
function GroupsSection() {
  const { currentTenant } = useTenant();
  const groups = getGroupsForTenant(currentTenant);

  return (
    <div className="space-y-6 max-w-7xl">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="font-display text-3xl font-bold tracking-tight">{currentTenant.name} группүүд</h1>
          <p className="text-sm text-black/60 mt-1">Нийт {groups.length} групп идэвхтэй</p>
        </div>
        <button className="px-4 py-2 text-sm text-white rounded-full flex items-center gap-2" style={{ background: currentTenant.color }}>
          <Plus className="w-3.5 h-3.5" /> Шинэ групп
        </button>
      </div>

      <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-4">
        {groups.map((g, i) => (
          <div key={i} className="bg-white rounded-2xl p-5 border border-black/5 hover:shadow-lg transition group">
            <div className="flex items-start justify-between mb-4">
              <div className="w-12 h-12 rounded-2xl flex items-center justify-center text-white font-display font-bold" style={{ background: g.color }}>
                {g.name[0]}
              </div>
              {g.badge && (
                <span className={`text-xs px-2 py-0.5 rounded-full ${g.badge === 'Албан ёсны' ? 'bg-[#1877F2]/10 text-[#1877F2]' : 'bg-[#42B72A]/10 text-[#42B72A]'}`}>
                  {g.badge}
                </span>
              )}
            </div>
            <h3 className="font-display text-lg font-semibold mb-1">{g.name}</h3>
            <p className="text-xs text-black/50 mb-4">{g.type} групп</p>
            <div className="grid grid-cols-2 gap-3 pt-4 border-t border-black/5">
              <div>
                <div className="text-xs text-black/50">Гишүүд</div>
                <div className="font-display font-bold">{g.members.toLocaleString()}</div>
              </div>
              <div>
                <div className="text-xs text-black/50">Постууд</div>
                <div className="font-display font-bold">{g.posts}</div>
              </div>
            </div>
            <button className="mt-4 w-full py-2 text-xs font-medium text-black/60 hover:text-[#1877F2] hover:bg-[#1877F2]/5 rounded-lg transition flex items-center justify-center gap-1">
              Удирдах <ChevronRight className="w-3 h-3" />
            </button>
          </div>
        ))}
      </div>
    </div>
  );
}

/* ============== CONTENT ============== */
function ContentSection() {
  const reports = [
    { post: 'Спам линк хуваалцсан байна...', author: 'Unknown User', reason: 'Спам', severity: 'high', time: '5 мин өмнө' },
    { post: 'Зүй бус харилцаа агуулсан...', author: 'Б. Эрдэнэ', reason: 'Зүй бус харилцаа', severity: 'medium', time: '23 мин өмнө' },
    { post: 'Зөвшөөрөлгүй маркетинг...', author: 'sales@external.com', reason: 'Маркетинг', severity: 'low', time: '1 цаг өмнө' },
    { post: 'Хувийн мэдээлэл задруулсан...', author: 'Anonymous', reason: 'Privacy', severity: 'high', time: '2 цаг өмнө' },
  ];

  return (
    <div className="space-y-6 max-w-7xl">
      <div>
        <h1 className="font-display text-3xl font-bold tracking-tight">Контент модерац</h1>
        <p className="text-sm text-black/60 mt-1">Тайланг хянаж, шийдвэр гаргах</p>
      </div>

      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        {[
          { label: 'Нийт пост', value: '847,392', color: '#1877F2', icon: FileText },
          { label: 'Тайлан', value: '23', color: '#E4405F', icon: AlertTriangle },
          { label: 'Шийдсэн', value: '1,247', color: '#42B72A', icon: CheckCircle2 },
          { label: 'Хяналтад', value: '8', color: '#F7B928', icon: Clock },
        ].map((s, i) => {
          const Icon = s.icon;
          return (
            <div key={i} className="bg-white rounded-2xl p-4 border border-black/5">
              <Icon className="w-4 h-4 mb-3" style={{ color: s.color }} />
              <div className="font-display text-2xl font-bold">{s.value}</div>
              <div className="text-xs text-black/50 mt-1">{s.label}</div>
            </div>
          );
        })}
      </div>

      <div className="bg-white rounded-2xl border border-black/5 overflow-hidden">
        <div className="p-5 border-b border-black/5 flex items-center justify-between">
          <h3 className="font-display text-lg font-semibold">Хүлээгдэж буй тайлан</h3>
          <span className="text-xs px-2 py-1 rounded-full bg-[#E4405F]/10 text-[#E4405F]">23 шинэ</span>
        </div>
        <div className="divide-y divide-black/5">
          {reports.map((r, i) => (
            <div key={i} className="p-5 hover:bg-black/[0.02] transition">
              <div className="flex items-start gap-4">
                <div className={`w-1 h-12 rounded-full flex-shrink-0 ${r.severity === 'high' ? 'bg-[#E4405F]' : r.severity === 'medium' ? 'bg-[#F7B928]' : 'bg-black/20'}`} />
                <div className="flex-1 min-w-0">
                  <div className="flex items-center gap-2 mb-1">
                    <span className={`text-[10px] uppercase font-bold px-2 py-0.5 rounded ${r.severity === 'high' ? 'bg-[#E4405F]/10 text-[#E4405F]' : r.severity === 'medium' ? 'bg-[#F7B928]/10 text-[#B88500]' : 'bg-black/5 text-black/60'}`}>
                      {r.severity}
                    </span>
                    <span className="text-xs text-black/50">{r.reason}</span>
                    <span className="text-xs text-black/30">·</span>
                    <span className="text-xs text-black/50">{r.time}</span>
                  </div>
                  <div className="text-sm font-medium mb-1">{r.post}</div>
                  <div className="text-xs text-black/60">Зохиогч: {r.author}</div>
                </div>
                <div className="flex items-center gap-2 flex-shrink-0">
                  <button className="px-3 py-1.5 text-xs bg-[#42B72A]/10 text-[#42B72A] rounded-lg hover:bg-[#42B72A]/20 transition flex items-center gap-1">
                    <CheckCircle2 className="w-3 h-3" /> Зөвшөөрөх
                  </button>
                  <button className="px-3 py-1.5 text-xs bg-[#E4405F]/10 text-[#E4405F] rounded-lg hover:bg-[#E4405F]/20 transition flex items-center gap-1">
                    <XCircle className="w-3 h-3" /> Устгах
                  </button>
                  <button className="w-7 h-7 rounded-lg hover:bg-black/5 flex items-center justify-center"><MoreHorizontal className="w-3.5 h-3.5" /></button>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}

/* ============== ANALYTICS ============== */
function AnalyticsSection() {
  const monthlyData = [
    { month: '1-р сар', users: 8400, engagement: 62 },
    { month: '2-р сар', users: 9100, engagement: 68 },
    { month: '3-р сар', users: 9800, engagement: 71 },
    { month: '4-р сар', users: 10500, engagement: 74 },
    { month: '5-р сар', users: 11200, engagement: 78 },
    { month: '6-р сар', users: 12000, engagement: 82 },
    { month: '7-р сар', users: 12847, engagement: 85 },
  ];

  const featureUsage = [
    { name: 'News Feed', value: 89 },
    { name: 'Chat', value: 76 },
    { name: 'Groups', value: 64 },
    { name: 'Live', value: 42 },
    { name: 'Knowledge', value: 38 },
  ];

  return (
    <div className="space-y-6 max-w-7xl">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="font-display text-3xl font-bold tracking-tight">Аналитик</h1>
          <p className="text-sm text-black/60 mt-1">Хэрэглээ ба идэвхийн дэлгэрэнгүй</p>
        </div>
        <select className="px-4 py-2 text-sm bg-white border border-black/10 rounded-full">
          <option>Сүүлийн 7 хоног</option>
          <option>Сүүлийн 30 хоног</option>
          <option>Энэ улирал</option>
          <option>Энэ жил</option>
        </select>
      </div>

      <div className="grid lg:grid-cols-2 gap-4">
        <div className="bg-white rounded-2xl p-5 border border-black/5">
          <h3 className="font-display text-lg font-semibold mb-1">Хэрэглэгчийн өсөлт</h3>
          <p className="text-xs text-black/50 mb-4">Сараар (2026)</p>
          <ResponsiveContainer width="100%" height={250}>
            <LineChart data={monthlyData} margin={{ left: -20 }}>
              <CartesianGrid strokeDasharray="3 3" stroke="#00000010" />
              <XAxis dataKey="month" stroke="#00000060" fontSize={10} />
              <YAxis stroke="#00000060" fontSize={11} />
              <Tooltip contentStyle={{ borderRadius: 12, border: '1px solid #00000010', fontSize: 12 }} />
              <Line type="monotone" dataKey="users" stroke="#1877F2" strokeWidth={3} dot={{ fill: '#1877F2', r: 4 }} />
            </LineChart>
          </ResponsiveContainer>
        </div>

        <div className="bg-white rounded-2xl p-5 border border-black/5">
          <h3 className="font-display text-lg font-semibold mb-1">Engagement %</h3>
          <p className="text-xs text-black/50 mb-4">Идэвхтэй хэрэглэгчийн харьцаа</p>
          <ResponsiveContainer width="100%" height={250}>
            <AreaChart data={monthlyData} margin={{ left: -20 }}>
              <defs>
                <linearGradient id="ge" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="0%" stopColor="#42B72A" stopOpacity={0.4} />
                  <stop offset="100%" stopColor="#42B72A" stopOpacity={0} />
                </linearGradient>
              </defs>
              <CartesianGrid strokeDasharray="3 3" stroke="#00000010" />
              <XAxis dataKey="month" stroke="#00000060" fontSize={10} />
              <YAxis stroke="#00000060" fontSize={11} />
              <Tooltip contentStyle={{ borderRadius: 12, border: '1px solid #00000010', fontSize: 12 }} />
              <Area type="monotone" dataKey="engagement" stroke="#42B72A" strokeWidth={2} fill="url(#ge)" />
            </AreaChart>
          </ResponsiveContainer>
        </div>
      </div>

      <div className="bg-white rounded-2xl p-5 border border-black/5">
        <h3 className="font-display text-lg font-semibold mb-1">Боломжуудын хэрэглээ</h3>
        <p className="text-xs text-black/50 mb-5">Тус бүрийн идэвхтэй хэрэглэгчийн %</p>
        <div className="space-y-4">
          {featureUsage.map((f, i) => (
            <div key={i}>
              <div className="flex items-center justify-between text-sm mb-1.5">
                <span className="font-medium">{f.name}</span>
                <span className="text-black/60">{f.value}%</span>
              </div>
              <div className="h-2 bg-black/5 rounded-full overflow-hidden">
                <div className="h-full bg-gradient-to-r from-[#1877F2] to-[#0866FF] rounded-full transition-all" style={{ width: `${f.value}%` }} />
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}

/* ============== SECURITY ============== */
function SecuritySection() {
  const events = [
    { type: 'login', user: 'admin@company.mn', detail: 'Амжилттай нэвтэрсэн', ip: '203.91.114.2', time: '2 минут өмнө', status: 'success' },
    { type: 'failed', user: 'unknown@external.com', detail: '5 удаа алдаатай нэвтрэхийг оролдов', ip: '185.220.101.12', time: '12 мин өмнө', status: 'danger' },
    { type: 'permission', user: 'saraa.b@company.mn', detail: 'Эрх дээшлүүлсэн (Manager → Admin)', ip: '203.91.114.5', time: '1 цаг өмнө', status: 'warning' },
    { type: 'export', user: 'dorj.a@company.mn', detail: 'Хэрэглэгчийн жагсаалт татав', ip: '203.91.114.8', time: '3 цаг өмнө', status: 'info' },
    { type: 'login', user: 'bold.g@company.mn', detail: 'Шинэ төхөөрөмжөөс нэвтэрсэн', ip: '110.45.180.99', time: '5 цаг өмнө', status: 'warning' },
  ];

  return (
    <div className="space-y-6 max-w-7xl">
      <div>
        <h1 className="font-display text-3xl font-bold tracking-tight">Аюулгүй байдал</h1>
        <p className="text-sm text-black/60 mt-1">Аудит лог ба хяналт</p>
      </div>

      {/* Security score */}
      <div className="bg-gradient-to-br from-[#1877F2] to-[#0866FF] rounded-2xl p-6 text-white relative overflow-hidden">
        <div className="absolute -top-10 -right-10 w-40 h-40 rounded-full bg-white/10 blur-2xl" />
        <div className="relative flex items-center justify-between gap-6">
          <div>
            <div className="text-xs uppercase tracking-wider text-white/60 mb-2">Аюулгүй байдлын үнэлгээ</div>
            <div className="font-display text-5xl font-bold">94<span className="text-2xl text-white/70">/100</span></div>
            <div className="text-sm text-white/80 mt-2">Маш сайн · Шинэчилсэн: өнөөдөр</div>
          </div>
          <Shield className="w-20 h-20 text-white/20" />
        </div>
        <div className="relative mt-5 grid grid-cols-3 gap-3">
          {[
            { label: '2FA идэвхтэй', value: '98%' },
            { label: 'SSO ашиглалт', value: '76%' },
            { label: 'Сэжигтэй үйлдэл', value: '3' },
          ].map((s, i) => (
            <div key={i} className="bg-white/10 backdrop-blur rounded-xl p-3">
              <div className="text-xs text-white/70">{s.label}</div>
              <div className="font-display text-xl font-bold mt-1">{s.value}</div>
            </div>
          ))}
        </div>
      </div>

      {/* Compliance badges */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-3">
        {['GDPR', 'SOC 2', 'ISO 27001', 'HIPAA'].map((c, i) => (
          <div key={i} className="bg-white rounded-2xl p-4 border border-black/5 flex items-center gap-3">
            <CheckCircle2 className="w-5 h-5 text-[#42B72A] flex-shrink-0" />
            <div>
              <div className="font-medium text-sm">{c}</div>
              <div className="text-xs text-black/50">Compliant</div>
            </div>
          </div>
        ))}
      </div>

      {/* Audit log */}
      <div className="bg-white rounded-2xl border border-black/5 overflow-hidden">
        <div className="p-5 border-b border-black/5 flex items-center justify-between">
          <h3 className="font-display text-lg font-semibold">Аудит лог</h3>
          <button className="text-xs text-[#1877F2] hover:underline flex items-center gap-1">
            Татах <Download className="w-3 h-3" />
          </button>
        </div>
        <div className="divide-y divide-black/5">
          {events.map((e, i) => (
            <div key={i} className="p-4 flex items-start gap-3 hover:bg-black/[0.02]">
              <div className={`w-8 h-8 rounded-lg flex items-center justify-center flex-shrink-0 ${
                e.status === 'success' ? 'bg-[#42B72A]/10 text-[#42B72A]' :
                e.status === 'danger' ? 'bg-[#E4405F]/10 text-[#E4405F]' :
                e.status === 'warning' ? 'bg-[#F7B928]/10 text-[#B88500]' :
                'bg-[#1877F2]/10 text-[#1877F2]'
              }`}>
                {e.status === 'success' ? <CheckCircle2 className="w-4 h-4" /> :
                 e.status === 'danger' ? <Ban className="w-4 h-4" /> :
                 e.status === 'warning' ? <AlertTriangle className="w-4 h-4" /> :
                 <Activity className="w-4 h-4" />}
              </div>
              <div className="flex-1 min-w-0">
                <div className="text-sm font-medium">{e.detail}</div>
                <div className="flex items-center gap-2 text-xs text-black/50 mt-0.5 flex-wrap">
                  <span>{e.user}</span>
                  <span>·</span>
                  <span className="font-mono">{e.ip}</span>
                  <span>·</span>
                  <span>{e.time}</span>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}

/* ============== SETTINGS ============== */
function SettingsSection() {
  const { currentTenant } = useTenant();
  const [notif, setNotif] = useState(true);
  const [twoFa, setTwoFa] = useState(true);
  const [pubProfile, setPubProfile] = useState(false);

  return (
    <div className="space-y-6 max-w-3xl">
      <div>
        <h1 className="font-display text-3xl font-bold tracking-tight">{currentTenant.name} тохиргоо</h1>
        <p className="text-sm text-black/60 mt-1">Компанийн ерөнхий тохиргоо</p>
      </div>

      {/* Company info */}
      <div className="bg-white rounded-2xl p-6 border border-black/5">
        <h3 className="font-display text-lg font-semibold mb-1">Компанийн мэдээлэл</h3>
        <p className="text-xs text-black/50 mb-5">Nexcore Platforms орчинд харагдах үндсэн мэдээлэл</p>
        <div className="space-y-4">
          <div>
            <label className="text-xs font-medium text-black/60 block mb-1.5">Компанийн нэр</label>
            <input defaultValue={currentTenant.name} className="w-full px-4 py-2.5 bg-[#F7F8FA] border-0 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-[#1877F2]/20" />
          </div>
          <div>
            <label className="text-xs font-medium text-black/60 block mb-1.5">Subdomain</label>
            <div className="flex items-center bg-[#F7F8FA] rounded-lg px-4 py-2.5 text-sm">
              <span className="text-black/40 font-mono">https://</span>
              <input defaultValue={currentTenant.subdomain} className="flex-1 bg-transparent border-0 focus:outline-none font-mono font-semibold mx-1" />
              <span className="text-black/40 font-mono">.nexcoreplatforms.mn</span>
            </div>
          </div>
          <div>
            <label className="text-xs font-medium text-black/60 block mb-1.5">Цагийн бүс</label>
            <select defaultValue={currentTenant.country === 'MN' ? 'Asia/Ulaanbaatar' : 'America/New_York'} className="w-full px-4 py-2.5 bg-[#F7F8FA] border-0 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-[#1877F2]/20">
              <option>Asia/Ulaanbaatar (GMT+8)</option>
              <option>UTC</option>
              <option>America/New_York</option>
            </select>
          </div>
          <div>
            <label className="text-xs font-medium text-black/60 block mb-1.5">Брэнд өнгө</label>
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-lg flex-shrink-0" style={{ background: currentTenant.color }} />
              <input defaultValue={currentTenant.color} className="flex-1 px-4 py-2.5 bg-[#F7F8FA] border-0 rounded-lg text-sm font-mono focus:outline-none focus:ring-2 focus:ring-[#1877F2]/20" />
            </div>
          </div>
        </div>
      </div>

      {/* Toggles */}
      <div className="bg-white rounded-2xl p-6 border border-black/5">
        <h3 className="font-display text-lg font-semibold mb-1">Аюулгүй байдал ба нууцлал</h3>
        <p className="text-xs text-black/50 mb-5">Бүх ажилтанд хамаарах дүрэм</p>
        <div className="space-y-1">
          {[
            { label: 'Имэйл мэдэгдэл', desc: 'Чухал зүйлс гарвал имэйлээр мэдэгдэх', state: notif, set: setNotif },
            { label: '2FA заавал', desc: 'Бүх ажилтанд хоёр шатт баталгаажуулалт шаардлагатай', state: twoFa, set: setTwoFa },
            { label: 'Олон нийтэд нээлттэй профайл', desc: 'Гадны хүн ажилтны нэр харах боломжтой', state: pubProfile, set: setPubProfile },
          ].map((t, i) => (
            <div key={i} className="flex items-center justify-between py-3 border-b border-black/5 last:border-0">
              <div className="flex-1">
                <div className="font-medium text-sm">{t.label}</div>
                <div className="text-xs text-black/50 mt-0.5">{t.desc}</div>
              </div>
              <button
                onClick={() => t.set(!t.state)}
                className={`relative w-11 h-6 rounded-full transition flex-shrink-0 ${t.state ? 'bg-[#1877F2]' : 'bg-black/15'}`}
              >
                <div className={`absolute top-0.5 w-5 h-5 rounded-full bg-white shadow transition-all ${t.state ? 'left-[22px]' : 'left-0.5'}`} />
              </button>
            </div>
          ))}
        </div>
      </div>

      {/* Danger zone */}
      <div className="bg-white rounded-2xl p-6 border border-[#E4405F]/20">
        <h3 className="font-display text-lg font-semibold text-[#E4405F] mb-1">Аюултай бүс</h3>
        <p className="text-xs text-black/50 mb-5">Эдгээр үйлдлийг буцаах боломжгүй</p>
        <div className="space-y-3">
          <div className="flex items-center justify-between p-4 border border-black/10 rounded-xl">
            <div>
              <div className="font-medium text-sm">Бүх датаг экспорт хийх</div>
              <div className="text-xs text-black/50 mt-0.5">JSON хэлбэрээр татах</div>
            </div>
            <button className="px-4 py-2 text-xs bg-black/5 hover:bg-black/10 rounded-full font-medium">Татах</button>
          </div>
          <div className="flex items-center justify-between p-4 border border-[#E4405F]/20 rounded-xl">
            <div>
              <div className="font-medium text-sm text-[#E4405F]">Nexcore Platforms орчныг устгах</div>
              <div className="text-xs text-black/50 mt-0.5">Бүх дата 30 хоногийн дараа устгагдана</div>
            </div>
            <button className="px-4 py-2 text-xs bg-[#E4405F]/10 text-[#E4405F] hover:bg-[#E4405F]/20 rounded-full font-medium">Устгах</button>
          </div>
        </div>
      </div>

      <div className="flex items-center justify-end gap-2 pt-2">
        <button className="px-5 py-2.5 text-sm bg-white border border-black/10 rounded-full hover:bg-black/5">Цуцлах</button>
        <button className="px-5 py-2.5 text-sm bg-[#1877F2] text-white rounded-full hover:bg-[#0866FF]">Хадгалах</button>
      </div>
    </div>
  );
}

/* ============== ADMIN LOCK SCREEN ============== */
function AdminLock({ onUnlock, tenant }) {
  const [password, setPassword] = useState('');
  const [showPw, setShowPw] = useState(false);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  const [attempts, setAttempts] = useState(0);

  // Master admin password — Н. Мягмардорж (Гол Админ)
  const DEMO_PASSWORD = 'Md98HcogxPCVrG';

  function handleSubmit(e) {
    e.preventDefault();
    setError('');
    setLoading(true);
    setTimeout(() => {
      if (password === DEMO_PASSWORD) {
        onUnlock();
      } else {
        setError('Нууц үг буруу байна');
        setAttempts(a => a + 1);
        setPassword('');
      }
      setLoading(false);
    }, 600);
  }

  return (
    <div className="min-h-screen bg-[#FAFAFC] flex items-center justify-center p-6" style={{ fontFamily: "'Geist', system-ui, sans-serif" }}>
      <style>{`
        @import url('https://fonts.googleapis.com/css2?family=Bricolage+Grotesque:opsz,wght@12..96,500;12..96,600;12..96,700&family=Geist:wght@400;500;600;700&display=swap');
        .font-display { font-family: 'Bricolage Grotesque', sans-serif; letter-spacing: -0.02em; }
        @keyframes shake {
          0%, 100% { transform: translateX(0) }
          25% { transform: translateX(-8px) }
          75% { transform: translateX(8px) }
        }
        .anim-shake { animation: shake 0.4s ease-out; }
      `}</style>

      <div className="w-full max-w-md">
        {/* Logo */}
        <Link to="/" className="flex items-center gap-2.5 justify-center mb-8">
          <div className="w-11 h-11 rounded-xl flex items-center justify-center text-white font-display font-bold text-lg" style={{ background: tenant.color }}>
            {tenant.logo}
          </div>
          <div>
            <div className="font-display font-bold">{tenant.name}</div>
            <div className="text-[10px] text-black/50 font-mono">{tenant.subdomain}.nexcoreplatforms.mn/admin</div>
          </div>
        </Link>

        <div className={`bg-white rounded-3xl border border-black/5 shadow-sm p-8 ${error ? 'anim-shake' : ''}`} key={attempts}>
          {/* Lock icon */}
          <div className="flex justify-center mb-5">
            <div className="w-16 h-16 rounded-2xl flex items-center justify-center" style={{ background: `${tenant.color}15` }}>
              <Shield className="w-7 h-7" style={{ color: tenant.color }} />
            </div>
          </div>

          <h1 className="font-display text-2xl font-bold text-center mb-2">Админ нэвтрэлт</h1>
          <p className="text-sm text-black/60 text-center mb-7">
            Энэ хэсэг зөвхөн админуудад нээлттэй
          </p>

          <form onSubmit={handleSubmit} className="space-y-4">
            <div>
              <label className="text-xs font-medium text-black/60 block mb-2">Админ нууц үг</label>
              <div className="relative">
                <Lock className="absolute left-4 top-1/2 -translate-y-1/2 w-4 h-4 text-black/40" />
                <input
                  type={showPw ? 'text' : 'password'}
                  value={password}
                  onChange={(e) => { setPassword(e.target.value); setError(''); }}
                  placeholder="••••••••"
                  autoFocus
                  className={`w-full pl-11 pr-11 py-3.5 bg-[#FAFAFC] border rounded-xl text-sm focus:outline-none focus:ring-4 transition ${error ? 'border-[#EF4444] focus:border-[#EF4444] focus:ring-[#EF4444]/10' : 'border-black/10 focus:border-[#1877F2] focus:ring-[#1877F2]/10'}`}
                />
                <button type="button" onClick={() => setShowPw(!showPw)} className="absolute right-4 top-1/2 -translate-y-1/2 text-black/40 hover:text-black">
                  {showPw ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                </button>
              </div>
              {error && (
                <div className="mt-2 flex items-center gap-1.5 text-xs text-[#EF4444]">
                  <XCircle className="w-3.5 h-3.5" />
                  {error} {attempts >= 3 && '· Олон удаа буруу оруулсан'}
                </div>
              )}
            </div>

            <button
              type="submit"
              disabled={!password || loading}
              className="w-full text-white py-3.5 rounded-xl font-semibold flex items-center justify-center gap-2 disabled:opacity-50 transition"
              style={{ background: tenant.color }}
            >
              {loading ? (
                <div className="w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin" />
              ) : (
                <>Нэвтрэх <ArrowLeft className="w-4 h-4 rotate-180" /></>
              )}
            </button>
          </form>
        </div>

        <div className="mt-5 text-center">
          <Link to="/" className="text-xs text-black/50 hover:text-black inline-flex items-center gap-1">
            <ArrowLeft className="w-3 h-3" /> Нүүр хуудас руу буцах
          </Link>
        </div>

        <div className="mt-6 text-center text-[10px] text-black/40">
          🔒 Production систем дээр SSO + 2FA шаардагдана
        </div>
      </div>
    </div>
  );
}
