import { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { useTenant } from '../contexts/TenantContext.jsx';
import { Mail, Lock, ArrowRight, Globe, Shield, CheckCircle2, Eye, EyeOff, Sparkles } from 'lucide-react';

export default function Login() {
  const { tenants, setCurrentTenant } = useTenant();
  const navigate = useNavigate();
  const [step, setStep] = useState('email'); // email | password
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [detectedTenant, setDetectedTenant] = useState(null);
  const [loading, setLoading] = useState(false);

  function handleEmailSubmit(e) {
    e.preventDefault();
    if (!email.includes('@')) return;

    const domain = email.split('@')[1].toLowerCase();
    // Match by subdomain
    const found = tenants.find(t =>
      domain.includes(t.subdomain) ||
      domain.split('.')[0] === t.subdomain
    );

    setLoading(true);
    setTimeout(() => {
      if (found) {
        setDetectedTenant(found);
        setStep('password');
      } else {
        setDetectedTenant(tenants[1]); // default MCS for demo
        setStep('password');
      }
      setLoading(false);
    }, 600);
  }

  function handleLogin(e) {
    e.preventDefault();
    setLoading(true);
    setTimeout(() => {
      setCurrentTenant(detectedTenant);
      navigate('/apps');
    }, 800);
  }

  return (
    <div className="min-h-screen bg-[#FAFAFC] flex" style={{ fontFamily: "'Geist', system-ui, sans-serif" }}>
      <style>{`
        @import url('https://fonts.googleapis.com/css2?family=Bricolage+Grotesque:opsz,wght@12..96,500;12..96,600;12..96,700&family=Geist:wght@400;500;600;700&display=swap');
        .font-display { font-family: 'Bricolage Grotesque', sans-serif; letter-spacing: -0.02em; }
        @keyframes fadeIn { from { opacity: 0; transform: translateY(8px) } to { opacity: 1; transform: translateY(0) } }
        .anim-fade { animation: fadeIn 0.4s cubic-bezier(0.22, 1, 0.36, 1); }
      `}</style>

      {/* Left side */}
      <div className="hidden lg:flex flex-1 relative bg-gradient-to-br from-[#1877F2] via-[#0866FF] to-[#0052CC] text-white p-12 overflow-hidden">
        <div className="absolute top-0 right-0 w-96 h-96 rounded-full bg-white/5 blur-3xl" />
        <div className="absolute bottom-0 left-0 w-80 h-80 rounded-full bg-white/5 blur-3xl" />

        <div className="relative z-10 flex flex-col justify-between w-full max-w-lg">
          <Link to="/" className="flex items-center gap-2.5">
            <div className="w-10 h-10 rounded-xl bg-white/20 backdrop-blur flex items-center justify-center font-display font-bold">N</div>
            <span className="font-display font-bold text-xl">Nexcore Platforms</span>
          </Link>

          <div>
            <div className="text-xs uppercase tracking-[0.3em] text-white/60 mb-4">— Тавтай морил</div>
            <h1 className="font-display text-5xl font-bold leading-tight mb-6">
              Танай ажлын
              <br />
              орон зайд буцаж<br />
              ирэв үү
            </h1>
            <p className="text-white/80 text-lg leading-relaxed mb-10 max-w-md">
              Имэйлээ оруулаад манай систем танай компанийг автоматаар таних болно.
            </p>

            <div className="space-y-3">
              {[
                'End-to-end шифрлэгдсэн',
                '99.99% uptime баталгаа',
                '30,000+ компани итгэдэг',
              ].map((f, i) => (
                <div key={i} className="flex items-center gap-3 text-sm">
                  <CheckCircle2 className="w-4 h-4 text-white/80" />
                  <span className="text-white/90">{f}</span>
                </div>
              ))}
            </div>
          </div>

          <div className="text-xs text-white/40">© 2026 Nexcore Platforms. Бүх эрх хуулиар хамгаалагдсан.</div>
        </div>
      </div>

      {/* Right side */}
      <div className="flex-1 flex items-center justify-center p-6 lg:p-12">
        <div className="w-full max-w-md">
          <Link to="/" className="lg:hidden flex items-center gap-2 mb-10">
            <div className="w-9 h-9 rounded-xl bg-[#1877F2] flex items-center justify-center text-white font-display font-bold">N</div>
            <span className="font-display font-bold text-xl">Nexcore Platforms</span>
          </Link>

          {step === 'email' && (
            <div className="anim-fade">
              <h2 className="font-display text-3xl font-bold mb-2">Нэвтрэх</h2>
              <p className="text-black/60 mb-8">Имэйлээ оруулна уу</p>

              <form onSubmit={handleEmailSubmit} className="space-y-4">
                <div>
                  <label className="text-xs font-medium text-black/60 block mb-2">Ажлын имэйл</label>
                  <div className="relative">
                    <Mail className="absolute left-4 top-1/2 -translate-y-1/2 w-4 h-4 text-black/40" />
                    <input
                      type="email"
                      value={email}
                      onChange={(e) => setEmail(e.target.value)}
                      placeholder="та@walmart.com"
                      autoFocus
                      className="w-full pl-11 pr-4 py-3.5 bg-[#FAFAFC] border border-black/10 rounded-xl text-sm focus:outline-none focus:border-[#1877F2] focus:ring-4 focus:ring-[#1877F2]/10 transition"
                    />
                  </div>
                </div>

                <button
                  type="submit"
                  disabled={!email.includes('@') || loading}
                  className="w-full bg-[#1877F2] hover:bg-[#0866FF] text-white py-3.5 rounded-xl font-semibold flex items-center justify-center gap-2 disabled:opacity-50 disabled:cursor-not-allowed transition"
                >
                  {loading ? (
                    <div className="w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin" />
                  ) : (
                    <>Үргэлжлүүлэх <ArrowRight className="w-4 h-4" /></>
                  )}
                </button>
              </form>

              <div className="my-6 flex items-center gap-3 text-xs text-black/40">
                <div className="flex-1 h-px bg-black/10" />
                <span>эсвэл</span>
                <div className="flex-1 h-px bg-black/10" />
              </div>

              <div className="space-y-2">
                <button className="w-full py-3 border border-black/10 rounded-xl text-sm font-medium hover:bg-black/[0.02] flex items-center justify-center gap-2">
                  <svg className="w-4 h-4" viewBox="0 0 24 24"><path fill="#4285F4" d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z"/><path fill="#34A853" d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z"/><path fill="#FBBC05" d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.07H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.93l2.85-2.22.81-.62z"/><path fill="#EA4335" d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.07l3.66 2.84c.87-2.6 3.3-4.53 6.16-4.53z"/></svg>
                  Google-аар нэвтрэх
                </button>
                <button className="w-full py-3 border border-black/10 rounded-xl text-sm font-medium hover:bg-black/[0.02] flex items-center justify-center gap-2">
                  <svg className="w-4 h-4" viewBox="0 0 24 24"><path fill="#0078D4" d="M0 0h11.4v11.4H0zM12.6 0H24v11.4H12.6zM0 12.6h11.4V24H0zM12.6 12.6H24V24H12.6z"/></svg>
                  Microsoft-аар нэвтрэх
                </button>
              </div>

              <p className="text-center text-sm text-black/60 mt-8">
                Шинэ компани уу?{' '}
                <Link to="/signup" className="text-[#1877F2] font-semibold hover:underline">Бүртгүүлэх</Link>
              </p>
            </div>
          )}

          {step === 'password' && detectedTenant && (
            <div className="anim-fade">
              {/* Tenant detected card */}
              <div className="mb-6 p-4 bg-white rounded-2xl border border-black/5 flex items-center gap-3 shadow-sm">
                <div className="w-12 h-12 rounded-xl flex items-center justify-center text-white font-display font-bold text-lg flex-shrink-0" style={{ background: detectedTenant.color }}>
                  {detectedTenant.logo}
                </div>
                <div className="flex-1 min-w-0">
                  <div className="flex items-center gap-1.5 text-[10px] font-medium text-[#10B981] uppercase tracking-wider mb-0.5">
                    <CheckCircle2 className="w-3 h-3" />
                    Компанийг тань илрүүллээ
                  </div>
                  <div className="font-semibold text-sm">{detectedTenant.name}</div>
                  <div className="text-xs text-black/50 font-mono">{detectedTenant.subdomain}.nexcoreplatforms.mn</div>
                </div>
                <button
                  onClick={() => { setStep('email'); setDetectedTenant(null); }}
                  className="text-xs text-[#1877F2] font-medium hover:underline"
                >
                  Солих
                </button>
              </div>

              <h2 className="font-display text-3xl font-bold mb-2">Сайн уу 👋</h2>
              <p className="text-black/60 mb-8">Нууц үгээ оруулна уу</p>

              <form onSubmit={handleLogin} className="space-y-4">
                <div>
                  <div className="flex items-center justify-between mb-2">
                    <label className="text-xs font-medium text-black/60">Нууц үг</label>
                    <a href="#" className="text-xs text-[#1877F2] font-medium hover:underline">Мартсан уу?</a>
                  </div>
                  <div className="relative">
                    <Lock className="absolute left-4 top-1/2 -translate-y-1/2 w-4 h-4 text-black/40" />
                    <input
                      type={showPassword ? 'text' : 'password'}
                      value={password}
                      onChange={(e) => setPassword(e.target.value)}
                      placeholder="••••••••"
                      autoFocus
                      className="w-full pl-11 pr-11 py-3.5 bg-[#FAFAFC] border border-black/10 rounded-xl text-sm focus:outline-none focus:border-[#1877F2] focus:ring-4 focus:ring-[#1877F2]/10 transition"
                    />
                    <button type="button" onClick={() => setShowPassword(!showPassword)} className="absolute right-4 top-1/2 -translate-y-1/2 text-black/40 hover:text-black">
                      {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                    </button>
                  </div>
                </div>

                <button
                  type="submit"
                  disabled={!password || loading}
                  className="w-full text-white py-3.5 rounded-xl font-semibold flex items-center justify-center gap-2 disabled:opacity-50 transition"
                  style={{ background: detectedTenant.color }}
                >
                  {loading ? (
                    <div className="w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin" />
                  ) : (
                    <>{detectedTenant.name} руу нэвтрэх <ArrowRight className="w-4 h-4" /></>
                  )}
                </button>
              </form>

              <div className="mt-6 p-3 bg-[#1877F2]/5 rounded-xl flex items-start gap-2 text-xs text-black/70">
                <Shield className="w-4 h-4 text-[#1877F2] flex-shrink-0 mt-0.5" />
                <div>
                  <strong>Аюулгүй холболт.</strong> Таны нэвтрэх мэдээлэл шифрлэгдэж <span className="font-mono">{detectedTenant.subdomain}.nexcoreplatforms.mn</span>-руу илгээгдэнэ.
                </div>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
