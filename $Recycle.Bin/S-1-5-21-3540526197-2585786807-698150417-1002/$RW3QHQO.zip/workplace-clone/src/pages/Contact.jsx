import { useState } from 'react';
import { Link } from 'react-router-dom';
import {
  Mail, Phone, MapPin, MessageSquare, Send, CheckCircle2,
  Building2, Sparkles, Globe, ArrowRight
} from 'lucide-react';

export default function Contact() {
  const [submitted, setSubmitted] = useState(false);
  const [form, setForm] = useState({
    name: '', company: '', email: '', phone: '', subject: 'sales', message: ''
  });

  function handleSubmit(e) {
    e.preventDefault();
    setTimeout(() => setSubmitted(true), 600);
  }

  return (
    <div className="min-h-screen bg-white" style={{ fontFamily: "'Geist', system-ui, sans-serif" }}>
      <style>{`
        @import url('https://fonts.googleapis.com/css2?family=Bricolage+Grotesque:opsz,wght@12..96,500;12..96,600;12..96,700&family=Geist:wght@400;500;600;700&family=Instrument+Serif:ital@1&display=swap');
        .font-display { font-family: 'Bricolage Grotesque', sans-serif; letter-spacing: -0.02em; }
        .font-serif-italic { font-family: 'Instrument Serif', serif; font-style: italic; }
      `}</style>

      <header className="border-b border-black/5 px-6 py-4 flex items-center justify-between max-w-7xl mx-auto">
        <Link to="/" className="flex items-center gap-2.5">
          <div className="w-9 h-9 rounded-xl bg-[#1877F2] flex items-center justify-center text-white font-display font-bold">N</div>
          <span className="font-display font-bold text-xl">Nexcore Platforms</span>
        </Link>
        <Link to="/" className="text-sm text-black/60 hover:text-black">← Нүүр</Link>
      </header>

      <section className="py-16 lg:py-20 px-6">
        <div className="max-w-6xl mx-auto">
          <div className="text-center max-w-2xl mx-auto mb-14">
            <div className="text-xs font-semibold uppercase tracking-[0.3em] text-[#1877F2] mb-4">— Холбоо барих</div>
            <h1 className="font-display text-5xl lg:text-6xl font-bold tracking-tight mb-5">
              Бидэнтэй <span className="font-serif-italic font-normal">ярилцая</span>
            </h1>
            <p className="text-lg text-black/60">
              Танай компанид хэрхэн туслах вэ? Бид 24 цагт хариу өгөх болно.
            </p>
          </div>

          <div className="grid lg:grid-cols-3 gap-6">
            {/* Contact info cards */}
            <div className="lg:col-span-1 space-y-3">
              {[
                {
                  icon: Mail,
                  title: 'Имэйл',
                  primary: 'hello@nexcoreplatforms.mn',
                  secondary: 'sales@nexcoreplatforms.mn',
                  color: '#1877F2'
                },
                {
                  icon: Phone,
                  title: 'Утас',
                  primary: '+976 7700 0000',
                  secondary: 'Даваа-Баасан, 09:00-18:00',
                  color: '#10B981'
                },
                {
                  icon: MapPin,
                  title: 'Оффис',
                  primary: 'Сүхбаатар дүүрэг',
                  secondary: 'Ulaanbaatar, Mongolia',
                  color: '#F59E0B'
                },
                {
                  icon: MessageSquare,
                  title: 'Live Chat',
                  primary: '24/7 онлайн дэмжлэг',
                  secondary: 'Premium хэрэглэгчдэд',
                  color: '#A855F7'
                },
              ].map((c, i) => {
                const Icon = c.icon;
                return (
                  <div key={i} className="bg-white border border-black/5 rounded-2xl p-5 hover:border-black/15 transition">
                    <div className="w-10 h-10 rounded-xl flex items-center justify-center mb-3" style={{ background: `${c.color}15`, color: c.color }}>
                      <Icon className="w-4 h-4" />
                    </div>
                    <div className="text-xs uppercase tracking-wider text-black/50 font-semibold mb-1">{c.title}</div>
                    <div className="font-medium">{c.primary}</div>
                    <div className="text-xs text-black/50 mt-0.5">{c.secondary}</div>
                  </div>
                );
              })}
            </div>

            {/* Form */}
            <div className="lg:col-span-2">
              {!submitted ? (
                <form onSubmit={handleSubmit} className="bg-white border border-black/10 rounded-3xl p-8">
                  <h2 className="font-display text-2xl font-bold mb-6">Зурвас илгээх</h2>

                  <div className="grid sm:grid-cols-2 gap-4 mb-4">
                    <div>
                      <label className="text-xs font-medium text-black/60 block mb-2">Бүтэн нэр *</label>
                      <input
                        required
                        value={form.name}
                        onChange={(e) => setForm({ ...form, name: e.target.value })}
                        placeholder="Бат-Эрдэнэ Доржийн"
                        className="w-full px-4 py-3 bg-[#FAFAFC] border border-black/10 rounded-xl text-sm focus:outline-none focus:border-[#1877F2] focus:ring-4 focus:ring-[#1877F2]/10"
                      />
                    </div>
                    <div>
                      <label className="text-xs font-medium text-black/60 block mb-2">Компанийн нэр</label>
                      <input
                        value={form.company}
                        onChange={(e) => setForm({ ...form, company: e.target.value })}
                        placeholder="Танай Компани ХХК"
                        className="w-full px-4 py-3 bg-[#FAFAFC] border border-black/10 rounded-xl text-sm focus:outline-none focus:border-[#1877F2] focus:ring-4 focus:ring-[#1877F2]/10"
                      />
                    </div>
                  </div>

                  <div className="grid sm:grid-cols-2 gap-4 mb-4">
                    <div>
                      <label className="text-xs font-medium text-black/60 block mb-2">Имэйл *</label>
                      <input
                        required
                        type="email"
                        value={form.email}
                        onChange={(e) => setForm({ ...form, email: e.target.value })}
                        placeholder="та@example.com"
                        className="w-full px-4 py-3 bg-[#FAFAFC] border border-black/10 rounded-xl text-sm focus:outline-none focus:border-[#1877F2] focus:ring-4 focus:ring-[#1877F2]/10"
                      />
                    </div>
                    <div>
                      <label className="text-xs font-medium text-black/60 block mb-2">Утас</label>
                      <input
                        type="tel"
                        value={form.phone}
                        onChange={(e) => setForm({ ...form, phone: e.target.value })}
                        placeholder="+976 ..."
                        className="w-full px-4 py-3 bg-[#FAFAFC] border border-black/10 rounded-xl text-sm focus:outline-none focus:border-[#1877F2] focus:ring-4 focus:ring-[#1877F2]/10"
                      />
                    </div>
                  </div>

                  <div className="mb-4">
                    <label className="text-xs font-medium text-black/60 block mb-2">Сэдэв *</label>
                    <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
                      {[
                        { id: 'sales', label: 'Борлуулалт', icon: Building2 },
                        { id: 'demo', label: 'Демо хүсэх', icon: Sparkles },
                        { id: 'support', label: 'Дэмжлэг', icon: MessageSquare },
                        { id: 'partner', label: 'Хамтрал', icon: Globe },
                      ].map((opt) => {
                        const Icon = opt.icon;
                        return (
                          <button
                            key={opt.id}
                            type="button"
                            onClick={() => setForm({ ...form, subject: opt.id })}
                            className={`p-3 rounded-xl border text-xs font-medium flex flex-col items-center gap-1.5 transition ${form.subject === opt.id ? 'border-[#1877F2] bg-[#1877F2]/5 text-[#1877F2]' : 'border-black/10 hover:border-black/20'}`}
                          >
                            <Icon className="w-4 h-4" />
                            {opt.label}
                          </button>
                        );
                      })}
                    </div>
                  </div>

                  <div className="mb-5">
                    <label className="text-xs font-medium text-black/60 block mb-2">Зурвас *</label>
                    <textarea
                      required
                      value={form.message}
                      onChange={(e) => setForm({ ...form, message: e.target.value })}
                      placeholder="Танд хэрхэн туслах вэ?"
                      rows={5}
                      className="w-full px-4 py-3 bg-[#FAFAFC] border border-black/10 rounded-xl text-sm focus:outline-none focus:border-[#1877F2] focus:ring-4 focus:ring-[#1877F2]/10 resize-none"
                    />
                  </div>

                  <button
                    type="submit"
                    className="w-full bg-[#1877F2] hover:bg-[#0866FF] text-white py-3.5 rounded-xl font-semibold flex items-center justify-center gap-2 transition"
                  >
                    <Send className="w-4 h-4" />
                    Илгээх
                  </button>

                  <p className="text-xs text-black/50 mt-4 text-center">
                    Бид 24 цагт хариу өгнө. Гэрээгээр илүү ярих бол sales багт.
                  </p>
                </form>
              ) : (
                <div className="bg-white border border-black/10 rounded-3xl p-12 text-center">
                  <div className="w-20 h-20 rounded-full bg-[#10B981]/10 flex items-center justify-center mx-auto mb-5">
                    <CheckCircle2 className="w-10 h-10 text-[#10B981]" />
                  </div>
                  <h2 className="font-display text-3xl font-bold mb-2">Илгээгдлээ! 🎉</h2>
                  <p className="text-black/60 mb-6 max-w-md mx-auto">
                    Танай зурвас амжилттай ирлээ. Бид 24 цагт <strong>{form.email}</strong> хаягаар хариу илгээх болно.
                  </p>
                  <Link to="/" className="inline-flex items-center gap-2 text-[#1877F2] font-semibold hover:underline">
                    Нүүр хуудас руу буцах <ArrowRight className="w-4 h-4" />
                  </Link>
                </div>
              )}
            </div>
          </div>
        </div>
      </section>

      <footer className="border-t border-black/5 py-8 px-6">
        <div className="max-w-7xl mx-auto flex items-center justify-between text-xs text-black/50">
          <div>© 2026 Nexcore Platforms.</div>
          <div className="flex gap-5">
            <Link to="/about" className="hover:text-black">Бидний тухай</Link>
            <Link to="/contact" className="hover:text-black">Холбогдох</Link>
            <Link to="/faq" className="hover:text-black">FAQ</Link>
          </div>
        </div>
      </footer>
    </div>
  );
}
