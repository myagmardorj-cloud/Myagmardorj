import { useState } from 'react';
import { Link } from 'react-router-dom';
import { AlertTriangle, X, ArrowRight, Clock } from 'lucide-react';

export default function MigrationBanner() {
  const [closed, setClosed] = useState(false);
  if (closed) return null;

  // Meta Workplace closes May 31, 2026 — calculate days remaining
  const closeDate = new Date('2026-05-31');
  const today = new Date();
  const daysLeft = Math.ceil((closeDate - today) / (1000 * 60 * 60 * 24));

  return (
    <div className="relative bg-gradient-to-r from-[#7C3AED] via-[#A855F7] to-[#EC4899] text-white">
      <div className="max-w-7xl mx-auto px-6 py-2.5 flex items-center justify-center gap-3 text-xs sm:text-sm">
        <AlertTriangle className="w-4 h-4 flex-shrink-0 animate-pulse" />
        <div className="flex items-center gap-2 flex-wrap justify-center">
          <span className="font-semibold">Meta Workplace 2026.05.31-нд бүрмөсөн хаагдана</span>
          <span className="hidden sm:inline opacity-80">·</span>
          <span className="hidden sm:inline opacity-90 flex items-center gap-1">
            <Clock className="w-3 h-3" />
            <strong className="font-mono">{daysLeft}</strong> хоног үлдсэн
          </span>
        </div>
        <Link to="/migrate" className="hidden sm:flex items-center gap-1 bg-white/20 hover:bg-white/30 backdrop-blur px-3 py-1 rounded-full font-semibold transition whitespace-nowrap">
          Шилжих туслалцаа
          <ArrowRight className="w-3 h-3" />
        </Link>
        <button onClick={() => setClosed(true)} className="ml-2 opacity-70 hover:opacity-100 transition">
          <X className="w-4 h-4" />
        </button>
      </div>
    </div>
  );
}
