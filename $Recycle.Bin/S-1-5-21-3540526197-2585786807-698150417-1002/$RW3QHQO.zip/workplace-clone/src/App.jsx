import { Suspense, lazy } from 'react';
import { BrowserRouter, Routes, Route, Link } from 'react-router-dom';
import Landing from './pages/Landing.jsx';

// Lazy-loaded pages (Landing-аас бусад нь хэрэгтэй цагтаа л татна)
const Login = lazy(() => import('./pages/Login.jsx'));
const Signup = lazy(() => import('./pages/Signup.jsx'));
const Migrate = lazy(() => import('./pages/Migrate.jsx'));
const About = lazy(() => import('./pages/About.jsx'));
const Contact = lazy(() => import('./pages/Contact.jsx'));
const FAQ = lazy(() => import('./pages/FAQ.jsx'));
const Admin = lazy(() => import('./pages/Admin.jsx'));
const SuperAdmin = lazy(() => import('./pages/SuperAdmin.jsx'));
const AppsLayout = lazy(() => import('./pages/apps/AppsLayout.jsx'));
const AppsHome = lazy(() => import('./pages/apps/AppsHome.jsx'));
const Chat = lazy(() => import('./pages/apps/Chat.jsx'));
const Meet = lazy(() => import('./pages/apps/Meet.jsx'));
const Learn = lazy(() => import('./pages/apps/Learn.jsx'));
const Mail = lazy(() => import('./pages/apps/Mail.jsx'));
const Docs = lazy(() => import('./pages/apps/Docs.jsx'));
const AI = lazy(() => import('./pages/apps/AI.jsx'));
const Calendar = lazy(() => import('./pages/apps/Calendar.jsx'));
const Whiteboard = lazy(() => import('./pages/apps/Whiteboard.jsx'));
const Drafts = lazy(() => import('./pages/apps/Drafts.jsx'));

// Loading fallback (Suspense дотор)
function PageLoader() {
  return (
    <div className="min-h-screen flex items-center justify-center bg-[#0A0E1F]">
      <div className="flex flex-col items-center gap-4">
        <div
          className="w-14 h-14 rounded-2xl flex items-center justify-center text-white font-bold text-2xl"
          style={{ background: 'linear-gradient(135deg, #06B6D4, #3B82F6)', animation: 'pulse 1.5s ease-in-out infinite' }}
        >
          N
        </div>
        <div className="text-white/40 text-xs">Ачаалж байна...</div>
      </div>
    </div>
  );
}

// 404 хуудас
function NotFound() {
  return (
    <div className="min-h-screen flex items-center justify-center bg-[#0A0E1F] p-6">
      <div className="text-center max-w-md">
        <div className="text-7xl mb-6">🔍</div>
        <div className="font-display text-7xl font-bold mb-3" style={{ background: 'linear-gradient(135deg, #06B6D4, #3B82F6)', WebkitBackgroundClip: 'text', WebkitTextFillColor: 'transparent', backgroundClip: 'text' }}>
          404
        </div>
        <h1 className="text-2xl font-bold text-white mb-3">Хуудас олдсонгүй</h1>
        <p className="text-white/60 mb-8">
          Таны хайсан хуудас байхгүй эсвэл устсан байна. URL-ыг шалгаад дахин оролдоорой.
        </p>
        <div className="flex flex-wrap gap-3 justify-center">
          <Link
            to="/"
            className="px-6 py-3 rounded-full font-semibold text-white"
            style={{ background: 'linear-gradient(135deg, #06B6D4, #3B82F6)' }}
          >
            🏠 Нүүр хуудас
          </Link>
          <Link
            to="/contact"
            className="px-6 py-3 rounded-full font-semibold border border-white/20 text-white hover:bg-white/5"
          >
            📞 Холбоо барих
          </Link>
        </div>
        <div className="mt-8 text-xs text-white/40">
          Тусламж хэрэгтэй юу? <a href="mailto:hello@nexcore.ltd" className="text-cyan-400 hover:underline">hello@nexcore.ltd</a>
        </div>
      </div>
    </div>
  );
}

export default function App() {
  return (
    <BrowserRouter>
      <Suspense fallback={<PageLoader />}>
        <Routes>
          <Route path="/" element={<Landing />} />
          <Route path="/login" element={<Login />} />
          <Route path="/signup" element={<Signup />} />
          <Route path="/migrate" element={<Migrate />} />
          <Route path="/about" element={<About />} />
          <Route path="/contact" element={<Contact />} />
          <Route path="/faq" element={<FAQ />} />
          <Route path="/admin/*" element={<Admin />} />
          <Route path="/super-admin/*" element={<SuperAdmin />} />
          <Route path="/apps" element={<AppsLayout />}>
            <Route index element={<AppsHome />} />
            <Route path="chat" element={<Chat />} />
            <Route path="meet" element={<Meet />} />
            <Route path="learn" element={<Learn />} />
            <Route path="mail" element={<Mail />} />
            <Route path="docs" element={<Docs />} />
            <Route path="ai" element={<AI />} />
            <Route path="calendar" element={<Calendar />} />
            <Route path="whiteboard" element={<Whiteboard />} />
            <Route path="drafts" element={<Drafts />} />
          </Route>
          {/* 404 — бүх таарахгүй URL */}
          <Route path="*" element={<NotFound />} />
        </Routes>
      </Suspense>
    </BrowserRouter>
  );
}
