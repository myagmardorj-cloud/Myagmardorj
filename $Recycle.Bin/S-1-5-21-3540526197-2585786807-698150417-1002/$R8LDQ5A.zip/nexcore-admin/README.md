# Nexcore Admin Console

Хязгаарлагдмал хэсэг — зөвхөн админуудад зориулагдсан.

## URLs

- `/admin` — Компанийн админ панель
- `/super-admin` — Nexcore master control

## Demo нууц үг

```
Md98HcogxPCVrG
```

## Local хөгжүүлэлт

```bash
npm install
npm run dev      # http://localhost:5173
npm run build    # Production build
```

## Production deploy

Vercel дээр:
- **Domain:** `admin.nexcoreplatforms.mn`
- **Repo:** `nexcore-admin`
- **Framework:** Vite (auto-detect)

## Аюулгүй байдал

- ✅ `robots.txt` — search engine-д индексжихгүй
- ✅ Meta `noindex, nofollow`
- ✅ Lock screen нууц үгтэй
- ⚠️ Production: server-side auth + 2FA + IP whitelist шаардлагатай
