import { createContext, useContext, useState } from 'react';

export const INITIAL_TENANTS = [
  { id: 'walmart', verified: true, name: 'Walmart Inc.', subdomain: 'walmart', logo: 'W', color: '#0071CE', users: 12847, plan: 'Premium', revenue: 102776, status: 'active', country: 'US', joined: '2023-01-15' },
  { id: 'mcs', verified: true, name: 'MCS Group', subdomain: 'mcs', logo: 'M', color: '#0066CC', users: 847, plan: 'Premium', revenue: 6776, status: 'active', country: 'MN', joined: '2024-06-01' },
  { id: 'khanbank', verified: true, name: 'Хаан Банк', subdomain: 'khanbank', logo: 'K', color: '#003876', users: 2340, plan: 'Enterprise', revenue: 23400, status: 'active', country: 'MN', joined: '2024-03-20' },
  { id: 'mmc', name: 'Mongolian Mining Corp', subdomain: 'mmc', logo: 'MM', color: '#D4AF37', users: 412, plan: 'Enterprise', revenue: 8240, status: 'active', country: 'MN', joined: '2024-08-12' },
  { id: 'apu', verified: true, name: 'APU ХК', subdomain: 'apu', logo: 'A', color: '#0066B3', users: 1247, plan: 'Premium', revenue: 9976, status: 'active', country: 'MN', joined: '2024-09-15' },
  { id: 'cocacola', verified: true, name: 'Coca-Cola Mongolia', subdomain: 'cocacola', logo: 'C', color: '#F40009', users: 389, plan: 'Premium', revenue: 3112, status: 'active', country: 'MN', joined: '2025-01-10' },
  { id: 'unitel', verified: true, name: 'Unitel', subdomain: 'unitel', logo: 'U', color: '#E60023', users: 987, plan: 'Premium', revenue: 7896, status: 'active', country: 'MN', joined: '2024-05-18' },
  { id: 'gobi', name: 'Gobi Cashmere', subdomain: 'gobi', logo: 'G', color: '#8B4513', users: 234, plan: 'Core', revenue: 936, status: 'active', country: 'MN', joined: '2024-11-30' },
  { id: 'shangrila', name: 'Shangri-La UB', subdomain: 'shangrila', logo: 'S', color: '#8B0000', users: 287, plan: 'Premium', revenue: 2296, status: 'active', country: 'MN', joined: '2025-02-22' },
  { id: 'erdenes', name: 'Эрдэнэс Тавантолгой', subdomain: 'etmgl', logo: 'ЭТ', color: '#1A5490', users: 1872, plan: 'Enterprise', revenue: 18720, status: 'pending', country: 'MN', joined: '2025-03-05' },
  { id: 'mobicom', name: 'Mobicom', subdomain: 'mobicom', logo: 'M', color: '#FF6B00', users: 1456, plan: 'Premium', revenue: 11648, status: 'active', country: 'MN', joined: '2024-07-08' },
  { id: 'tdb', verified: true, name: 'Худалдаа хөгжлийн банк', subdomain: 'tdbm', logo: 'TDB', color: '#005BAA', users: 1089, plan: 'Enterprise', revenue: 10890, status: 'active', country: 'MN', joined: '2024-04-12' },
];

export const TENANTS = INITIAL_TENANTS;

const MN_PEOPLE = [
  { name: 'Бат-Эрдэнэ Д.', firstName: 'baterdene' },
  { name: 'Сараа Болд', firstName: 'saraa' },
  { name: 'Дорж Аюуш', firstName: 'dorj' },
  { name: 'Туяа Мөнх', firstName: 'tuya' },
  { name: 'Болд Ган', firstName: 'bold' },
  { name: 'Энхтуяа Б.', firstName: 'enkhtuya' },
  { name: 'Ганбат Ж.', firstName: 'ganbat' },
  { name: 'Намуун О.', firstName: 'namuun' },
];

const US_PEOPLE = [
  { name: 'Sarah Johnson', firstName: 'sarah' },
  { name: 'Michael Chen', firstName: 'michael' },
  { name: 'Emily Rodriguez', firstName: 'emily' },
  { name: 'David Kim', firstName: 'david' },
  { name: 'Jessica Patel', firstName: 'jessica' },
  { name: 'Christopher Lee', firstName: 'chris' },
  { name: 'Amanda Wilson', firstName: 'amanda' },
  { name: 'Daniel Martinez', firstName: 'daniel' },
];

const ROLES = ['Admin', 'Manager', 'CEO', 'Member', 'Member', 'Manager', 'Member', 'Member'];
const STATUSES = ['active', 'active', 'active', 'active', 'inactive', 'pending', 'active', 'active'];
const DEPTS_MN = ['IT', 'HR', 'Удирдлага', 'Маркетинг', 'Борлуулалт', 'Финанс', 'Инженер', 'Дизайн'];
const DEPTS_US = ['IT', 'HR', 'Executive', 'Marketing', 'Sales', 'Finance', 'Engineering', 'Design'];
const AVATAR_COLORS = ['#6366F1', '#10B981', '#F59E0B', '#EC4899', '#8B5CF6', '#06B6D4', '#EF4444', '#14B8A6'];

export function getUsersForTenant(tenant) {
  const people = tenant.country === 'US' ? US_PEOPLE : MN_PEOPLE;
  const depts = tenant.country === 'US' ? DEPTS_US : DEPTS_MN;
  return people.map((p, i) => ({
    name: p.name,
    email: `${p.firstName}@${tenant.subdomain}.com`,
    role: ROLES[i],
    dept: depts[i],
    status: STATUSES[i],
    avatar: AVATAR_COLORS[i],
  }));
}

export function getGroupsForTenant(tenant) {
  const isMN = tenant.country === 'MN';
  return [
    { name: isMN ? `${tenant.name} удирдлага` : `${tenant.name} HQ`, members: tenant.users, posts: 23, type: isMN ? 'Захиргаа' : 'Official', color: tenant.color, badge: isMN ? 'Албан ёсны' : 'Official' },
    { name: isMN ? 'Маркетингийн баг' : 'Marketing Team', members: Math.floor(tenant.users * 0.05), posts: 184, type: isMN ? 'Хувийн' : 'Private', color: '#EC4899', badge: isMN ? 'Идэвхтэй' : 'Active' },
    { name: isMN ? 'Шинэ ажилтан' : 'New Hires', members: Math.floor(tenant.users * 0.02), posts: 56, type: isMN ? 'Нээлттэй' : 'Open', color: '#10B981' },
    { name: isMN ? 'Инженерийн баг' : 'Engineering', members: Math.floor(tenant.users * 0.15), posts: 1247, type: isMN ? 'Хувийн' : 'Private', color: '#F59E0B', badge: isMN ? 'Идэвхтэй' : 'Active' },
    { name: isMN ? 'Спорт & Хобби' : 'Sports & Hobbies', members: Math.floor(tenant.users * 0.3), posts: 421, type: isMN ? 'Нээлттэй' : 'Open', color: '#8B5CF6' },
    { name: isMN ? 'IT дэмжлэг' : 'IT Support', members: tenant.users, posts: 89, type: isMN ? 'Албан' : 'Official', color: '#06B6D4' },
  ];
}

export function getStatsForTenant(tenant) {
  const todayActive = Math.floor(tenant.users * 0.65);
  return {
    totalUsers: tenant.users,
    activeToday: todayActive,
    newPosts: Math.floor(tenant.users * 0.1),
    reports: Math.max(1, Math.floor(tenant.users * 0.002)),
    activeUsers: todayActive,
    inactiveUsers: Math.floor(tenant.users * 0.32),
    pendingUsers: Math.max(1, Math.floor(tenant.users * 0.02)),
    blockedUsers: Math.max(1, Math.floor(tenant.users * 0.005)),
  };
}

const TenantContext = createContext();

export function TenantProvider({ children }) {
  const [tenants, setTenants] = useState(INITIAL_TENANTS);
  const [currentTenant, setCurrentTenant] = useState(INITIAL_TENANTS[1]); // MCS default

  function addTenant(newTenant) {
    setTenants(prev => [newTenant, ...prev]);
    setCurrentTenant(newTenant);
  }

  return (
    <TenantContext.Provider value={{ currentTenant, setCurrentTenant, tenants, addTenant }}>
      {children}
    </TenantContext.Provider>
  );
}

export function useTenant() {
  const ctx = useContext(TenantContext);
  if (!ctx) throw new Error('useTenant must be used within TenantProvider');
  return ctx;
}
