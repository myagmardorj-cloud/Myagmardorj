import { BrowserRouter, Routes, Route, Navigate } from 'react-router-dom';
import Admin from './pages/Admin.jsx';
import SuperAdmin from './pages/SuperAdmin.jsx';

export default function App() {
  return (
    <BrowserRouter>
      <Routes>
        {/* Default — Admin руу очих */}
        <Route path="/" element={<Navigate to="/admin" replace />} />
        <Route path="/admin/*" element={<Admin />} />
        <Route path="/super-admin/*" element={<SuperAdmin />} />
        {/* 404 — бүх бусад path-уудыг admin руу буцаах */}
        <Route path="*" element={<Navigate to="/admin" replace />} />
      </Routes>
    </BrowserRouter>
  );
}
