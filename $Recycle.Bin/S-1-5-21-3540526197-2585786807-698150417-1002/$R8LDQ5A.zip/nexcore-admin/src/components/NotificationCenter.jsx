import { useState } from 'react';
import { useTenant } from '../contexts/TenantContext.jsx';
import {
  Bell, X, AtSign, MessageSquare, Heart, Calendar, FileText,
  Pin, CheckCircle2, Settings, Filter, Sparkles, BadgeCheck
} from 'lucide-react';

export default function NotificationCenter({ onClose }) {
  const { tenants, currentTenant, setCurrentTenant } = useTenant();
  const [filter, setFilter] = useState('all');
  const [pinned, setPinned] = useState([currentTenant.id, 'walmart', 'khanbank']);

  // Mock notifications from multiple tenants
  const allNotifications = [
    { id: 1, tenantId: 'mcs', from: 'Сараа Болд', message: '@Та Q4 кампанит ажлын тайланг үзээрэй', time: '5 мин', type: 'mention', unread: true },
    { id: 2, tenantId: 'walmart', from: 'Sarah Johnson', message: 'Approved your PR #42', time: '12 мин', type: 'message', unread: true },
    { id: 3, tenantId: 'khanbank', from: 'Хаан Банк HR', message: 'Шинэ ажилтны сургалт зарлагдлаа', time: '34 мин', type: 'announcement', unread: true },
    { id: 4, tenantId: 'mcs', from: 'Дорж А.', message: 'CEO Town Hall эхэлж байна', time: '1 цаг', type: 'meeting', unread: true },
    { id: 5, tenantId: 'apu', from: 'Туяа М.', message: 'Шинэ документ хуваалцлаа: Q4_Brief.pdf', time: '2 цаг', type: 'file' },
    { id: 6, tenantId: 'walmart', from: 'Michael Chen', message: 'Liked your post', time: '3 цаг', type: 'like' },
    { id: 7, tenantId: 'cocacola', from: 'Coca-Cola Marketing', message: 'Шинэ кампанит ажил эхэллээ', time: '5 цаг', type: 'announcement' },
    { id: 8, tenantId: 'khanbank', from: 'Бат Г.', message: '@Та-аас санал хүсэж байна', time: 'Өчигдөр', type: 'mention' },
  ];

  const filtered = filter === 'all'
    ? allNotifications
    : filter === 'unread'
      ? allNotifications.filter(n => n.unread)
      : filter === 'mentions'
        ? allNotifications.filter(n => n.type === 'mention')
        : allNotifications.filter(n => n.tenantId === filter);

  function getTenant(id) {
    return tenants.find(t => t.id === id) || tenants[0];
  }

  function togglePin(tenantId) {
    setPinned(p => p.includes(tenantId) ? p.filter(id => id !== tenantId) : [...p, tenantId]);
  }

  function getIcon(type) {
    switch(type) {
      case 'mention': return AtSign;
      case 'meeting': return Calendar;
      case 'file': return FileText;
      case 'like': return Heart;
      case 'announcement': return Sparkles;
      default: return MessageSquare;
    }
  }

  const unreadCount = allNotifications.filter(n => n.unread).length;
  const tenantsWithNotifs = [...new Set(allNotifications.map(n => n.tenantId))]
    .map(id => getTenant(id))
    .filter(Boolean);

  return (
    <>
      <div className="fixed inset-0 z-40" onClick={onClose} />
      <div className="absolute top-12 right-4 w-96 max-h-[calc(100vh-100px)] bg-white rounded-2xl shadow-2xl border border-black/5 z-50 overflow-hidden flex flex-col">
        {/* Header */}
        <div className="px-4 py-3 border-b border-black/5 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Bell className="w-4 h-4" />
            <h3 className="font-semibold text-sm">Мэдэгдэл</h3>
            {unreadCount > 0 && <span className="text-[10px] px-1.5 py-0.5 bg-[#EF4444] text-white rounded-full font-bold">{unreadCount}</span>}
          </div>
          <button onClick={onClose} className="w-7 h-7 rounded-lg hover:bg-black/5 flex items-center justify-center">
            <X className="w-3.5 h-3.5" />
          </button>
        </div>

        {/* Multi-tenant subscription bar */}
        <div className="px-4 py-3 border-b border-black/5 bg-[#FAFAFC]">
          <div className="text-[10px] font-semibold uppercase tracking-wider text-black/40 mb-2 flex items-center justify-between">
            <span>Танай компаниуд ({tenantsWithNotifs.length})</span>
            <span className="text-[#6366F1] cursor-pointer hover:underline">Удирдах</span>
          </div>
          <div className="flex gap-1.5 overflow-x-auto scrollbar-hide pb-1">
            {tenantsWithNotifs.map(t => {
              const isPinned = pinned.includes(t.id);
              const tenantUnread = allNotifications.filter(n => n.tenantId === t.id && n.unread).length;
              return (
                <button
                  key={t.id}
                  onClick={() => setFilter(t.id)}
                  className={`relative flex-shrink-0 group ${filter === t.id ? '' : 'opacity-70 hover:opacity-100'}`}
                  title={t.name}
                >
                  <div className={`w-9 h-9 rounded-lg flex items-center justify-center text-white font-bold text-xs transition ${filter === t.id ? 'ring-2 ring-offset-2 ring-[#6366F1]' : ''}`} style={{ background: t.color }}>
                    {t.logo}
                  </div>
                  {isPinned && <Pin className="absolute -top-1 -right-1 w-3 h-3 text-[#F59E0B] fill-[#F59E0B]" />}
                  {tenantUnread > 0 && (
                    <span className="absolute -bottom-1 -right-1 w-4 h-4 bg-[#EF4444] text-white text-[8px] font-bold rounded-full flex items-center justify-center border border-white">
                      {tenantUnread}
                    </span>
                  )}
                </button>
              );
            })}
          </div>
        </div>

        {/* Filter tabs */}
        <div className="flex border-b border-black/5 px-2">
          {[
            { id: 'all', label: 'Бүгд' },
            { id: 'unread', label: 'Уншаагүй' },
            { id: 'mentions', label: '@Mentions' },
          ].map(f => (
            <button
              key={f.id}
              onClick={() => setFilter(f.id)}
              className={`px-3 py-2 text-xs font-medium relative ${filter === f.id ? 'text-[#6366F1]' : 'text-black/60 hover:text-black'}`}
            >
              {f.label}
              {filter === f.id && <div className="absolute bottom-0 left-0 right-0 h-0.5 bg-[#6366F1]" />}
            </button>
          ))}
        </div>

        {/* Notifications list */}
        <div className="flex-1 overflow-y-auto scrollbar-thin">
          {filtered.length === 0 ? (
            <div className="p-8 text-center text-black/40 text-sm">
              <Bell className="w-8 h-8 mx-auto mb-2 opacity-30" />
              Мэдэгдэл байхгүй
            </div>
          ) : filtered.map(n => {
            const tenant = getTenant(n.tenantId);
            const Icon = getIcon(n.type);
            return (
              <div key={n.id} className={`p-4 border-b border-black/5 hover:bg-black/[0.02] transition cursor-pointer ${n.unread ? 'bg-[#6366F1]/[0.02]' : ''}`}>
                <div className="flex items-start gap-3">
                  <div className="relative flex-shrink-0">
                    <div className="w-9 h-9 rounded-lg flex items-center justify-center text-white font-bold text-xs" style={{ background: tenant.color }}>
                      {tenant.logo}
                    </div>
                    <div className="absolute -bottom-1 -right-1 w-5 h-5 rounded-full bg-white border-2 border-white flex items-center justify-center">
                      <div className="w-full h-full rounded-full flex items-center justify-center" style={{ background: '#6366F1' }}>
                        <Icon className="w-2.5 h-2.5 text-white" />
                      </div>
                    </div>
                  </div>
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-1.5 mb-0.5">
                      <span className="font-semibold text-xs">{n.from}</span>
                      {tenant.verified && <BadgeCheck className="w-3 h-3 text-[#1877F2]" fill="#1877F2" stroke="#fff" />}
                      <span className="text-[10px] text-black/40">·</span>
                      <span className="text-[10px] text-black/40 font-mono">{tenant.subdomain}</span>
                    </div>
                    <div className="text-xs text-black/80 leading-relaxed">{n.message}</div>
                    <div className="flex items-center gap-2 mt-1.5">
                      <span className="text-[10px] text-black/40">{n.time}</span>
                      {n.unread && (
                        <button
                          onClick={(e) => { e.stopPropagation(); setCurrentTenant(tenant); onClose(); }}
                          className="text-[10px] text-[#6366F1] font-medium hover:underline"
                        >
                          {tenant.name} руу шилжих →
                        </button>
                      )}
                    </div>
                  </div>
                  {n.unread && <div className="w-2 h-2 rounded-full bg-[#6366F1] flex-shrink-0 mt-1.5" />}
                </div>
              </div>
            );
          })}
        </div>

        {/* Footer */}
        <div className="px-4 py-2.5 border-t border-black/5 flex items-center justify-between text-xs">
          <button className="text-black/60 hover:text-black flex items-center gap-1.5">
            <CheckCircle2 className="w-3.5 h-3.5" /> Бүгдийг уншсанаар тэмдэглэх
          </button>
          <button className="text-black/60 hover:text-black">
            <Settings className="w-3.5 h-3.5" />
          </button>
        </div>
      </div>
    </>
  );
}
