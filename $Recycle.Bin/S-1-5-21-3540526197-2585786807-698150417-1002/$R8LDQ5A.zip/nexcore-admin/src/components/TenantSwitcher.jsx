import { useState } from 'react';
import { useTenant } from '../contexts/TenantContext.jsx';
import { ChevronDown, Check, Search, Globe, Building2, Plus, BadgeCheck } from 'lucide-react';

export default function TenantSwitcher({ compact = false }) {
  const { currentTenant, setCurrentTenant, tenants } = useTenant();
  const [open, setOpen] = useState(false);
  const [search, setSearch] = useState('');

  const filtered = tenants.filter(t =>
    t.name.toLowerCase().includes(search.toLowerCase()) ||
    t.subdomain.toLowerCase().includes(search.toLowerCase())
  );

  return (
    <div className="relative">
      <button
        onClick={() => setOpen(!open)}
        className={`flex items-center gap-2.5 ${compact ? 'px-2 py-1.5' : 'px-3 py-2'} rounded-lg hover:bg-black/5 transition`}
      >
        <div className={`${compact ? 'w-7 h-7' : 'w-8 h-8'} rounded-lg flex items-center justify-center text-white font-display font-bold text-sm flex-shrink-0`} style={{ background: currentTenant.color }}>
          {currentTenant.logo}
        </div>
        {!compact && (
          <div className="text-left">
            <div className="text-sm font-semibold leading-tight truncate max-w-[160px] flex items-center gap-1">
              {currentTenant.name}
              {currentTenant.verified && <BadgeCheck className="w-3.5 h-3.5 text-[#1877F2] flex-shrink-0" fill="#1877F2" stroke="#fff" />}
            </div>
            <div className="text-[10px] text-black/50 font-mono truncate max-w-[140px]">{currentTenant.subdomain}.nexcoreplatforms.mn</div>
          </div>
        )}
        <ChevronDown className={`w-3.5 h-3.5 text-black/50 transition ${open ? 'rotate-180' : ''}`} />
      </button>

      {open && (
        <>
          <div className="fixed inset-0 z-30" onClick={() => setOpen(false)} />
          <div className="absolute top-full left-0 mt-1 w-80 bg-white rounded-2xl shadow-2xl border border-black/5 z-40 overflow-hidden">
            <div className="p-3 border-b border-black/5">
              <div className="relative">
                <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-3.5 h-3.5 text-black/40" />
                <input
                  autoFocus
                  value={search}
                  onChange={(e) => setSearch(e.target.value)}
                  placeholder="Компани хайх..."
                  className="w-full pl-9 pr-3 py-2 bg-[#FAFAFC] border border-black/5 rounded-lg text-sm focus:outline-none focus:border-[#1877F2]/30"
                />
              </div>
            </div>

            <div className="max-h-80 overflow-y-auto py-1">
              <div className="px-3 py-1.5 text-[10px] uppercase tracking-wider text-black/40 font-semibold">
                Танай компаниуд ({filtered.length})
              </div>
              {filtered.map((t) => (
                <button
                  key={t.id}
                  onClick={() => { setCurrentTenant(t); setOpen(false); setSearch(''); }}
                  className={`w-full flex items-center gap-3 px-3 py-2 hover:bg-black/[0.02] transition ${currentTenant.id === t.id ? 'bg-[#1877F2]/5' : ''}`}
                >
                  <div className="w-9 h-9 rounded-lg flex items-center justify-center text-white font-display font-bold text-sm flex-shrink-0" style={{ background: t.color }}>
                    {t.logo}
                  </div>
                  <div className="flex-1 min-w-0 text-left">
                    <div className="text-sm font-medium truncate flex items-center gap-1.5">
                      {t.name}
                      {t.verified && <BadgeCheck className="w-3.5 h-3.5 text-[#1877F2] flex-shrink-0" fill="#1877F2" stroke="#fff" />}
                      {t.status === 'pending' && <span className="text-[9px] px-1.5 py-0.5 bg-[#F7B928]/10 text-[#B88500] rounded-full">Хүлээгдэж буй</span>}
                    </div>
                    <div className="text-[10px] text-black/50 font-mono truncate">{t.subdomain}.nexcoreplatforms.mn · {t.users.toLocaleString()} хэрэглэгч</div>
                  </div>
                  {currentTenant.id === t.id && <Check className="w-4 h-4 text-[#1877F2]" />}
                </button>
              ))}
            </div>

            <div className="p-2 border-t border-black/5">
              <button className="w-full flex items-center gap-2 px-3 py-2 rounded-lg hover:bg-black/5 text-sm text-[#1877F2] font-medium">
                <Plus className="w-3.5 h-3.5" />
                Шинэ компани нэмэх
              </button>
            </div>
          </div>
        </>
      )}
    </div>
  );
}
