import { useState } from 'react';
import { Link } from 'react-router-dom';
import { useTenant, TENANTS } from '../contexts/TenantContext.jsx';
import {
  LayoutDashboard, Building2, CreditCard, Activity, MessageSquare,
  Settings, Search, Bell, ChevronRight, MoreHorizontal, TrendingUp,
  TrendingDown, ArrowUpRight, Plus, Filter, Download, Globe,
  Server, Shield, Zap, Users, DollarSign, AlertTriangle,
  CheckCircle2, Clock, ArrowLeft, LogOut, ExternalLink,
  ChevronDown, Star, Eye, EyeOff, XCircle, Lock
} from 'lucide-react';
import {
  LineChart, Line, BarChart, Bar, AreaChart, Area, PieChart, Pie, Cell,
  XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer
} from 'recharts';

export default function SuperAdmin() {
  const [tab, setTab] = useState('overview');
  const [sidebarOpen, setSidebarOpen] = useState(false);
  const { setCurrentTenant } = useTenant();
  const [authed, setAuthed] = useState(() => sessionStorage.getItem('superadmin_auth') === 'ok');

  if (!authed) {
    return <SuperAdminLock onUnlock={() => { sessionStorage.setItem('superadmin_auth', 'ok'); setAuthed(true); }} />;
  }

  const tabs = [
    { id: 'overview', label: 'Тойм', icon: LayoutDashboard },
    { id: 'tenants', label: 'Компаниуд', icon: Building2 },
    { id: 'billing', label: 'Орлого & Билл', icon: CreditCard },
    { id: 'health', label: 'Систем эрүүл мэнд', icon: Activity },
    { id: 'support', label: 'Дэмжлэг', icon: MessageSquare },
    { id: 'settings', label: 'Тохиргоо', icon: Settings },
  ];

  return (
    <div className="min-h-screen bg-[#050816] text-white flex" style={{ fontFamily: "'Geist', system-ui, sans-serif" }}>
      <style>{`
        @import url('https://fonts.googleapis.com/css2?family=Bricolage+Grotesque:opsz,wght@12..96,500;12..96,600;12..96,700&family=Geist:wght@400;500;600;700&family=JetBrains+Mono:wght@400;500&display=swap');
        .font-display { font-family: 'Bricolage Grotesque', sans-serif; letter-spacing: -0.02em; }
        .font-mono { font-family: 'JetBrains Mono', monospace; }
        @keyframes fadeUp { from { opacity: 0; transform: translateY(8px) } to { opacity: 1; transform: translateY(0) } }
        .anim-fade { animation: fadeUp 0.4s ease-out; }
        .glow { box-shadow: 0 0 40px rgba(99, 102, 241, 0.15); }
      `}</style>

      {/* Sidebar */}
      <aside className={`fixed lg:sticky top-0 left-0 h-screen w-64 bg-[#0A0F1F] border-r border-white/5 z-40 flex flex-col transition-transform ${sidebarOpen ? 'translate-x-0' : '-translate-x-full lg:translate-x-0'}`}>
        <div className="px-6 py-5 border-b border-white/5">
          <Link to="/" className="flex items-center gap-2.5">
            <div className="w-9 h-9 rounded-xl bg-gradient-to-br from-[#6366F1] to-[#A855F7] flex items-center justify-center text-white font-display font-bold relative glow">
              <span>N</span>
            </div>
            <div>
              <div className="font-display font-bold text-sm tracking-tight">Nexcore</div>
              <div className="text-[10px] text-white/40 -mt-0.5 flex items-center gap-1">
                <Shield className="w-2.5 h-2.5" />
                Super Admin
              </div>
            </div>
          </Link>
        </div>

        <nav className="flex-1 px-3 py-5 space-y-1 overflow-y-auto">
          {tabs.map((t) => {
            const Icon = t.icon;
            const active = tab === t.id;
            return (
              <button
                key={t.id}
                onClick={() => { setTab(t.id); setSidebarOpen(false); }}
                className={`w-full flex items-center gap-3 px-3 py-2.5 rounded-lg text-sm transition ${active ? 'bg-gradient-to-r from-[#6366F1] to-[#A855F7] text-white' : 'text-white/60 hover:bg-white/5 hover:text-white'}`}
              >
                <Icon className="w-4 h-4" />
                <span className="font-medium">{t.label}</span>
                {active && <ChevronRight className="w-3 h-3 ml-auto" />}
              </button>
            );
          })}
        </nav>

        <div className="p-3 border-t border-white/5">
          <a href="https://nexcoreplatforms.mn" className="flex items-center gap-3 px-3 py-2.5 rounded-lg text-sm text-white/60 hover:bg-white/5 transition">
            <ArrowLeft className="w-4 h-4" />
            <span>Нүүр хуудас</span>
          </a>
          <div className="mt-2 p-3 bg-white/5 rounded-xl flex items-center gap-3">
            <div className="w-9 h-9 rounded-full bg-gradient-to-br from-[#6366F1] to-[#A855F7] flex-shrink-0 flex items-center justify-center text-xs font-bold">НМ</div>
            <div className="flex-1 min-w-0">
              <div className="text-sm font-medium truncate">Н. Мягмардорж</div>
              <div className="text-xs text-white/50 truncate flex items-center gap-1">
                <Shield className="w-2.5 h-2.5" />
                Гол Админ
              </div>
            </div>
            <button
              onClick={() => {
                sessionStorage.removeItem('superadmin_auth');
                setAuthed(false);
              }}
              className="w-7 h-7 rounded-lg hover:bg-[#EF4444]/20 hover:text-[#EF4444] flex items-center justify-center transition"
              title="Гарах"
            >
              <LogOut className="w-4 h-4 text-white/40" />
            </button>
          </div>
        </div>
      </aside>

      {sidebarOpen && <div className="fixed inset-0 bg-black/70 z-30 lg:hidden" onClick={() => setSidebarOpen(false)} />}

      {/* Main */}
      <main className="flex-1 min-w-0">
        <header className="sticky top-0 bg-[#050816]/80 backdrop-blur border-b border-white/5 z-20 px-6 py-3 flex items-center gap-4">
          <button onClick={() => setSidebarOpen(true)} className="lg:hidden">
            <LayoutDashboard className="w-5 h-5" />
          </button>
          <div className="flex-1 max-w-md relative">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-white/40" />
            <input
              type="text"
              placeholder="Бүх компани, ажилтан, өгөгдөл хайх..."
              className="w-full pl-10 pr-4 py-2 bg-white/5 border border-white/10 rounded-lg text-sm text-white placeholder:text-white/40 focus:outline-none focus:border-[#6366F1]/50"
            />
          </div>
          <div className="flex items-center gap-2">
            <div className="hidden md:flex items-center gap-1.5 px-2.5 py-1 rounded-full bg-[#10B981]/10 text-[#10B981] text-[10px] font-bold">
              <div className="w-1.5 h-1.5 rounded-full bg-[#10B981] animate-pulse" />
              Бүх систем хэвийн
            </div>
            <button className="w-9 h-9 rounded-full hover:bg-white/5 flex items-center justify-center relative">
              <Bell className="w-4 h-4" />
              <div className="absolute top-1.5 right-1.5 w-2 h-2 rounded-full bg-[#EF4444]" />
            </button>
            <button
              onClick={() => {
                sessionStorage.removeItem('superadmin_auth');
                setAuthed(false);
              }}
              className="w-9 h-9 rounded-full hover:bg-[#EF4444]/20 hover:text-[#FCA5A5] flex items-center justify-center transition"
              title="Гарах"
            >
              <LogOut className="w-4 h-4" />
            </button>
          </div>
        </header>

        <div className="p-6 lg:p-8 anim-fade" key={tab}>
          {tab === 'overview' && <OverviewTab />}
          {tab === 'tenants' && <TenantsTab onLoginAs={setCurrentTenant} />}
          {tab === 'billing' && <BillingTab />}
          {tab === 'health' && <HealthTab />}
          {tab === 'support' && <SupportTab />}
          {tab === 'settings' && <SettingsTab />}
        </div>
      </main>
    </div>
  );
}

/* ============== OVERVIEW ============== */
function OverviewTab() {
  const totalUsers = TENANTS.reduce((s, t) => s + t.users, 0);
  const totalRevenue = TENANTS.reduce((s, t) => s + t.revenue, 0);
  const activeTenants = TENANTS.filter(t => t.status === 'active').length;

  const stats = [
    { label: 'Нийт компани', value: TENANTS.length, change: '+2', up: true, icon: Building2, color: '#6366F1' },
    { label: 'Идэвхтэй компани', value: activeTenants, change: `${Math.round(activeTenants/TENANTS.length*100)}%`, up: true, icon: CheckCircle2, color: '#10B981' },
    { label: 'Нийт хэрэглэгч', value: totalUsers.toLocaleString(), change: '+12.4%', up: true, icon: Users, color: '#A855F7' },
    { label: 'MRR (Сарын орлого)', value: `$${(totalRevenue/1000).toFixed(0)}K`, change: '+18.7%', up: true, icon: DollarSign, color: '#F59E0B' },
  ];

  const revenueData = [
    { month: '10-р сар', value: 120000 },
    { month: '11-р сар', value: 142000 },
    { month: '12-р сар', value: 158000 },
    { month: '1-р сар', value: 178000 },
    { month: '2-р сар', value: 192000 },
    { month: '3-р сар', value: 198000 },
    { month: '4-р сар', value: totalRevenue },
  ];

  const planData = [
    { name: 'Core', value: TENANTS.filter(t => t.plan === 'Core').length, color: '#94A3B8' },
    { name: 'Premium', value: TENANTS.filter(t => t.plan === 'Premium').length, color: '#6366F1' },
    { name: 'Enterprise', value: TENANTS.filter(t => t.plan === 'Enterprise').length, color: '#A855F7' },
  ];

  return (
    <div className="space-y-6 max-w-7xl">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="font-display text-3xl font-bold tracking-tight">Тойм самбар</h1>
          <p className="text-sm text-white/50 mt-1">Nexcore Platforms-ын дэлхий даяар</p>
        </div>
        <div className="flex items-center gap-2">
          <button className="px-4 py-2 text-sm bg-white/5 border border-white/10 rounded-full hover:bg-white/10 transition flex items-center gap-2">
            <Download className="w-3.5 h-3.5" /> Тайлан
          </button>
          <button className="px-4 py-2 text-sm bg-gradient-to-r from-[#6366F1] to-[#A855F7] rounded-full font-medium flex items-center gap-2 hover:scale-[1.02] transition">
            <Plus className="w-3.5 h-3.5" /> Шинэ компани
          </button>
        </div>
      </div>

      {/* Stat cards */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        {stats.map((s, i) => {
          const Icon = s.icon;
          return (
            <div key={i} className="bg-white/[0.03] border border-white/5 rounded-2xl p-5 hover:bg-white/[0.06] transition">
              <div className="flex items-start justify-between mb-3">
                <div className="w-10 h-10 rounded-xl flex items-center justify-center" style={{ background: `${s.color}20`, color: s.color }}>
                  <Icon className="w-4 h-4" />
                </div>
                <div className="flex items-center gap-1 text-xs font-medium text-[#10B981]">
                  <TrendingUp className="w-3 h-3" /> {s.change}
                </div>
              </div>
              <div className="font-display text-3xl font-bold tracking-tight">{s.value}</div>
              <div className="text-xs text-white/50 mt-1">{s.label}</div>
            </div>
          );
        })}
      </div>

      {/* Charts */}
      <div className="grid lg:grid-cols-3 gap-4">
        <div className="lg:col-span-2 bg-white/[0.03] border border-white/5 rounded-2xl p-5">
          <div className="flex items-center justify-between mb-4">
            <div>
              <h3 className="font-display text-lg font-semibold">Орлогын өсөлт</h3>
              <p className="text-xs text-white/50">7 сарын MRR (Monthly Recurring Revenue)</p>
            </div>
          </div>
          <ResponsiveContainer width="100%" height={250}>
            <AreaChart data={revenueData} margin={{ left: -10 }}>
              <defs>
                <linearGradient id="rev-grad" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="0%" stopColor="#6366F1" stopOpacity={0.5} />
                  <stop offset="100%" stopColor="#6366F1" stopOpacity={0} />
                </linearGradient>
              </defs>
              <CartesianGrid strokeDasharray="3 3" stroke="#ffffff10" />
              <XAxis dataKey="month" stroke="#ffffff60" fontSize={10} />
              <YAxis stroke="#ffffff60" fontSize={10} tickFormatter={(v) => `$${v/1000}K`} />
              <Tooltip contentStyle={{ background: '#0A0F1F', border: '1px solid #ffffff20', borderRadius: 12, fontSize: 12 }} />
              <Area type="monotone" dataKey="value" stroke="#6366F1" strokeWidth={2.5} fill="url(#rev-grad)" />
            </AreaChart>
          </ResponsiveContainer>
        </div>

        <div className="bg-white/[0.03] border border-white/5 rounded-2xl p-5">
          <h3 className="font-display text-lg font-semibold mb-1">Багцын тархалт</h3>
          <p className="text-xs text-white/50 mb-4">Идэвхтэй subscription</p>
          <ResponsiveContainer width="100%" height={170}>
            <PieChart>
              <Pie data={planData} dataKey="value" innerRadius={45} outerRadius={75} paddingAngle={3}>
                {planData.map((d, i) => <Cell key={i} fill={d.color} />)}
              </Pie>
              <Tooltip contentStyle={{ background: '#0A0F1F', border: '1px solid #ffffff20', borderRadius: 12, fontSize: 12 }} />
            </PieChart>
          </ResponsiveContainer>
          <div className="space-y-2 mt-3">
            {planData.map((p, i) => (
              <div key={i} className="flex items-center justify-between text-xs">
                <div className="flex items-center gap-2">
                  <div className="w-2 h-2 rounded-full" style={{ background: p.color }} />
                  <span>{p.name}</span>
                </div>
                <span className="font-medium">{p.value} компани</span>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Top tenants */}
      <div className="bg-white/[0.03] border border-white/5 rounded-2xl overflow-hidden">
        <div className="p-5 flex items-center justify-between border-b border-white/5">
          <h3 className="font-display text-lg font-semibold">Шилдэг компаниуд</h3>
          <button className="text-xs text-[#6366F1] hover:underline">Бүгдийг үзэх →</button>
        </div>
        <div className="divide-y divide-white/5">
          {[...TENANTS].sort((a,b) => b.revenue - a.revenue).slice(0, 5).map((t, i) => (
            <div key={t.id} className="p-4 flex items-center gap-4 hover:bg-white/[0.02]">
              <div className="text-xs text-white/40 font-mono w-4">{i+1}</div>
              <div className="w-10 h-10 rounded-lg flex items-center justify-center text-white font-bold flex-shrink-0" style={{ background: t.color }}>{t.logo}</div>
              <div className="flex-1 min-w-0">
                <div className="font-medium truncate">{t.name}</div>
                <div className="text-xs text-white/50 font-mono truncate">{t.subdomain}.nexcoreplatforms.mn</div>
              </div>
              <div className="text-right">
                <div className="font-display font-bold">${t.revenue.toLocaleString()}</div>
                <div className="text-xs text-white/50">{t.users.toLocaleString()} хэрэглэгч</div>
              </div>
              <span className={`text-[10px] px-2 py-0.5 rounded-full font-semibold ${t.plan === 'Enterprise' ? 'bg-[#A855F7]/20 text-[#C084FC]' : t.plan === 'Premium' ? 'bg-[#6366F1]/20 text-[#A5B4FC]' : 'bg-white/10 text-white/60'}`}>
                {t.plan}
              </span>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}

/* ============== TENANTS ============== */
function TenantsTab({ onLoginAs }) {
  const [filter, setFilter] = useState('all');
  const filtered = TENANTS.filter(t => filter === 'all' || t.status === filter);

  return (
    <div className="space-y-6 max-w-7xl">
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3">
        <div>
          <h1 className="font-display text-3xl font-bold tracking-tight">Бүх компани</h1>
          <p className="text-sm text-white/50 mt-1">{TENANTS.length} компани · {TENANTS.filter(t=>t.status==='active').length} идэвхтэй</p>
        </div>
        <div className="flex items-center gap-2">
          <div className="flex bg-white/5 rounded-full p-0.5">
            {[
              { id: 'all', label: 'Бүгд' },
              { id: 'active', label: 'Идэвхтэй' },
              { id: 'pending', label: 'Хүлээгдэж буй' },
            ].map(f => (
              <button
                key={f.id}
                onClick={() => setFilter(f.id)}
                className={`px-3 py-1.5 text-xs rounded-full transition ${filter === f.id ? 'bg-white text-black font-semibold' : 'text-white/60'}`}
              >
                {f.label}
              </button>
            ))}
          </div>
          <button className="px-4 py-2 text-sm bg-gradient-to-r from-[#6366F1] to-[#A855F7] rounded-full font-medium flex items-center gap-2">
            <Plus className="w-3.5 h-3.5" /> Шинэ компани
          </button>
        </div>
      </div>

      <div className="bg-white/[0.03] border border-white/5 rounded-2xl overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead className="bg-white/[0.02] text-white/50 text-xs uppercase tracking-wider">
              <tr>
                <th className="px-5 py-3 text-left font-medium">Компани</th>
                <th className="px-5 py-3 text-left font-medium">Subdomain</th>
                <th className="px-5 py-3 text-left font-medium">Багц</th>
                <th className="px-5 py-3 text-left font-medium">Хэрэглэгч</th>
                <th className="px-5 py-3 text-left font-medium">MRR</th>
                <th className="px-5 py-3 text-left font-medium">Төлөв</th>
                <th className="px-5 py-3 text-right font-medium">Үйлдэл</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-white/5">
              {filtered.map((t) => (
                <tr key={t.id} className="hover:bg-white/[0.02] transition">
                  <td className="px-5 py-3">
                    <div className="flex items-center gap-3">
                      <div className="w-9 h-9 rounded-lg flex items-center justify-center text-white font-bold flex-shrink-0" style={{ background: t.color }}>{t.logo}</div>
                      <div>
                        <div className="font-medium">{t.name}</div>
                        <div className="text-xs text-white/50">{t.country} · {t.joined}</div>
                      </div>
                    </div>
                  </td>
                  <td className="px-5 py-3 font-mono text-xs text-white/60">{t.subdomain}.nexcoreplatforms.mn</td>
                  <td className="px-5 py-3">
                    <span className={`text-[10px] px-2 py-1 rounded-full font-semibold ${t.plan === 'Enterprise' ? 'bg-[#A855F7]/20 text-[#C084FC]' : t.plan === 'Premium' ? 'bg-[#6366F1]/20 text-[#A5B4FC]' : 'bg-white/10 text-white/60'}`}>
                      {t.plan}
                    </span>
                  </td>
                  <td className="px-5 py-3 text-white/80">{t.users.toLocaleString()}</td>
                  <td className="px-5 py-3 font-display font-bold">${t.revenue.toLocaleString()}</td>
                  <td className="px-5 py-3">
                    <div className="flex items-center gap-2">
                      <div className={`w-2 h-2 rounded-full ${t.status === 'active' ? 'bg-[#10B981]' : 'bg-[#F59E0B]'}`} />
                      <span className="text-xs">{t.status === 'active' ? 'Идэвхтэй' : 'Хүлээгдэж буй'}</span>
                    </div>
                  </td>
                  <td className="px-5 py-3 text-right">
                    <div className="flex items-center justify-end gap-1">
                      <Link to="/admin" onClick={() => onLoginAs(t)} className="px-2.5 py-1 text-xs bg-[#6366F1]/20 text-[#A5B4FC] rounded hover:bg-[#6366F1]/30 transition flex items-center gap-1">
                        <ExternalLink className="w-3 h-3" /> Нэвтрэх
                      </Link>
                      <button className="w-7 h-7 rounded hover:bg-white/5 flex items-center justify-center"><MoreHorizontal className="w-3.5 h-3.5" /></button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}

/* ============== BILLING ============== */
function BillingTab() {
  const totalRevenue = TENANTS.reduce((s, t) => s + t.revenue, 0);
  const arrData = [
    { month: '1-р сар', mrr: 142000, arr: 1704000 },
    { month: '2-р сар', mrr: 158000, arr: 1896000 },
    { month: '3-р сар', mrr: 178000, arr: 2136000 },
    { month: '4-р сар', mrr: totalRevenue, arr: totalRevenue * 12 },
  ];

  return (
    <div className="space-y-6 max-w-7xl">
      <div>
        <h1 className="font-display text-3xl font-bold tracking-tight">Орлого & Билл</h1>
        <p className="text-sm text-white/50 mt-1">Санхүүгийн нэгдсэн харагдац</p>
      </div>

      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        {[
          { label: 'MRR', value: `$${(totalRevenue/1000).toFixed(0)}K`, sub: 'Сарын орлого', color: '#6366F1' },
          { label: 'ARR', value: `$${(totalRevenue*12/1000000).toFixed(2)}M`, sub: 'Жилийн орлого', color: '#A855F7' },
          { label: 'ARPU', value: `$${(totalRevenue/TENANTS.reduce((s,t)=>s+t.users,0)).toFixed(2)}`, sub: 'Хэрэглэгч/сар', color: '#F59E0B' },
          { label: 'Churn', value: '2.3%', sub: 'Сарын алдагдал', color: '#EF4444' },
        ].map((s, i) => (
          <div key={i} className="bg-white/[0.03] border border-white/5 rounded-2xl p-5">
            <div className="text-xs uppercase tracking-wider text-white/50 mb-2">{s.label}</div>
            <div className="font-display text-3xl font-bold tracking-tight" style={{ color: s.color }}>{s.value}</div>
            <div className="text-xs text-white/50 mt-1">{s.sub}</div>
          </div>
        ))}
      </div>

      <div className="bg-white/[0.03] border border-white/5 rounded-2xl p-5">
        <h3 className="font-display text-lg font-semibold mb-1">MRR vs ARR</h3>
        <p className="text-xs text-white/50 mb-5">Сүүлийн 4 сар</p>
        <ResponsiveContainer width="100%" height={300}>
          <BarChart data={arrData} margin={{ left: -10 }}>
            <CartesianGrid strokeDasharray="3 3" stroke="#ffffff10" />
            <XAxis dataKey="month" stroke="#ffffff60" fontSize={11} />
            <YAxis stroke="#ffffff60" fontSize={11} tickFormatter={(v) => `$${v/1000}K`} />
            <Tooltip contentStyle={{ background: '#0A0F1F', border: '1px solid #ffffff20', borderRadius: 12, fontSize: 12 }} />
            <Bar dataKey="mrr" fill="#6366F1" radius={[8, 8, 0, 0]} />
            <Bar dataKey="arr" fill="#A855F7" radius={[8, 8, 0, 0]} />
          </BarChart>
        </ResponsiveContainer>
      </div>

      <div className="bg-white/[0.03] border border-white/5 rounded-2xl overflow-hidden">
        <div className="p-5 border-b border-white/5">
          <h3 className="font-display text-lg font-semibold">Сүүлийн билл</h3>
        </div>
        <div className="divide-y divide-white/5">
          {TENANTS.slice(0, 5).map((t) => (
            <div key={t.id} className="p-4 flex items-center gap-4 hover:bg-white/[0.02]">
              <div className="w-9 h-9 rounded-lg flex items-center justify-center text-white font-bold flex-shrink-0" style={{ background: t.color }}>{t.logo}</div>
              <div className="flex-1 min-w-0">
                <div className="font-medium">{t.name}</div>
                <div className="text-xs text-white/50">{t.plan} · {t.users.toLocaleString()} хэрэглэгч</div>
              </div>
              <div className="text-right">
                <div className="font-display font-bold">${t.revenue.toLocaleString()}</div>
                <div className="text-xs text-[#10B981]">Төлөгдсөн</div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}

/* ============== HEALTH ============== */
function HealthTab() {
  const services = [
    { name: 'API Gateway', status: 'operational', uptime: '99.99%', latency: '23ms' },
    { name: 'Authentication', status: 'operational', uptime: '99.98%', latency: '45ms' },
    { name: 'Database', status: 'operational', uptime: '99.99%', latency: '12ms' },
    { name: 'File Storage', status: 'degraded', uptime: '99.87%', latency: '89ms' },
    { name: 'Email Service', status: 'operational', uptime: '99.95%', latency: '156ms' },
    { name: 'Video/Meet', status: 'operational', uptime: '99.92%', latency: '34ms' },
  ];

  return (
    <div className="space-y-6 max-w-7xl">
      <div>
        <h1 className="font-display text-3xl font-bold tracking-tight">Систем эрүүл мэнд</h1>
        <p className="text-sm text-white/50 mt-1">Real-time үйлчилгээний төлөв</p>
      </div>

      <div className="bg-gradient-to-br from-[#10B981]/20 to-transparent border border-[#10B981]/30 rounded-2xl p-6 flex items-center gap-5">
        <div className="w-16 h-16 rounded-2xl bg-[#10B981]/20 flex items-center justify-center">
          <CheckCircle2 className="w-7 h-7 text-[#10B981]" />
        </div>
        <div className="flex-1">
          <div className="font-display text-2xl font-bold">Бүх систем хэвийн ажиллаж байна</div>
          <div className="text-sm text-white/60 mt-1">Сүүлд шалгасан: 23 секундын өмнө</div>
        </div>
        <div className="text-right">
          <div className="font-display text-3xl font-bold text-[#10B981]">99.97%</div>
          <div className="text-xs text-white/50">Сүүлийн 30 хоног</div>
        </div>
      </div>

      <div className="grid lg:grid-cols-2 gap-4">
        {services.map((s, i) => (
          <div key={i} className="bg-white/[0.03] border border-white/5 rounded-2xl p-5">
            <div className="flex items-start justify-between mb-3">
              <div>
                <div className="font-semibold">{s.name}</div>
                <div className="text-xs text-white/50 mt-0.5">Uptime сүүлийн 30 хоног</div>
              </div>
              <div className="flex items-center gap-1.5 px-2 py-1 rounded-full text-[10px] font-bold uppercase" style={{
                background: s.status === 'operational' ? '#10B98120' : s.status === 'degraded' ? '#F59E0B20' : '#EF444420',
                color: s.status === 'operational' ? '#10B981' : s.status === 'degraded' ? '#F59E0B' : '#EF4444'
              }}>
                <div className="w-1.5 h-1.5 rounded-full bg-current" />
                {s.status === 'operational' ? 'Хэвийн' : s.status === 'degraded' ? 'Удаашрал' : 'Алдаа'}
              </div>
            </div>
            <div className="grid grid-cols-2 gap-3 mt-4">
              <div>
                <div className="text-xs text-white/50">Uptime</div>
                <div className="font-display font-bold text-lg">{s.uptime}</div>
              </div>
              <div>
                <div className="text-xs text-white/50">Latency</div>
                <div className="font-display font-bold text-lg">{s.latency}</div>
              </div>
            </div>
            <div className="mt-3 flex gap-0.5 h-6">
              {[...Array(60)].map((_, j) => (
                <div key={j} className={`flex-1 rounded-sm ${j === 47 && s.status === 'degraded' ? 'bg-[#F59E0B]' : 'bg-[#10B981]/60'}`} />
              ))}
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}

/* ============== SUPPORT ============== */
function SupportTab() {
  const tickets = [
    { id: '#4821', tenant: 'Walmart Inc.', subject: 'SSO тохиргоонд алдаа', priority: 'high', status: 'open', time: '12 мин өмнө', tColor: '#0071CE' },
    { id: '#4820', tenant: 'Хаан Банк', subject: 'Mobile app crash', priority: 'high', status: 'open', time: '34 мин өмнө', tColor: '#003876' },
    { id: '#4819', tenant: 'MCS Group', subject: 'API rate limit нэмүүлэх хүсэлт', priority: 'medium', status: 'in_progress', time: '2 цаг өмнө', tColor: '#0066CC' },
    { id: '#4818', tenant: 'APU ХК', subject: 'Билл буруу гарсан', priority: 'medium', status: 'in_progress', time: '5 цаг өмнө', tColor: '#0066B3' },
    { id: '#4817', tenant: 'Gobi Cashmere', subject: 'Шинэ хэрэглэгч нэмэгдэхгүй байна', priority: 'low', status: 'resolved', time: 'Өчигдөр', tColor: '#8B4513' },
  ];

  return (
    <div className="space-y-6 max-w-7xl">
      <div>
        <h1 className="font-display text-3xl font-bold tracking-tight">Дэмжлэгийн тасалбар</h1>
        <p className="text-sm text-white/50 mt-1">Бүх компаниас ирсэн дэмжлэгийн хүсэлт</p>
      </div>

      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        {[
          { label: 'Нээлттэй', value: '23', color: '#EF4444' },
          { label: 'Боловсруулж буй', value: '12', color: '#F59E0B' },
          { label: 'Шийдэгдсэн (өнөөдөр)', value: '47', color: '#10B981' },
          { label: 'Дундаж SLA', value: '2.3ц', color: '#6366F1' },
        ].map((s, i) => (
          <div key={i} className="bg-white/[0.03] border border-white/5 rounded-2xl p-5">
            <div className="font-display text-3xl font-bold tracking-tight" style={{ color: s.color }}>{s.value}</div>
            <div className="text-xs text-white/50 mt-1">{s.label}</div>
          </div>
        ))}
      </div>

      <div className="bg-white/[0.03] border border-white/5 rounded-2xl overflow-hidden">
        <div className="p-5 border-b border-white/5 flex items-center justify-between">
          <h3 className="font-display text-lg font-semibold">Сүүлийн тасалбар</h3>
          <button className="text-xs text-[#6366F1] font-medium">Бүгдийг үзэх →</button>
        </div>
        <div className="divide-y divide-white/5">
          {tickets.map((t) => (
            <div key={t.id} className="p-4 flex items-center gap-4 hover:bg-white/[0.02]">
              <div className={`w-1 h-12 rounded-full flex-shrink-0`} style={{ background: t.priority === 'high' ? '#EF4444' : t.priority === 'medium' ? '#F59E0B' : '#94A3B8' }} />
              <div className="font-mono text-xs text-white/40 w-16">{t.id}</div>
              <div className="w-7 h-7 rounded flex items-center justify-center text-white text-[10px] font-bold flex-shrink-0" style={{ background: t.tColor }}>{t.tenant[0]}</div>
              <div className="flex-1 min-w-0">
                <div className="font-medium text-sm truncate">{t.subject}</div>
                <div className="text-xs text-white/50">{t.tenant} · {t.time}</div>
              </div>
              <span className={`text-[10px] px-2 py-1 rounded-full font-semibold ${
                t.status === 'open' ? 'bg-[#EF4444]/20 text-[#FCA5A5]' :
                t.status === 'in_progress' ? 'bg-[#F59E0B]/20 text-[#FCD34D]' :
                'bg-[#10B981]/20 text-[#6EE7B7]'
              }`}>
                {t.status === 'open' ? 'Нээлттэй' : t.status === 'in_progress' ? 'Боловсруулж буй' : 'Шийдсэн'}
              </span>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}

/* ============== SETTINGS ============== */
function SettingsTab() {
  return (
    <div className="space-y-6 max-w-3xl">
      <div>
        <h1 className="font-display text-3xl font-bold tracking-tight">Платформын тохиргоо</h1>
        <p className="text-sm text-white/50 mt-1">Nexcore-ийн ерөнхий тохиргоо</p>
      </div>

      <div className="bg-white/[0.03] border border-white/5 rounded-2xl p-6">
        <h3 className="font-display text-lg font-semibold mb-1">Платформын мэдээлэл</h3>
        <p className="text-xs text-white/50 mb-5">Nexcore Platforms-ын танилцуулга</p>
        <div className="space-y-4">
          <div>
            <label className="text-xs font-medium text-white/60 block mb-1.5">Үндсэн домэйн</label>
            <input defaultValue="nexcoreplatforms.mn" className="w-full px-4 py-2.5 bg-white/5 border border-white/10 rounded-lg text-sm text-white focus:outline-none focus:border-[#6366F1]/50" />
          </div>
          <div>
            <label className="text-xs font-medium text-white/60 block mb-1.5">Дэмжлэгийн имэйл</label>
            <input defaultValue="support@nexcoreplatforms.mn" className="w-full px-4 py-2.5 bg-white/5 border border-white/10 rounded-lg text-sm text-white focus:outline-none focus:border-[#6366F1]/50" />
          </div>
          <div>
            <label className="text-xs font-medium text-white/60 block mb-1.5">Үндсэн валют</label>
            <select className="w-full px-4 py-2.5 bg-white/5 border border-white/10 rounded-lg text-sm text-white focus:outline-none focus:border-[#6366F1]/50">
              <option>USD</option>
              <option>MNT</option>
              <option>EUR</option>
            </select>
          </div>
        </div>
      </div>

      <div className="bg-white/[0.03] border border-white/5 rounded-2xl p-6">
        <h3 className="font-display text-lg font-semibold mb-1">Үнэ багц</h3>
        <p className="text-xs text-white/50 mb-5">Бүх компанид нэгдсэн үнэ</p>
        <div className="space-y-3">
          {[
            { plan: 'Starter', price: 'Үнэгүй', features: '5 хэрэглэгч хүртэл, үндсэн апп' },
            { plan: 'Core', price: '9,900₮', features: '5 апп, 100GB' },
            { plan: 'Premium', price: '28,800₮', features: 'Бүх апп, 1TB, SSO' },
            { plan: 'Enterprise', price: 'Тусгай', features: 'SLA, dedicated CSM' },
          ].map((p, i) => (
            <div key={i} className="flex items-center justify-between p-4 bg-white/5 rounded-xl">
              <div>
                <div className="font-semibold">{p.plan}</div>
                <div className="text-xs text-white/50">{p.features}</div>
              </div>
              <div className="font-display text-xl font-bold">{p.price}<span className="text-xs text-white/40">{p.price !== 'Тусгай' && p.price !== 'Үнэгүй' ? '/хэрэглэгч/сар' : ''}</span></div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}

/* ============== SUPER ADMIN LOCK ============== */
function SuperAdminLock({ onUnlock }) {
  const [password, setPassword] = useState('');
  const [showPw, setShowPw] = useState(false);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  const [attempts, setAttempts] = useState(0);

  const SUPER_PASSWORD = 'Md98HcogxPCVrG';

  function handleSubmit(e) {
    e.preventDefault();
    setError('');
    setLoading(true);
    setTimeout(() => {
      if (password === SUPER_PASSWORD) {
        onUnlock();
      } else {
        setError('Нууц үг буруу байна');
        setAttempts(a => a + 1);
        setPassword('');
      }
      setLoading(false);
    }, 700);
  }

  return (
    <div className="min-h-screen bg-[#050816] text-white flex items-center justify-center p-6 relative overflow-hidden" style={{ fontFamily: "'Geist', system-ui, sans-serif" }}>
      <style>{`
        @import url('https://fonts.googleapis.com/css2?family=Bricolage+Grotesque:opsz,wght@12..96,500;12..96,600;12..96,700&family=Geist:wght@400;500;600;700&family=JetBrains+Mono:wght@400;500&display=swap');
        .font-display { font-family: 'Bricolage Grotesque', sans-serif; letter-spacing: -0.02em; }
        .font-mono { font-family: 'JetBrains Mono', monospace; }
        @keyframes shake {
          0%, 100% { transform: translateX(0) }
          25% { transform: translateX(-8px) }
          75% { transform: translateX(8px) }
        }
        .anim-shake { animation: shake 0.4s ease-out; }
      `}</style>

      {/* Background glow */}
      <div className="absolute top-0 left-1/2 -translate-x-1/2 w-[600px] h-[600px] rounded-full bg-gradient-to-br from-[#6366F1]/20 to-[#A855F7]/20 blur-3xl" />

      <div className="w-full max-w-md relative z-10">
        {/* Logo */}
        <Link to="/" className="flex items-center gap-2.5 justify-center mb-8">
          <div className="w-11 h-11 rounded-xl bg-gradient-to-br from-[#6366F1] to-[#A855F7] flex items-center justify-center font-display font-bold text-lg">N</div>
          <div>
            <div className="font-display font-bold">Nexcore Platforms</div>
            <div className="text-[10px] text-white/50 font-mono flex items-center gap-1">
              <Shield className="w-2.5 h-2.5" /> Super Admin
            </div>
          </div>
        </Link>

        <div className={`bg-white/[0.04] backdrop-blur border border-white/10 rounded-3xl p-8 ${error ? 'anim-shake' : ''}`} key={attempts}>
          <div className="flex justify-center mb-5">
            <div className="w-16 h-16 rounded-2xl bg-gradient-to-br from-[#6366F1] to-[#A855F7] flex items-center justify-center" style={{ boxShadow: '0 0 40px rgba(99, 102, 241, 0.5)' }}>
              <Lock className="w-7 h-7 text-white" />
            </div>
          </div>

          <h1 className="font-display text-2xl font-bold text-center mb-2">Хязгаарлагдмал хэсэг</h1>
          <p className="text-sm text-white/60 text-center mb-7">
            Зөвхөн Nexcore багт зориулагдсан
          </p>

          <form onSubmit={handleSubmit} className="space-y-4">
            <div>
              <label className="text-xs font-medium text-white/60 block mb-2">Master нууц үг</label>
              <div className="relative">
                <Lock className="absolute left-4 top-1/2 -translate-y-1/2 w-4 h-4 text-white/40" />
                <input
                  type={showPw ? 'text' : 'password'}
                  value={password}
                  onChange={(e) => { setPassword(e.target.value); setError(''); }}
                  placeholder="••••••••"
                  autoFocus
                  className={`w-full pl-11 pr-11 py-3.5 bg-white/5 border rounded-xl text-sm text-white placeholder:text-white/40 focus:outline-none focus:ring-4 transition ${error ? 'border-[#EF4444] focus:border-[#EF4444] focus:ring-[#EF4444]/10' : 'border-white/10 focus:border-[#6366F1] focus:ring-[#6366F1]/10'}`}
                />
                <button type="button" onClick={() => setShowPw(!showPw)} className="absolute right-4 top-1/2 -translate-y-1/2 text-white/40 hover:text-white">
                  {showPw ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                </button>
              </div>
              {error && (
                <div className="mt-2 flex items-center gap-1.5 text-xs text-[#FCA5A5]">
                  <XCircle className="w-3.5 h-3.5" />
                  {error} {attempts >= 3 && '· Олон удаа буруу оруулсан'}
                </div>
              )}
            </div>

            <button
              type="submit"
              disabled={!password || loading}
              className="w-full bg-gradient-to-r from-[#6366F1] to-[#A855F7] text-white py-3.5 rounded-xl font-semibold flex items-center justify-center gap-2 disabled:opacity-50 hover:scale-[1.01] transition"
            >
              {loading ? (
                <div className="w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin" />
              ) : (
                <>Нэвтрэх <ArrowLeft className="w-4 h-4 rotate-180" /></>
              )}
            </button>
          </form>
        </div>

        <div className="mt-5 text-center">
          <a href="https://nexcoreplatforms.mn" className="text-xs text-white/50 hover:text-white inline-flex items-center gap-1">
            <ArrowLeft className="w-3 h-3" /> Нүүр хуудас руу буцах
          </a>
        </div>

        <div className="mt-6 text-center text-[10px] text-white/30">
          🔒 Production систем дээр SSO + 2FA + IP whitelist шаардагдана
        </div>
      </div>
    </div>
  );
}
