// ═══════════════════════════════════════════════════════
// НОМИН Admin Panels — sbFetch callback pattern ашиглана
// sbFetch(method, path, body, cb) — Promise биш!
// jobs.active → jobs.status засагдсан
// ═══════════════════════════════════════════════════════

// ── Dashboard KPI ─────────────────────────────────────
function loadDashboard() {
  var counts = [
    {table:'news',      q:'status=eq.published&select=id', el:'kNews'},
    {table:'jobs',      q:'status=eq.open&select=id',      el:'kJobs'},   // active→status
    {table:'suppliers', q:'status=eq.new&select=id',       el:'kSup'},
    {table:'tenders',   q:'status=eq.open&select=id',      el:'kTender'}
  ];
  counts.forEach(function(c){
    sbFetch('GET', c.table+'?'+c.q, null, function(err, d){
      var el = document.getElementById(c.el);
      if(el && !err && Array.isArray(d)) el.textContent = d.length;
    });
  });
  sbFetch('GET','news?select=id,title,status,created_at&order=created_at.desc&limit=5', null, function(err,d){
    var el = document.getElementById('dashNews');
    if(!el || err || !Array.isArray(d)) return;
    el.innerHTML = d.map(function(n){
      return '<div style="display:flex;justify-content:space-between;padding:.5rem 0;border-bottom:1px solid #f1f5f9;font-size:.82rem">' +
        '<span>'+escapeHtml(n.title||'')+'</span>' +
        '<span class="badge badge-'+(n.status==='published'?'green':n.status==='archived'?'gray':'amber')+'">'+escapeHtml(n.status||'')+'</span></div>';
    }).join('');
  });
  sbFetch('GET','news?status=eq.draft&select=id', null, function(err,d){
    var b=document.getElementById('draftBadge');
    if(b && !err && Array.isArray(d) && d.length>0){b.textContent=d.length;b.style.display='';}
  });
}

// ── Мэдээ ─────────────────────────────────────────────
function loadNews() {
  var el = document.getElementById('newsGrid');
  if(!el) return;
  el.innerHTML = '<div style="text-align:center;padding:2rem">⏳</div>';
  sbFetch('GET','news?select=id,title,cat,status,created_at&order=created_at.desc&limit=100', null, function(err,d){
    if(err||!Array.isArray(d)||!d.length){el.innerHTML='<div class="empty"><div class="empty-ic">📰</div>Мэдээ байхгүй</div>';return;}
    el.innerHTML = d.map(function(n){
      var st=n.status||'draft';
      return '<div class="ban-item news-card" data-status="'+st+'">' +
        '<div class="ban-info"><h4>'+escapeHtml(n.title||'')+'</h4><p>'+escapeHtml(n.cat||'Ерөнхий')+' · '+(n.created_at||'').slice(0,10)+'</p></div>' +
        '<span class="badge badge-'+(st==='published'?'green':st==='archived'?'gray':'amber')+'">'+escapeHtml(st)+'</span>' +
        '<button class="btn btn-xs" onclick="editNews('+n.id+')">✏️</button></div>';
    }).join('');
  });
}
function filterNewsList(q){document.querySelectorAll('#newsGrid .news-card').forEach(function(c){c.style.display=!q||c.textContent.toLowerCase().includes(q.toLowerCase())?'':'none';});}
function filterNewsStatus(s){document.querySelectorAll('#newsGrid .news-card').forEach(function(c){c.style.display=s&&c.dataset.status!==s?'none':'';});}

// ── Баннер ────────────────────────────────────────────
function loadBanners() {
  var el=document.getElementById('bannersGrid');
  if(!el) return;
  el.innerHTML='<div style="text-align:center;padding:2rem">⏳</div>';
  sbFetch('GET','banners?select=*&order=sort_order', null, function(err,d){
    if(err||!Array.isArray(d)||!d.length){el.innerHTML='<div class="empty"><div class="empty-ic">🖼</div>Баннер байхгүй</div>';return;}
    el.innerHTML=d.map(function(b){
      return '<div class="card" style="padding:.85rem">' +
        '<div class="ban-thumb">'+(b.image_url?'<img src="'+b.image_url+'">':'🖼')+'</div>' +
        '<div style="margin-top:.5rem"><strong style="font-size:.85rem">'+escapeHtml(b.title||'')+'</strong></div>' +
        '<div style="display:flex;justify-content:space-between;align-items:center;margin-top:.5rem">' +
        '<span class="badge '+(b.active?'badge-green':'badge-gray')+'">'+(b.active?'Идэвхтэй':'Идэвхгүй')+'</span>' +
        '<button class="btn btn-xs" onclick="openBM('+b.id+')">✏️</button></div></div>';
    }).join('');
  });
}

// ── Хуудас ────────────────────────────────────────────
function loadPages() {
  var el=document.getElementById('pageTbody');
  if(!el) return;
  el.innerHTML='<tr><td colspan="5" style="text-align:center;padding:1.5rem">⏳</td></tr>';
  sbFetch('GET','pages?select=*&order=sort_order', null, function(err,d){
    if(err||!Array.isArray(d)||!d.length){el.innerHTML='<tr><td colspan="5" style="text-align:center;padding:1.5rem;color:#94a3b8">Байхгүй</td></tr>';return;}
    el.innerHTML=d.map(function(p){
      return '<tr><td>/'+escapeHtml(p.slug||'')+'</td><td>'+escapeHtml(p.title_mn||'')+'</td><td>'+escapeHtml(p.meta_title||'')+'</td><td>'+(p.sort_order||0)+'</td>' +
        '<td><button class="btn btn-xs" onclick="openPageM('+p.id+')">✏️</button></td></tr>';
    }).join('');
  });
}
function filterPages(q){document.querySelectorAll('#pageTbody tr').forEach(function(r){r.style.display=!q||r.textContent.toLowerCase().includes(q.toLowerCase())?'':'none';});}

// ── SEO ───────────────────────────────────────────────
function loadSeo() {
  var el=document.getElementById('seoTbody');
  if(!el) return;
  sbFetch('GET','pages?select=id,slug,meta_title,meta_desc&order=sort_order', null, function(err,d){
    if(err||!Array.isArray(d)||!d.length){el.innerHTML='<tr><td colspan="4" style="text-align:center;padding:1.5rem;color:#94a3b8">Байхгүй</td></tr>';return;}
    el.innerHTML=d.map(function(p){
      var tl=(p.meta_title||'').length, dl=(p.meta_desc||'').length;
      return '<tr><td>/'+escapeHtml(p.slug||'')+'</td>' +
        '<td style="color:'+(tl>0&&tl<70?'#22c55e':tl>=70?'#ef4444':'#94a3b8')+'">'+escapeHtml(p.meta_title||'Хоосон')+'</td>' +
        '<td style="color:'+(dl>0&&dl<160?'#22c55e':dl>=160?'#ef4444':'#94a3b8')+'">'+(p.meta_desc||'').substring(0,60)+'</td>' +
        '<td><button class="btn btn-xs" onclick="openPageM('+p.id+')">✏️</button></td></tr>';
    }).join('');
  });
}
function filterSeo(q){document.querySelectorAll('#seoTbody tr').forEach(function(r){r.style.display=!q||r.textContent.toLowerCase().includes(q.toLowerCase())?'':'none';});}

// ── Тохиргоо ──────────────────────────────────────────
var _sKeys=['site_name','site_email','site_phone','site_address','fb_url','news_per_page','footer_text'];
var _sLabels={site_name:'Сайтын нэр',site_email:'И-мэйл',site_phone:'Утас',site_address:'Хаяг',fb_url:'Facebook URL',news_per_page:'Нэг хуудсанд мэдээ',footer_text:'Footer текст'};
function loadSettings() {
  var el=document.getElementById('settingsForm');
  if(!el) return;
  sbFetch('GET','settings?select=key,value', null, function(err,d){
    var map={};
    if(!err&&Array.isArray(d)) d.forEach(function(x){map[x.key]=x.value;});
    el.innerHTML=_sKeys.map(function(k){
      return '<div><label class="form-label">'+(_sLabels[k]||k)+'</label><input class="form-control" id="set_'+k+'" value="'+escapeHtml(map[k]||'')+'"></div>';
    }).join('');
  });
}
function saveSettings(){
  _sKeys.forEach(function(k){
    var v=(document.getElementById('set_'+k)||{}).value||'';
    sbFetch('POST','settings',{key:k,value:v,updated_at:new Date().toISOString()},function(err){
      if(err) sbFetch('PATCH','settings?key=eq.'+k,{value:v},function(){});
    });
  });
  toast('✅ Тохиргоо хадгалагдлаа','success');
}

// ── Тайлан тоймлол ────────────────────────────────────
function loadRptOverview() {
  var el=document.getElementById('rptKpis');
  if(!el) return;
  var items=[{id:'news',label:'Мэдээ',icon:'📰'},{id:'jobs',label:'Ажлын байр',icon:'💼'},{id:'tenders',label:'Тендер',icon:'📋'},{id:'suppliers',label:'Нийлүүлэгч',icon:'🚚'}];
  el.innerHTML=items.map(function(x){return '<div class="kpi"><div class="kpi-ic" style="background:#EEF1FD">'+x.icon+'</div><div><div class="kpi-val" id="rpt_'+x.id+'">—</div><div class="kpi-lbl">'+x.label+'</div></div></div>';}).join('');
  items.forEach(function(x){
    sbFetch('GET',x.id+'?select=id&limit=500', null, function(err,d){
      var e=document.getElementById('rpt_'+x.id);
      if(e&&!err&&Array.isArray(d)) e.textContent=d.length;
    });
  });
}

// ── Stores Manager ────────────────────────────────────
function loadStoresMgr() {
  var tbody=document.getElementById('stores-tbody'), total=document.getElementById('stores-total');
  if(!tbody) return;
  tbody.innerHTML='<tr><td colspan="8" style="text-align:center;padding:2rem">⏳</td></tr>';
  sbFetch('GET','stores?select=*&order=sort_order.asc,name.asc&limit=500', null, function(err,d){
    if(err||!Array.isArray(d)||!d.length){tbody.innerHTML='<tr><td colspan="8" style="text-align:center;padding:2rem;color:#94a3b8">Салбар байхгүй</td></tr>';if(total)total.textContent='0';return;}
    if(total)total.textContent=d.length;
    tbody.innerHTML=d.map(function(s,i){
      var imgCell = s.img_url
        ? '<img src="'+s.img_url+'" style="width:48px;height:48px;object-fit:cover;border-radius:8px" loading="lazy" onerror="this.outerHTML=\'<div style=&quot;width:48px;height:48px;background:#EEF1FD;border-radius:8px;display:inline-flex;align-items:center;justify-content:center;font-size:1.2rem&quot;>🏪</div>\'">'
        : '<div style="width:48px;height:48px;background:#EEF1FD;border-radius:8px;display:inline-flex;align-items:center;justify-content:center;font-size:1.2rem">🏪</div>';
      return '<tr>' +
        '<td style="text-align:center">'+(i+1)+'</td>' +
        '<td style="text-align:center">'+imgCell+'</td>' +
        '<td style="font-weight:600">'+escapeHtml(s.name||'')+'</td>' +
        '<td>'+escapeHtml(s.address||'')+'</td>' +
        '<td>'+escapeHtml(s.district||s.type||'')+'</td>' +
        '<td style="font-size:.78rem">'+escapeHtml(s.phone||'')+'</td>' +
        '<td style="font-size:.75rem">'+escapeHtml(s.hours||'')+'</td>' +
        '<td style="text-align:center">' +
          '<button class="btn btn-xs" onclick="openStoreModal('+s.id+')">✏️</button> ' +
          '<button class="btn btn-xs btn-danger" onclick="deleteStore('+s.id+')">🗑</button>' +
        '</td></tr>';
    }).join('');
  });
}
function deleteStore(id){
  if(!confirm('Устгах уу?')) return;
  sbFetch('DELETE','stores?id=eq.'+id, null, function(err){
    toast(err?'❌ Алдаа':'✅ Устгагдлаа',err?'error':'success');
    if(!err) loadStoresMgr();
  });
}
function applyStoreFilter(){loadStoresMgr();}
function openStoreModal(id) {
  var isEdit = !!id;
  var load = isEdit
    ? new Promise(function(resolve){
        sbFetch('GET','stores?id=eq.'+id+'&select=*', null, function(err,d){
          resolve(err||!d||!d[0] ? null : d[0]);
        });
      })
    : Promise.resolve({name:'',address:'',district:'',phone:'',hours:'09:00 - 22:00',type:'',lat:'',lng:'',map_url:'',img_url:'',active:true,sort_order:0});
  load.then(function(s){
    if(!s){ toast('Өгөгдөл олдсонгүй','error'); return; }
    var types = ['Их Дэлгүүр','Хайпермаркет','Супермаркет','Агуулах Худалдаа','Электроникс','Моторс'];
    var typeOpts = types.map(function(t){return '<option value="'+t+'"'+(s.type===t?' selected':'')+'>'+t+'</option>';}).join('');
    nmModal(isEdit?'🏪 Салбар засах':'🏪 Шинэ салбар нэмэх',
      '<div style="display:grid;grid-template-columns:1fr 1fr;gap:.75rem">' +
        '<div style="grid-column:1/-1"><label class="form-label">Нэр *</label><input class="form-control" id="sf-name" value="'+escapeHtml(s.name||'')+'"></div>' +
        '<div><label class="form-label">Хаяг</label><input class="form-control" id="sf-address" value="'+escapeHtml(s.address||'')+'"></div>' +
        '<div><label class="form-label">Дүүрэг/Аймаг</label><input class="form-control" id="sf-district" value="'+escapeHtml(s.district||'')+'"></div>' +
        '<div><label class="form-label">Утас</label><input class="form-control" id="sf-phone" value="'+escapeHtml(s.phone||'')+'"></div>' +
        '<div><label class="form-label">Ажлын цаг</label><input class="form-control" id="sf-hours" value="'+escapeHtml(s.hours||'')+'"></div>' +
        '<div><label class="form-label">Төрөл</label><select class="form-control" id="sf-type"><option value="">—</option>'+typeOpts+'</select></div>' +
        '<div><label class="form-label">Дараалал</label><input class="form-control" type="number" id="sf-order" value="'+(s.sort_order||0)+'"></div>' +
        '<div><label class="form-label">Өргөрөг (lat)</label><input class="form-control" id="sf-lat" value="'+escapeHtml(s.lat||'')+'"></div>' +
        '<div><label class="form-label">Уртраг (lng)</label><input class="form-control" id="sf-lng" value="'+escapeHtml(s.lng||'')+'"></div>' +
        '<div style="grid-column:1/-1"><label class="form-label">Google Maps URL</label><input class="form-control" id="sf-map" value="'+escapeHtml(s.map_url||'')+'"></div>' +
        '<div style="grid-column:1/-1">' +
          '<label class="form-label">Зураг</label>' +
          '<div style="display:flex;gap:.5rem;align-items:center;margin-bottom:.5rem">' +
            '<input type="file" id="sf-img-file" accept="image/*" style="flex:1" onchange="_previewImg(\'sf-img-file\',\'sf-img-preview\')">' +
            '<button type="button" class="btn btn-primary btn-sm" onclick="_uploadImgToSupabase(\'sf-img-file\',\'sf-img\',\'stores\',\'sf-img-preview\')">⬆ Upload</button>' +
          '</div>' +
          '<input class="form-control" id="sf-img" value="'+escapeHtml(s.img_url||'')+'" placeholder="https://... эсвэл дээрээс upload">' +
          '<div id="sf-img-preview" style="margin-top:.5rem;text-align:center">' +
            (s.img_url?'<img src="'+s.img_url+'" style="max-height:120px;border-radius:8px">':'') +
          '</div>' +
        '</div>' +
        '<div style="grid-column:1/-1"><label style="display:flex;align-items:center;gap:.5rem;font-size:.85rem"><input type="checkbox" id="sf-active"'+(s.active!==false?' checked':'')+'> Идэвхитэй</label></div>' +
      '</div>',
      [{label:isEdit?'Хадгалах':'Нэмэх',cls:'btn-primary',cb:function(){saveStore(id);}},{label:'Болих',cls:'btn-secondary'}]
    );
  });
}
function saveStore(id){
  var body = {
    name: document.getElementById('sf-name').value.trim(),
    address: document.getElementById('sf-address').value.trim(),
    district: document.getElementById('sf-district').value.trim(),
    phone: document.getElementById('sf-phone').value.trim(),
    hours: document.getElementById('sf-hours').value.trim(),
    type: document.getElementById('sf-type').value,
    lat: document.getElementById('sf-lat').value.trim() || null,
    lng: document.getElementById('sf-lng').value.trim() || null,
    map_url: document.getElementById('sf-map').value.trim(),
    img_url: document.getElementById('sf-img').value.trim(),
    sort_order: parseInt(document.getElementById('sf-order').value)||0,
    active: document.getElementById('sf-active').checked
  };
  if(!body.name){ toast('Нэр оруулна уу','error'); return; }
  var method = id ? 'PATCH' : 'POST';
  var path = id ? 'stores?id=eq.'+id : 'stores';
  sbFetch(method, path, body, function(err){
    if(err){ toast('❌ '+err,'error'); return; }
    toast(id?'✅ Хадгалагдлаа':'✅ Нэмэгдлээ','success');
    nmCloseModal && nmCloseModal();
    loadStoresMgr();
  });
}

// ── Leadership Manager ────────────────────────────────
function loadLeadershipMgr() {
  var grid=document.getElementById('leaders-grid'), total=document.getElementById('leaders-total');
  if(!grid) return;
  grid.innerHTML='<div style="grid-column:1/-1;text-align:center;padding:2rem">⏳</div>';
  sbFetch('GET','leadership?select=*&order=sort_order.asc', null, function(err,d){
    if(err||!Array.isArray(d)||!d.length){grid.innerHTML='<div style="grid-column:1/-1;text-align:center;padding:2rem;color:#94a3b8">Удирдлага байхгүй</div>';return;}
    if(total)total.textContent=d.length;
    grid.innerHTML=d.map(function(l){
      return '<div style="background:#fff;border:1px solid #e2e8f0;border-radius:12px;padding:1rem;text-align:center">' +
        (l.img_url?'<img src="'+l.img_url+'" style="width:80px;height:80px;border-radius:50%;object-fit:cover;margin:0 auto .75rem;display:block" onerror="this.style.display=\'none\'">':
          '<div style="width:80px;height:80px;border-radius:50%;background:#EEF1FD;display:flex;align-items:center;justify-content:center;margin:0 auto .75rem;font-size:1.5rem;font-weight:700;color:#4D68EF">'+(l.name||'?')[0]+'</div>') +
        '<div style="font-weight:700;font-size:.82rem;color:#0f172a;margin-bottom:.25rem">'+escapeHtml(l.name||'')+'</div>' +
        '<div style="font-size:.72rem;color:#64748b;margin-bottom:.4rem">'+escapeHtml(l.title||'')+'</div>' +
        '<div style="display:flex;gap:.3rem;justify-content:center;margin-top:.5rem">' +
        '<button class="btn btn-xs" onclick="openLeaderModal('+l.id+')">✏️</button>' +
        '<button class="btn btn-xs btn-danger" onclick="deleteLeader('+l.id+')">🗑</button></div></div>';
    }).join('');
  });
}
function filterLeaders(){loadLeadershipMgr();}
function openLeaderModal(id) {
  var isEdit = !!id;
  var load = isEdit
    ? new Promise(function(resolve){
        sbFetch('GET','leadership?id=eq.'+id+'&select=*', null, function(err,d){
          resolve(err||!d||!d[0] ? null : d[0]);
        });
      })
    : Promise.resolve({name:'',title:'',section:'Удирдлагууд',img_url:'',sort_order:0,active:true});
  load.then(function(l){
    if(!l){ toast('Өгөгдөл олдсонгүй','error'); return; }
    var sections = ['Төлөөлөн удирдах зөвлөл','Удирдлагууд','Газар, хэлтсийн захирлууд','Бизнесийн захирлууд','Салбарын захирлууд'];
    var secOpts = sections.map(function(x){return '<option value="'+x+'"'+(l.section===x?' selected':'')+'>'+x+'</option>';}).join('');
    nmModal(isEdit?'👤 Удирдлага засах':'👤 Шинэ удирдлага нэмэх',
      '<div style="display:grid;grid-template-columns:1fr 1fr;gap:.75rem">' +
        '<div style="grid-column:1/-1"><label class="form-label">Нэр *</label><input class="form-control" id="lf-name" value="'+escapeHtml(l.name||'')+'"></div>' +
        '<div style="grid-column:1/-1"><label class="form-label">Албан тушаал</label><input class="form-control" id="lf-title" value="'+escapeHtml(l.title||'')+'"></div>' +
        '<div><label class="form-label">Хэсэг</label><select class="form-control" id="lf-section">'+secOpts+'</select></div>' +
        '<div><label class="form-label">Дараалал</label><input class="form-control" type="number" id="lf-order" value="'+(l.sort_order||0)+'"></div>' +
        '<div style="grid-column:1/-1">' +
          '<label class="form-label">Зураг</label>' +
          '<div style="display:flex;gap:.5rem;align-items:center;margin-bottom:.5rem">' +
            '<input type="file" id="lf-img-file" accept="image/*" style="flex:1" onchange="_previewImg(\'lf-img-file\',\'lf-img-preview\')">' +
            '<button type="button" class="btn btn-primary btn-sm" onclick="_uploadImgToSupabase(\'lf-img-file\',\'lf-img\',\'leadership\',\'lf-img-preview\')">⬆ Upload</button>' +
          '</div>' +
          '<input class="form-control" id="lf-img" value="'+escapeHtml(l.img_url||'')+'" placeholder="https://... эсвэл дээрээс upload">' +
          '<div id="lf-img-preview" style="margin-top:.5rem;text-align:center">' +
            (l.img_url?'<img src="'+l.img_url+'" style="max-height:160px;border-radius:8px">':'') +
          '</div>' +
        '</div>' +
        '<div style="grid-column:1/-1"><label style="display:flex;align-items:center;gap:.5rem;font-size:.85rem"><input type="checkbox" id="lf-active"'+(l.active!==false?' checked':'')+'> Идэвхитэй</label></div>' +
      '</div>',
      [{label:isEdit?'Хадгалах':'Нэмэх',cls:'btn-primary',cb:function(){saveLeader(id);}},{label:'Болих',cls:'btn-secondary'}]
    );
  });
}
function saveLeader(id){
  var body = {
    name: document.getElementById('lf-name').value.trim(),
    title: document.getElementById('lf-title').value.trim(),
    section: document.getElementById('lf-section').value,
    img_url: document.getElementById('lf-img').value.trim(),
    sort_order: parseInt(document.getElementById('lf-order').value)||0,
    active: document.getElementById('lf-active').checked
  };
  if(!body.name){ toast('Нэр оруулна уу','error'); return; }
  var method = id ? 'PATCH' : 'POST';
  var path = id ? 'leadership?id=eq.'+id : 'leadership';
  sbFetch(method, path, body, function(err){
    if(err){ toast('❌ '+err,'error'); return; }
    toast(id?'✅ Хадгалагдлаа':'✅ Нэмэгдлээ','success');
    nmCloseModal && nmCloseModal();
    loadLeadershipMgr();
  });
}

// ── Shared Modal Helper ───────────────────────────────
function nmModal(title, bodyHTML, buttons){
  var existing = document.getElementById('nm-modal');
  if(existing) existing.remove();
  var m = document.createElement('div');
  m.id = 'nm-modal';
  m.style.cssText = 'position:fixed;inset:0;background:rgba(15,23,42,.55);z-index:9999;display:flex;align-items:center;justify-content:center;padding:1rem;backdrop-filter:blur(4px)';
  var btns = (buttons||[]).map(function(b,i){
    return '<button class="btn '+(b.cls||'btn-secondary')+'" data-nm-btn="'+i+'" style="margin-left:.5rem">'+b.label+'</button>';
  }).join('');
  m.innerHTML = '<div style="background:#fff;border-radius:14px;max-width:620px;width:100%;max-height:90vh;overflow-y:auto;box-shadow:0 20px 60px rgba(0,0,0,.3)">' +
    '<div style="padding:1.1rem 1.25rem;border-bottom:1px solid #e5e7eb;display:flex;align-items:center;justify-content:space-between">' +
      '<h3 style="font-size:1rem;font-weight:800;color:#0f172a;margin:0">'+title+'</h3>' +
      '<button onclick="nmCloseModal()" style="background:none;border:none;font-size:1.5rem;color:#64748b;cursor:pointer;line-height:1">×</button>' +
    '</div>' +
    '<div style="padding:1.25rem">'+bodyHTML+'</div>' +
    '<div style="padding:.85rem 1.25rem;border-top:1px solid #e5e7eb;text-align:right;background:#f8fafc;border-radius:0 0 14px 14px">'+btns+'</div>' +
  '</div>';
  document.body.appendChild(m);
  (buttons||[]).forEach(function(b,i){
    var el = m.querySelector('[data-nm-btn="'+i+'"]');
    if(el) el.onclick = function(){ if(b.cb) b.cb(); else nmCloseModal(); };
  });
  m.addEventListener('click', function(e){ if(e.target===m) nmCloseModal(); });
}
function nmCloseModal(){ var m=document.getElementById('nm-modal'); if(m) m.remove(); }
window.nmModal = nmModal;
window.nmCloseModal = nmCloseModal;

function exportStoresExcel(){toast('Excel export удахгүй','info');}
function importStoresExcel(){toast('Excel import удахгүй','info');}
function deleteLeader(id){
  if(!confirm('Устгах уу?')) return;
  sbFetch('DELETE','leadership?id=eq.'+id, null, function(err){
    toast(err?'❌ Алдаа':'✅ Устгагдлаа',err?'error':'success');
    if(!err) loadLeadershipMgr();
  });
}

// Aliases for compatibility
window.loadStores = loadStoresMgr;

// ── Catalogue ─────────────────────────────────────────────
function loadCatalogueMgr(){
  var SB_URL = window.__NM_SB_URL__ || 'https://hunygqumohxinhndrcph.supabase.co';
  var SB_KEY = window.__NM_SB_KEY__ || 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6Imh1bnlncXVtb2h4aW5obmRyY3BoIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NzQzNTA4NjMsImV4cCI6MjA4OTkyNjg2M30.2eFxPABgxosblHajh85txP_yrv0VsDCbhxSVIcO3T88';
  var keys=[];
  ['mn','en','ru','zh'].forEach(function(l){
    keys.push('"nm_catalogue_pdf_'+l+'"');
    keys.push('"nm_catalogue_video_'+l+'"');
  });
  fetch(SB_URL+'/rest/v1/settings?key=in.('+keys.join(',')+')&select=key,value',{
    headers:{apikey:SB_KEY,Authorization:'Bearer '+SB_KEY}
  }).then(function(r){return r.ok?r.json():[];}).then(function(rows){
    // Initialize all statuses
    ['mn','en','ru','zh'].forEach(function(l){
      var st=document.getElementById('cat-'+l+'-status');
      if(st) st.textContent='\u2014 \u0411\u0430\u0439\u0445\u0433\u04af\u0439';
    });
    (rows||[]).forEach(function(row){
      if(row.key.indexOf('nm_catalogue_pdf_')===0){
        var lang=row.key.replace('nm_catalogue_pdf_','');
        var urlInp=document.getElementById('cat-'+lang+'-url');
        var st=document.getElementById('cat-'+lang+'-status');
        if(urlInp) urlInp.value=row.value||'';
        if(st&&row.value) st.innerHTML='\u2705 <a href="'+row.value+'" target="_blank" style="color:var(--blue)">\u0425\u0430\u0440\u0430\u0445</a>';
      } else if(row.key.indexOf('nm_catalogue_video_')===0){
        var lang=row.key.replace('nm_catalogue_video_','');
        var vi=document.getElementById('vid-'+lang+'-url');
        if(vi) vi.value=row.value||'';
      }
    });
  }).catch(function(){});
}
function saveCatalogues(){
  var SB_URL = window.__NM_SB_URL__ || 'https://hunygqumohxinhndrcph.supabase.co';
  var SB_KEY = window.__NM_SB_KEY__ || 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6Imh1bnlncXVtb2h4aW5obmRyY3BoIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NzQzNTA4NjMsImV4cCI6MjA4OTkyNjg2M30.2eFxPABgxosblHajh85txP_yrv0VsDCbhxSVIcO3T88';
  var pending=0, done=0, errs=0;
  function saveUrl(lang, url){
    return fetch(SB_URL+'/rest/v1/settings?on_conflict=key', {
      method:'POST',
      headers:{apikey:SB_KEY,Authorization:'Bearer '+SB_KEY,'Content-Type':'application/json','Prefer':'resolution=merge-duplicates,return=minimal'},
      body:JSON.stringify({key:'nm_catalogue_pdf_'+lang, value:url})
    });
  }
  ['mn','en','ru','zh'].forEach(function(lang){
    var inp=document.getElementById('cat-'+lang);
    var urlInp=document.getElementById('cat-'+lang+'-url');
    var st=document.getElementById('cat-'+lang+'-status');
    // Option 1: Direct URL
    if(urlInp && urlInp.value && urlInp.value.trim()){
      pending++;
      if(st) st.textContent='\u23f3 URL \u0445\u0430\u0434\u0433\u0430\u043b\u0436 \u0431\u0430\u0439\u043d\u0430...';
      saveUrl(lang, urlInp.value.trim()).then(function(r){
        done++;
        if(r.ok){ if(st) st.innerHTML='\u2705 <a href="'+urlInp.value+'" target="_blank" style="color:var(--blue)">\u0425\u0430\u0440\u0430\u0445</a>'; }
        else { errs++; if(st) st.textContent='\u274c Save failed'; }
        if(done===pending) toast((done-errs)+'/'+done+' \u0445\u0430\u0434\u0433\u0430\u043b\u0430\u0433\u0434\u043b\u0430\u0430', errs?'error':'success');
      });
      return;
    }
    // Option 2: File upload
    if(!inp||!inp.files||!inp.files[0]) return;
    pending++;
    var file=inp.files[0];
    var name='catalogue_'+lang+'.pdf';
    if(st) st.textContent='\u23f3 \u0425\u0443\u0443\u043b\u0436 \u0431\u0430\u0439\u043d\u0430...';
    fetch(SB_URL+'/storage/v1/object/media/'+name,{
      method:'POST',
      headers:{'apikey':SB_KEY,'Authorization':'Bearer '+SB_KEY,'Content-Type':'application/pdf','x-upsert':'true'},
      body:file
    }).then(function(r){
      if(r.ok){
        var url=SB_URL+'/storage/v1/object/public/media/'+name;
        return saveUrl(lang, url).then(function(){
          done++;
          if(st) st.innerHTML='\u2705 <a href="'+url+'" target="_blank" style="color:var(--blue)">\u0425\u0430\u0440\u0430\u0445</a>';
          if(done===pending) toast((done-errs)+'/'+done+' \u0445\u0443\u0443\u043b\u0430\u0433\u0434\u043b\u0430\u0430', errs?'error':'success');
        });
      } else {
        done++; errs++;
        return r.text().then(function(e){
          if(st) st.textContent='\u274c '+(e||'').slice(0,50);
          if(done===pending) toast('\u0410\u043b\u0434\u0430\u0430 \u0433\u0430\u0440\u043b\u0430\u0430','error');
        });
      }
    }).catch(function(e){
      done++; errs++;
      if(st) st.textContent='\u274c '+e.message;
      if(done===pending) toast('\u0410\u043b\u0434\u0430\u0430 \u0433\u0430\u0440\u043b\u0430\u0430','error');
    });
  });
  if(!pending) toast('\u0424\u0430\u0439\u043b \u044d\u0441\u0432\u044d\u043b URL \u043e\u0440\u0443\u0443\u043b\u043d\u0430 \u0443\u0443','error');
}
function saveCatalogueVideos(){
  var SB_URL = window.__NM_SB_URL__ || 'https://hunygqumohxinhndrcph.supabase.co';
  var SB_KEY = window.__NM_SB_KEY__ || 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6Imh1bnlncXVtb2h4aW5obmRyY3BoIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NzQzNTA4NjMsImV4cCI6MjA4OTkyNjg2M30.2eFxPABgxosblHajh85txP_yrv0VsDCbhxSVIcO3T88';
  var done=0, pending=0, errs=0;
  ['mn','en','ru','zh'].forEach(function(lang){
    var vi=document.getElementById('vid-'+lang+'-url');
    if(!vi) return;
    var url=(vi.value||'').trim();
    if(url && url.indexOf('youtube.com/watch?v=')>=0){
      url = url.replace('youtube.com/watch?v=', 'youtube.com/embed/').split('&')[0];
    } else if(url && url.indexOf('youtu.be/')>=0){
      url = url.replace('youtu.be/', 'youtube.com/embed/').split('?')[0];
    }
    pending++;
    fetch(SB_URL+'/rest/v1/settings?on_conflict=key',{
      method:'POST',
      headers:{apikey:SB_KEY,Authorization:'Bearer '+SB_KEY,'Content-Type':'application/json','Prefer':'resolution=merge-duplicates,return=minimal'},
      body:JSON.stringify({key:'nm_catalogue_video_'+lang, value:url})
    }).then(function(r){
      done++;
      if(!r.ok) errs++;
      if(done===pending) toast((done-errs)+'/'+done+' \u0432\u0438\u0434\u0435\u043e \u0445\u0430\u0434\u0433\u0430\u043b\u0430\u0433\u0434\u043b\u0430\u0430', errs?'error':'success');
    }).catch(function(){
      done++; errs++;
      if(done===pending) toast('\u0410\u043b\u0434\u0430\u0430 \u0433\u0430\u0440\u043b\u0430\u0430','error');
    });
  });
  if(!pending) toast('\u04ae\u0440 \u0434\u04af\u043d \u0431\u0430\u0439\u0445\u0433\u04af\u0439','error');
}

// ── Per-language catalogue helpers (used by per-row buttons) ──
function uploadCatalogueFile(lang){
  var SB_URL = window.__NM_SB_URL__ || 'https://hunygqumohxinhndrcph.supabase.co';
  var SB_KEY = window.__NM_SB_KEY__ || 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6Imh1bnlncXVtb2h4aW5obmRyY3BoIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NzQzNTA4NjMsImV4cCI6MjA4OTkyNjg2M30.2eFxPABgxosblHajh85txP_yrv0VsDCbhxSVIcO3T88';
  var inp = document.getElementById('cat-'+lang);
  var st = document.getElementById('cat-'+lang+'-status');
  var urlInp = document.getElementById('cat-'+lang+'-url');
  if(!inp||!inp.files||!inp.files[0]){ toast('\u0424\u0430\u0439\u043b \u0441\u043e\u043d\u0433\u043e\u043d\u043e \u0443\u0443','error'); return; }
  var file = inp.files[0];
  var name = 'catalogue_'+lang+'_'+Date.now()+'.pdf';
  if(st) st.innerHTML='\u23f3 \u0425\u0443\u0443\u043b\u0436 \u0431\u0430\u0439\u043d\u0430...';
  fetch(SB_URL+'/storage/v1/object/media/'+name,{
    method:'POST',
    headers:{apikey:SB_KEY,Authorization:'Bearer '+SB_KEY,'Content-Type':'application/pdf','x-upsert':'true'},
    body:file
  }).then(function(r){
    if(!r.ok){ if(st) st.innerHTML='<span style="color:#ef4444">\u274c Upload \u0430\u043b\u0434\u0430\u0430</span>'; toast('Upload \u0430\u043b\u0434\u0430\u0430','error'); return; }
    var publicUrl = SB_URL+'/storage/v1/object/public/media/'+name;
    if(urlInp) urlInp.value = publicUrl;
    // Also save to settings
    return fetch(SB_URL+'/rest/v1/settings?on_conflict=key',{
      method:'POST',
      headers:{apikey:SB_KEY,Authorization:'Bearer '+SB_KEY,'Content-Type':'application/json','Prefer':'resolution=merge-duplicates,return=minimal'},
      body:JSON.stringify({key:'nm_catalogue_pdf_'+lang, value:publicUrl})
    }).then(function(){
      if(st) st.innerHTML='<span style="color:#10b981">\u2705 \u0425\u0430\u0434\u0433\u0430\u043b\u0430\u0433\u0434\u043b\u0430\u0430</span>';
      toast('\u2705 '+lang.toUpperCase()+' PDF \u0443\u043f\u043b\u043e\u0430\u0434 \u0445\u0438\u0439\u0433\u0434\u043b\u044d\u044d','success');
    });
  }).catch(function(e){
    if(st) st.innerHTML='<span style="color:#ef4444">\u274c '+e.message+'</span>';
    toast('\u0410\u043b\u0434\u0430\u0430','error');
  });
}

function saveCatalogueUrl(lang){
  var SB_URL = window.__NM_SB_URL__ || 'https://hunygqumohxinhndrcph.supabase.co';
  var SB_KEY = window.__NM_SB_KEY__ || 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6Imh1bnlncXVtb2h4aW5obmRyY3BoIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NzQzNTA4NjMsImV4cCI6MjA4OTkyNjg2M30.2eFxPABgxosblHajh85txP_yrv0VsDCbhxSVIcO3T88';
  var urlInp = document.getElementById('cat-'+lang+'-url');
  var st = document.getElementById('cat-'+lang+'-status');
  var url = (urlInp && urlInp.value || '').trim();
  if(!url){ toast('URL \u043e\u0440\u0443\u0443\u043b\u043d\u0430 \u0443\u0443','error'); return; }
  if(st) st.innerHTML='\u23f3 \u0425\u0430\u0434\u0433\u0430\u043b\u0436 \u0431\u0430\u0439\u043d\u0430...';
  fetch(SB_URL+'/rest/v1/settings?on_conflict=key',{
    method:'POST',
    headers:{apikey:SB_KEY,Authorization:'Bearer '+SB_KEY,'Content-Type':'application/json','Prefer':'resolution=merge-duplicates,return=minimal'},
    body:JSON.stringify({key:'nm_catalogue_pdf_'+lang, value:url})
  }).then(function(r){
    if(r.ok){
      if(st) st.innerHTML='<span style="color:#10b981">\u2705 \u0425\u0430\u0434\u0433\u0430\u043b\u0430\u0433\u0434\u043b\u0430\u0430</span>';
      toast('\u2705 '+lang.toUpperCase()+' URL \u0445\u0430\u0434\u0433\u0430\u043b\u0430\u0433\u0434\u043b\u0430\u0430','success');
    } else {
      if(st) st.innerHTML='<span style="color:#ef4444">\u274c \u0410\u043b\u0434\u0430\u0430</span>';
      toast('\u0410\u043b\u0434\u0430\u0430','error');
    }
  }).catch(function(){
    if(st) st.innerHTML='<span style="color:#ef4444">\u274c \u0410\u043b\u0434\u0430\u0430</span>';
    toast('\u0410\u043b\u0434\u0430\u0430','error');
  });
}

// ── Structure functions moved to admins.html (newer version) ──
// ── Audit ──────────────────────────────────────────────────
function runFullAudit(){
  var el=document.getElementById('audit-results');
  if(!el) return;
  el.innerHTML='<div class="card" style="padding:1rem;color:#64748b">⏳ Ажиллаж байна...</div>';
  var checks=[], tables=['news','jobs','tenders','suppliers','stores','leadership'];
  var done=0;
  sbFetch('GET','news?select=id&limit=1',null,function(err,d){
    checks.push({label:'Supabase холболт',ok:!err,detail:err?String(err):'OK'});
  });
  tables.forEach(function(t){
    sbFetch('GET',t+'?select=id&limit=1',null,function(err,rows){
      checks.push({label:'Хүснэгт: '+t,ok:!err,detail:err?String(err):(Array.isArray(rows)?rows.length+' мөр':'OK')});
      done++;
      if(done===tables.length) setTimeout(function(){renderAuditResults(checks);},500);
    });
  });
}
function renderAuditResults(checks){
  var el=document.getElementById('audit-results');if(!el)return;
  var pass=checks.filter(function(c){return c.ok;}).length;
  var color=pass===checks.length?'#22c55e':pass>checks.length/2?'#f59e0b':'#ef4444';
  el.innerHTML='<div class="card" style="margin-bottom:1rem"><span style="font-size:1.1rem;font-weight:800;color:'+color+'">'+pass+'/'+checks.length+' шалгалт тэнцсэн</span></div>'+
    '<div class="card"><table class="tbl" style="width:100%"><thead><tr><th>Шалгалт</th><th>Үр дүн</th><th>Дэлгэрэнгүй</th></tr></thead><tbody>'+
    checks.map(function(c){return '<tr><td>'+escapeHtml(c.label)+'</td><td><span class="badge '+(c.ok?'bg-green':'bg-red')+'">'+(c.ok?'✅':'❌')+'</span></td><td style="font-size:.75rem;color:#64748b">'+escapeHtml(c.detail||'')+'</td></tr>';}).join('')+
    '</tbody></table></div>';
}
function loadNominImport(){
  var logEl = document.getElementById('import-log');
  if(logEl) logEl.innerHTML = '<div style="color:#64748b;padding:.5rem">💡 Импорт модуль идэвхгүй. CSV импорт ашиглана уу.</div>';
}
function importCSV(type){
  var inp=document.getElementById('import-'+type);
  var log=document.getElementById('import-log');
  if(!inp||!inp.files||!inp.files[0]){toast('Файл сонгоно уу','error');return;}
  var reader=new FileReader();
  reader.onload=function(e){
    var lines=e.target.result.split('\n').filter(function(l){return l.trim();});
    var headers=lines[0].split(',').map(function(h){return h.replace(/"/g,'').trim();});
    var rows=lines.slice(1).map(function(l){
      var vals=l.split(',');var obj={};
      headers.forEach(function(h,i){obj[h]=(vals[i]||'').replace(/"/g,'').trim();});
      return obj;
    });
    if(log) log.textContent=rows.length+' мөр уншлаа...';
    var done=0,errs=0;
    if(!rows.length){toast('Өгөгдөл байхгүй','error');return;}
    rows.forEach(function(row){
      sbFetch('POST',type,row,function(err){
        done++;if(err)errs++;
        if(done===rows.length){
          var msg=(done-errs)+'/'+done+' амжилттай'+(errs?' ('+errs+' алдаа)':'');
          if(log)log.textContent=msg;
          toast(msg,errs?'error':'success');
        }
      });
    });
  };
  reader.readAsText(inp.files[0]);
}
// ═══════════════════════════════════════════════════════
// Panel extensions — Phase 1-4 (all 20 missing panels)
// Appended to admin-panels.js
// ═══════════════════════════════════════════════════════

// Generic CRUD helper — reuses nmModal
function _crudField(label, id, val, type, opts) {
  val = val==null?'':val;
  type = type||'text';
  if(type==='textarea') return '<div style="grid-column:1/-1"><label class="form-label">'+label+'</label><textarea class="form-control" id="'+id+'" rows="3">'+escapeHtml(val)+'</textarea></div>';
  if(type==='select') {
    var o = (opts||[]).map(function(x){var v=typeof x==='string'?x:x.v; var l=typeof x==='string'?x:x.l; return '<option value="'+v+'"'+(val===v?' selected':'')+'>'+l+'</option>';}).join('');
    return '<div><label class="form-label">'+label+'</label><select class="form-control" id="'+id+'">'+o+'</select></div>';
  }
  if(type==='checkbox') return '<div><label style="display:flex;align-items:center;gap:.5rem;font-size:.85rem;margin-top:1.6rem"><input type="checkbox" id="'+id+'"'+(val?' checked':'')+'> '+label+'</label></div>';
  if(type==='number') return '<div><label class="form-label">'+label+'</label><input class="form-control" type="number" id="'+id+'" value="'+escapeHtml(val)+'"></div>';
  return '<div><label class="form-label">'+label+'</label><input class="form-control" id="'+id+'" value="'+escapeHtml(val)+'"></div>';
}
function _getVal(id, type) {
  var el = document.getElementById(id);
  if(!el) return null;
  if(type==='checkbox') return el.checked;
  if(type==='number') return parseFloat(el.value)||0;
  return el.value.trim();
}

// ═══════════════════════════════════════════════════════
// 📰 NEWS — full CRUD
// ═══════════════════════════════════════════════════════
function openNewsModal(id) {
  var load = id ? new Promise(function(r){sbFetch('GET','news?id=eq.'+id+'&select=*',null,function(e,d){r(e||!d||!d[0]?null:d[0]);});}) : Promise.resolve({title:'',slug:'',category:'',status:'draft',excerpt:'',content:'',img_url:'',published_at:new Date().toISOString().split('T')[0]});
  load.then(function(n){
    if(!n){toast('Олдсонгүй','error');return;}
    nmModal(id?'📰 Мэдээ засах':'📰 Шинэ мэдээ',
      '<div style="display:grid;grid-template-columns:1fr 1fr;gap:.75rem">' +
        '<div style="grid-column:1/-1">'+_crudField('Гарчиг *','nf-title',n.title)+'</div>' +
        _crudField('Slug (URL)','nf-slug',n.slug) +
        _crudField('Ангилал','nf-cat',n.category,'select',[{v:'news',l:'Мэдээ'},{v:'event',l:'Арга хэмжээ'},{v:'award',l:'Шагнал'},{v:'csr',l:'Нийгэм'}]) +
        _crudField('Статус','nf-status',n.status,'select',['draft','published','archived']) +
        _crudField('Огноо','nf-date',(n.published_at||'').split('T')[0]) +
        '<div style="grid-column:1/-1">'+_crudField('Тайлбар','nf-excerpt',n.excerpt,'textarea')+'</div>' +
        '<div style="grid-column:1/-1">'+_crudField('Агуулга (HTML)','nf-content',n.content,'textarea')+'</div>' +
        '<div style="grid-column:1/-1">'+_crudField('Зургийн URL','nf-img',n.img_url)+'</div>' +
        (n.img_url?'<div style="grid-column:1/-1;text-align:center"><img src="'+n.img_url+'" style="max-height:120px;border-radius:8px"></div>':'') +
      '</div>',
      [{label:id?'Хадгалах':'Нэмэх',cls:'btn-primary',cb:function(){saveNews(id);}},{label:'Болих',cls:'btn-secondary'}]
    );
  });
}
function saveNews(id) {
  var body = {
    title:_getVal('nf-title'), slug:_getVal('nf-slug'), category:_getVal('nf-cat'),
    status:_getVal('nf-status'), excerpt:_getVal('nf-excerpt'), content:_getVal('nf-content'),
    img_url:_getVal('nf-img'), published_at:_getVal('nf-date')||null
  };
  if(!body.title){toast('Гарчиг оруулна уу','error');return;}
  sbFetch(id?'PATCH':'POST', id?'news?id=eq.'+id:'news', body, function(err){
    if(err){toast('❌ '+err,'error');return;}
    toast('✅ '+(id?'Хадгалагдлаа':'Нэмэгдлээ'),'success');
    nmCloseModal(); loadNews();
  });
}
function deleteNews(id){if(!confirm('Устгах уу?'))return;sbFetch('DELETE','news?id=eq.'+id,null,function(e){toast(e?'❌':'✅ Устгагдлаа',e?'error':'success');if(!e)loadNews();});}

// ═══════════════════════════════════════════════════════
// 🖼 BANNERS — full CRUD
// ═══════════════════════════════════════════════════════
function openBannerModal(id) {
  var load = id ? new Promise(function(r){sbFetch('GET','banners?id=eq.'+id+'&select=*',null,function(e,d){r(e||!d||!d[0]?null:d[0]);});}) : Promise.resolve({title:'',subtitle:'',img_url:'',link_url:'',position:'home',sort_order:0,active:true});
  load.then(function(b){
    if(!b){toast('Олдсонгүй','error');return;}
    nmModal(id?'🖼 Баннер засах':'🖼 Шинэ баннер',
      '<div style="display:grid;grid-template-columns:1fr 1fr;gap:.75rem">' +
        '<div style="grid-column:1/-1">'+_crudField('Гарчиг','bf-title',b.title)+'</div>' +
        '<div style="grid-column:1/-1">'+_crudField('Дэд гарчиг','bf-sub',b.subtitle)+'</div>' +
        '<div style="grid-column:1/-1">'+_crudField('Зургийн URL *','bf-img',b.img_url)+'</div>' +
        (b.img_url?'<div style="grid-column:1/-1;text-align:center"><img src="'+b.img_url+'" style="max-height:160px;border-radius:8px"></div>':'') +
        '<div style="grid-column:1/-1">'+_crudField('Холбоос','bf-link',b.link_url)+'</div>' +
        _crudField('Байршил','bf-pos',b.position,'select',['home','news','about','careers']) +
        _crudField('Дараалал','bf-order',b.sort_order,'number') +
        _crudField('Идэвхитэй','bf-active',b.active!==false,'checkbox') +
      '</div>',
      [{label:id?'Хадгалах':'Нэмэх',cls:'btn-primary',cb:function(){saveBanner(id);}},{label:'Болих',cls:'btn-secondary'}]
    );
  });
}
function saveBanner(id){
  var body={title:_getVal('bf-title'),subtitle:_getVal('bf-sub'),img_url:_getVal('bf-img'),link_url:_getVal('bf-link'),position:_getVal('bf-pos'),sort_order:_getVal('bf-order','number'),active:_getVal('bf-active','checkbox')};
  if(!body.img_url){toast('Зургийн URL шаардлагатай','error');return;}
  sbFetch(id?'PATCH':'POST',id?'banners?id=eq.'+id:'banners',body,function(e){
    if(e){toast('❌ '+e,'error');return;}
    toast('✅ '+(id?'Хадгалагдлаа':'Нэмэгдлээ'),'success'); nmCloseModal(); loadBanners();
  });
}
function deleteBanner(id){if(!confirm('Устгах уу?'))return;sbFetch('DELETE','banners?id=eq.'+id,null,function(e){toast(e?'❌':'✅ Устгагдлаа',e?'error':'success');if(!e)loadBanners();});}

// ═══════════════════════════════════════════════════════
// 💼 JOBS — full CRUD
// ═══════════════════════════════════════════════════════
function loadJobs(){
  var el=document.getElementById('jobsGrid')||document.getElementById('jobsList')||document.getElementById('jobs-tbody');
  if(!el)return;
  el.innerHTML='<tr><td colspan="6" style="text-align:center;padding:2rem">⏳</td></tr>';
  sbFetch('GET','jobs?select=*&order=created_at.desc&limit=200',null,function(err,d){
    if(err||!Array.isArray(d)){el.innerHTML='<tr><td colspan="6" style="text-align:center;color:#94a3b8">Ажлын байр байхгүй</td></tr>';return;}
    var cnt=document.getElementById('jobs-total'); if(cnt)cnt.textContent=d.length;
    el.innerHTML=d.map(function(j,i){
      var statusColor={open:'#22c55e',closed:'#94a3b8',draft:'#f59e0b'}[j.status]||'#64748b';
      return '<tr><td>'+(i+1)+'</td><td style="font-weight:600">'+escapeHtml(j.title||'')+'</td><td>'+escapeHtml(j.department||'')+'</td><td>'+escapeHtml(j.location||'')+'</td>' +
        '<td><span style="color:'+statusColor+';font-weight:700">●</span> '+escapeHtml(j.status||'')+'</td>' +
        '<td style="text-align:center"><button class="btn btn-xs" onclick="openJobModal('+j.id+')">✏️</button> <button class="btn btn-xs btn-danger" onclick="deleteJob('+j.id+')">🗑</button></td></tr>';
    }).join('');
  });
}
function openJobModal(id){
  var load=id?new Promise(function(r){sbFetch('GET','jobs?id=eq.'+id+'&select=*',null,function(e,d){r(e||!d||!d[0]?null:d[0]);});}):Promise.resolve({title:'',department:'',location:'Улаанбаатар',type:'full_time',status:'open',description:'',requirements:'',salary:'',deadline:''});
  load.then(function(j){
    if(!j){toast('Олдсонгүй','error');return;}
    nmModal(id?'💼 Ажил засах':'💼 Шинэ ажлын байр',
      '<div style="display:grid;grid-template-columns:1fr 1fr;gap:.75rem">'+
        '<div style="grid-column:1/-1">'+_crudField('Албан тушаал *','jf-title',j.title)+'</div>'+
        _crudField('Хэлтэс','jf-dept',j.department)+
        _crudField('Байршил','jf-loc',j.location)+
        _crudField('Ажлын хэлбэр','jf-type',j.type,'select',[{v:'full_time',l:'Бүтэн цаг'},{v:'part_time',l:'Цагаар'},{v:'contract',l:'Гэрээт'},{v:'internship',l:'Дадлага'}])+
        _crudField('Статус','jf-status',j.status,'select',['open','closed','draft'])+
        _crudField('Цалин','jf-salary',j.salary)+
        _crudField('Хугацаа','jf-deadline',(j.deadline||'').split('T')[0])+
        '<div style="grid-column:1/-1">'+_crudField('Ажлын үүрэг','jf-desc',j.description,'textarea')+'</div>'+
        '<div style="grid-column:1/-1">'+_crudField('Шаардлага','jf-req',j.requirements,'textarea')+'</div>'+
      '</div>',
      [{label:id?'Хадгалах':'Нэмэх',cls:'btn-primary',cb:function(){saveJob(id);}},{label:'Болих',cls:'btn-secondary'}]);
  });
}
function saveJob(id){
  var body={title:_getVal('jf-title'),department:_getVal('jf-dept'),location:_getVal('jf-loc'),type:_getVal('jf-type'),status:_getVal('jf-status'),salary:_getVal('jf-salary'),deadline:_getVal('jf-deadline')||null,description:_getVal('jf-desc'),requirements:_getVal('jf-req')};
  if(!body.title){toast('Албан тушаал шаардлагатай','error');return;}
  sbFetch(id?'PATCH':'POST',id?'jobs?id=eq.'+id:'jobs',body,function(e){if(e){toast('❌ '+e,'error');return;}toast('✅ '+(id?'Хадгалагдлаа':'Нэмэгдлээ'),'success');nmCloseModal();loadJobs();});
}
function deleteJob(id){if(!confirm('Устгах уу?'))return;sbFetch('DELETE','jobs?id=eq.'+id,null,function(e){toast(e?'❌':'✅ Устгагдлаа',e?'error':'success');if(!e)loadJobs();});}

// ═══════════════════════════════════════════════════════
// 📋 TENDER — full CRUD
// ═══════════════════════════════════════════════════════
function loadTender(){
  var el=document.getElementById('tenders-tbody')||document.getElementById('tenderList');
  if(!el)return;
  el.innerHTML='<tr><td colspan="6" style="text-align:center;padding:2rem">⏳</td></tr>';
  sbFetch('GET','tenders?select=*&order=created_at.desc',null,function(err,d){
    if(err||!Array.isArray(d)){el.innerHTML='<tr><td colspan="6" style="text-align:center;color:#94a3b8">Тендер байхгүй</td></tr>';return;}
    var cnt=document.getElementById('tenders-total'); if(cnt)cnt.textContent=d.length;
    el.innerHTML=d.map(function(t,i){
      return '<tr><td>'+(i+1)+'</td><td style="font-weight:600">'+escapeHtml(t.title||'')+'</td><td>'+escapeHtml(t.category||'')+'</td>' +
        '<td>'+escapeHtml((t.deadline||'').split('T')[0])+'</td>' +
        '<td>'+escapeHtml(t.status||'')+'</td>' +
        '<td style="text-align:center"><button class="btn btn-xs" onclick="openTenderModal('+t.id+')">✏️</button> <button class="btn btn-xs btn-danger" onclick="deleteTender('+t.id+')">🗑</button></td></tr>';
    }).join('');
  });
}
function openTenderModal(id){
  var load=id?new Promise(function(r){sbFetch('GET','tenders?id=eq.'+id+'&select=*',null,function(e,d){r(e||!d||!d[0]?null:d[0]);});}):Promise.resolve({title:'',category:'',description:'',requirements:'',status:'open',deadline:'',contact_email:'',budget:''});
  load.then(function(t){
    if(!t){toast('Олдсонгүй','error');return;}
    nmModal(id?'📋 Тендер засах':'📋 Шинэ тендер',
      '<div style="display:grid;grid-template-columns:1fr 1fr;gap:.75rem">'+
        '<div style="grid-column:1/-1">'+_crudField('Гарчиг *','tf-title',t.title)+'</div>'+
        _crudField('Ангилал','tf-cat',t.category)+
        _crudField('Статус','tf-status',t.status,'select',['open','closed','awarded'])+
        _crudField('Хугацаа','tf-deadline',(t.deadline||'').split('T')[0])+
        _crudField('Төсөв','tf-budget',t.budget)+
        '<div style="grid-column:1/-1">'+_crudField('Имэйл','tf-email',t.contact_email)+'</div>'+
        '<div style="grid-column:1/-1">'+_crudField('Тайлбар','tf-desc',t.description,'textarea')+'</div>'+
        '<div style="grid-column:1/-1">'+_crudField('Шаардлага','tf-req',t.requirements,'textarea')+'</div>'+
      '</div>',
      [{label:id?'Хадгалах':'Нэмэх',cls:'btn-primary',cb:function(){saveTender(id);}},{label:'Болих',cls:'btn-secondary'}]);
  });
}
function saveTender(id){
  var body={title:_getVal('tf-title'),category:_getVal('tf-cat'),status:_getVal('tf-status'),deadline:_getVal('tf-deadline')||null,budget:_getVal('tf-budget'),contact_email:_getVal('tf-email'),description:_getVal('tf-desc'),requirements:_getVal('tf-req')};
  if(!body.title){toast('Гарчиг шаардлагатай','error');return;}
  sbFetch(id?'PATCH':'POST',id?'tenders?id=eq.'+id:'tenders',body,function(e){if(e){toast('❌ '+e,'error');return;}toast('✅','success');nmCloseModal();loadTender();});
}
function deleteTender(id){if(!confirm('Устгах уу?'))return;sbFetch('DELETE','tenders?id=eq.'+id,null,function(e){toast(e?'❌':'✅ Устгагдлаа',e?'error':'success');if(!e)loadTender();});}

// ═══════════════════════════════════════════════════════
// 📄 PAGES — full CRUD
// ═══════════════════════════════════════════════════════
function openPageModal(id) {
  var load=id?new Promise(function(r){sbFetch('GET','pages?id=eq.'+id+'&select=*',null,function(e,d){r(e||!d||!d[0]?null:d[0]);});}):Promise.resolve({slug:'',title:'',meta_description:'',content:'',status:'published'});
  load.then(function(p){
    if(!p){toast('Олдсонгүй','error');return;}
    nmModal(id?'📄 Хуудас засах':'📄 Шинэ хуудас',
      '<div style="display:grid;grid-template-columns:1fr 1fr;gap:.75rem">'+
        _crudField('Slug *','pf-slug',p.slug)+
        _crudField('Статус','pf-status',p.status,'select',['published','draft','archived'])+
        '<div style="grid-column:1/-1">'+_crudField('Title','pf-title',p.title)+'</div>'+
        '<div style="grid-column:1/-1">'+_crudField('Meta description','pf-meta',p.meta_description,'textarea')+'</div>'+
        '<div style="grid-column:1/-1">'+_crudField('Агуулга (HTML/Markdown)','pf-content',p.content,'textarea')+'</div>'+
      '</div>',
      [{label:id?'Хадгалах':'Нэмэх',cls:'btn-primary',cb:function(){savePage(id);}},{label:'Болих',cls:'btn-secondary'}]);
  });
}
function savePage(id){
  var body={slug:_getVal('pf-slug'),title:_getVal('pf-title'),meta_description:_getVal('pf-meta'),content:_getVal('pf-content'),status:_getVal('pf-status')};
  if(!body.slug){toast('Slug шаардлагатай','error');return;}
  sbFetch(id?'PATCH':'POST',id?'pages?id=eq.'+id:'pages',body,function(e){if(e){toast('❌ '+e,'error');return;}toast('✅','success');nmCloseModal();loadPages();});
}
function deletePage(id){if(!confirm('Устгах уу?'))return;sbFetch('DELETE','pages?id=eq.'+id,null,function(e){toast(e?'❌':'✅ Устгагдлаа',e?'error':'success');if(!e)loadPages();});}

// ═══════════════════════════════════════════════════════
// 👤 USERS — full CRUD
// ═══════════════════════════════════════════════════════
// ═══════════════════════════════════════════════════════
// 👥 USERS — Soft Delete + Архив + Сэргээх
// ═══════════════════════════════════════════════════════
var _usersView = 'active'; // 'active' эсвэл 'archived'

function switchUsersView(view){
  _usersView = view;
  // Tab-уудыг update хийх
  var tActive = document.getElementById('users-tab-active');
  var tArchived = document.getElementById('users-tab-archived');
  if(tActive && tArchived){
    tActive.style.cssText = view==='active' 
      ? 'padding:.55rem 1rem;background:none;border:none;font-weight:700;font-size:.85rem;cursor:pointer;color:#0f172a;border-bottom:2px solid #2a4fca;margin-bottom:-2px'
      : 'padding:.55rem 1rem;background:none;border:none;font-weight:600;font-size:.85rem;cursor:pointer;color:#64748b;border-bottom:2px solid transparent;margin-bottom:-2px';
    tArchived.style.cssText = view==='archived'
      ? 'padding:.55rem 1rem;background:none;border:none;font-weight:700;font-size:.85rem;cursor:pointer;color:#0f172a;border-bottom:2px solid #2a4fca;margin-bottom:-2px'
      : 'padding:.55rem 1rem;background:none;border:none;font-weight:600;font-size:.85rem;cursor:pointer;color:#64748b;border-bottom:2px solid transparent;margin-bottom:-2px';
  }
  loadUsers();
}

function loadUsers(){
  var el=document.getElementById('users-tbody')||document.getElementById('usersList')||document.getElementById('uTbody');
  if(!el)return;
  
  // Tab UI-г эхлээд байгуулах (хэрэв байхгүй бол)
  var toolbar = el.closest('.panel') ? el.closest('.panel').querySelector('.toolbar') : null;
  if(toolbar && !document.getElementById('users-tab-active')){
    var tabHtml = '<div style="display:flex;gap:0;border-bottom:2px solid #e8ecf2;margin-right:auto">' +
      '<button id="users-tab-active" onclick="switchUsersView(\'active\')" style="padding:.55rem 1rem;background:none;border:none;font-weight:700;font-size:.85rem;cursor:pointer;color:#0f172a;border-bottom:2px solid #2a4fca;margin-bottom:-2px">✓ Идэвхтэй <span id="users-count-active" style="background:#dcfce7;color:#166534;padding:1px 6px;border-radius:8px;font-size:.68rem;margin-left:.3rem">—</span></button>' +
      '<button id="users-tab-archived" onclick="switchUsersView(\'archived\')" style="padding:.55rem 1rem;background:none;border:none;font-weight:600;font-size:.85rem;cursor:pointer;color:#64748b;border-bottom:2px solid transparent;margin-bottom:-2px">🗄 Архив <span id="users-count-archived" style="background:#fee2e2;color:#991b1b;padding:1px 6px;border-radius:8px;font-size:.68rem;margin-left:.3rem">—</span></button>' +
      '</div>';
    toolbar.insertAdjacentHTML('afterbegin', tabHtml);
  }
  
  el.innerHTML='<tr><td colspan="5" style="text-align:center;padding:2rem">⏳ Ачаалж байна...</td></tr>';
  
  // Бүх хэрэглэгчийг татна (active + archived)
  sbFetch('GET','users?select=*&order=created_at.desc',null,function(err,d){
    if(err||!Array.isArray(d)){
      el.innerHTML='<tr><td colspan="5" style="text-align:center;color:#94a3b8;padding:2rem">Хэрэглэгч байхгүй</td></tr>';
      return;
    }
    
    // Active болон Archived хуваах (archived_at байвал архив)
    var active = d.filter(function(u){ return !u.archived_at; });
    var archived = d.filter(function(u){ return !!u.archived_at; });
    
    // Tab counter-үүд шинэчлэх
    var cActive = document.getElementById('users-count-active');
    var cArchived = document.getElementById('users-count-archived');
    if(cActive) cActive.textContent = active.length;
    if(cArchived) cArchived.textContent = archived.length;
    
    var cnt=document.getElementById('users-total');
    if(cnt) cnt.textContent = _usersView==='active' ? active.length : archived.length;
    
    var list = _usersView==='archived' ? archived : active;
    
    if(list.length===0){
      el.innerHTML='<tr><td colspan="5" style="text-align:center;color:#94a3b8;padding:3rem">'+
        (_usersView==='archived' 
          ? '🗄 Архивт хэрэглэгч байхгүй'
          : 'Хэрэглэгч байхгүй. <button class="btn btn-xs btn-primary" onclick="openUM&&openUM()" style="margin-left:.5rem">+ Нэмэх</button>')
        +'</td></tr>';
      return;
    }
    
    el.innerHTML=list.map(function(u){
      var lastLogin = u.last_login_at ? new Date(u.last_login_at).toLocaleDateString('mn-MN') : '—';
      var archivedDate = u.archived_at ? new Date(u.archived_at).toLocaleDateString('mn-MN') : '';
      var initials = (u.name||u.email||'?').substring(0,1).toUpperCase();
      var isArchived = !!u.archived_at;
      
      var actions = isArchived 
        ? '<button class="btn btn-sm" style="background:#16a34a;color:#fff;border:none" onclick="restoreUser('+u.id+')" title="Сэргээх">↩️ Сэргээх</button> <button class="btn btn-sm btn-danger" onclick="permanentDeleteUser('+u.id+',\''+escapeHtml(u.email||'')+'\')" title="Бүр устгах">🗑</button>'
        : '<button class="btn btn-sm" onclick="openUserModal('+u.id+')" title="Засах">✏️</button> <button class="btn btn-sm" style="background:#f59e0b;color:#fff;border:none" onclick="archiveUser('+u.id+')" title="Архивлах">🗄</button>';
      
      return '<tr' + (isArchived ? ' style="opacity:.7;background:#fef3c7"' : '') + '>' +
        '<td><div style="display:flex;align-items:center;gap:.5rem"><div style="width:28px;height:28px;border-radius:50%;background:'+(isArchived?'#94a3b8':'linear-gradient(135deg,#1a2f7a,#2a4fca)')+';color:#fff;display:flex;align-items:center;justify-content:center;font-weight:700;font-size:.75rem">'+initials+'</div><div><div style="font-weight:600">'+escapeHtml(u.name||'—')+'</div>'+
        (isArchived 
          ? '<span style="font-size:.65rem;color:#f59e0b">🗄 Архивласан '+archivedDate+'</span>'
          : (u.active===false?'<span style="font-size:.65rem;color:#ef4444">● Идэвхгүй</span>':'<span style="font-size:.65rem;color:#22c55e">● Идэвхтэй</span>'))
        +'</div></div></td>' +
        '<td>'+escapeHtml(u.email||'')+'</td>' +
        '<td><span style="background:'+(u.role==='admin'?'#dbeafe':u.role==='editor'?'#dcfce7':u.role==='publisher'?'#f3e8ff':'#f1f5f9')+';color:'+(u.role==='admin'?'#1e40af':u.role==='editor'?'#166534':u.role==='publisher'?'#6b21a8':'#475569')+';padding:2px 10px;border-radius:12px;font-size:.72rem;font-weight:700">'+escapeHtml(u.role||'viewer')+'</span></td>' +
        '<td style="font-size:.78rem;color:#64748b">'+lastLogin+'</td>' +
        '<td style="text-align:center;white-space:nowrap">'+actions+'</td>' +
      '</tr>';
    }).join('');
  });
}

function openUserModal(id){
  var load=id?new Promise(function(r){sbFetch('GET','users?id=eq.'+id+'&select=*',null,function(e,d){r(e||!d||!d[0]?null:d[0]);});}):Promise.resolve({name:'',email:'',role:'editor',active:true});
  load.then(function(u){
    if(!u){toast('Олдсонгүй','error');return;}
    nmModal(id?'👤 Хэрэглэгч засах':'👤 Шинэ хэрэглэгч',
      '<div style="display:grid;grid-template-columns:1fr 1fr;gap:.75rem">'+
        '<div style="grid-column:1/-1">'+_crudField('Нэр *','uf-name',u.name)+'</div>'+
        '<div style="grid-column:1/-1">'+_crudField('Имэйл *','uf-email',u.email)+'</div>'+
        _crudField('Эрх','uf-role',u.role,'select',[{v:'admin',l:'Админ'},{v:'editor',l:'Редактор'},{v:'publisher',l:'Нийтлэгч'},{v:'viewer',l:'Уншигч'}])+
        _crudField('Идэвхитэй','uf-active',u.active!==false,'checkbox')+
        // 🔐 НУУЦ ҮГ СОЛИХ ТАЛБАР
        '<div style="grid-column:1/-1;margin-top:.75rem;padding-top:.75rem;border-top:1px solid #e2e8f0">'+
          '<label style="display:flex;align-items:center;gap:.5rem;font-weight:600;font-size:.85rem;color:#1a2f7a;margin-bottom:.5rem">'+
            '🔐 Нууц үг солих'+
            '<span style="font-size:.7rem;color:#94a3b8;font-weight:400">(хоосон орхивол өөрчлөгдөхгүй)</span>'+
          '</label>'+
          '<div style="display:flex;gap:.5rem;align-items:stretch">'+
            '<input type="text" id="uf-pwd" class="form-control" placeholder="Шинэ нууц үг..." autocomplete="new-password" style="flex:1;font-family:monospace">'+
            '<button type="button" class="btn btn-sm" style="background:#f59e0b;color:#fff;border:none;white-space:nowrap" onclick="generatePassword()" title="Random нууц үг үүсгэх">🎲 Random</button>'+
          '</div>'+
          '<div id="uf-pwd-strength" style="font-size:.7rem;margin-top:.35rem;color:#94a3b8"></div>'+
        '</div>'+
      '</div>',
      [{label:id?'Хадгалах':'Нэмэх',cls:'btn-primary',cb:function(){saveUser(id);}},{label:'Болих',cls:'btn-secondary'}]);
    
    // Password strength indicator
    setTimeout(function(){
      var pwd = document.getElementById('uf-pwd');
      if(pwd) pwd.addEventListener('input', function(){ checkPasswordStrength(this.value); });
    }, 100);
  });
}

// 🎲 Санамсаргүй нууц үг үүсгэх
function generatePassword(){
  var len = 14;
  var upper = 'ABCDEFGHJKLMNPQRSTUVWXYZ';
  var lower = 'abcdefghjkmnpqrstuvwxyz';
  var nums = '23456789';
  var syms = '!@#$%&*';
  var all = upper + lower + nums + syms;
  var pwd = '';
  // Minimum 1 of each
  pwd += upper[Math.floor(Math.random()*upper.length)];
  pwd += lower[Math.floor(Math.random()*lower.length)];
  pwd += nums[Math.floor(Math.random()*nums.length)];
  pwd += syms[Math.floor(Math.random()*syms.length)];
  // Fill rest
  for(var i=4;i<len;i++) pwd += all[Math.floor(Math.random()*all.length)];
  // Shuffle
  pwd = pwd.split('').sort(function(){return Math.random()-0.5;}).join('');
  
  var el = document.getElementById('uf-pwd');
  if(el){ el.value = pwd; checkPasswordStrength(pwd); }
  // Clipboard-д хуулах
  if(navigator.clipboard){
    navigator.clipboard.writeText(pwd).then(function(){
      toast('🎲 Нууц үг үүсгэгдсэн + clipboard-д хуулагдсан','success');
    });
  } else {
    toast('🎲 Нууц үг үүсгэгдсэн','success');
  }
}

// 💪 Нууц үгийн хүч шалгах
function checkPasswordStrength(pwd){
  var el = document.getElementById('uf-pwd-strength');
  if(!el) return;
  if(!pwd){ el.innerHTML = ''; return; }
  var score = 0;
  var issues = [];
  if(pwd.length >= 8) score++; else issues.push('8+ тэмдэгт');
  if(pwd.length >= 12) score++;
  if(/[A-Z]/.test(pwd)) score++; else issues.push('том үсэг');
  if(/[a-z]/.test(pwd)) score++; else issues.push('жижиг үсэг');
  if(/[0-9]/.test(pwd)) score++; else issues.push('тоо');
  if(/[^A-Za-z0-9]/.test(pwd)) score++; else issues.push('тусгай тэмдэгт');
  
  var levels = [
    {min:0, text:'Маш сул', color:'#ef4444'},
    {min:2, text:'Сул', color:'#f59e0b'},
    {min:4, text:'Дунд', color:'#eab308'},
    {min:5, text:'Хүчтэй', color:'#22c55e'},
    {min:6, text:'Маш хүчтэй', color:'#10b981'}
  ];
  var level = levels[0];
  for(var i=levels.length-1;i>=0;i--){
    if(score >= levels[i].min){ level = levels[i]; break; }
  }
  el.innerHTML = '<span style="color:'+level.color+';font-weight:600">'+level.text+'</span>' +
    (issues.length ? ' · Дутуу: ' + issues.join(', ') : '');
}

function saveUser(id){
  var body={name:_getVal('uf-name'),email:_getVal('uf-email'),role:_getVal('uf-role'),active:_getVal('uf-active','checkbox')};
  if(!body.name||!body.email){toast('Нэр, имэйл шаардлагатай','error');return;}
  
  var newPwd = _getVal('uf-pwd');
  
  sbFetch(id?'PATCH':'POST',id?'users?id=eq.'+id:'users',body,function(e){
    if(e){toast('❌ '+e,'error');return;}
    
    // Хэрэв нууц үг оруулсан бол Supabase Auth-д солих
    if(newPwd && newPwd.length >= 6){
      resetUserPassword(body.email, newPwd, function(pe){
        if(pe){
          toast('⚠️ Хэрэглэгч хадгалагдсан, гэхдээ нууц үг солигдсонгүй: '+pe,'error');
        } else {
          toast('✅ Хэрэглэгч + нууц үг шинэчлэгдсэн','success');
        }
        nmCloseModal();
        loadUsers();
      });
    } else {
      toast('✅ Хадгалагдлаа','success');
      nmCloseModal();
      loadUsers();
    }
  });
}

// 🔐 Supabase Auth API ашиглан нууц үг солих
function resetUserPassword(email, newPwd, cb){
  // Supabase admin API нь service_role key шаарддаг
  // Энэ нь клиент талд хадгалах боломжгүй тул SQL RPC хийдэг
  var SB = 'https://hunygqumohxinhndrcph.supabase.co';
  var KEY = window.__NM_SB_KEY__ || 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6Imh1bnlncXVtb2h4aW5obmRyY3BoIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NzQzNTA4NjMsImV4cCI6MjA4OTkyNjg2M30.2eFxPABgxosblHajh85txP_yrv0VsDCbhxSVIcO3T88';
  
  // Edge function-г дуудаж нууц үг солих
  fetch('/api/reset-password', {
    method: 'POST',
    headers: {'Content-Type': 'application/json'},
    body: JSON.stringify({ email: email, new_password: newPwd })
  })
  .then(function(r){ return r.json(); })
  .then(function(d){
    if(d.error) return cb(d.error);
    cb(null);
  })
  .catch(function(e){ cb(e.message || 'Network алдаа'); });
}

// 🗄 АРХИВЛАХ (soft delete) — archived_at талбарт огноо тавина
function archiveUser(id){
  if(!confirm('Энэ хэрэглэгчийг архивлах уу?\n\nАрхивт шилжсэн хэрэглэгч нэвтрэх боломжгүй болно,\nгэхдээ дараа нь сэргээх боломжтой.')) return;
  
  sbFetch('PATCH','users?id=eq.'+id,{archived_at:new Date().toISOString(),active:false},function(e){
    if(e){ toast('❌ '+e,'error'); return; }
    toast('🗄 Архивлагдсан — "Архив" tab-д харагдана','success');
    loadUsers();
  });
}

// ↩️ СЭРГЭЭХ — archived_at талбарыг хоослоно
function restoreUser(id){
  if(!confirm('Энэ хэрэглэгчийг сэргээх үү?\n\n"Идэвхтэй" жагсаалтад буцаж орно.')) return;
  
  sbFetch('PATCH','users?id=eq.'+id,{archived_at:null,active:true},function(e){
    if(e){ toast('❌ '+e,'error'); return; }
    toast('↩️ Сэргэв','success');
    loadUsers();
  });
}

// 🗑 БҮР УСТГАХ — зөвхөн архивт байгаа хэрэглэгчийг
function permanentDeleteUser(id, email){
  var confirmText = 'Энэ хэрэглэгчийг БҮР УСТГАХ уу?\n\n'+
    'Email: '+email+'\n\n'+
    '⚠️  АНХААР: Устгасны дараа сэргээх боломжгүй!\n\n'+
    'Үргэлжлүүлэхийн тулд "УСТГАХ" гэж бичнэ үү:';
  var answer = prompt(confirmText);
  if(answer !== 'УСТГАХ'){
    toast('Цуцлагдлаа','error');
    return;
  }
  
  sbFetch('DELETE','users?id=eq.'+id,null,function(e){
    if(e){ toast('❌ '+e,'error'); return; }
    toast('🗑 Бүр устгагдсан','success');
    loadUsers();
  });
}

// Хуучин deleteUser-г архивлах руу чиглүүлнэ (backward compat)
function deleteUser(id){ archiveUser(id); }

// ═══════════════════════════════════════════════════════
// 🚚 SUPPLIERS, ✉️ CONTACTS — inline list load fallbacks
// ═══════════════════════════════════════════════════════
function loadSuppliers(){
  var el=document.getElementById('suppliers-tbody')||document.getElementById('supList');
  if(!el)return;
  sbFetch('GET','suppliers?select=*&order=created_at.desc&limit=200',null,function(err,d){
    if(err||!Array.isArray(d)){el.innerHTML='<tr><td colspan="7" style="text-align:center;color:#94a3b8">Байхгүй</td></tr>';return;}
    var cnt=document.getElementById('sup-total'); if(cnt)cnt.textContent=d.length;
    el.innerHTML=d.map(function(s,i){
      var sc={new:'#f59e0b',reviewed:'#3b82f6',approved:'#22c55e',rejected:'#ef4444'}[s.status]||'#64748b';
      return '<tr><td>'+(i+1)+'</td><td style="font-weight:600">'+escapeHtml(s.company_name||s.company||'')+'</td>' +
        '<td>'+escapeHtml(s.contact_name||s.contact||'')+'</td>' +
        '<td>'+escapeHtml(s.phone||'')+'</td><td>'+escapeHtml(s.email||'')+'</td>' +
        '<td><span style="color:'+sc+';font-weight:700">●</span> '+escapeHtml(s.status||'new')+'</td>' +
        '<td style="text-align:center"><button class="btn btn-xs" onclick="openSupplierModal('+s.id+')">✏️</button> <button class="btn btn-xs btn-danger" onclick="deleteSupplier('+s.id+')">🗑</button></td></tr>';
    }).join('');
  });
}
function openSupplierModal(id){
  var load=id?new Promise(function(r){sbFetch('GET','suppliers?id=eq.'+id+'&select=*',null,function(e,d){r(e||!d||!d[0]?null:d[0]);});}):Promise.resolve({company_name:'',contact_name:'',phone:'',email:'',category:'',note:'',status:'new'});
  load.then(function(s){
    if(!s){toast('Олдсонгүй','error');return;}
    nmModal(id?'🚚 Нийлүүлэгч':'🚚 Шинэ нийлүүлэгч',
      '<div style="display:grid;grid-template-columns:1fr 1fr;gap:.75rem">'+
        '<div style="grid-column:1/-1">'+_crudField('Компани *','supf-comp',s.company_name||s.company)+'</div>'+
        _crudField('Хариуцсан','supf-contact',s.contact_name||s.contact)+
        _crudField('Утас','supf-phone',s.phone)+
        _crudField('Имэйл','supf-email',s.email)+
        _crudField('Ангилал','supf-cat',s.category)+
        _crudField('Статус','supf-status',s.status||'new','select',['new','reviewed','approved','rejected'])+
        '<div style="grid-column:1/-1">'+_crudField('Тэмдэглэл','supf-note',s.note,'textarea')+'</div>'+
      '</div>',
      [{label:id?'Хадгалах':'Нэмэх',cls:'btn-primary',cb:function(){saveSupplier(id);}},{label:'Болих',cls:'btn-secondary'}]);
  });
}
function saveSupplier(id){
  var body={company_name:_getVal('supf-comp'),contact_name:_getVal('supf-contact'),phone:_getVal('supf-phone'),email:_getVal('supf-email'),category:_getVal('supf-cat'),status:_getVal('supf-status'),note:_getVal('supf-note')};
  if(!body.company_name){toast('Компани шаардлагатай','error');return;}
  sbFetch(id?'PATCH':'POST',id?'suppliers?id=eq.'+id:'suppliers',body,function(e){if(e){toast('❌ '+e,'error');return;}toast('✅','success');nmCloseModal();loadSuppliers();});
}
function deleteSupplier(id){if(!confirm('Устгах уу?'))return;sbFetch('DELETE','suppliers?id=eq.'+id,null,function(e){toast(e?'❌':'✅ Устгагдлаа',e?'error':'success');if(!e)loadSuppliers();});}

// ═══════════════════════════════════════════════════════
// 🗂 MENU — edit modal
// ═══════════════════════════════════════════════════════
function openMenuItemModal(id){
  var load=id?new Promise(function(r){sbFetch('GET','menu?id=eq.'+id+'&select=*',null,function(e,d){r(e||!d||!d[0]?null:d[0]);});}):Promise.resolve({label:'',url:'',icon:'',location:'header',sort_order:0,external:false});
  load.then(function(m){
    if(!m){toast('Олдсонгүй','error');return;}
    nmModal(id?'🗂 Цэс засах':'🗂 Шинэ цэс',
      '<div style="display:grid;grid-template-columns:1fr 1fr;gap:.75rem">'+
        '<div style="grid-column:1/-1">'+_crudField('Нэр *','mf-label',m.label)+'</div>'+
        '<div style="grid-column:1/-1">'+_crudField('URL *','mf-url',m.url)+'</div>'+
        _crudField('Emoji','mf-icon',m.icon)+
        _crudField('Байршил','mf-loc',m.location,'select',['header','footer','util','dropdown'])+
        _crudField('Дараалал','mf-order',m.sort_order,'number')+
        _crudField('Гадна холбоос','mf-ext',m.external,'checkbox')+
      '</div>',
      [{label:id?'Хадгалах':'Нэмэх',cls:'btn-primary',cb:function(){saveMenuEntry(id);}},{label:'Болих',cls:'btn-secondary'}]);
  });
}
function saveMenuEntry(id){
  var body={label:_getVal('mf-label'),url:_getVal('mf-url'),icon:_getVal('mf-icon'),location:_getVal('mf-loc'),sort_order:_getVal('mf-order','number'),external:_getVal('mf-ext','checkbox')};
  if(!body.label||!body.url){toast('Нэр, URL шаардлагатай','error');return;}
  sbFetch(id?'PATCH':'POST',id?'menu?id=eq.'+id:'menu',body,function(e){if(e){toast('❌ '+e,'error');return;}toast('✅','success');nmCloseModal();if(typeof loadMenu==='function')loadMenu();else if(typeof renderMenuLists==='function')renderMenuLists();});
}
function deleteMenuEntry(id){if(!confirm('Устгах уу?'))return;sbFetch('DELETE','menu?id=eq.'+id,null,function(e){toast(e?'❌':'✅','success');if(!e&&typeof loadMenu==='function')loadMenu();});}

// ═══════════════════════════════════════════════════════
// 📚 CATALOGUE — improved PDF upload
// ═══════════════════════════════════════════════════════
function loadCatalogueUI(){
  var langs=['mn','en','ru','zh'];
  sbFetch('GET','settings?select=key,value&key=in.(catalogue_mn_url,catalogue_en_url,catalogue_ru_url,catalogue_zh_url)',null,function(err,rows){
    var map={};
    if(!err&&Array.isArray(rows))rows.forEach(function(r){map[r.key]=r.value;});
    langs.forEach(function(l){
      var st=document.getElementById('cat-'+l+'-status');
      var url=map['catalogue_'+l+'_url'];
      if(st){
        st.innerHTML = url
          ? '<span style="color:#22c55e">✓ Хадгалсан:</span> <a href="'+url+'" target="_blank" style="color:#3b82f6;word-break:break-all">'+url+'</a>'
          : '<span style="color:#94a3b8">— Байхгүй —</span>';
      }
    });
  });
}

// ═══════════════════════════════════════════════════════
// 🗂 MEDIA — Supabase Storage upload
// ═══════════════════════════════════════════════════════
function uploadMedia(inputId,folder){
  var inp=document.getElementById(inputId||'mediaUpload');
  if(!inp||!inp.files||!inp.files[0]){toast('Файл сонгоно уу','error');return;}
  var file=inp.files[0];
  var url=(window.__NM_SB_URL__||'https://hunygqumohxinhndrcph.supabase.co')+'/storage/v1/object/media/'+(folder||'uploads')+'/'+Date.now()+'_'+file.name.replace(/[^a-zA-Z0-9._-]/g,'_');
  var key=window.__NM_SB_KEY__||'';
  var sess=JSON.parse(localStorage.getItem('nm_sess')||'{}');
  var jwt=sess.token||key;
  fetch(url,{method:'POST',headers:{'Authorization':'Bearer '+jwt,'Content-Type':file.type||'application/octet-stream'},body:file})
    .then(function(r){return r.ok?r.json():r.text().then(function(t){throw new Error(t);});})
    .then(function(d){
      var publicUrl=(window.__NM_SB_URL__||'https://hunygqumohxinhndrcph.supabase.co')+'/storage/v1/object/public/media/'+(folder||'uploads')+'/'+url.split('/').pop();
      toast('✅ Хуулагдлаа','success');
      if(typeof renderMedia==='function')renderMedia();
      navigator.clipboard && navigator.clipboard.writeText(publicUrl);
    }).catch(function(e){toast('❌ '+e.message,'error');});
}

// ═══════════════════════════════════════════════════════
// 🌐 TRANSLATIONS — add/edit/delete row
// ═══════════════════════════════════════════════════════
function addTranslation(){
  nmModal('🌐 Шинэ орчуулга',
    '<div style="display:grid;grid-template-columns:1fr 1fr;gap:.75rem">'+
      '<div style="grid-column:1/-1">'+_crudField('Key *','tf-key','')+'</div>'+
      '<div style="grid-column:1/-1">'+_crudField('Монгол','tf-mn','')+'</div>'+
      '<div style="grid-column:1/-1">'+_crudField('English','tf-en','')+'</div>'+
      '<div style="grid-column:1/-1">'+_crudField('Русский','tf-ru','')+'</div>'+
      '<div style="grid-column:1/-1">'+_crudField('中文','tf-zh','')+'</div>'+
    '</div>',
    [{label:'Нэмэх',cls:'btn-primary',cb:saveTranslation},{label:'Болих',cls:'btn-secondary'}]);
}
function saveTranslation(){
  var body={key:_getVal('tf-key'),mn:_getVal('tf-mn'),en:_getVal('tf-en'),ru:_getVal('tf-ru'),zh:_getVal('tf-zh')};
  if(!body.key){toast('Key шаардлагатай','error');return;}
  sbFetch('POST','translations',body,function(e){if(e){toast('❌ '+e,'error');return;}toast('✅','success');nmCloseModal();if(typeof renderTransTable==='function')renderTransTable();});
}

// ═══════════════════════════════════════════════════════
// 🧩 BLOCKS — reusable content blocks
// ═══════════════════════════════════════════════════════
function loadBlocks(){
  var el=document.getElementById('blocks-grid')||document.getElementById('blocksList');
  if(!el)return;
  sbFetch('GET','blocks?select=*&order=name.asc',null,function(err,d){
    if(err||!Array.isArray(d)){el.innerHTML='<div style="text-align:center;color:#94a3b8;padding:2rem">Блок байхгүй</div>';return;}
    el.innerHTML=d.map(function(b){
      return '<div style="background:#fff;border:1px solid #e2e8f0;border-radius:10px;padding:1rem;margin-bottom:.5rem">' +
        '<div style="display:flex;justify-content:space-between;align-items:center">' +
        '<div><strong>'+escapeHtml(b.name||'')+'</strong> <span style="font-size:.7rem;color:#64748b">'+escapeHtml(b.type||'')+'</span></div>' +
        '<div><button class="btn btn-xs" onclick="openBlockModal('+b.id+')">✏️</button> <button class="btn btn-xs btn-danger" onclick="deleteBlock('+b.id+')">🗑</button></div>' +
        '</div></div>';
    }).join('');
  });
}
function openBlockModal(id){
  var load=id?new Promise(function(r){sbFetch('GET','blocks?id=eq.'+id+'&select=*',null,function(e,d){r(e||!d||!d[0]?null:d[0]);});}):Promise.resolve({name:'',type:'text',data:'{}'});
  load.then(function(b){
    if(!b){toast('Олдсонгүй','error');return;}
    nmModal(id?'🧩 Блок засах':'🧩 Шинэ блок',
      '<div style="display:grid;grid-template-columns:1fr 1fr;gap:.75rem">'+
        '<div style="grid-column:1/-1">'+_crudField('Нэр *','blkf-name',b.name)+'</div>'+
        _crudField('Төрөл','blkf-type',b.type,'select',['text','image','video','cta','hero','stats','testimonial'])+
        '<div style="grid-column:1/-1">'+_crudField('Data (JSON)','blkf-data',typeof b.data==='object'?JSON.stringify(b.data,null,2):b.data,'textarea')+'</div>'+
      '</div>',
      [{label:id?'Хадгалах':'Нэмэх',cls:'btn-primary',cb:function(){saveBlock(id);}},{label:'Болих',cls:'btn-secondary'}]);
  });
}
function saveBlock(id){
  var dataStr=_getVal('blkf-data')||'{}';
  var data;
  try{data=JSON.parse(dataStr);}catch(e){toast('JSON буруу: '+e.message,'error');return;}
  var body={name:_getVal('blkf-name'),type:_getVal('blkf-type'),data:data};
  if(!body.name){toast('Нэр шаардлагатай','error');return;}
  sbFetch(id?'PATCH':'POST',id?'blocks?id=eq.'+id:'blocks',body,function(e){if(e){toast('❌ '+e,'error');return;}toast('✅','success');nmCloseModal();loadBlocks();});
}
function deleteBlock(id){if(!confirm('Устгах уу?'))return;sbFetch('DELETE','blocks?id=eq.'+id,null,function(e){toast(e?'❌':'✅','success');if(!e)loadBlocks();});}

// ═══════════════════════════════════════════════════════
// 🏗 BUILDER (layouts) — simple save
// ═══════════════════════════════════════════════════════
function loadLayouts(){
  var el=document.getElementById('builderCanvas')||document.getElementById('layouts-list');
  if(!el)return;
  sbFetch('GET','layouts?select=*&order=updated_at.desc.nullslast',null,function(err,d){
    if(err||!Array.isArray(d)||!d.length){el.innerHTML='<div style="text-align:center;color:#94a3b8;padding:2rem">Layout байхгүй. <button class="btn btn-primary btn-sm" onclick="newLayout()">Шинэ үүсгэх</button></div>';return;}
    el.innerHTML=d.map(function(l){
      return '<div style="background:#fff;border:1px solid #e2e8f0;border-radius:10px;padding:1rem;margin-bottom:.5rem">'+
        '<strong>'+escapeHtml(l.name||l.page||'')+'</strong>'+
        '<div style="font-size:.75rem;color:#64748b">Зонууд: '+(Array.isArray(l.zones)?l.zones.length:0)+'</div>'+
        '<button class="btn btn-xs" onclick="editLayout('+l.id+')">✏️ Засах</button>'+
      '</div>';
    }).join('');
  });
}
function newLayout(){sbFetch('POST','layouts',{name:'Шинэ layout','page':'home',zones:[]},function(e){if(e){toast('❌ '+e,'error');return;}toast('✅ Үүсгэгдлээ','success');loadLayouts();});}
function editLayout(id){toast('Layout editor удахгүй орно','info');}

// ═══════════════════════════════════════════════════════
// 📧 REPORTS — monthly report sending
// ═══════════════════════════════════════════════════════
function loadReports(){
  var el=document.getElementById('reportsList')||document.getElementById('reports-tbody');
  if(!el)return;
  sbFetch('GET','reports?select=*&order=created_at.desc.nullslast&limit=50',null,function(err,d){
    if(err||!Array.isArray(d)){el.innerHTML='<div style="color:#94a3b8;padding:1rem">Тайлан байхгүй</div>';return;}
    el.innerHTML=d.map(function(r){
      return '<div style="background:#fff;border:1px solid #e2e8f0;border-radius:10px;padding:.85rem;margin-bottom:.5rem;display:flex;justify-content:space-between">'+
        '<div><strong>'+escapeHtml(r.month||'')+'</strong> — '+escapeHtml(r.title||'')+'</div>'+
        '<div style="font-size:.75rem;color:#64748b">'+(r.sent_at?'📧 илгээгдсэн':'📝 ноорог')+'</div></div>';
    }).join('');
  });
}
function generateReport(){
  toast('Тайлан бэлдэж байна...','info');
  var month=new Date().toISOString().substr(0,7);
  sbFetch('POST','reports',{month:month,title:'Сарын тайлан '+month,content:'Авто-үүсгэсэн'},function(e){if(e){toast('❌ '+e,'error');return;}toast('✅ Үүсгэгдлээ','success');loadReports();});
}
function sendReport(id){
  if(!confirm('Имэйлээр илгээх үү?'))return;
  sbFetch('PATCH','reports?id=eq.'+id,{sent_at:new Date().toISOString()},function(e){if(e){toast('❌ '+e,'error');return;}toast('✅ Илгээгдлээ','success');loadReports();});
}

// ═══════════════════════════════════════════════════════
// 🎨 DESIGN / ✏️ TYPOGRAPHY / 📊 STATS — settings-based
// ═══════════════════════════════════════════════════════
function loadDesignTokens(){
  sbFetch('GET','settings?key=in.(color_primary,color_secondary,color_accent,color_bg,color_text)',null,function(err,rows){
    if(err||!Array.isArray(rows))return;
    var map={}; rows.forEach(function(r){map[r.key]=r.value;});
    ['primary','secondary','accent','bg','text'].forEach(function(k){
      var el=document.getElementById('design-color-'+k);
      if(el)el.value=map['color_'+k]||'';
    });
  });
}
function saveDesignTokens(){
  var updates=[];
  ['primary','secondary','accent','bg','text'].forEach(function(k){
    var el=document.getElementById('design-color-'+k);
    if(el&&el.value)updates.push({key:'color_'+k,value:el.value});
  });
  if(!updates.length){toast('Утга байхгүй','error');return;}
  var done=0;
  updates.forEach(function(u){
    sbFetch('POST','settings?on_conflict=key',u,function(e){done++;if(done===updates.length)toast(e?'❌':'✅ Хадгалагдлаа',e?'error':'success');},{'Prefer':'resolution=merge-duplicates,return=minimal'});
  });
}
function loadTypoSettings(){
  sbFetch('GET','settings?key=in.(font_heading,font_body,font_size_base)',null,function(err,rows){
    if(err||!Array.isArray(rows))return;
    var m={}; rows.forEach(function(r){m[r.key]=r.value;});
    ['heading','body'].forEach(function(k){var el=document.getElementById('typo-font-'+k); if(el)el.value=m['font_'+k]||'';});
    var sz=document.getElementById('typo-size-base'); if(sz)sz.value=m.font_size_base||'16';
  });
}
function saveTypoSettings(){
  var updates=[];
  ['heading','body'].forEach(function(k){var el=document.getElementById('typo-font-'+k); if(el&&el.value)updates.push({key:'font_'+k,value:el.value});});
  var sz=document.getElementById('typo-size-base'); if(sz&&sz.value)updates.push({key:'font_size_base',value:sz.value});
  var done=0;
  if(!updates.length){toast('Утга байхгүй','error');return;}
  updates.forEach(function(u){sbFetch('POST','settings?on_conflict=key',u,function(e){done++;if(done===updates.length)toast(e?'❌':'✅','success');},{'Prefer':'resolution=merge-duplicates,return=minimal'});});
}
function loadStatsAndTicker(){
  sbFetch('GET','settings?key=like.stat_*',null,function(err,rows){
    if(err||!Array.isArray(rows))return;
    rows.forEach(function(r){var el=document.getElementById(r.key); if(el)el.value=r.value||'';});
  });
  sbFetch('GET','settings?key=eq.ticker_text',null,function(err,rows){
    var el=document.getElementById('ticker-text');
    if(el&&Array.isArray(rows)&&rows[0])el.value=rows[0].value||'';
  });
}
function saveStatsAndTicker(){
  var updates=[];
  ['stat_years','stat_companies','stat_employees','stat_brands','stat_bonus','stat_customers'].forEach(function(k){var el=document.getElementById(k); if(el&&el.value)updates.push({key:k,value:el.value});});
  var tk=document.getElementById('ticker-text'); if(tk)updates.push({key:'ticker_text',value:tk.value});
  if(!updates.length){toast('Утга байхгүй','error');return;}
  var done=0;
  updates.forEach(function(u){sbFetch('POST','settings?on_conflict=key',u,function(e){done++;if(done===updates.length)toast(e?'❌':'✅ Хадгалагдлаа','success');},{'Prefer':'resolution=merge-duplicates,return=minimal'});});
}

// ═══════════════════════════════════════════════════════
// 🔍 SEO — save by page slug
// ═══════════════════════════════════════════════════════
function saveSeoItem(slug){
  var title=document.getElementById('seo-title-'+slug);
  var desc=document.getElementById('seo-desc-'+slug);
  var og=document.getElementById('seo-og-'+slug);
  if(!title||!desc)return;
  var body={slug:slug,title:title.value,description:desc.value,og_image:og?og.value:null};
  sbFetch('POST','seo?on_conflict=slug',body,function(e){
    if(e){toast('❌ '+e,'error');return;}
    toast('✅ '+slug,'success');
  },{'Prefer':'resolution=merge-duplicates,return=minimal'});
}

// ═══════════════════════════════════════════════════════
// 📥 IMPORT — scrape from nomin.co (demo)
// ═══════════════════════════════════════════════════════
function runImport(type){
  var el=document.getElementById('nomin-import-log');
  if(el)el.innerHTML='<div>⏳ '+type+' импорт эхэллээ...</div>';
  fetch((window.__NM_SB_URL__||'https://hunygqumohxinhndrcph.supabase.co')+'/functions/v1/import-nomin?type='+type,{
    headers:{Authorization:'Bearer '+(window.__NM_SB_KEY__||'')}
  }).then(function(r){return r.ok?r.json():r.text().then(function(t){throw new Error(t);});})
    .then(function(d){
      if(el)el.innerHTML+='<div>✅ '+type+': '+(d.count||0)+' мөр импортлогдлоо</div>';
      toast('✅ '+type+' импортлогдлоо','success');
    }).catch(function(e){
      if(el)el.innerHTML+='<div style="color:#ef4444">❌ '+e.message+'</div>';
      toast('Edge function дутуу. Backend суулгах хэрэгтэй','info');
    });
}

// ═══════════════════════════════════════════════════════
// 📈 ANALYTICS — Plausible/GA basic
// ═══════════════════════════════════════════════════════
function loadAnalytics(){
  var el=document.getElementById('analytics-content')||document.getElementById('analyticsDash');
  if(!el)return;
  el.innerHTML='<div style="text-align:center;padding:2rem">'+
    '<h3 style="margin-bottom:1rem">📈 Аналитик</h3>'+
    '<p style="color:#64748b;margin-bottom:1rem">Google Analytics эсвэл Plausible-аар холбогдоно уу.</p>'+
    '<div style="display:grid;grid-template-columns:repeat(3,1fr);gap:1rem;max-width:600px;margin:0 auto">'+
      '<div style="background:#fff;border-radius:10px;padding:1rem;border:1px solid #e2e8f0"><div style="font-size:2rem;font-weight:800">—</div><div style="color:#64748b;font-size:.8rem">Нийт үзэлт</div></div>'+
      '<div style="background:#fff;border-radius:10px;padding:1rem;border:1px solid #e2e8f0"><div style="font-size:2rem;font-weight:800">—</div><div style="color:#64748b;font-size:.8rem">Өвөрмөц</div></div>'+
      '<div style="background:#fff;border-radius:10px;padding:1rem;border:1px solid #e2e8f0"><div style="font-size:2rem;font-weight:800">—</div><div style="color:#64748b;font-size:.8rem">Bounce</div></div>'+
    '</div>'+
    '<p style="color:#94a3b8;margin-top:1.5rem;font-size:.82rem">Холбох: Settings → Analytics provider тохиргоо</p>'+
  '</div>';
}

// ═══════════════════════════════════════════════════════
// 🔍 AUDIT — real site check
// ═══════════════════════════════════════════════════════
function runRealAudit(){
  var el=document.getElementById('audit-results');
  if(!el)return;
  el.innerHTML='<div style="text-align:center;padding:2rem">⏳ Шалгаж байна...</div>';
  var pages=['index.html','about.html','history.html','leadership.html','mission.html','awards.html','business.html','brands.html','news.html','careers.html','tender.html','suppliers.html','buyers.html','contact.html','store-locator.html','catalogue.html','bonus-card.html','social.html'];
  var results=[];
  var done=0;
  pages.forEach(function(p){
    fetch('/'+p,{method:'HEAD'}).then(function(r){
      results.push({page:p,ok:r.ok,status:r.status});
    }).catch(function(){results.push({page:p,ok:false,status:0});})
    .finally(function(){
      done++;
      if(done===pages.length){
        var okCount=results.filter(function(r){return r.ok;}).length;
        el.innerHTML='<div style="margin-bottom:1rem;padding:.85rem 1rem;background:'+(okCount===pages.length?'#dcfce7':'#fef3c7')+';border-radius:8px;color:'+(okCount===pages.length?'#166534':'#92400e')+';font-weight:700">'+
          (okCount===pages.length?'✅':'⚠️')+' '+okCount+'/'+pages.length+' хуудас идэвхитэй</div>'+
          results.map(function(r){
            return '<div style="display:flex;align-items:center;gap:.75rem;padding:.6rem 0;border-bottom:1px solid #e5e7eb">'+
              '<span style="color:'+(r.ok?'#22c55e':'#ef4444')+'">'+(r.ok?'✓':'✗')+'</span>'+
              '<div style="flex:1;font-weight:600">'+r.page+'</div>'+
              '<div style="color:'+(r.ok?'#22c55e':'#ef4444')+';font-weight:700">'+r.status+'</div></div>';
          }).join('');
      }
    });
  });
}

// Overriding runFullAudit
if(typeof runFullAudit==='undefined'||true) window.runFullAudit=runRealAudit;

// ═══════════════════════════════════════════════════════
// Global export
// ═══════════════════════════════════════════════════════
window.openNewsModal=openNewsModal; window.saveNews=saveNews; window.deleteNews=deleteNews;
window.openBannerModal=openBannerModal; window.saveBanner=saveBanner; window.deleteBanner=deleteBanner;
window.loadJobs=loadJobs; window.openJobModal=openJobModal; window.saveJob=saveJob; window.deleteJob=deleteJob;
window.loadTender=loadTender; window.openTenderModal=openTenderModal; window.saveTender=saveTender; window.deleteTender=deleteTender;
window.openPageModal=openPageModal; window.savePage=savePage; window.deletePage=deletePage;
// NOTE: openCompanyModal/saveCompany/openSectorModal/saveSector are exported from admins.html (newer version with parent_id, is_jv, sort_order support). DO NOT export here.
window.loadUsers=loadUsers; window.openUserModal=openUserModal; window.saveUser=saveUser; window.deleteUser=deleteUser;
window.loadSuppliers=loadSuppliers; window.openSupplierModal=openSupplierModal; window.saveSupplier=saveSupplier; window.deleteSupplier=deleteSupplier;
window.openMenuItemModal=openMenuItemModal; window.saveMenuEntry=saveMenuEntry; window.deleteMenuEntry=deleteMenuEntry;
window.loadCatalogueUI=loadCatalogueUI;
window.uploadMedia=uploadMedia;
window.addTranslation=addTranslation; window.saveTranslation=saveTranslation;
window.loadBlocks=loadBlocks; window.openBlockModal=openBlockModal; window.saveBlock=saveBlock; window.deleteBlock=deleteBlock;
window.loadLayouts=loadLayouts; window.newLayout=newLayout; window.editLayout=editLayout;
window.loadReports=loadReports; window.generateReport=generateReport; window.sendReport=sendReport;
window.loadDesignTokens=loadDesignTokens; window.saveDesignTokens=saveDesignTokens;
window.loadTypoSettings=loadTypoSettings; window.saveTypoSettings=saveTypoSettings;
window.loadStatsAndTicker=loadStatsAndTicker; window.saveStatsAndTicker=saveStatsAndTicker;
window.saveSeoItem=saveSeoItem;
window.runImport=runImport;
window.loadAnalytics=loadAnalytics;
window.runRealAudit=runRealAudit;

// ═══════════════════════════════════════════════════════
// A. PAGE SECTIONS CMS EDITOR — live site content control
// ═══════════════════════════════════════════════════════
var _currentPageId = null;
var _currentPageSlug = null;

function openPageSectionsEditor(pageId, pageSlug){
  _currentPageId = pageId;
  _currentPageSlug = pageSlug;
  sbFetch('GET','page_sections?page_id=eq.'+pageId+'&order=sort_order.asc',null,function(err,sections){
    if(err){toast('❌ '+err,'error');return;}
    var sectionsList = (sections||[]).map(function(s,i){
      return '<div style="background:#f8fafc;border:1px solid #e2e8f0;border-radius:10px;padding:.85rem;margin-bottom:.5rem;display:flex;justify-content:space-between;align-items:center">'+
        '<div style="flex:1">'+
          '<div style="display:inline-block;background:#3b82f6;color:#fff;padding:.15rem .5rem;border-radius:4px;font-size:.7rem;font-weight:700;text-transform:uppercase;margin-right:.5rem">'+(s.section_key||'?')+'</div>'+
          '<span style="font-weight:600">'+escapeHtml((s.content&&s.content.title)||'(гарчиггүй)')+'</span>'+
          '<span style="color:#94a3b8;font-size:.72rem;margin-left:.5rem">#'+s.sort_order+'</span>'+
        '</div>'+
        '<div style="display:flex;gap:.3rem">'+
          '<button class="btn btn-xs" onclick="moveSection('+s.id+',-1)">↑</button>'+
          '<button class="btn btn-xs" onclick="moveSection('+s.id+',1)">↓</button>'+
          '<button class="btn btn-xs" onclick="editSection('+s.id+')">✏️</button>'+
          '<button class="btn btn-xs btn-danger" onclick="deleteSection('+s.id+')">🗑</button>'+
        '</div></div>';
    }).join('');
    
    nmModal('📄 '+pageSlug+' — Section editor',
      '<div style="margin-bottom:1rem;padding:.75rem;background:#eff6ff;border-radius:8px;font-size:.8rem">'+
        '💡 Хуудас бүр олон section-с бүтнэ (hero, text, image+text, stats, cards, cta...). Section нэмэх, засах, эрэмбэлэх боломжтой.'+
      '</div>'+
      '<div style="display:flex;gap:.5rem;margin-bottom:1rem;flex-wrap:wrap">'+
        '<button class="btn btn-xs btn-primary" onclick="addSection(\''+pageSlug+'\',\'hero\')">+ Hero</button>'+
        '<button class="btn btn-xs btn-primary" onclick="addSection(\''+pageSlug+'\',\'text\')">+ Text</button>'+
        '<button class="btn btn-xs btn-primary" onclick="addSection(\''+pageSlug+'\',\'image_text\')">+ Image+Text</button>'+
        '<button class="btn btn-xs btn-primary" onclick="addSection(\''+pageSlug+'\',\'stats\')">+ Stats</button>'+
        '<button class="btn btn-xs btn-primary" onclick="addSection(\''+pageSlug+'\',\'cards\')">+ Cards</button>'+
        '<button class="btn btn-xs btn-primary" onclick="addSection(\''+pageSlug+'\',\'cta\')">+ CTA</button>'+
        '<button class="btn btn-xs btn-primary" onclick="addSection(\''+pageSlug+'\',\'accordion\')">+ FAQ</button>'+
      '</div>'+
      '<div id="sections-list">'+(sectionsList||'<div style="text-align:center;color:#94a3b8;padding:2rem">Section байхгүй — дээрээс нэмнэ үү</div>')+'</div>',
      [{label:'Хаах',cls:'btn-secondary'}]
    );
  });
}

function addSection(pageSlug, type){
  var defaults = {
    hero: {title:'',subtitle:'',btn_text:'',btn_url:'',bg_color:'#1a2f7a'},
    text: {title:'',body:'',align:'left'},
    image_text: {title:'',body:'',image_url:'',layout:'left',btn_text:'',btn_url:''},
    stats: {items:[{val:'',label:''},{val:'',label:''},{val:'',label:''}]},
    cards: {title:'',items:[{title:'',desc:'',icon:'',url:''}]},
    cta: {title:'',subtitle:'',btn_text:'',btn_url:'',bg_color:'#1a2f7a'},
    accordion: {items:[{q:'',a:''}]}
  };
  sbFetch('GET','page_sections?page_id=eq.'+_currentPageId+'&order=sort_order.desc&limit=1',null,function(err,last){
    var newOrder = (last&&last[0]?last[0].sort_order:0)+1;
    sbFetch('POST','page_sections',{
      page_id: _currentPageId,
      section_key: type,
      content: defaults[type]||{},
      sort_order: newOrder,
      active: true
    },function(e){
      if(e){toast('❌ '+e,'error');return;}
      toast('✅ '+type+' нэмэгдлээ','success');
      openPageSectionsEditor(_currentPageId, _currentPageSlug);
    });
  });
}

function editSection(id){
  sbFetch('GET','page_sections?id=eq.'+id+'&select=*',null,function(err,d){
    if(err||!d||!d[0]){toast('Олдсонгүй','error');return;}
    var s = d[0];
    var c = s.content||{};
    var type = s.section_key;
    var fields = '';
    
    if(type==='hero'||type==='cta'){
      fields = _crudField('Гарчиг','sf-title',c.title)+
        '<div style="grid-column:1/-1">'+_crudField('Дэд гарчиг','sf-subtitle',c.subtitle,'textarea')+'</div>'+
        _crudField('Товчны текст','sf-btntext',c.btn_text)+
        _crudField('Товчны URL','sf-btnurl',c.btn_url)+
        _crudField('Фоны өнгө','sf-bgcolor',c.bg_color||'#1a2f7a');
    } else if(type==='text'){
      fields = '<div style="grid-column:1/-1">'+_crudField('Гарчиг','sf-title',c.title)+'</div>'+
        '<div style="grid-column:1/-1">'+_crudField('Агуулга','sf-body',c.body,'textarea')+'</div>'+
        _crudField('Тэгшлэлт','sf-align',c.align||'left','select',['left','center','right']);
    } else if(type==='image_text'){
      fields = '<div style="grid-column:1/-1">'+_crudField('Гарчиг','sf-title',c.title)+'</div>'+
        '<div style="grid-column:1/-1">'+_crudField('Зургийн URL','sf-image',c.image_url)+'</div>'+
        (c.image_url?'<div style="grid-column:1/-1;text-align:center"><img src="'+c.image_url+'" style="max-height:140px;border-radius:8px"></div>':'')+
        '<div style="grid-column:1/-1">'+_crudField('Текст','sf-body',c.body,'textarea')+'</div>'+
        _crudField('Layout','sf-layout',c.layout||'left','select',['left','right'])+
        _crudField('Товчны текст','sf-btntext',c.btn_text)+
        '<div style="grid-column:1/-1">'+_crudField('Товчны URL','sf-btnurl',c.btn_url)+'</div>';
    } else if(type==='stats'||type==='cards'||type==='accordion'){
      // JSON mode for complex types
      fields = (type==='cards'?'<div style="grid-column:1/-1">'+_crudField('Гарчиг','sf-title',c.title)+'</div>':'')+
        '<div style="grid-column:1/-1">'+_crudField('Items (JSON array)','sf-items',typeof c.items==='object'?JSON.stringify(c.items,null,2):c.items||'[]','textarea')+'</div>';
    } else {
      fields = '<div style="grid-column:1/-1">'+_crudField('Content (JSON)','sf-raw',JSON.stringify(c,null,2),'textarea')+'</div>';
    }
    
    nmModal('✏️ Section засах: '+type,
      '<div style="display:grid;grid-template-columns:1fr 1fr;gap:.75rem">'+fields+
        _crudField('Дараалал','sf-order',s.sort_order,'number')+
        _crudField('Идэвхитэй','sf-active',s.active!==false,'checkbox')+
      '</div>',
      [{label:'Хадгалах',cls:'btn-primary',cb:function(){saveSection(id, type);}},{label:'Болих',cls:'btn-secondary'}]
    );
  });
}

function saveSection(id, type){
  var content = {};
  if(type==='hero'||type==='cta'){
    content = {title:_getVal('sf-title'),subtitle:_getVal('sf-subtitle'),btn_text:_getVal('sf-btntext'),btn_url:_getVal('sf-btnurl'),bg_color:_getVal('sf-bgcolor')};
  } else if(type==='text'){
    content = {title:_getVal('sf-title'),body:_getVal('sf-body'),align:_getVal('sf-align')};
  } else if(type==='image_text'){
    content = {title:_getVal('sf-title'),image_url:_getVal('sf-image'),body:_getVal('sf-body'),layout:_getVal('sf-layout'),btn_text:_getVal('sf-btntext'),btn_url:_getVal('sf-btnurl')};
  } else if(type==='stats'||type==='accordion'){
    try{content.items = JSON.parse(_getVal('sf-items')||'[]');}catch(e){toast('JSON алдаа: '+e.message,'error');return;}
  } else if(type==='cards'){
    content.title = _getVal('sf-title');
    try{content.items = JSON.parse(_getVal('sf-items')||'[]');}catch(e){toast('JSON алдаа: '+e.message,'error');return;}
  } else {
    try{content = JSON.parse(_getVal('sf-raw')||'{}');}catch(e){toast('JSON алдаа: '+e.message,'error');return;}
  }
  
  var body = {content:content, sort_order:_getVal('sf-order','number'), active:_getVal('sf-active','checkbox')};
  sbFetch('PATCH','page_sections?id=eq.'+id, body, function(e){
    if(e){toast('❌ '+e,'error');return;}
    toast('✅ Хадгалагдлаа','success');
    nmCloseModal();
    if(_currentPageId) openPageSectionsEditor(_currentPageId, _currentPageSlug);
  });
}

function deleteSection(id){
  if(!confirm('Section устгах уу?'))return;
  sbFetch('DELETE','page_sections?id=eq.'+id,null,function(e){
    if(e){toast('❌ '+e,'error');return;}
    toast('✅ Устгагдлаа','success');
    if(_currentPageId) openPageSectionsEditor(_currentPageId, _currentPageSlug);
  });
}

function moveSection(id, direction){
  sbFetch('GET','page_sections?id=eq.'+id+'&select=*',null,function(err,d){
    if(err||!d||!d[0])return;
    var s = d[0];
    sbFetch('PATCH','page_sections?id=eq.'+id, {sort_order: (s.sort_order||0)+direction}, function(e){
      if(!e && _currentPageId) openPageSectionsEditor(_currentPageId, _currentPageSlug);
    });
  });
}

// Enhance loadPages to include section edit button
function loadPagesEnhanced(){
  var tb = document.getElementById('pageTbody')||document.getElementById('pages-tbody');
  if(!tb)return;
  tb.innerHTML='<tr><td colspan="6" style="text-align:center;padding:2rem">⏳</td></tr>';
  sbFetch('GET','pages?select=id,slug,title,status,updated_at&order=slug.asc',null,function(err,d){
    if(err||!Array.isArray(d)){tb.innerHTML='<tr><td colspan="6" style="text-align:center;color:#94a3b8">Хуудас байхгүй</td></tr>';return;}
    var cnt=document.getElementById('pages-total'); if(cnt)cnt.textContent=d.length;
    tb.innerHTML=d.map(function(p,i){
      return '<tr><td>'+(i+1)+'</td><td style="font-weight:600">'+escapeHtml(p.slug||'')+'</td>' +
        '<td>'+escapeHtml(p.title||'')+'</td>' +
        '<td>'+escapeHtml(p.status||'')+'</td>' +
        '<td style="font-size:.72rem;color:#64748b">'+((p.updated_at||'').split('T')[0])+'</td>' +
        '<td style="text-align:center">' +
          '<button class="btn btn-xs btn-primary" onclick="openPageSectionsEditor('+p.id+',\''+p.slug+'\')" title="Агуулга">📝</button> ' +
          '<button class="btn btn-xs" onclick="openPageModal('+p.id+')" title="Meta">✏️</button> ' +
          '<button class="btn btn-xs btn-danger" onclick="deletePage('+p.id+')">🗑</button>' +
        '</td></tr>';
    }).join('');
  });
}
// Override loadPages
window.loadPages = loadPagesEnhanced;

// ═══════════════════════════════════════════════════════
// B. PAGE VISITS ANALYTICS WIDGET
// ═══════════════════════════════════════════════════════
function loadAnalyticsReal(){
  var el = document.getElementById('analytics-content')||document.getElementById('analyticsDash');
  if(!el) return;
  el.innerHTML = '<div style="text-align:center;padding:2rem">⏳ Аналитик ачаалж байна...</div>';
  
  // Fetch visits (last 30 days)
  var thirtyDaysAgo = new Date(Date.now() - 30*24*3600*1000).toISOString();
  sbFetch('GET','page_visits?select=page,visited_at&visited_at=gte.'+thirtyDaysAgo+'&limit=10000', null, function(err, visits){
    if(err||!Array.isArray(visits)){
      el.innerHTML='<div style="text-align:center;padding:2rem;color:#ef4444">❌ Аналитик татагдсангүй: '+(err||'No data')+'<br><small style="color:#64748b">page_visits хүснэгт байхгүй бол Supabase-д үүсгэх хэрэгтэй</small></div>';
      return;
    }
    
    var total = visits.length;
    var byPage = {};
    var byDay = {};
    visits.forEach(function(v){
      var p = v.page || '/';
      byPage[p] = (byPage[p]||0)+1;
      var day = (v.visited_at||'').split('T')[0];
      byDay[day] = (byDay[day]||0)+1;
    });
    
    // Top 10 pages
    var topPages = Object.entries(byPage).sort(function(a,b){return b[1]-a[1];}).slice(0,10);
    // Last 14 days
    var days = [];
    for(var i=13;i>=0;i--){
      var d=new Date(Date.now()-i*24*3600*1000).toISOString().split('T')[0];
      days.push([d, byDay[d]||0]);
    }
    var maxVisits = Math.max.apply(null, days.map(function(d){return d[1];})) || 1;
    var avgDaily = Math.round(total/30);
    var uniquePages = Object.keys(byPage).length;
    
    el.innerHTML = 
      '<div style="display:grid;grid-template-columns:repeat(3,1fr);gap:1rem;margin-bottom:1.5rem">'+
        '<div style="background:#fff;border-radius:10px;padding:1rem;border:1px solid #e2e8f0">'+
          '<div style="font-size:.7rem;color:#64748b;text-transform:uppercase;font-weight:700">30 хоногт</div>'+
          '<div style="font-size:2rem;font-weight:900;color:#1a2f7a">'+total.toLocaleString()+'</div>'+
          '<div style="font-size:.78rem;color:#64748b">Нийт үзэлт</div>'+
        '</div>'+
        '<div style="background:#fff;border-radius:10px;padding:1rem;border:1px solid #e2e8f0">'+
          '<div style="font-size:.7rem;color:#64748b;text-transform:uppercase;font-weight:700">Өдөрт дундаж</div>'+
          '<div style="font-size:2rem;font-weight:900;color:#22c55e">'+avgDaily.toLocaleString()+'</div>'+
          '<div style="font-size:.78rem;color:#64748b">үзэлт/өдөр</div>'+
        '</div>'+
        '<div style="background:#fff;border-radius:10px;padding:1rem;border:1px solid #e2e8f0">'+
          '<div style="font-size:.7rem;color:#64748b;text-transform:uppercase;font-weight:700">Хуудас</div>'+
          '<div style="font-size:2rem;font-weight:900;color:#8656cd">'+uniquePages+'</div>'+
          '<div style="font-size:.78rem;color:#64748b">идэвхитэй хуудас</div>'+
        '</div>'+
      '</div>'+
      '<div style="background:#fff;border-radius:10px;padding:1rem;border:1px solid #e2e8f0;margin-bottom:1rem">'+
        '<h4 style="margin-bottom:.85rem;font-size:.88rem;font-weight:700">📈 Сүүлийн 14 хоног</h4>'+
        '<div style="display:flex;align-items:flex-end;gap:4px;height:120px">'+
          days.map(function(d){
            var h = Math.round((d[1]/maxVisits)*100);
            var day = d[0].substr(5);
            return '<div style="flex:1;display:flex;flex-direction:column;align-items:center;justify-content:flex-end;height:100%" title="'+d[0]+': '+d[1]+' үзэлт">'+
              '<div style="width:100%;background:linear-gradient(to top,#3b82f6,#60a5fa);height:'+h+'%;min-height:2px;border-radius:3px 3px 0 0;transition:all .3s"></div>'+
              '<div style="font-size:.6rem;color:#94a3b8;margin-top:4px">'+day+'</div>'+
              '<div style="font-size:.68rem;color:#1e293b;font-weight:700">'+d[1]+'</div>'+
            '</div>';
          }).join('')+
        '</div>'+
      '</div>'+
      '<div style="background:#fff;border-radius:10px;padding:1rem;border:1px solid #e2e8f0">'+
        '<h4 style="margin-bottom:.85rem;font-size:.88rem;font-weight:700">🏆 Хамгийн их үзсэн хуудас (TOP 10)</h4>'+
        topPages.map(function(row,i){
          var pct = Math.round((row[1]/total)*100);
          return '<div style="display:flex;align-items:center;gap:.75rem;padding:.5rem 0;border-bottom:1px solid #f1f5f9">'+
            '<div style="width:24px;height:24px;background:'+(i<3?'#f59e0b':'#e2e8f0')+';color:'+(i<3?'#fff':'#64748b')+';border-radius:50%;display:flex;align-items:center;justify-content:center;font-weight:700;font-size:.75rem;flex-shrink:0">'+(i+1)+'</div>'+
            '<div style="flex:1"><div style="font-weight:600;font-size:.85rem">'+escapeHtml(row[0])+'</div>'+
              '<div style="background:#e2e8f0;height:4px;border-radius:2px;margin-top:4px"><div style="background:#3b82f6;height:100%;width:'+pct+'%;border-radius:2px"></div></div>'+
            '</div>'+
            '<div style="font-weight:700;color:#1e293b;min-width:50px;text-align:right">'+row[1].toLocaleString()+'</div>'+
          '</div>';
        }).join('')+
      '</div>';
  });
}

// Override loadAnalytics
window.loadAnalytics = loadAnalyticsReal;

// ═══════════════════════════════════════════════════════
// Exports
// ═══════════════════════════════════════════════════════
window.openPageSectionsEditor = openPageSectionsEditor;
window.addSection = addSection;
window.editSection = editSection;
window.saveSection = saveSection;
window.deleteSection = deleteSection;
window.moveSection = moveSection;
window.loadPagesEnhanced = loadPagesEnhanced;
window.loadAnalyticsReal = loadAnalyticsReal;

// ═══════════════════════════════════════════════════════
// FILE UPLOAD HELPERS — preview + Supabase Storage upload
// ═══════════════════════════════════════════════════════
function _previewImg(fileInputId, previewDivId){
  var inp = document.getElementById(fileInputId);
  var pv = document.getElementById(previewDivId);
  if(!inp||!pv||!inp.files||!inp.files[0])return;
  var file = inp.files[0];
  var reader = new FileReader();
  reader.onload = function(e){
    pv.innerHTML = '<img src="'+e.target.result+'" style="max-height:160px;border-radius:8px;border:2px dashed #3b82f6"><div style="font-size:.72rem;color:#3b82f6;margin-top:.3rem">📁 '+escapeHtml(file.name)+' ('+Math.round(file.size/1024)+'KB) — Upload товчийг дарна уу</div>';
  };
  reader.readAsDataURL(file);
}

function _uploadImgToSupabase(fileInputId, urlInputId, folder, previewDivId){
  var inp = document.getElementById(fileInputId);
  if(!inp||!inp.files||!inp.files[0]){toast('Файл сонгоно уу','error');return;}
  var file = inp.files[0];
  if(file.size > 5*1024*1024){toast('Файл 5MB-аас их','error');return;}
  
  var SB_URL = window.__NM_SB_URL__ || 'https://hunygqumohxinhndrcph.supabase.co';
  var KEY = window.__NM_SB_KEY__ || 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6Imh1bnlncXVtb2h4aW5obmRyY3BoIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NzQzNTA4NjMsImV4cCI6MjA4OTkyNjg2M30.2eFxPABgxosblHajh85txP_yrv0VsDCbhxSVIcO3T88';
  
  // Get JWT for authenticated upload
  var sess = {};
  try{ sess = JSON.parse(localStorage.getItem('nm_sess')||'{}'); }catch(e){}
  var jwt = sess.token || KEY;
  
  // Generate unique filename
  var ext = (file.name.split('.').pop()||'jpg').toLowerCase();
  var cleanName = file.name.replace(/\.[^.]+$/,'').replace(/[^a-zA-Z0-9._-]/g,'_').substring(0,50);
  var filename = folder + '/' + Date.now() + '_' + cleanName + '.' + ext;
  var uploadUrl = SB_URL + '/storage/v1/object/media/' + filename;
  var publicUrl = SB_URL + '/storage/v1/object/public/media/' + filename;
  
  var pv = document.getElementById(previewDivId);
  if(pv) pv.innerHTML = '<div style="padding:1rem;color:#3b82f6">⏳ Upload хийж байна...</div>';
  
  fetch(uploadUrl, {
    method: 'POST',
    headers: {
      'Authorization': 'Bearer ' + jwt,
      'apikey': KEY,
      'Content-Type': file.type || 'application/octet-stream',
      'x-upsert': 'true'
    },
    body: file
  })
  .then(function(r){
    if(!r.ok) return r.text().then(function(t){throw new Error('HTTP '+r.status+': '+t);});
    return r.json();
  })
  .then(function(){
    // Set URL in input
    var urlInp = document.getElementById(urlInputId);
    if(urlInp) urlInp.value = publicUrl;
    if(pv) pv.innerHTML = '<img src="'+publicUrl+'" style="max-height:160px;border-radius:8px;border:2px solid #22c55e"><div style="font-size:.72rem;color:#22c55e;margin-top:.3rem;font-weight:700">✅ Upload амжилттай</div>';
    toast('✅ Зураг upload хийгдлээ','success');
  })
  .catch(function(e){
    if(pv) pv.innerHTML = '<div style="padding:1rem;color:#ef4444">❌ '+escapeHtml(e.message)+'</div>';
    toast('❌ Upload амжилтгүй: '+e.message,'error');
  });
}

window._previewImg = _previewImg;
window._uploadImgToSupabase = _uploadImgToSupabase;

// ═══════════════════════════════════════════════════════
// TRANSLATIONS — load from Supabase (LONG format: key+lang+value)
// ═══════════════════════════════════════════════════════
function loadTranslationsFromSupabase(){
  var tb = document.getElementById('transTbody');
  if(tb) tb.innerHTML = '<tr><td colspan="6" style="text-align:center;padding:2rem">⏳ Supabase-ээс ачаалж байна...</td></tr>';
  
  sbFetch('GET', 'translations?select=key,lang,value&limit=10000', null, function(err, rows){
    if(err){
      if(tb) tb.innerHTML = '<tr><td colspan="6" style="text-align:center;padding:2rem;color:#ef4444">❌ '+err+'</td></tr>';
      toast('❌ Орчуулга татагдсангүй: '+err, 'error');
      return;
    }
    if(!Array.isArray(rows) || !rows.length){
      if(tb) tb.innerHTML = '<tr><td colspan="6" style="text-align:center;padding:2rem;color:#94a3b8">Орчуулга байхгүй</td></tr>';
      return;
    }
    
    // LONG format: {key, lang, value} per row
    window.LANG = window.LANG || {};
    window.LANG.mn = {}; window.LANG.en = {}; window.LANG.ru = {}; window.LANG.zh = {};
    
    rows.forEach(function(r){
      var k = r.key, lang = r.lang, v = r.value;
      if(!k || !lang) return;
      // Normalize lang code (cn → zh)
      if(lang === 'cn') lang = 'zh';
      if(!window.LANG[lang]) window.LANG[lang] = {};
      if(v) window.LANG[lang][k] = v;
    });
    
    var mnCount = Object.keys(window.LANG.mn).length;
    var enCount = Object.keys(window.LANG.en).length;
    var ruCount = Object.keys(window.LANG.ru).length;
    var zhCount = Object.keys(window.LANG.zh).length;
    
    // Use UNION of all keys as the total (some langs may have orphan keys)
    var allKeys = {};
    ['mn','en','ru','zh'].forEach(function(l){
      Object.keys(window.LANG[l]||{}).forEach(function(k){ allKeys[k] = 1; });
    });
    var totalKeys = Object.keys(allKeys).length;
    
    console.log('[Translations] Loaded:', {total:rows.length, mn:mnCount, en:enCount, ru:ruCount, zh:zhCount, unique:totalKeys});
    
    // Mirror to localStorage for i18n-loader compatibility
    try {
      localStorage.setItem('nm_strings_mn', JSON.stringify(window.LANG.mn));
      localStorage.setItem('nm_strings_en', JSON.stringify(window.LANG.en));
      localStorage.setItem('nm_strings_ru', JSON.stringify(window.LANG.ru));
      localStorage.setItem('nm_strings_zh', JSON.stringify(window.LANG.zh));
    } catch(e){ console.warn('localStorage write:', e); }
    
    // Update stats — use totalKeys (union) as denominator
    var update = function(id, count, total){
      var el = document.getElementById(id);
      if(!el) return;
      var pct = total>0 ? Math.round(count/total*100) : 0;
      var full = pct >= 95;
      el.textContent = (full?'✅ ':'') + count.toLocaleString()+' / '+total.toLocaleString()+' ('+pct+'%)';
      el.style.color = full ? '#22c55e' : pct>=50 ? '#f59e0b' : '#ef4444';
    };
    var mnEl = document.getElementById('mn-count');
    if(mnEl){
      var mnPct = Math.round(mnCount/totalKeys*100);
      mnEl.textContent = mnCount.toLocaleString()+' / '+totalKeys.toLocaleString()+' ('+mnPct+'%)';
      mnEl.style.color = mnPct>=95 ? '#22c55e' : '#f59e0b';
    }
    update('en-count', enCount, totalKeys);
    update('ru-count', ruCount, totalKeys);
    update('zh-count', zhCount, totalKeys);
    
    // Re-render table
    if(typeof renderTransTable === 'function') renderTransTable();
    
    toast("✅ "+totalKeys.toLocaleString()+' текст ('+rows.length.toLocaleString()+' мөр) ачаалагдлаа', 'success');
  });
}

// Auto-trigger when translations panel opened
(function(){
  var origGoto = window.gotoPanel;
  if(typeof origGoto === 'function'){
    window.gotoPanel = function(id){
      var result = origGoto.apply(this, arguments);
      if(id === 'translations'){
        setTimeout(loadTranslationsFromSupabase, 100);
      }
      return result;
    };
  }
})();

// Also allow manual trigger from buttons
window.loadTranslationsFromSupabase = loadTranslationsFromSupabase;
window.refreshTranslations = loadTranslationsFromSupabase;

// ═══════════════════════════════════════════════════════
// COPY ORPHAN — fill missing MN entries from EN/RU (bulk)
// ═══════════════════════════════════════════════════════
function copyOrphanMN(){
  var mn = (window.LANG&&window.LANG.mn)||{};
  var en = (window.LANG&&window.LANG.en)||{};
  var ru = (window.LANG&&window.LANG.ru)||{};
  var zh = (window.LANG&&window.LANG.zh)||{};
  
  // Find keys missing MN
  var orphans = [];
  [en, ru, zh].forEach(function(d){
    Object.keys(d).forEach(function(k){
      if(!mn[k] && !orphans.includes(k)) orphans.push(k);
    });
  });
  
  if(!orphans.length){
    toast('✅ MN дутуу түлхүүр байхгүй','success');
    return;
  }
  
  if(!confirm(orphans.length+' түлхүүр MN-д дутуу байна.\n\nАвтоматаар MN-д EN текстийг (байхгүй бол RU, ZH) бөглөх үү?\n\nЭнэ нь түр шийдэл — дараа нь гараар засах ёстой.')) return;
  
  var toInsert = orphans.map(function(k){
    return {key:k, lang:'mn', value: en[k] || ru[k] || zh[k] || '[MN TODO: '+k+']'};
  });
  
  // Batch upsert to Supabase
  var BATCH = 100;
  var done = 0, errs = 0;
  var total = toInsert.length;
  toast('⏳ '+total+' түлхүүр оруулж байна...','info');
  
  function processBatch(idx){
    if(idx >= total){
      toast(errs ? ('⚠️ '+(total-errs)+'/'+total+' амжилттай ('+errs+' алдаа)') : ('✅ '+total+' түлхүүр бөглөгдлөө'), errs?'error':'success');
      loadTranslationsFromSupabase();
      return;
    }
    var batch = toInsert.slice(idx, idx+BATCH);
    sbFetch('POST', 'translations?on_conflict=key,lang', batch, function(err){
      if(err) errs += batch.length;
      else {
        // Update local cache
        batch.forEach(function(row){
          window.LANG.mn[row.key] = row.value;
        });
      }
      done += batch.length;
      setTimeout(function(){ processBatch(idx+BATCH); }, 250);
    }, {'Prefer':'resolution=merge-duplicates,return=minimal'});
  }
  processBatch(0);
}

window.copyOrphanMN = copyOrphanMN;

// ═══════════════════════════════════════════════════════
// TRANSLATION REPAIR TOOLKIT
// ═══════════════════════════════════════════════════════

// Helper: Check if text contains Cyrillic
function _hasCyrillic(s){
  return typeof s === 'string' && /[А-ЯЁӨҮҺ]/i.test(s);
}

// 1. CLEANUP — Remove Cyrillic values from EN/ZH columns (they're Mongolian fallback junk)
function cleanupWrongLangValues(){
  var en = (window.LANG&&window.LANG.en)||{};
  var zh = (window.LANG&&window.LANG.zh)||{};
  var enBad = Object.keys(en).filter(function(k){return _hasCyrillic(en[k]);});
  var zhBad = Object.keys(zh).filter(function(k){return _hasCyrillic(zh[k]);});
  
  var total = enBad.length + zhBad.length;
  if(!total){
    toast('✅ Цэвэрлэх зүйл байхгүй','success');
    return;
  }
  
  if(!confirm('🗑️ Буруу бичигдсэн хэлний утгуудыг устгах уу?\n\n'+
    '🇬🇧 EN: '+enBad.length+' мөр Кирилл текст\n'+
    '🇨🇳 ZH: '+zhBad.length+' мөр Кирилл текст\n\n'+
    'ЭНЭ НЬ SUPABASE-ЭЭС УСТГАНА. Буцаах боломжгүй.\n'+
    'Дараа нь Google Translate-ээр орчуулах ёстой.')) return;
  
  toast('⏳ '+total+' мөр устгаж байна...','info');
  
  var tasks = [];
  enBad.forEach(function(k){ tasks.push({key:k,lang:'en'}); });
  zhBad.forEach(function(k){ tasks.push({key:k,lang:'zh'}); });
  
  var done = 0, errs = 0;
  
  function next(idx){
    if(idx >= tasks.length){
      toast('✅ '+(done-errs)+' устгагдлаа'+(errs?' ('+errs+' алдаа)':''), errs?'error':'success');
      setTimeout(loadTranslationsFromSupabase, 500);
      return;
    }
    var t = tasks[idx];
    sbFetch('DELETE', 'translations?key=eq.'+encodeURIComponent(t.key)+'&lang=eq.'+t.lang, null, function(err){
      done++;
      if(err) errs++;
      if(done % 50 === 0){
        toast('⏳ '+done+'/'+tasks.length+' ('+errs+' алдаа)','info');
      }
      setTimeout(function(){ next(idx+1); }, 30);
    });
  }
  next(0);
}

// 2. GOOGLE TRANSLATE — Free endpoint (no key needed for small batches)
function _googleTranslate(text, targetLang, cb){
  // Use free Google Translate endpoint (client=gtx)
  var url = 'https://translate.googleapis.com/translate_a/single?client=gtx&sl=mn&tl='+targetLang+'&dt=t&q='+encodeURIComponent(text);
  fetch(url)
    .then(function(r){return r.json();})
    .then(function(data){
      // data = [[["translated","original",null,null,0]],null,"mn"]
      if(data && data[0] && Array.isArray(data[0])){
        var result = data[0].map(function(piece){return piece[0]||'';}).join('');
        cb(null, result);
      } else {
        cb('invalid response', null);
      }
    })
    .catch(function(e){ cb(e.message||'fetch failed', null); });
}

// Bulk translate missing EN/ZH from MN
function bulkTranslateMissing(targetLang){
  var mn = (window.LANG&&window.LANG.mn)||{};
  var target = (window.LANG&&window.LANG[targetLang])||{};
  
  // Find keys that have MN but missing in target
  var toTranslate = Object.keys(mn).filter(function(k){
    return mn[k] && mn[k].trim() && !target[k];
  });
  
  if(!toTranslate.length){
    toast('✅ '+targetLang.toUpperCase()+'-д орчуулах зүйл байхгүй','success');
    return;
  }
  
  var langName = {en:'English',ru:'Русский',zh:'中文'}[targetLang] || targetLang;
  if(!confirm('🤖 '+toTranslate.length+' текстийг Google Translate-ээр '+langName+' болгож орчуулах уу?\n\n'+
    'Үргэлжлэх хугацаа: ~'+Math.ceil(toTranslate.length*0.2)+' секунд\n'+
    'Rate limit гарвал автомат зогсоно.')) return;
  
  toast('⏳ '+toTranslate.length+' текст орчуулж байна...','info');
  
  var done = 0, errs = 0, batch = [];
  var BATCH_SIZE = 50; // upload to Supabase every 50
  var DELAY_MS = 200;  // between Google calls
  
  function flushBatch(final){
    if(!batch.length){
      if(final) finish();
      return;
    }
    var payload = batch.slice();
    batch = [];
    sbFetch('POST', 'translations?on_conflict=key,lang', payload, function(err){
      if(err) console.warn('Batch upload error:', err);
      if(final) finish();
    }, {'Prefer':'resolution=merge-duplicates,return=minimal'});
  }
  
  function finish(){
    toast('✅ '+(done-errs)+' орчуулагдлаа'+(errs?' ('+errs+' алдаа)':''), errs?'error':'success');
    setTimeout(loadTranslationsFromSupabase, 1000);
  }
  
  function next(idx){
    if(idx >= toTranslate.length){
      flushBatch(true);
      return;
    }
    var key = toTranslate[idx];
    var src = mn[key];
    
    _googleTranslate(src, targetLang, function(err, translated){
      done++;
      if(err || !translated){
        errs++;
        console.warn('Translate fail:', key, err);
      } else {
        batch.push({key:key, lang:targetLang, value:translated});
      }
      
      if(batch.length >= BATCH_SIZE){
        flushBatch(false);
      }
      
      if(done % 20 === 0){
        toast('⏳ '+done+'/'+toTranslate.length+' ('+errs+' алдаа)','info');
      }
      
      // Stop if too many consecutive errors
      if(errs > 20 && done < 50){
        toast('❌ Rate limit байж магадгүй — зогслоо','error');
        flushBatch(true);
        return;
      }
      
      setTimeout(function(){ next(idx+1); }, DELAY_MS);
    });
  }
  next(0);
}

function translateAllMissing(){
  if(!confirm('🌍 EN, RU, ZH гурван хэл рүү бүх дутуу орчуулгыг Google-ээр хийх үү?\n\nЭнэ нь удаан үргэлжилж болно (5-15 минут).')) return;
  bulkTranslateMissing('en');
  // RU, ZH will be triggered after EN finishes (via loadTranslationsFromSupabase)
  // Actually just do them sequentially with delay
  setTimeout(function(){ bulkTranslateMissing('ru'); }, 3000);
  setTimeout(function(){ bulkTranslateMissing('zh'); }, 6000);
}

window.cleanupWrongLangValues = cleanupWrongLangValues;
window.bulkTranslateMissing = bulkTranslateMissing;
window.translateAllMissing = translateAllMissing;
window._hasCyrillic = _hasCyrillic;

// Enhance renderTransTable filter to support Cyrillic detection
var _origRenderTrans = window.renderTransTable;

// ═══════════════════════════════════════════════════════
// MEDIA GALLERY — Supabase Storage list + delete
// ═══════════════════════════════════════════════════════
var _mediaFolders = ['stores','leadership','banners','news','uploads','general'];

function loadMediaGallery(){
  var grid = document.getElementById('mGrid');
  if(!grid) return;
  
  var SB_URL = window.__NM_SB_URL__ || 'https://hunygqumohxinhndrcph.supabase.co';
  var SB_KEY = window.__NM_SB_KEY__ || 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6Imh1bnlncXVtb2h4aW5obmRyY3BoIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NzQzNTA4NjMsImV4cCI6MjA4OTkyNjg2M30.2eFxPABgxosblHajh85txP_yrv0VsDCbhxSVIcO3T88';
  
  grid.innerHTML = '<div style="grid-column:1/-1;padding:2rem;text-align:center;color:#64748b">⏳ Файлууд ачаалж байна...</div>';
  
  // Session token (may have upload permission)
  var token = SB_KEY;
  try { token = JSON.parse(localStorage.getItem('nm_sess')||'{}').token || SB_KEY; } catch(e){}
  
  var allFiles = [];
  var done = 0;
  
  _mediaFolders.forEach(function(folder){
    fetch(SB_URL + '/storage/v1/object/list/media', {
      method: 'POST',
      headers: {
        'apikey': SB_KEY,
        'Authorization': 'Bearer ' + token,
        'Content-Type': 'application/json'
      },
      body: JSON.stringify({ prefix: folder + '/', limit: 200, offset: 0, sortBy: {column:'created_at',order:'desc'} })
    })
    .then(function(r){ return r.ok ? r.json() : []; })
    .then(function(files){
      if(Array.isArray(files)) {
        files.forEach(function(f){
          if(f.name && !f.name.endsWith('/')) {
            allFiles.push({
              folder: folder,
              name: f.name,
              path: folder + '/' + f.name,
              url: SB_URL + '/storage/v1/object/public/media/' + folder + '/' + f.name,
              size: (f.metadata && f.metadata.size) || 0,
              created: f.created_at || f.updated_at
            });
          }
        });
      }
    })
    .catch(function(){})
    .finally(function(){
      done++;
      if(done === _mediaFolders.length) renderMediaGrid(allFiles);
    });
  });
}

function renderMediaGrid(files){
  var grid = document.getElementById('mGrid');
  if(!grid) return;
  
  // Keep the "Add" button first
  var addBtn = '<div class="media-add" onclick="document.getElementById(\'mInput\').click()"><div style="font-size:1.5rem">＋</div><span>Нэмэх</span><input type="file" id="mInput" multiple accept="image/*" style="display:none" onchange="uploadMMulti(this)"></div>';
  
  if(!files.length) {
    grid.innerHTML = addBtn + '<div style="grid-column:2/-1;padding:2rem;text-align:center;color:#94a3b8;border:1px dashed #cbd5e1;border-radius:8px">Хоосон — Нэмэх товчыг дарна уу</div>';
    return;
  }
  
  // Group by folder — show folder tabs
  var folders = {};
  files.forEach(function(f){ (folders[f.folder] = folders[f.folder] || []).push(f); });
  
  var totalSize = files.reduce(function(s,f){return s+(f.size||0);}, 0);
  var sizeMb = (totalSize/1024/1024).toFixed(2);
  
  var header = '<div style="grid-column:1/-1;padding:.75rem;background:#f8fafc;border-radius:8px;margin-bottom:.5rem;display:flex;gap:.75rem;flex-wrap:wrap;align-items:center"><strong style="color:#0f172a">📊 '+files.length+' файл ('+sizeMb+' MB)</strong>';
  header += ' <span style="color:#94a3b8">|</span> ';
  Object.keys(folders).forEach(function(f){
    header += '<span style="font-size:.78rem;color:#475569">📁 '+f+' ('+folders[f].length+')</span> ';
  });
  header += '</div>';
  
  var items = files.map(function(f){
    var isImg = /\.(jpg|jpeg|png|gif|webp|svg|avif)$/i.test(f.name);
    var sizeKb = Math.round((f.size||0)/1024);
    return '<div class="media-item" data-path="'+escapeHtml(f.path)+'" style="position:relative;cursor:default">'+
      (isImg 
        ? '<img src="'+f.url+'" loading="lazy" style="cursor:pointer" onclick="openMediaDetail(\''+escapeHtml(f.path)+'\',\''+f.url+'\')">'
        : '<div style="font-size:2rem;color:#94a3b8">📄</div>'
      )+
      '<div class="mi-lbl" title="'+escapeHtml(f.name)+'">'+escapeHtml(f.name.length>20?f.name.substring(0,17)+'...':f.name)+' · '+sizeKb+'KB</div>'+
      '<button onclick="deleteMediaFile(\''+escapeHtml(f.path)+'\')" style="position:absolute;top:4px;right:4px;background:rgba(239,68,68,.9);border:none;color:#fff;width:22px;height:22px;border-radius:50%;cursor:pointer;font-size:.75rem;display:flex;align-items:center;justify-content:center" title="Устгах">×</button>'+
      '<button onclick="copyMediaUrl(\''+f.url+'\')" style="position:absolute;top:4px;left:4px;background:rgba(59,130,246,.9);border:none;color:#fff;width:22px;height:22px;border-radius:50%;cursor:pointer;font-size:.7rem;display:flex;align-items:center;justify-content:center" title="URL хуулах">🔗</button>'+
    '</div>';
  }).join('');
  
  grid.innerHTML = header + addBtn + items;
}

function deleteMediaFile(path){
  if(!confirm('🗑 Файлыг УСТГАХ уу?\n\n'+path+'\n\nЭнэ нь Supabase Storage-оос бүрэн устгана.')) return;
  
  var SB_URL = window.__NM_SB_URL__ || 'https://hunygqumohxinhndrcph.supabase.co';
  var SB_KEY = window.__NM_SB_KEY__ || '';
  var token = SB_KEY;
  try { token = JSON.parse(localStorage.getItem('nm_sess')||'{}').token || SB_KEY; } catch(e){}
  
  fetch(SB_URL + '/storage/v1/object/media/' + path, {
    method: 'DELETE',
    headers: { 'apikey': SB_KEY, 'Authorization': 'Bearer ' + token }
  })
  .then(function(r){
    if(r.ok) {
      toast('✅ Устгагдлаа','success');
      loadMediaGallery();
    } else {
      r.text().then(function(t){ toast('❌ '+t.substring(0,80),'error'); });
    }
  })
  .catch(function(e){ toast('❌ '+e.message,'error'); });
}

function copyMediaUrl(url){
  if(navigator.clipboard) {
    navigator.clipboard.writeText(url).then(function(){
      toast('📋 URL хуулагдлаа','success');
    });
  }
}

function openMediaDetail(path, url){
  nmModal('🖼 '+path,
    '<div style="text-align:center"><img src="'+url+'" style="max-width:100%;max-height:400px;border-radius:8px"></div>'+
    '<div style="margin-top:1rem;padding:.75rem;background:#f1f5f9;border-radius:6px;font-family:monospace;font-size:.75rem;word-break:break-all">'+url+'</div>',
    [
      {label:'📋 URL хуулах', cls:'btn-primary', cb: function(){ copyMediaUrl(url); }},
      {label:'🗑 Устгах', cls:'btn-danger', cb: function(){ nmCloseModal(); deleteMediaFile(path); }},
      {label:'Хаах', cls:'btn-secondary'}
    ]
  );
}

function uploadMMulti(input){
  if(!input.files || !input.files.length) return;
  var files = Array.from(input.files);
  var folder = prompt('Аль фолдерт оруулах? (stores/leadership/banners/news/uploads/general):', 'uploads') || 'uploads';
  
  toast('⏳ '+files.length+' файл upload хийж байна...','info');
  
  var SB_URL = window.__NM_SB_URL__ || 'https://hunygqumohxinhndrcph.supabase.co';
  var SB_KEY = window.__NM_SB_KEY__ || '';
  var token = SB_KEY;
  try { token = JSON.parse(localStorage.getItem('nm_sess')||'{}').token || SB_KEY; } catch(e){}
  
  var done = 0, errs = 0;
  files.forEach(function(file){
    var safeName = file.name.replace(/[^a-zA-Z0-9._-]/g,'_');
    var path = folder + '/' + Date.now() + '_' + safeName;
    fetch(SB_URL + '/storage/v1/object/media/' + path, {
      method: 'POST',
      headers: {
        'apikey': SB_KEY,
        'Authorization': 'Bearer ' + token,
        'Content-Type': file.type || 'application/octet-stream'
      },
      body: file
    }).then(function(r){
      done++;
      if(!r.ok) errs++;
      if(done === files.length) {
        toast(errs ? ('⚠️ '+(done-errs)+'/'+done+' upload хийгдлээ') : ('✅ '+done+' файл upload хийгдлээ'), errs?'error':'success');
        loadMediaGallery();
      }
    }).catch(function(){
      done++; errs++;
      if(done === files.length) {
        toast('⚠️ Алдаатай', 'error');
        loadMediaGallery();
      }
    });
  });
  
  input.value = '';
}

// Hook into panel navigation
(function(){
  var origGoto = window.gotoPanel;
  if(typeof origGoto === 'function') {
    window.gotoPanel = function(name){
      var r = origGoto.apply(this, arguments);
      if(name === 'media') setTimeout(loadMediaGallery, 100);
      return r;
    };
  }
})();

window.loadMediaGallery = loadMediaGallery;
window.deleteMediaFile = deleteMediaFile;
window.copyMediaUrl = copyMediaUrl;
window.openMediaDetail = openMediaDetail;
window.uploadMMulti = uploadMMulti;

// ═══════════════════════════════════════════════════════════════
// 1. FULL CONTENT AUDIT — checks links, images, translations, SEO
// ═══════════════════════════════════════════════════════════════
function runContentAudit(){
  var el = document.getElementById('audit-results');
  if(!el) return;
  el.innerHTML = '<div style="text-align:center;padding:2rem"><div style="font-size:1.5rem">⏳</div><div style="color:#64748b">Шалгаж байна... бүрэн аудит ~30 секунд</div></div>';
  
  var checks = [];
  var pages = ['index.html','about.html','history.html','leadership.html','mission.html','awards.html','business.html','brands.html','news.html','careers.html','tender.html','suppliers.html','buyers.html','contact.html','store-locator.html','catalogue.html','bonus-card.html','social.html','why-choose-us.html','sector-retail.html','sector-import.html','sector-finance.html','sector-construction.html','sector-tech.html','sector-aviation.html'];
  
  var brokenLinks = 0, missingImgs = 0, emptyPages = 0;
  var pageResults = [];
  var done = 0;
  
  pages.forEach(function(p){
    fetch('/'+p).then(function(r){
      if(!r.ok) {
        pageResults.push({page:p, ok:false, status:r.status, issues:['Хуудас олдсонгүй']});
        emptyPages++;
        return null;
      }
      return r.text();
    }).then(function(html){
      if(!html) return;
      var issues = [];
      
      // Check 1: broken <img src>
      var imgs = html.match(/<img[^>]*src=["']([^"']+)["']/gi) || [];
      imgs.forEach(function(tag){
        var src = (tag.match(/src=["']([^"']+)/)||[])[1] || '';
        if(!src || src === '#' || src === 'javascript:void(0)') {
          missingImgs++;
          issues.push('Хоосон img src');
        }
      });
      
      // Check 2: empty data-t attributes (translation keys)
      var dtMatches = html.match(/data-t=["']([^"']+)["']/g) || [];
      var missingTx = 0;
      dtMatches.forEach(function(m){
        var key = (m.match(/data-t=["']([^"']+)/)||[])[1];
        if(key && (!window.LANG || !window.LANG.mn || !window.LANG.mn[key])) missingTx++;
      });
      if(missingTx > 5) issues.push(missingTx + ' орчуулгын key дутуу');
      
      // Check 3: meta description
      if(!/<meta\s+name=["']description["']/i.test(html)) issues.push('Meta description дутуу');
      
      // Check 4: og:image
      if(!/<meta\s+property=["']og:image["']/i.test(html)) issues.push('og:image дутуу');
      
      // Check 5: size
      if(html.length < 2000) {
        issues.push('Хуудас богино (<2KB)');
        emptyPages++;
      }
      
      pageResults.push({page:p, ok:true, status:200, size:html.length, issues:issues, missingTx:missingTx});
    }).catch(function(){
      pageResults.push({page:p, ok:false, status:0, issues:['Network алдаа']});
    }).finally(function(){
      done++;
      el.innerHTML = '<div style="text-align:center;padding:2rem"><div style="font-size:1.5rem">⏳</div><div style="color:#64748b">Шалгаж байна: '+done+'/'+pages.length+'</div></div>';
      if(done === pages.length) renderAuditReport(pageResults);
    });
  });
  
  // Also check orphan translations
  setTimeout(function(){
    if(window.LANG && window.LANG.mn && window.LANG.en) {
      var mn = Object.keys(window.LANG.mn||{});
      var en = Object.keys(window.LANG.en||{});
      var orphanMN = mn.filter(function(k){return !window.LANG.en[k];}).length;
      var orphanEN = en.filter(function(k){return !window.LANG.mn[k];}).length;
      checks.push({name:'Орчуулгын тэгш бус', ok:orphanMN===0&&orphanEN===0, detail:'MN-д байгаа ч EN дутуу: '+orphanMN+', эсрэгээр: '+orphanEN});
    }
  }, 500);
}

function renderAuditReport(results){
  var el = document.getElementById('audit-results');
  if(!el) return;
  
  var okCount = results.filter(function(r){return r.ok && !r.issues.length;}).length;
  var warnCount = results.filter(function(r){return r.ok && r.issues.length;}).length;
  var errorCount = results.filter(function(r){return !r.ok;}).length;
  var total = results.length;
  
  var score = Math.round(okCount/total*100);
  var scoreColor = score >= 90 ? '#22c55e' : score >= 70 ? '#f59e0b' : '#ef4444';
  
  // Also supabase data counts
  var dbChecks = [];
  var tables = ['news','stores','leadership','jobs','tenders','suppliers','pages','translations','banners'];
  var tDone = 0;
  tables.forEach(function(t){
    sbFetch('GET', t+'?select=id&limit=500', null, function(err, data){
      dbChecks.push({table:t, ok:!err, count:Array.isArray(data)?data.length:0, error:err});
      tDone++;
      if(tDone === tables.length) renderWithDb();
    });
  });
  
  function renderWithDb(){
    el.innerHTML = 
      '<div style="display:grid;grid-template-columns:repeat(4,1fr);gap:1rem;margin-bottom:1.5rem">'+
        '<div style="background:#fff;border-radius:12px;padding:1.25rem;text-align:center;border:2px solid '+scoreColor+'">'+
          '<div style="font-size:2.5rem;font-weight:900;color:'+scoreColor+'">'+score+'%</div>'+
          '<div style="font-size:.72rem;color:#64748b;font-weight:600;text-transform:uppercase">Нийт оноо</div>'+
        '</div>'+
        '<div style="background:#dcfce7;border-radius:10px;padding:1rem;text-align:center"><div style="font-size:1.8rem;font-weight:900;color:#16a34a">'+okCount+'</div><div style="font-size:.75rem;color:#166534">✅ Зөв</div></div>'+
        '<div style="background:#fef3c7;border-radius:10px;padding:1rem;text-align:center"><div style="font-size:1.8rem;font-weight:900;color:#d97706">'+warnCount+'</div><div style="font-size:.75rem;color:#92400e">⚠️ Анхааруулга</div></div>'+
        '<div style="background:#fee2e2;border-radius:10px;padding:1rem;text-align:center"><div style="font-size:1.8rem;font-weight:900;color:#dc2626">'+errorCount+'</div><div style="font-size:.75rem;color:#991b1b">❌ Алдаа</div></div>'+
      '</div>'+
      
      // Supabase tables
      '<div class="card" style="margin-bottom:1rem"><h3 style="font-size:.88rem;font-weight:700;margin-bottom:.75rem">🗄 Supabase хүснэгтүүд</h3>'+
        '<div style="display:grid;grid-template-columns:repeat(3,1fr);gap:.5rem">'+
        dbChecks.map(function(c){
          return '<div style="display:flex;justify-content:space-between;padding:.5rem .75rem;background:'+(c.ok?'#f0fdf4':'#fef2f2')+';border-radius:6px;font-size:.78rem">'+
            '<span>'+(c.ok?'✅':'❌')+' '+c.table+'</span>'+
            '<strong>'+(c.ok?c.count:'—')+'</strong>'+
          '</div>';
        }).join('')+
        '</div>'+
      '</div>'+
      
      // Pages detail
      '<div class="card"><h3 style="font-size:.88rem;font-weight:700;margin-bottom:.75rem">📄 Хуудсаар дэлгэрэнгүй</h3>'+
        '<table style="width:100%;font-size:.78rem"><thead><tr style="background:#f8fafc;text-align:left"><th style="padding:.5rem">Хуудас</th><th>HTTP</th><th>Хэмжээ</th><th>Асуудал</th></tr></thead><tbody>'+
        results.map(function(r){
          var rowBg = !r.ok ? '#fef2f2' : r.issues.length ? '#fef3c7' : '#fff';
          return '<tr style="background:'+rowBg+';border-bottom:1px solid #f1f5f9">'+
            '<td style="padding:.5rem"><strong>'+r.page+'</strong></td>'+
            '<td>'+(r.ok?'<span style="color:#16a34a">✓ '+r.status+'</span>':'<span style="color:#dc2626">✗ '+r.status+'</span>')+'</td>'+
            '<td>'+(r.size?Math.round(r.size/1024)+' KB':'—')+'</td>'+
            '<td>'+(r.issues.length?r.issues.map(function(i){return '<span style="display:inline-block;background:#fef3c7;color:#92400e;padding:.1rem .4rem;border-radius:4px;margin:.1rem;font-size:.7rem">'+i+'</span>';}).join(''):'<span style="color:#22c55e">Цэвэр</span>')+'</td>'+
          '</tr>';
        }).join('')+
        '</tbody></table>'+
      '</div>'+
      
      '<div style="text-align:right;margin-top:1rem"><button class="btn btn-sm btn-outline" onclick="runContentAudit()">🔄 Дахин шалгах</button></div>';
  }
}

// ═══════════════════════════════════════════════════════════════
// 2. MONTHLY REPORT — real PDF with jsPDF
// ═══════════════════════════════════════════════════════════════
function generateMonthlyReport(){
  var now = new Date();
  var mn = now.getMonth()+1;
  var year = now.getFullYear();
  var titleEl = document.getElementById('reportMonthTitle');
  if(titleEl) titleEl.textContent = year+' оны '+mn+'-р сарын тайлан';
  
  var stats = {news:0, sup:0, job:0, tender:0};
  var tableData = {news:[], suppliers:[], jobs:[], tenders:[]};
  var monthStart = new Date(year, mn-1, 1).toISOString();
  var monthEnd = new Date(year, mn, 0, 23, 59, 59).toISOString();
  
  var fetches = [
    {table:'news', q:'select=title,created_at,status&created_at=gte.'+monthStart+'&created_at=lte.'+monthEnd+'&order=created_at.desc', key:'news'},
    {table:'suppliers', q:'select=*&created_at=gte.'+monthStart+'&created_at=lte.'+monthEnd+'&order=created_at.desc', key:'sup'},
    {table:'jobs', q:'select=*&created_at=gte.'+monthStart+'&created_at=lte.'+monthEnd+'&order=created_at.desc', key:'job'},
    {table:'tenders', q:'select=*&created_at=gte.'+monthStart+'&created_at=lte.'+monthEnd+'&order=created_at.desc', key:'tender'}
  ];
  
  var done = 0;
  fetches.forEach(function(f){
    sbFetch('GET', f.table+'?'+f.q, null, function(err, data){
      if(!err && Array.isArray(data)) {
        stats[f.key] = data.length;
        tableData[f.table] = data;
      }
      done++;
      if(done === fetches.length) {
        // Update UI stats
        ['news','sup','job'].forEach(function(k){
          var el = document.getElementById('rpt-'+k);
          if(el) el.textContent = stats[k];
        });
        
        // Render supplier table
        var supEl = document.getElementById('rpt-sup-table');
        if(supEl) {
          if(tableData.suppliers.length) {
            supEl.innerHTML = '<div style="margin-top:1rem;padding:1rem;background:#f8fafc;border-radius:8px"><h4 style="font-size:.85rem;font-weight:700;margin-bottom:.5rem">🚚 Энэ сарын нийлүүлэгчид</h4>'+
              tableData.suppliers.slice(0,10).map(function(s){
                return '<div style="padding:.4rem 0;border-bottom:1px solid #e2e8f0;font-size:.78rem;display:flex;justify-content:space-between">'+
                  '<span><strong>'+escapeHtml(s.company_name||s.company||s.name||'')+'</strong> — '+escapeHtml(s.contact_name||s.contact||'')+'</span>'+
                  '<span style="color:#64748b">'+escapeHtml(s.status||'')+'</span>'+
                '</div>';
              }).join('')+
            '</div>';
          } else {
            supEl.innerHTML = '<div style="text-align:center;color:#94a3b8;padding:1rem">Энэ сард нийлүүлэгчийн хүсэлт байхгүй</div>';
          }
        }
        
        // Store report snapshot
        window.__lastReport = {
          year: year, month: mn, stats: stats, data: tableData,
          generated: now.toISOString()
        };
        
        toast('✅ Тайлан бэлэн — PDF татаж авах боломжтой','success');
      }
    });
  });
}

function downloadReportPDF(){
  if(!window.__lastReport) {
    toast('Эхлээд тайлан үүсгэнэ үү','error');
    return;
  }
  
  // Load jsPDF if not loaded
  if(typeof window.jspdf === 'undefined') {
    toast('⏳ jsPDF татаж байна...','info');
    var script = document.createElement('script');
    script.src = 'https://cdnjs.cloudflare.com/ajax/libs/jspdf/2.5.1/jspdf.umd.min.js';
    script.onload = function(){ buildPDF(); };
    script.onerror = function(){ toast('❌ jsPDF татагдсангүй','error'); };
    document.head.appendChild(script);
  } else {
    buildPDF();
  }
}

function buildPDF(){
  var r = window.__lastReport;
  var jsPDF = window.jspdf && window.jspdf.jsPDF;
  if(!jsPDF) { toast('❌ jsPDF сан татагдсангүй','error'); return; }
  
  var doc = new jsPDF();
  var y = 20;
  
  doc.setFontSize(18);
  doc.setFont(undefined, 'bold');
  doc.text('NOMIN Holding - Monthly Report', 105, y, {align:'center'});
  y += 8;
  doc.setFontSize(12);
  doc.setFont(undefined, 'normal');
  doc.text(r.year + ' / ' + r.month + ' (' + r.generated.split('T')[0] + ')', 105, y, {align:'center'});
  y += 15;
  
  // Summary boxes
  doc.setFontSize(11);
  doc.setFont(undefined, 'bold');
  doc.text('Summary', 20, y); y += 7;
  doc.setFont(undefined, 'normal');
  doc.setFontSize(10);
  doc.text('News published: ' + r.stats.news, 25, y); y += 6;
  doc.text('Supplier requests: ' + r.stats.sup, 25, y); y += 6;
  doc.text('Job postings: ' + r.stats.job, 25, y); y += 6;
  doc.text('Tenders: ' + r.stats.tender, 25, y); y += 10;
  
  // Suppliers
  if(r.data.suppliers && r.data.suppliers.length) {
    doc.setFont(undefined, 'bold');
    doc.setFontSize(11);
    doc.text('Supplier Requests', 20, y); y += 7;
    doc.setFont(undefined, 'normal');
    doc.setFontSize(9);
    r.data.suppliers.slice(0,20).forEach(function(s){
      if(y > 270) { doc.addPage(); y = 20; }
      // Latin only — jsPDF Mongolian issue
      doc.text('- ' + (s.company_name||s.company||s.name||'').substring(0,40) + ' | ' + (s.status||''), 25, y);
      y += 5;
    });
    y += 5;
  }
  
  // News
  if(r.data.news && r.data.news.length) {
    if(y > 250) { doc.addPage(); y = 20; }
    doc.setFont(undefined, 'bold');
    doc.setFontSize(11);
    doc.text('News Articles', 20, y); y += 7;
    doc.setFont(undefined, 'normal');
    doc.setFontSize(9);
    r.data.news.slice(0,15).forEach(function(n){
      if(y > 270) { doc.addPage(); y = 20; }
      doc.text('- ' + (n.title||'').substring(0,60), 25, y);
      y += 5;
    });
  }
  
  doc.save('NOMIN_Report_' + r.year + '-' + String(r.month).padStart(2,'0') + '.pdf');
  toast('📄 PDF татагдлаа','success');
}

// ═══════════════════════════════════════════════════════════════
// 3. REVISION HISTORY — Supabase snapshots
// ═══════════════════════════════════════════════════════════════
function loadRevisions(){
  var el = document.getElementById('historyList');
  if(!el) return;
  el.innerHTML = '<div style="text-align:center;padding:1rem;color:#64748b">⏳ Ачаалж байна...</div>';
  
  sbFetch('GET', 'revisions?select=*&order=created_at.desc&limit=50', null, function(err, data){
    if(err || !Array.isArray(data)) {
      el.innerHTML = '<div style="text-align:center;padding:2rem;color:#64748b"><div style="font-size:2rem;margin-bottom:.5rem">📋</div><p style="font-size:.82rem">Хувилбар байхгүй</p><p style="font-size:.7rem;color:#94a3b8;margin-top:.5rem">Supabase-д revisions хүснэгт үүсгэх эсвэл "Snapshot авах" товч дарна уу.</p><div style="margin-top:1rem;padding:.75rem;background:#f1f5f9;border-radius:6px;font-family:monospace;font-size:.68rem;text-align:left">CREATE TABLE revisions (<br>  id bigint PRIMARY KEY GENERATED ALWAYS AS IDENTITY,<br>  label text NOT NULL,<br>  data jsonb,<br>  created_at timestamptz DEFAULT now()<br>);</div></div>';
      return;
    }
    if(!data.length) {
      el.innerHTML = '<div style="text-align:center;padding:2rem;color:#94a3b8"><div style="font-size:2rem">📋</div><p style="font-size:.82rem">Хувилбар байхгүй — "Snapshot авах" дар</p></div>';
      return;
    }
    el.innerHTML = data.map(function(r, i){
      var date = r.created_at ? new Date(r.created_at).toLocaleString('mn-MN') : '—';
      var summary = r.data ? (Object.keys(r.data).map(function(k){return k+':'+r.data[k];}).join(' · ')) : '';
      return '<div style="display:flex;align-items:center;gap:.75rem;padding:.85rem 1rem;border-bottom:1px solid #f1f5f9;cursor:pointer" onclick="viewRev('+r.id+')">'+
        '<div style="width:8px;height:8px;border-radius:50%;background:'+(i===0?'#22c55e':'#94a3b8')+';flex-shrink:0"></div>'+
        '<div style="flex:1;min-width:0">'+
          '<div style="font-size:.82rem;font-weight:600;color:#0f172a">'+escapeHtml(r.label||'Untitled')+'</div>'+
          '<div style="font-size:.7rem;color:#64748b;margin-top:.15rem">🕐 '+date+'</div>'+
          (summary?'<div style="font-size:.68rem;color:#94a3b8;margin-top:.15rem">'+escapeHtml(summary)+'</div>':'')+
        '</div>'+
        (i===0?'<span style="font-size:.65rem;font-weight:700;background:#dcfce7;color:#16a34a;padding:2px 8px;border-radius:10px">Шинэ</span>':'')+
        '<button class="btn btn-xs btn-danger" onclick="event.stopPropagation();deleteRev('+r.id+')">🗑</button>'+
      '</div>';
    }).join('');
  });
}

function takeRevisionSnapshot(label){
  label = label || prompt('Хувилбарын нэр:', 'Snapshot ' + new Date().toLocaleDateString('mn-MN'));
  if(!label) return;
  
  toast('⏳ Snapshot авч байна...','info');
  
  var snapshot = {};
  var tables = ['news','stores','leadership','jobs','tenders','suppliers','pages','banners'];
  var done = 0;
  
  tables.forEach(function(t){
    sbFetch('GET', t+'?select=id&limit=500', null, function(err, data){
      snapshot[t+'_count'] = (!err && Array.isArray(data)) ? data.length : 0;
      done++;
      if(done === tables.length) {
        snapshot.timestamp = new Date().toISOString();
        sbFetch('POST', 'revisions', {label:label, data:snapshot}, function(err){
          if(err) {
            toast('❌ '+err.substring(0,80),'error');
            console.error('Snapshot error:', err);
          } else {
            toast('✅ Snapshot хадгалагдлаа','success');
            loadRevisions();
          }
        });
      }
    });
  });
}

function viewRev(id){
  sbFetch('GET', 'revisions?id=eq.'+id+'&select=*', null, function(err, data){
    if(err || !data || !data[0]) return;
    var r = data[0];
    var el = document.getElementById('historyDetail');
    if(!el) return;
    el.innerHTML = 
      '<div style="font-size:.95rem;font-weight:700;color:#0f172a;margin-bottom:.3rem">'+escapeHtml(r.label)+'</div>'+
      '<div style="font-size:.72rem;color:#64748b;margin-bottom:1rem">🕐 '+new Date(r.created_at).toLocaleString('mn-MN')+'</div>'+
      '<div style="background:#f8fafc;border-radius:8px;padding:.75rem;font-family:monospace;font-size:.72rem;line-height:1.6;max-height:400px;overflow-y:auto">'+
        Object.keys(r.data||{}).map(function(k){
          return '<div style="display:flex;justify-content:space-between;padding:.2rem 0;border-bottom:1px solid #e2e8f0"><strong>'+k+'</strong><span>'+r.data[k]+'</span></div>';
        }).join('')+
      '</div>';
  });
}

function deleteRev(id){
  if(!confirm('Хувилбарыг устгах уу?')) return;
  sbFetch('DELETE', 'revisions?id=eq.'+id, null, function(err){
    if(err) toast('❌ '+err,'error');
    else { toast('✅ Устгагдлаа','success'); loadRevisions(); }
  });
}

// ═══════════════════════════════════════════════════════════════
// 4. LAYOUT BUILDER — drag & drop section ordering
// ═══════════════════════════════════════════════════════════════
function loadLayoutBuilder(){
  var el = document.getElementById('builderCanvas') || document.getElementById('layouts-list');
  if(!el) return;
  
  el.innerHTML = '<div style="text-align:center;padding:1rem;color:#64748b">⏳ Ачаалж байна...</div>';
  
  sbFetch('GET', 'pages?select=id,slug,title&order=slug.asc', null, function(err, pages){
    if(err) { el.innerHTML = '<div style="color:#ef4444">'+err+'</div>'; return; }
    if(!pages || !pages.length) { el.innerHTML = '<div style="color:#94a3b8;padding:2rem;text-align:center">Хуудас байхгүй</div>'; return; }
    
    el.innerHTML = 
      '<div style="margin-bottom:1rem;padding:.75rem 1rem;background:#eff6ff;border-radius:8px;font-size:.82rem;color:#1e40af">💡 Хуудсаа сонгоод section-уудыг <strong>↕ drag хийж</strong> эрэмбэлж болно. Section нэмэх/засах бол 📝 товч ашигла.</div>'+
      '<div style="margin-bottom:1rem"><label style="font-size:.82rem;font-weight:600">Хуудас сонгох:</label> '+
      '<select class="form-control" style="max-width:300px;display:inline-block;margin-left:.5rem" onchange="loadLayoutSections(this.value, this.options[this.selectedIndex].text)">'+
      '<option value="">— Хуудас сонгоно уу —</option>'+
      pages.map(function(p){return '<option value="'+p.id+'">'+escapeHtml(p.slug)+' ('+escapeHtml(p.title||'')+')</option>';}).join('')+
      '</select></div>'+
      '<div id="layoutSectionsPanel"></div>';
  });
}

function loadLayoutSections(pageId, pageLabel){
  var el = document.getElementById('layoutSectionsPanel');
  if(!el || !pageId) { if(el) el.innerHTML=''; return; }
  
  el.innerHTML = '<div style="text-align:center;padding:1rem">⏳</div>';
  
  sbFetch('GET', 'page_sections?page_id=eq.'+pageId+'&order=sort_order.asc', null, function(err, sections){
    if(err) { el.innerHTML = '<div style="color:#ef4444">'+err+'</div>'; return; }
    
    if(!sections || !sections.length) {
      el.innerHTML = '<div class="card" style="padding:2rem;text-align:center;color:#94a3b8">Section байхгүй. <button class="btn btn-primary btn-sm" onclick="openPageSectionsEditor('+pageId+',\''+pageLabel+'\')">📝 Section нэмэх</button></div>';
      return;
    }
    
    el.innerHTML = 
      '<div class="card">'+
        '<div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:1rem"><h4 style="font-size:.9rem;font-weight:700">📋 '+escapeHtml(pageLabel)+' — '+sections.length+' section</h4>'+
          '<button class="btn btn-sm btn-primary" onclick="openPageSectionsEditor('+pageId+',\''+pageLabel+'\')">📝 Section editor</button>'+
        '</div>'+
        '<div id="sortableSections" data-page-id="'+pageId+'">'+
        sections.map(function(s){
          var title = (s.content && s.content.title) || '(Гарчиггүй)';
          var typeLabel = {hero:'🎭 Hero',text:'📝 Text',image_text:'🖼 Image+Text',stats:'📊 Stats',cards:'🃏 Cards',cta:'📣 CTA',accordion:'❓ FAQ'}[s.section_key] || s.section_key;
          return '<div draggable="true" data-sec-id="'+s.id+'" data-sort="'+s.sort_order+'" '+
            'ondragstart="layoutDragStart(event)" ondragover="event.preventDefault()" ondrop="layoutDrop(event)" ondragenter="layoutDragEnter(event)" ondragleave="layoutDragLeave(event)" '+
            'style="background:#fff;border:2px solid #e2e8f0;border-radius:10px;padding:.85rem 1rem;margin-bottom:.5rem;cursor:grab;display:flex;align-items:center;gap:.75rem;transition:all .15s">'+
            '<div style="color:#94a3b8;font-size:1.2rem;user-select:none">⋮⋮</div>'+
            '<div style="background:#3b82f6;color:#fff;padding:.2rem .5rem;border-radius:4px;font-size:.68rem;font-weight:700;flex-shrink:0">'+typeLabel+'</div>'+
            '<div style="flex:1;min-width:0;font-weight:600;font-size:.85rem;white-space:nowrap;overflow:hidden;text-overflow:ellipsis">'+escapeHtml(title)+'</div>'+
            '<div style="color:#94a3b8;font-size:.7rem">#'+s.sort_order+'</div>'+
            '<button class="btn btn-xs" onclick="editSection('+s.id+')">✏️</button>'+
            '<button class="btn btn-xs btn-danger" onclick="deleteSection('+s.id+')">🗑</button>'+
          '</div>';
        }).join('')+
        '</div>'+
      '</div>';
  });
}

var _dragEl = null;
function layoutDragStart(e){ _dragEl = e.currentTarget; e.currentTarget.style.opacity='.5'; }
function layoutDragEnter(e){ e.currentTarget.style.borderColor = '#3b82f6'; }
function layoutDragLeave(e){ e.currentTarget.style.borderColor = '#e2e8f0'; }
function layoutDrop(e){
  e.preventDefault();
  if(!_dragEl || _dragEl === e.currentTarget) return;
  
  var dropEl = e.currentTarget;
  dropEl.style.borderColor = '#e2e8f0';
  
  // Physical DOM swap
  var parent = dropEl.parentElement;
  var allItems = Array.from(parent.children);
  var dragIdx = allItems.indexOf(_dragEl);
  var dropIdx = allItems.indexOf(dropEl);
  
  if(dragIdx < dropIdx) parent.insertBefore(_dragEl, dropEl.nextSibling);
  else parent.insertBefore(_dragEl, dropEl);
  
  _dragEl.style.opacity = '1';
  
  // Save new order to Supabase
  saveNewSectionOrder(parent);
}

function saveNewSectionOrder(container){
  var items = Array.from(container.children);
  toast('⏳ Дарааллыг хадгалж байна...','info');
  
  var done = 0, errs = 0;
  items.forEach(function(item, idx){
    var id = item.dataset.secId;
    if(!id) return;
    sbFetch('PATCH', 'page_sections?id=eq.'+id, {sort_order:idx+1}, function(err){
      done++;
      if(err) errs++;
      if(done === items.length) {
        if(errs) toast('⚠️ '+(done-errs)+'/'+done+' хадгалагдлаа','error');
        else toast('✅ Дараалал хадгалагдлаа','success');
      }
    });
  });
}

// Hook into navigation
(function(){
  var origGoto = window.gotoPanel;
  if(typeof origGoto === 'function') {
    window.gotoPanel = function(name){
      var r = origGoto.apply(this, arguments);
      setTimeout(function(){
        if(name === 'audit') runContentAudit();
        else if(name === 'reports') generateMonthlyReport();
        else if(name === 'history' || name === 'revision') loadRevisions();
        else if(name === 'layouts' || name === 'layout-builder') loadLayoutBuilder();
      }, 100);
      return r;
    };
  }
})();

window.runContentAudit = runContentAudit;
window.renderAuditReport = renderAuditReport;
window.runFullAudit = runContentAudit; // Override placeholder
window.generateMonthlyReport = generateMonthlyReport;
window.generateReport = generateMonthlyReport; // Override placeholder
window.downloadReportPDF = downloadReportPDF;
window.loadRevisions = loadRevisions;
window.takeRevisionSnapshot = takeRevisionSnapshot;
window.createSnapshot = takeRevisionSnapshot; // Match panel button
window.viewRev = viewRev;
window.deleteRev = deleteRev;
window.loadLayoutBuilder = loadLayoutBuilder;
window.loadLayouts = loadLayoutBuilder; // Override placeholder
window.loadLayoutSections = loadLayoutSections;
window.layoutDragStart = layoutDragStart;
window.layoutDragEnter = layoutDragEnter;
window.layoutDragLeave = layoutDragLeave;
window.layoutDrop = layoutDrop;

// ══ Testimonials Manager ══════════════════════════════
var _testimonials = [];
var _editingTestimonialId = null;

function loadTestimonialsMgr(){
  var grid = document.getElementById('testimonials-grid-admin');
  if(!grid) return;
  grid.innerHTML = '<div style="color:#94a3b8;padding:1rem">⏳ Ачаалж байна...</div>';
  var sb = _structSB();
  fetch(sb.URL+'/rest/v1/testimonials?select=*&order=display_order.asc', {
    headers: {apikey:sb.KEY, Authorization:'Bearer '+sb.KEY}
  }).then(function(r){
    if(!r.ok) throw new Error('status '+r.status);
    return r.json();
  }).then(function(rows){
    _testimonials = Array.isArray(rows) ? rows : [];
    renderTestimonials();
  }).catch(function(err){
    console.error('[testimonials]', err);
    grid.innerHTML = '<div style="padding:1rem;background:#fee2e2;border-radius:8px;color:#991b1b;font-size:.85rem">❌ Ачаалж чадсангүй: '+err.message+'<br><small>testimonials хүснэгт үүссэн эсэхийг шалгана уу. SETUP_TESTIMONIALS.sql ажиллуулсан эсэх?</small></div>';
  });
}

function renderTestimonials(){
  var grid = document.getElementById('testimonials-grid-admin');
  if(!grid) return;
  if(_testimonials.length === 0){
    grid.innerHTML = '<div style="grid-column:1/-1;text-align:center;padding:2rem;color:#94a3b8">Одоогоор сэтгэгдэл байхгүй. <b>➕ Сэтгэгдэл нэмэх</b> товч дар</div>';
    return;
  }
  grid.innerHTML = _testimonials.map(function(t){
    var stars = '';
    for(var i=0;i<5;i++) stars += '<span style="color:'+(i<t.rating?'#fbbf24':'#e2e8f0')+'">★</span>';
    var featured = t.is_featured ? '<span style="background:#dbeafe;color:#1e40af;padding:2px 8px;border-radius:4px;font-size:.68rem;font-weight:700">⭐ Онцлох</span>' : '<span style="background:#fee2e2;color:#991b1b;padding:2px 8px;border-radius:4px;font-size:.68rem">Нуусан</span>';
    return '<div onclick="openTestimonialModal('+t.id+')" style="background:#fff;border:1px solid #e8ecf2;border-radius:10px;padding:1rem;cursor:pointer;transition:all .15s" onmouseover="this.style.borderColor=\'#2a4fca\';this.style.boxShadow=\'0 4px 12px rgba(0,0,0,.08)\'" onmouseout="this.style.borderColor=\'#e8ecf2\';this.style.boxShadow=\'\'">' +
      '<div style="display:flex;justify-content:space-between;align-items:start;margin-bottom:.5rem;gap:.5rem"><div style="font-weight:700;font-size:.88rem;color:#0f172a">'+escapeHtml(t.name||'')+'</div>'+featured+'</div>' +
      '<div style="font-size:.72rem;color:#64748b;margin-bottom:.5rem">'+escapeHtml(t.role||'')+(t.company?' · '+escapeHtml(t.company):'')+'</div>' +
      '<div style="margin-bottom:.5rem;font-size:.85rem">'+stars+'</div>' +
      '<div style="font-size:.78rem;color:#475569;line-height:1.5;display:-webkit-box;-webkit-line-clamp:3;-webkit-box-orient:vertical;overflow:hidden">"'+escapeHtml(t.content||'')+'"</div>' +
      '<div style="margin-top:.5rem;font-size:.65rem;color:#94a3b8;text-transform:uppercase">'+(t.lang||'mn')+' · #'+(t.display_order||0)+'</div>' +
      '</div>';
  }).join('');
}

function openTestimonialModal(id){
  _editingTestimonialId = id || null;
  var modal = document.getElementById('testimonialModal');
  if(!modal) return;
  var title = document.getElementById('tsMTitle');
  var delBtn = document.getElementById('tsDelBtn');
  if(id){
    var t = _testimonials.find(function(x){return x.id===id;});
    if(t){
      title.textContent = 'Сэтгэгдэл засах';
      document.getElementById('tsInName').value = t.name || '';
      document.getElementById('tsInRole').value = t.role || '';
      document.getElementById('tsInCompany').value = t.company || '';
      document.getElementById('tsInContent').value = t.content || '';
      document.getElementById('tsInRating').value = String(t.rating || 5);
      document.getElementById('tsInLang').value = t.lang || 'mn';
      document.getElementById('tsInOrder').value = t.display_order || 0;
      document.getElementById('tsInFeatured').checked = !!t.is_featured;
      delBtn.style.display = '';
    }
  } else {
    title.textContent = 'Шинэ сэтгэгдэл';
    document.getElementById('tsInName').value = '';
    document.getElementById('tsInRole').value = '';
    document.getElementById('tsInCompany').value = '';
    document.getElementById('tsInContent').value = '';
    document.getElementById('tsInRating').value = '5';
    document.getElementById('tsInLang').value = localStorage.getItem('nm_lang') || 'mn';
    document.getElementById('tsInOrder').value = _testimonials.length + 1;
    document.getElementById('tsInFeatured').checked = true;
    delBtn.style.display = 'none';
  }
  modal.style.display = 'flex';
}

function saveTestimonial(){
  var body = {
    name: document.getElementById('tsInName').value.trim(),
    role: document.getElementById('tsInRole').value.trim(),
    company: document.getElementById('tsInCompany').value.trim(),
    content: document.getElementById('tsInContent').value.trim(),
    rating: parseInt(document.getElementById('tsInRating').value) || 5,
    lang: document.getElementById('tsInLang').value,
    display_order: parseInt(document.getElementById('tsInOrder').value) || 0,
    is_featured: document.getElementById('tsInFeatured').checked
  };
  if(!body.name || !body.content){ toast('Нэр болон сэтгэгдэл шаардлагатай','error'); return; }
  var sb = _structSB();
  var url = _editingTestimonialId ? sb.URL+'/rest/v1/testimonials?id=eq.'+_editingTestimonialId : sb.URL+'/rest/v1/testimonials';
  fetch(url, {
    method: _editingTestimonialId ? 'PATCH' : 'POST',
    headers: {apikey:sb.KEY, Authorization:'Bearer '+sb.KEY, 'Content-Type':'application/json', 'Prefer':'return=minimal'},
    body: JSON.stringify(body)
  }).then(function(r){
    if(!r.ok) return r.text().then(function(t){ throw new Error(t||r.status); });
    toast('✅ Хадгалагдлаа','success');
    document.getElementById('testimonialModal').style.display='none';
    loadTestimonialsMgr();
  }).catch(function(err){
    toast('❌ Алдаа: '+(err.message||err),'error');
  });
}

function deleteTestimonialConfirm(){
  if(!_editingTestimonialId) return;
  if(!confirm('Энэ сэтгэгдлийг устгах уу?')) return;
  var sb = _structSB();
  fetch(sb.URL+'/rest/v1/testimonials?id=eq.'+_editingTestimonialId, {
    method: 'DELETE',
    headers: {apikey:sb.KEY, Authorization:'Bearer '+sb.KEY, 'Prefer':'return=minimal'}
  }).then(function(r){
    if(!r.ok) throw new Error(r.status);
    toast('✅ Устгагдлаа','success');
    document.getElementById('testimonialModal').style.display='none';
    loadTestimonialsMgr();
  }).catch(function(err){
    toast('❌ Алдаа: '+(err.message||err),'error');
  });
}

// ══ CRM / Leads Manager ══════════════════════════════
var _allLeads = [];

function loadLeadsMgr(){
  var list = document.getElementById('leads-list');
  if(!list) return;
  list.innerHTML = '<div style="color:#94a3b8;padding:1rem">⏳ Ачаалж байна...</div>';
  var sb = _structSB();
  fetch(sb.URL+'/rest/v1/leads?select=*&order=created_at.desc&limit=500', {
    headers: {apikey:sb.KEY, Authorization:'Bearer '+sb.KEY}
  }).then(function(r){
    if(!r.ok) throw new Error('status '+r.status);
    return r.json();
  }).then(function(rows){
    _allLeads = Array.isArray(rows) ? rows : [];
    renderLeadsStats();
    renderLeads();
    updateLeadsNavBadge();
  }).catch(function(err){
    console.error('[leads]', err);
    list.innerHTML = '<div style="padding:1rem;background:#fee2e2;border-radius:8px;color:#991b1b;font-size:.85rem">❌ Ачаалж чадсангүй: '+err.message+'<br><small>leads хүснэгт үүссэн эсэхийг шалгана уу. SETUP_CRM_LEADS.sql ажиллуулсан эсэх?</small></div>';
  });
}

function updateLeadsNavBadge(){
  var badge = document.getElementById('leadsNavBadge');
  if(!badge) return;
  var newCount = _allLeads.filter(function(l){return l.status==='new';}).length;
  if(newCount>0){
    badge.textContent = newCount;
    badge.style.display = '';
  } else {
    badge.style.display = 'none';
  }
}

function renderLeadsStats(){
  var el = document.getElementById('leads-stats');
  if(!el) return;
  var total = _allLeads.length;
  var newCount = _allLeads.filter(function(l){return l.status==='new';}).length;
  var progress = _allLeads.filter(function(l){return l.status==='in_progress';}).length;
  var converted = _allLeads.filter(function(l){return l.status==='converted';}).length;
  var today = new Date().toISOString().split('T')[0];
  var todayCount = _allLeads.filter(function(l){return (l.created_at||'').startsWith(today);}).length;
  
  el.innerHTML = 
    '<div style="background:linear-gradient(135deg,#1a2f7a,#2a4fca);color:#fff;padding:1rem;border-radius:10px"><div style="font-size:.65rem;opacity:.85;font-weight:700;text-transform:uppercase">Нийт</div><div style="font-size:1.6rem;font-weight:800;margin-top:.25rem">'+total+'</div></div>' +
    '<div style="background:#fef3c7;color:#78350f;padding:1rem;border-radius:10px;border:1px solid #fde68a"><div style="font-size:.65rem;font-weight:700;text-transform:uppercase">🆕 Шинэ</div><div style="font-size:1.6rem;font-weight:800;margin-top:.25rem">'+newCount+'</div></div>' +
    '<div style="background:#dbeafe;color:#1e3a8a;padding:1rem;border-radius:10px;border:1px solid #bfdbfe"><div style="font-size:.65rem;font-weight:700;text-transform:uppercase">⏳ Хийгдэж буй</div><div style="font-size:1.6rem;font-weight:800;margin-top:.25rem">'+progress+'</div></div>' +
    '<div style="background:#dcfce7;color:#166534;padding:1rem;border-radius:10px;border:1px solid #bbf7d0"><div style="font-size:.65rem;font-weight:700;text-transform:uppercase">✅ Хөрвүүлсэн</div><div style="font-size:1.6rem;font-weight:800;margin-top:.25rem">'+converted+'</div></div>' +
    '<div style="background:#f1f5f9;color:#0f172a;padding:1rem;border-radius:10px;border:1px solid #e2e8f0"><div style="font-size:.65rem;font-weight:700;text-transform:uppercase">📅 Өнөөдөр</div><div style="font-size:1.6rem;font-weight:800;margin-top:.25rem">'+todayCount+'</div></div>';
}

function renderLeads(){
  var list = document.getElementById('leads-list');
  if(!list) return;
  
  var filterType = (document.getElementById('leads-filter-type')||{}).value || '';
  var filterStatus = (document.getElementById('leads-filter-status')||{}).value || '';
  
  var filtered = _allLeads.filter(function(l){
    if(filterType && l.type !== filterType) return false;
    if(filterStatus && l.status !== filterStatus) return false;
    return true;
  });
  
  if(filtered.length === 0){
    list.innerHTML = '<div style="text-align:center;padding:3rem;color:#94a3b8">Хүсэлт байхгүй байна</div>';
    return;
  }
  
  var typeIcons = {contact:'📞', supplier:'🚚', buyer:'🛒', career:'💼', partner:'🤝', tender:'📋', media:'📰'};
  var statusColors = {new:'#f59e0b', in_progress:'#3b82f6', contacted:'#8b5cf6', converted:'#10b981', closed:'#64748b', spam:'#ef4444'};
  var statusLabels = {new:'🆕 Шинэ', in_progress:'⏳ Хийгдэж буй', contacted:'📞 Холбогдсон', converted:'✅ Хөрвүүлсэн', closed:'🔒 Хаасан', spam:'🗑 Spam'};
  
  list.innerHTML = filtered.map(function(l){
    var icon = typeIcons[l.type] || '📋';
    var statusColor = statusColors[l.status] || '#64748b';
    var statusLabel = statusLabels[l.status] || l.status;
    var date = new Date(l.created_at).toLocaleString('mn-MN', {month:'short', day:'numeric', hour:'2-digit', minute:'2-digit'});
    var msgPreview = (l.message||l.subject||'').substring(0, 100);
    if((l.message||l.subject||'').length > 100) msgPreview += '...';
    
    return '<div onclick="openLeadDetail('+l.id+')" style="background:#fff;border:1px solid #e8ecf2;border-radius:10px;padding:1rem;cursor:pointer;transition:all .15s;display:grid;grid-template-columns:auto 1fr auto;gap:1rem;align-items:start" onmouseover="this.style.borderColor=\'#2a4fca\';this.style.boxShadow=\'0 4px 12px rgba(0,0,0,.08)\'" onmouseout="this.style.borderColor=\'#e8ecf2\';this.style.boxShadow=\'\'">' +
      '<div style="font-size:1.5rem">'+icon+'</div>' +
      '<div style="min-width:0">' +
        '<div style="display:flex;align-items:center;gap:.5rem;flex-wrap:wrap;margin-bottom:.25rem">' +
          '<div style="font-weight:700;color:#0f172a">'+escapeHtml(l.full_name||'?')+'</div>' +
          '<span style="background:'+statusColor+'20;color:'+statusColor+';padding:2px 8px;border-radius:4px;font-size:.7rem;font-weight:700">'+statusLabel+'</span>' +
        '</div>' +
        '<div style="font-size:.75rem;color:#64748b;margin-bottom:.35rem">'+(l.email?escapeHtml(l.email):'')+(l.phone?' · '+escapeHtml(l.phone):'')+(l.company?' · '+escapeHtml(l.company):'')+'</div>' +
        '<div style="font-size:.8rem;color:#475569;line-height:1.5">'+escapeHtml(msgPreview)+'</div>' +
      '</div>' +
      '<div style="font-size:.7rem;color:#94a3b8;white-space:nowrap">'+date+'</div>' +
      '</div>';
  }).join('');
}

function openLeadDetail(id){
  var l = _allLeads.find(function(x){return x.id===id;});
  if(!l) return;
  var body = document.getElementById('ldModalBody');
  var statusOptions = ['new','in_progress','contacted','converted','closed','spam'];
  var statusLabels = {new:'🆕 Шинэ', in_progress:'⏳ Хийгдэж буй', contacted:'📞 Холбогдсон', converted:'✅ Хөрвүүлсэн', closed:'🔒 Хаасан', spam:'🗑 Spam'};
  
  body.innerHTML = 
    '<div style="display:grid;gap:1rem">' +
      '<div style="display:grid;grid-template-columns:1fr 1fr;gap:.75rem">' +
        '<div><div style="font-size:.7rem;font-weight:700;color:#64748b;text-transform:uppercase">Нэр</div><div style="font-weight:700;margin-top:.2rem">'+escapeHtml(l.full_name||'')+'</div></div>' +
        '<div><div style="font-size:.7rem;font-weight:700;color:#64748b;text-transform:uppercase">Төрөл</div><div style="margin-top:.2rem">'+escapeHtml(l.type||'')+'</div></div>' +
      '</div>' +
      '<div style="display:grid;grid-template-columns:1fr 1fr;gap:.75rem">' +
        '<div><div style="font-size:.7rem;font-weight:700;color:#64748b;text-transform:uppercase">И-мэйл</div><div style="margin-top:.2rem">'+(l.email?'<a href="mailto:'+escapeHtml(l.email)+'" style="color:#2a4fca">'+escapeHtml(l.email)+'</a>':'—')+'</div></div>' +
        '<div><div style="font-size:.7rem;font-weight:700;color:#64748b;text-transform:uppercase">Утас</div><div style="margin-top:.2rem">'+(l.phone?'<a href="tel:'+escapeHtml(l.phone)+'" style="color:#2a4fca">'+escapeHtml(l.phone)+'</a>':'—')+'</div></div>' +
      '</div>' +
      (l.company?'<div><div style="font-size:.7rem;font-weight:700;color:#64748b;text-transform:uppercase">Компани</div><div style="margin-top:.2rem">'+escapeHtml(l.company)+'</div></div>':'') +
      (l.subject?'<div><div style="font-size:.7rem;font-weight:700;color:#64748b;text-transform:uppercase">Сэдэв</div><div style="margin-top:.2rem">'+escapeHtml(l.subject)+'</div></div>':'') +
      (l.message?'<div><div style="font-size:.7rem;font-weight:700;color:#64748b;text-transform:uppercase">Мессеж</div><div style="margin-top:.2rem;padding:.75rem;background:#f8fafc;border-radius:8px;white-space:pre-wrap">'+escapeHtml(l.message)+'</div></div>':'') +
      '<div><div style="font-size:.7rem;font-weight:700;color:#64748b;text-transform:uppercase;margin-bottom:.4rem">Статус</div>' +
        '<select id="ld-status-select" class="form-control" onchange="updateLeadStatus('+l.id+', this.value)">' +
        statusOptions.map(function(s){return '<option value="'+s+'"'+(s===l.status?' selected':'')+'>'+statusLabels[s]+'</option>';}).join('') +
        '</select></div>' +
      '<div><div style="font-size:.7rem;font-weight:700;color:#64748b;text-transform:uppercase;margin-bottom:.4rem">Дотоод тэмдэглэл</div>' +
        '<textarea id="ld-notes" class="form-control" rows="3" placeholder="Admin тэмдэглэл...">'+escapeHtml(l.notes||'')+'</textarea>' +
        '<button onclick="saveLeadNotes('+l.id+')" class="btn btn-primary btn-sm" style="margin-top:.5rem">💾 Тэмдэглэл хадгалах</button></div>' +
      '<div style="display:grid;grid-template-columns:1fr 1fr;gap:.75rem;padding-top:.75rem;border-top:1px solid #e8ecf2">' +
        '<div><div style="font-size:.68rem;color:#94a3b8">📅 Үүссэн</div><div style="font-size:.78rem">'+new Date(l.created_at).toLocaleString('mn-MN')+'</div></div>' +
        '<div><div style="font-size:.68rem;color:#94a3b8">🔗 Эх сурвалж</div><div style="font-size:.78rem;word-break:break-all">'+escapeHtml(l.source_url||'—')+'</div></div>' +
      '</div>' +
      '<div style="display:flex;gap:.5rem;justify-content:space-between;padding-top:.75rem;border-top:1px solid #e8ecf2">' +
        '<button class="btn btn-danger btn-sm" onclick="deleteLeadConfirm('+l.id+')">🗑 Устгах</button>' +
        '<button class="btn btn-outline btn-sm" onclick="document.getElementById(\'leadModal\').style.display=\'none\'">Хаах</button>' +
      '</div>' +
    '</div>';
  document.getElementById('leadModal').style.display='flex';
}

function updateLeadStatus(id, status){
  var sb = _structSB();
  var body = {status: status};
  if(status==='contacted') body.contacted_at = new Date().toISOString();
  if(status==='converted') body.converted_at = new Date().toISOString();
  
  fetch(sb.URL+'/rest/v1/leads?id=eq.'+id, {
    method: 'PATCH',
    headers: {apikey:sb.KEY, Authorization:'Bearer '+sb.KEY, 'Content-Type':'application/json', 'Prefer':'return=minimal'},
    body: JSON.stringify(body)
  }).then(function(r){
    if(!r.ok) throw new Error(r.status);
    toast('✅ Статус шинэчлэгдлээ','success');
    var idx = _allLeads.findIndex(function(x){return x.id===id;});
    if(idx>=0) _allLeads[idx].status = status;
    renderLeadsStats();
    renderLeads();
    updateLeadsNavBadge();
  }).catch(function(err){
    toast('❌ Алдаа: '+err,'error');
  });
}

function saveLeadNotes(id){
  var notes = document.getElementById('ld-notes').value;
  var sb = _structSB();
  fetch(sb.URL+'/rest/v1/leads?id=eq.'+id, {
    method: 'PATCH',
    headers: {apikey:sb.KEY, Authorization:'Bearer '+sb.KEY, 'Content-Type':'application/json', 'Prefer':'return=minimal'},
    body: JSON.stringify({notes: notes})
  }).then(function(r){
    if(!r.ok) throw new Error(r.status);
    toast('✅ Тэмдэглэл хадгалагдлаа','success');
    var idx = _allLeads.findIndex(function(x){return x.id===id;});
    if(idx>=0) _allLeads[idx].notes = notes;
  }).catch(function(err){
    toast('❌ Алдаа: '+err,'error');
  });
}

function deleteLeadConfirm(id){
  if(!confirm('Энэ хүсэлтийг устгах уу?')) return;
  var sb = _structSB();
  fetch(sb.URL+'/rest/v1/leads?id=eq.'+id, {
    method: 'DELETE',
    headers: {apikey:sb.KEY, Authorization:'Bearer '+sb.KEY}
  }).then(function(r){
    if(!r.ok) throw new Error(r.status);
    toast('✅ Устгагдлаа','success');
    document.getElementById('leadModal').style.display='none';
    loadLeadsMgr();
  }).catch(function(err){
    toast('❌ Алдаа: '+err,'error');
  });
}

function exportLeadsCSV(){
  if(_allLeads.length === 0){ toast('Өгөгдөл байхгүй','error'); return; }
  var headers = ['ID','Төрөл','Нэр','Имэйл','Утас','Компани','Сэдэв','Мессеж','Статус','Үүссэн'];
  var rows = _allLeads.map(function(l){
    return [l.id, l.type, l.full_name, l.email||'', l.phone||'', l.company||'', l.subject||'', (l.message||'').replace(/[\n\r]/g,' '), l.status, l.created_at];
  });
  var csv = headers.join(',') + '\n' + rows.map(function(r){
    return r.map(function(c){ return '"'+String(c).replace(/"/g,'""')+'"'; }).join(',');
  }).join('\n');
  
  var blob = new Blob(['\uFEFF'+csv], {type:'text/csv;charset=utf-8;'});
  var url = URL.createObjectURL(blob);
  var link = document.createElement('a');
  link.href = url;
  link.download = 'nomin-leads-'+new Date().toISOString().split('T')[0]+'.csv';
  link.click();
  URL.revokeObjectURL(url);
  toast('✅ CSV файл татагдлаа','success');
}

// ══ Full Diagnose (Combined audit + diagnose) ═════════════
var _diagData = { tables: [], pages: [], connectivity: [] };

function showDiagTab(tab){
  document.querySelectorAll('.diag-tab-btn').forEach(function(b){
    var isActive = b.dataset.tab === tab;
    b.style.color = isActive ? 'var(--navy)' : '#64748b';
    b.style.borderBottomColor = isActive ? 'var(--blue)' : 'transparent';
    b.style.fontWeight = isActive ? '700' : '600';
  });
  renderDiagTabContent(tab);
}

function renderDiagTabContent(tab){
  var el = document.getElementById('audit-results');
  if(!el) return;
  
  if(tab === 'tables'){
    var results = _diagData.tables;
    el.innerHTML = '<div style="overflow-x:auto"><table style="width:100%;border-collapse:collapse;font-size:.82rem">' +
      '<thead><tr style="background:#f8fafc">' +
        '<th style="padding:.65rem 1rem;text-align:left;border-bottom:2px solid #e8ecf2">Хүснэгт</th>' +
        '<th style="padding:.65rem 1rem;text-align:left;border-bottom:2px solid #e8ecf2">Статус</th>' +
        '<th style="padding:.65rem 1rem;text-align:right;border-bottom:2px solid #e8ecf2">Мөрийн тоо</th>' +
        '<th style="padding:.65rem 1rem;text-align:left;border-bottom:2px solid #e8ecf2">Жишээ</th>' +
      '</tr></thead><tbody>' +
      results.map(function(r){
        var status = r.ok 
          ? '<span style="color:#16a34a;font-weight:700">✓ ' + r.status + '</span>'
          : '<span style="color:#dc2626;font-weight:700">✗ ' + (r.status || 'Алдаа') + '</span>';
        var example = r.data && r.data[0] 
          ? Object.keys(r.data[0]).slice(0,3).map(function(k){ return k+'='+String(r.data[0][k]).substring(0,20); }).join(', ')
          : '—';
        return '<tr style="border-bottom:1px solid #f1f5f9">' +
          '<td style="padding:.6rem 1rem"><b>' + escapeHtml(r.table) + '</b></td>' +
          '<td style="padding:.6rem 1rem">' + status + '</td>' +
          '<td style="padding:.6rem 1rem;text-align:right;font-weight:600">' + (r.count || 0) + '</td>' +
          '<td style="padding:.6rem 1rem;font-family:monospace;font-size:.72rem;color:#64748b">' + escapeHtml(example) + '</td>' +
        '</tr>';
      }).join('') +
      '</tbody></table></div>';
  } else if(tab === 'pages'){
    var results = _diagData.pages;
    el.innerHTML = '<div style="overflow-x:auto"><table style="width:100%;border-collapse:collapse;font-size:.82rem">' +
      '<thead><tr style="background:#f8fafc">' +
        '<th style="padding:.65rem 1rem;text-align:left;border-bottom:2px solid #e8ecf2">Хуудас</th>' +
        '<th style="padding:.65rem 1rem;text-align:left;border-bottom:2px solid #e8ecf2">Статус</th>' +
        '<th style="padding:.65rem 1rem;text-align:right;border-bottom:2px solid #e8ecf2">Хэмжээ</th>' +
        '<th style="padding:.65rem 1rem;text-align:right;border-bottom:2px solid #e8ecf2">Зураг</th>' +
        '<th style="padding:.65rem 1rem;text-align:center;border-bottom:2px solid #e8ecf2">Nav</th>' +
      '</tr></thead><tbody>' +
      results.map(function(r){
        var status = r.ok 
          ? '<span style="color:#16a34a;font-weight:700">✓ ' + r.status + '</span>'
          : '<span style="color:#dc2626;font-weight:700">✗ ' + (r.status || 'Алдаа') + '</span>';
        return '<tr style="border-bottom:1px solid #f1f5f9">' +
          '<td style="padding:.6rem 1rem"><a href="/' + escapeHtml(r.page) + '" target="_blank" style="color:var(--blue);text-decoration:none"><b>' + escapeHtml(r.page) + '</b></a></td>' +
          '<td style="padding:.6rem 1rem">' + status + '</td>' +
          '<td style="padding:.6rem 1rem;text-align:right">' + (r.size ? Math.round(r.size/1024)+' KB' : '—') + '</td>' +
          '<td style="padding:.6rem 1rem;text-align:right">' + (r.hasImages || 0) + '</td>' +
          '<td style="padding:.6rem 1rem;text-align:center">' + (r.hasNav ? '✓' : '✗') + '</td>' +
        '</tr>';
      }).join('') +
      '</tbody></table></div>';
  } else if(tab === 'connectivity'){
    var results = _diagData.connectivity;
    el.innerHTML = results.map(function(r){
      var icon = r.ok ? '<span style="color:#16a34a">✓</span>' : '<span style="color:#dc2626">✗</span>';
      var detail = r.error || ('HTTP ' + r.status);
      return '<div style="padding:.85rem 1rem;border-bottom:1px solid #f1f5f9;display:flex;align-items:center;gap:.75rem">' +
        '<span style="font-size:1.25rem">' + icon + '</span>' +
        '<div style="flex:1"><div style="font-weight:700;font-size:.88rem">' + escapeHtml(r.name) + '</div>' +
        '<div style="font-size:.72rem;color:#64748b;font-family:monospace;margin-top:.2rem">' + escapeHtml(detail) + '</div></div>' +
      '</div>';
    }).join('');
  } else if(tab === 'quick'){
    // Re-run quick audit
    runFullAudit();
  }
}

async function runFullDiagnose(){
  var el = document.getElementById('audit-results');
  var summaryEl = document.getElementById('diag-summary');
  var tabsEl = document.getElementById('diag-tabs');
  if(!el) return;
  
  el.innerHTML = '<div style="text-align:center;padding:3rem"><div style="font-size:2rem;margin-bottom:.75rem">⏳</div><div style="color:#64748b">Оношлогоо ажиллаж байна... (~10 сек)</div></div>';
  
  var SB_URL = window.__NM_SB_URL__ || 'https://hunygqumohxinhndrcph.supabase.co';
  var SB_KEY = window.__NM_SB_KEY__ || 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6Imh1bnlncXVtb2h4aW5obmRyY3BoIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NzQzNTA4NjMsImV4cCI6MjA4OTkyNjg2M30.2eFxPABgxosblHajh85txP_yrv0VsDCbhxSVIcO3T88';
  
  // 1. Check all tables
  var tables = ['news','banners','jobs','tenders','suppliers','stores','leadership','pages','page_sections','translations','menu','settings','blocks','companies','contact_messages','revisions','sectors','testimonials','leads'];
  var tableResults = [];
  for(var i=0;i<tables.length;i++){
    var t = tables[i];
    try {
      var r = await fetch(SB_URL+'/rest/v1/'+t+'?select=*&limit=3', {
        headers: {apikey:SB_KEY, Authorization:'Bearer '+SB_KEY, Prefer:'count=exact'}
      });
      var count = (r.headers.get('content-range')||'').split('/')[1];
      var data = r.ok ? await r.json() : [];
      tableResults.push({table:t, ok:r.ok, count:count||data.length, data:data, status:r.status});
    } catch(e){ tableResults.push({table:t, ok:false, error:e.message, status:0}); }
  }
  _diagData.tables = tableResults;
  
  // 2. Check pages
  var pages = ['index.html','about.html','history.html','leadership.html','mission.html','awards.html','business.html','brands.html','news.html','careers.html','tender.html','suppliers.html','buyers.html','contact.html','store-locator.html','catalogue.html','bonus-card.html','social.html','why-choose-us.html','sector-retail.html','sector-import.html','sector-finance.html','sector-construction.html','sector-tech.html','sector-aviation.html'];
  var pageResults = [];
  for(var j=0;j<pages.length;j++){
    var p = pages[j];
    try {
      var pr = await fetch('/'+p);
      var text = pr.ok ? await pr.text() : '';
      pageResults.push({
        page:p, ok:pr.ok, status:pr.status,
        size:text.length,
        hasTitle:/<title>([^<]+)<\/title>/.test(text),
        hasImages:(text.match(/<img/gi)||[]).length,
        hasNav:/<nav|<header/i.test(text)
      });
    } catch(e){ pageResults.push({page:p, ok:false, error:e.message, status:0}); }
  }
  _diagData.pages = pageResults;
  
  // 3. Connectivity
  var tests = [
    { name:'Supabase REST API', url:SB_URL+'/rest/v1/' },
    { name:'Supabase Storage', url:SB_URL+'/storage/v1/object/public/media/' },
    { name:'Google Fonts', url:'https://fonts.googleapis.com/css2?family=Inter' }
  ];
  var connResults = [];
  for(var k=0;k<tests.length;k++){
    var tt = tests[k];
    try {
      var rr = await fetch(tt.url, {headers:{apikey:SB_KEY, Authorization:'Bearer '+SB_KEY}, mode:'cors'});
      connResults.push({name:tt.name, ok:true, status:rr.status});
    } catch(e){ connResults.push({name:tt.name, ok:false, error:e.message}); }
  }
  _diagData.connectivity = connResults;
  
  // Render summary
  var tableOk = tableResults.filter(function(r){return r.ok;}).length;
  var pageOk = pageResults.filter(function(r){return r.ok;}).length;
  var connOk = connResults.filter(function(r){return r.ok;}).length;
  var totalRows = tableResults.reduce(function(s,r){return s + (parseInt(r.count)||0);}, 0);
  
  summaryEl.innerHTML = 
    '<div style="background:linear-gradient(135deg,#1a2f7a,#2a4fca);color:#fff;padding:1rem;border-radius:10px"><div style="font-size:.65rem;opacity:.85;font-weight:700;text-transform:uppercase">Хүснэгт</div><div style="font-size:1.6rem;font-weight:800;margin-top:.25rem">'+tableOk+'/'+tableResults.length+'</div></div>' +
    '<div style="background:'+(pageOk===pageResults.length?'#dcfce7':'#fef3c7')+';color:'+(pageOk===pageResults.length?'#166534':'#78350f')+';padding:1rem;border-radius:10px;border:1px solid '+(pageOk===pageResults.length?'#bbf7d0':'#fde68a')+'"><div style="font-size:.65rem;font-weight:700;text-transform:uppercase">Хуудас</div><div style="font-size:1.6rem;font-weight:800;margin-top:.25rem">'+pageOk+'/'+pageResults.length+'</div></div>' +
    '<div style="background:'+(connOk===connResults.length?'#dbeafe':'#fee2e2')+';color:'+(connOk===connResults.length?'#1e3a8a':'#991b1b')+';padding:1rem;border-radius:10px;border:1px solid '+(connOk===connResults.length?'#bfdbfe':'#fecaca')+'"><div style="font-size:.65rem;font-weight:700;text-transform:uppercase">Холболт</div><div style="font-size:1.6rem;font-weight:800;margin-top:.25rem">'+connOk+'/'+connResults.length+'</div></div>' +
    '<div style="background:#f1f5f9;color:#0f172a;padding:1rem;border-radius:10px;border:1px solid #e2e8f0"><div style="font-size:.65rem;font-weight:700;text-transform:uppercase">Нийт мөр</div><div style="font-size:1.6rem;font-weight:800;margin-top:.25rem">'+totalRows.toLocaleString()+'</div></div>';
  summaryEl.style.display = 'grid';
  tabsEl.style.display = 'flex';
  
  // Show first tab
  showDiagTab('tables');
  toast('✅ Оношлогоо дууссан','success');
}
