import { useState, useEffect, useRef } from 'react';
import { useNavigate } from 'react-router-dom';
import {
  collection, addDoc, query, orderBy,
  onSnapshot, serverTimestamp, limit,
  doc, setDoc, onSnapshot as onSnap,
  getDocs, where
} from 'firebase/firestore';
import { auth, db } from '../firebase';

// ── Өнгөний палитр ───────────────────────────────────────────
const COLORS = ['#4D068E','#16a34a','#d97706','#0ea5e9','#ec4899','#f97316','#7c3aed','#dc2626'];
const getColor = (uid) => COLORS[(uid?.charCodeAt(0) || 0) % COLORS.length];
const getInitial = (name) => (name || '?')[0].toUpperCase();
const fmtTime = (ts) => {
  if (!ts) return '';
  const d = ts.toDate ? ts.toDate() : new Date(ts);
  return d.toLocaleTimeString('mn-MN', { hour: '2-digit', minute: '2-digit' });
};

// ── Өрөөний жагсаалт ─────────────────────────────────────────
const ROOMS = [
  { id: 'general',  name: 'Нийтийн өрөө',   icon: '🌍', desc: 'Бүгдэд нээлттэй' },
  { id: 'mongolia', name: 'Монгол дотор',    icon: '🇲🇳', desc: 'Улаанбаатар & дотоод' },
  { id: 'korea',    name: 'Солонгос',         icon: '🇰🇷', desc: 'Солонгост байгаа монголчууд' },
  { id: 'usa',      name: 'Америк',           icon: '🇺🇸', desc: 'АНУ-д байгаа монголчууд' },
  { id: 'europe',   name: 'Европ',            icon: '🇪🇺', desc: 'Европт байгаа монголчууд' },
  { id: 'japan',    name: 'Япон',             icon: '🇯🇵', desc: 'Японд байгаа монголчууд' },
];

export default function Messenger() {
  const navigate = useNavigate();
  const [user, setUser]               = useState(null);
  const [tab, setTab]                 = useState('rooms');     // rooms | online | dm
  const [activeRoom, setActiveRoom]   = useState(ROOMS[0]);
  const [activeDM, setActiveDM]       = useState(null);
  const [messages, setMessages]       = useState([]);
  const [input, setInput]             = useState('');
  const [onlineUsers, setOnlineUsers] = useState([]);
  const [typing, setTyping]           = useState(false);
  const [status, setStatus]           = useState('online');    // online | away | busy
  const [statusMenu, setStatusMenu]   = useState(false);
  const [searchQ, setSearchQ]         = useState('');
  const bottomRef = useRef(null);
  const typingTimer = useRef(null);

  // ── Auth шалгалт ──────────────────────────────────────────
  useEffect(() => {
    const unsub = auth.onAuthStateChanged(async (u) => {
      if (!u) { navigate('/login'); return; }
      setUser(u);
      // Presence бичих
      await setDoc(doc(db, 'presence', u.uid), {
        uid: u.uid,
        name: u.displayName || u.phoneNumber || 'Монгол',
        status: 'online',
        lastSeen: serverTimestamp(),
      }, { merge: true });
    });
    return () => unsub();
  }, [navigate]);

  // ── Presence ажиглах ──────────────────────────────────────
  useEffect(() => {
    const q = query(collection(db, 'presence'), where('status', '!=', 'offline'));
    const unsub = onSnapshot(q, (snap) => {
      setOnlineUsers(snap.docs.map(d => d.data()).filter(u => u.uid !== auth.currentUser?.uid));
    });
    return () => unsub();
  }, []);

  // ── Мессеж ажиглах ────────────────────────────────────────
  useEffect(() => {
    const col = activeDM
      ? `dm_${[auth.currentUser?.uid, activeDM.uid].sort().join('_')}`
      : `rooms/${activeRoom.id}/messages`;

    const q = query(collection(db, col), orderBy('createdAt', 'asc'), limit(80));
    const unsub = onSnapshot(q, (snap) => {
      setMessages(snap.docs.map(d => ({ id: d.id, ...d.data() })));
    });
    return () => unsub();
  }, [activeRoom, activeDM]);

  // ── Scroll ────────────────────────────────────────────────
  useEffect(() => {
    bottomRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages]);

  // ── Мессеж илгээх ─────────────────────────────────────────
  const sendMsg = async () => {
    const text = input.trim();
    if (!text || !user) return;
    setInput('');
    const col = activeDM
      ? `dm_${[user.uid, activeDM.uid].sort().join('_')}`
      : `rooms/${activeRoom.id}/messages`;
    await addDoc(collection(db, col), {
      text,
      uid:       user.uid,
      name:      user.displayName || user.phoneNumber || 'Монгол',
      createdAt: serverTimestamp(),
    });
  };

  // ── Typing indicator ──────────────────────────────────────
  const handleInput = (e) => {
    setInput(e.target.value);
    clearTimeout(typingTimer.current);
    typingTimer.current = setTimeout(() => setTyping(false), 2000);
  };

  // ── Статус солих ──────────────────────────────────────────
  const changeStatus = async (s) => {
    setStatus(s);
    setStatusMenu(false);
    if (user) {
      await setDoc(doc(db, 'presence', user.uid), { status: s }, { merge: true });
    }
  };

  // ── Logout ────────────────────────────────────────────────
  const logout = async () => {
    if (user) {
      await setDoc(doc(db, 'presence', user.uid), { status: 'offline' }, { merge: true });
    }
    localStorage.removeItem('phone_user'); await auth.signOut();
    navigate('/');
  };

  const myName    = user?.displayName || user?.phoneNumber || 'Монгол';
  const chatTitle = activeDM ? activeDM.name : activeRoom.name;
  const chatIcon  = activeDM ? activeDM.icon || '👤' : activeRoom.icon;
  const chatDesc  = activeDM ? `💬 Шууд мессеж` : activeRoom.desc;

  const filteredOnline = onlineUsers.filter(u =>
    u.name?.toLowerCase().includes(searchQ.toLowerCase())
  );

  const STATUS_OPTS = [
    { key: 'online', label: '🟢 Онлайн',    color: '#4ade80' },
    { key: 'away',   label: '🟡 Чөлөөгүй',  color: '#fbbf24' },
    { key: 'busy',   label: '🔴 Завгүй',    color: '#f87171' },
  ];
  const myStatus = STATUS_OPTS.find(s => s.key === status);

  return (
    <div style={S.root} onClick={() => setStatusMenu(false)}>

      {/* ══ ЗҮҮН: Buddy Panel ══ */}
      <div style={S.panel}>

        {/* Миний профайл */}
        <div style={S.myProfile}>
          <div style={{ ...S.ava, background: getColor(user?.uid), fontSize: 18, width: 42, height: 42 }}>
            {getInitial(myName)}
          </div>
          <div style={S.myInfo}>
            <div style={S.myName}>{myName}</div>
            <div
              style={S.myStatusRow}
              onClick={(e) => { e.stopPropagation(); setStatusMenu(v => !v); }}
            >
              <span style={{ ...S.dot, background: myStatus?.color }} />
              <span style={S.myStatusText}>{myStatus?.label}</span>
              <span style={{ color: 'rgba(255,255,255,.4)', fontSize: 10 }}>▾</span>
            </div>
          </div>
          <button style={S.backBtn} onClick={() => navigate('/')} title="Буцах">←</button>
        </div>

        {/* Статус цэс */}
        {statusMenu && (
          <div style={S.statusMenu} onClick={e => e.stopPropagation()}>
            {STATUS_OPTS.map(opt => (
              <div key={opt.key} style={S.statusOpt} onClick={() => changeStatus(opt.key)}>
                <span style={{ ...S.dot, background: opt.color }} />
                {opt.label}
              </div>
            ))}
          </div>
        )}

        {/* Хайлт */}
        <div style={S.searchWrap}>
          <input
            style={S.searchInput}
            placeholder="🔍 Хайх..."
            value={searchQ}
            onChange={e => setSearchQ(e.target.value)}
          />
        </div>

        {/* Табууд */}
        <div style={S.tabs}>
          {[
            { key: 'rooms',  label: '🚪 Өрөөнүүд' },
            { key: 'online', label: `🟢 Онлайн (${onlineUsers.length})` },
          ].map(t => (
            <div
              key={t.key}
              style={{ ...S.tab, ...(tab === t.key ? S.tabActive : {}) }}
              onClick={() => setTab(t.key)}
            >
              {t.label}
            </div>
          ))}
        </div>

        {/* Жагсаалт */}
        <div style={S.listScroll}>
          {tab === 'rooms' && (
            <>
              <div style={S.groupLabel}>ӨРӨӨНҮҮД</div>
              {ROOMS.map(room => (
                <div
                  key={room.id}
                  style={{
                    ...S.listItem,
                    ...(activeRoom?.id === room.id && !activeDM ? S.listItemActive : {}),
                  }}
                  onClick={() => { setActiveRoom(room); setActiveDM(null); }}
                >
                  <div style={S.roomIcon}>{room.icon}</div>
                  <div style={S.listInfo}>
                    <div style={S.listName}>{room.name}</div>
                    <div style={S.listSub}>{room.desc}</div>
                  </div>
                </div>
              ))}
            </>
          )}

          {tab === 'online' && (
            <>
              <div style={S.groupLabel}>ОНЛАЙН ({filteredOnline.length})</div>
              {filteredOnline.length === 0 && (
                <div style={S.emptyMsg}>Одоохондоо хэн ч онлайн байхгүй</div>
              )}
              {filteredOnline.map(u => (
                <div
                  key={u.uid}
                  style={{
                    ...S.listItem,
                    ...(activeDM?.uid === u.uid ? S.listItemActive : {}),
                  }}
                  onClick={() => {
                    setActiveDM({ ...u, icon: '👤' });
                    setTab('online');
                  }}
                >
                  <div style={{ position: 'relative', flexShrink: 0 }}>
                    <div style={{ ...S.ava, background: getColor(u.uid) }}>
                      {getInitial(u.name)}
                    </div>
                    <span style={{
                      ...S.dot,
                      position: 'absolute', bottom: -1, right: -1,
                      border: '2px solid #1a0a3d',
                      background: u.status === 'away' ? '#fbbf24' : u.status === 'busy' ? '#f87171' : '#4ade80',
                    }} />
                  </div>
                  <div style={S.listInfo}>
                    <div style={S.listName}>{u.name}</div>
                    <div style={S.listSub}>
                      {u.status === 'away' ? '🟡 Чөлөөгүй' : u.status === 'busy' ? '🔴 Завгүй' : '🟢 Онлайн'}
                    </div>
                  </div>
                </div>
              ))}
            </>
          )}
        </div>

        {/* Footer */}
        <div style={S.panelFooter}>
          <button style={S.footerBtn} onClick={() => navigate('/chat')} title="Хуучин чат">💬</button>
          <button style={S.footerBtn} onClick={() => navigate('/profile')} title="Профайл">👤</button>
          <button style={S.footerBtn} onClick={logout} title="Гарах">🚪</button>
        </div>
      </div>

      {/* ══ ГОЛ: Chat Area ══ */}
      <div style={S.chatArea}>

        {/* Chat header */}
        <div style={S.chatHeader}>
          <div style={{ ...S.ava, background: activeDM ? getColor(activeDM.uid) : '#4D068E', fontSize: 16, width: 36, height: 36 }}>
            {activeDM ? getInitial(activeDM.name) : chatIcon}
          </div>
          <div style={S.chatHeaderInfo}>
            <div style={S.chatTitle}>{chatTitle}</div>
            <div style={S.chatSub}>{chatDesc}</div>
          </div>
          <div style={S.chatActions}>
            {['📞', '📹', '📎', '🎮'].map(ic => (
              <button key={ic} style={S.actionBtn}>{ic}</button>
            ))}
          </div>
        </div>

        {/* Toolbar */}
        <div style={S.toolbar}>
          {['B','I','U'].map(f => (
            <button key={f} style={S.toolBtn}><span style={f==='B'?{fontWeight:700}:f==='I'?{fontStyle:'italic'}:{textDecoration:'underline'}}>{f}</span></button>
          ))}
          <div style={S.toolSep}/>
          {['😊','🎵','🎲','🎯','❤️','👏'].map(em => (
            <button key={em} style={S.toolBtn} onClick={() => setInput(v => v + em)}>{em}</button>
          ))}
          <div style={S.toolSep}/>
          <button style={S.toolBtn} title="Файл">📎</button>
          <button style={S.toolBtn} title="Зураг">🖼️</button>
        </div>

        {/* Messages */}
        <div style={S.messages}>
          {messages.length === 0 && (
            <div style={S.emptyChat}>
              <div style={{ fontSize: 40, marginBottom: 12 }}>{chatIcon}</div>
              <div style={{ fontSize: 14, color: '#888' }}>{chatTitle} — яриа эхлүүлнэ үү!</div>
            </div>
          )}

          {messages.map((msg, i) => {
            const isMe = msg.uid === user?.uid;
            const showName = !isMe && (i === 0 || messages[i-1]?.uid !== msg.uid);
            return (
              <div key={msg.id} style={{ ...S.msgRow, ...(isMe ? S.msgRowMe : {}) }}>
                {!isMe && (
                  <div style={{ ...S.ava, background: getColor(msg.uid), width: 28, height: 28, fontSize: 11, flexShrink: 0, alignSelf: 'flex-end', marginBottom: 2 }}>
                    {getInitial(msg.name)}
                  </div>
                )}
                <div style={S.msgBody}>
                  {showName && <div style={S.msgSender}>{msg.name}</div>}
                  <div style={{ ...S.bubble, ...(isMe ? S.bubbleMe : S.bubbleThem) }}>
                    {msg.text}
                  </div>
                  <div style={{ ...S.msgTime, ...(isMe ? { textAlign: 'right' } : {}) }}>
                    {fmtTime(msg.createdAt)}
                  </div>
                </div>
              </div>
            );
          })}
          <div ref={bottomRef} />
        </div>

        {/* Input */}
        <div style={S.inputArea}>
          <input
            style={S.input}
            value={input}
            onChange={handleInput}
            onKeyDown={e => e.key === 'Enter' && !e.shiftKey && sendMsg()}
            placeholder={`${activeDM ? activeDM.name : chatTitle}-д мессеж бичих...`}
          />
          <button style={S.sendBtn} onClick={sendMsg}>Илгээх ➤</button>
        </div>
      </div>

      {/* ══ БАРУУН: Info Panel ══ */}
      <div style={S.infoPanel}>
        <div style={S.infoTop}>
          <div style={{ ...S.ava, background: activeDM ? getColor(activeDM.uid) : '#4D068E', width: 56, height: 56, fontSize: 22, margin: '0 auto 10px' }}>
            {activeDM ? getInitial(activeDM.name) : chatIcon}
          </div>
          <div style={S.infoName}>{chatTitle}</div>
          <div style={S.infoSub}>{chatDesc}</div>
          {!activeDM && (
            <div style={S.memberCount}>
              <span style={S.dot} /> {onlineUsers.length + 1} гишүүн онлайн
            </div>
          )}
        </div>

        {!activeDM && (
          <div style={S.infoSection}>
            <div style={S.infoLabel}>ОНЛАЙН ГИШҮҮД</div>
            {[{ uid: user?.uid, name: myName }, ...onlineUsers.slice(0, 6)].map(u => (
              <div key={u.uid} style={S.infoUser}>
                <div style={{ ...S.ava, background: getColor(u.uid), width: 22, height: 22, fontSize: 9, flexShrink: 0 }}>
                  {getInitial(u.name)}
                </div>
                <span style={S.infoUserName}>{u.name}</span>
                {u.uid === user?.uid && <span style={S.meBadge}>та</span>}
              </div>
            ))}
          </div>
        )}

        {activeDM && (
          <div style={S.infoSection}>
            <div style={S.infoLabel}>ХЭРЭГЛЭГЧИЙН МЭДЭЭЛЭЛ</div>
            <div style={S.infoItem}>
              <span style={S.dot} />
              <span>{activeDM.status === 'away' ? 'Чөлөөгүй' : activeDM.status === 'busy' ? 'Завгүй' : 'Онлайн'}</span>
            </div>
          </div>
        )}

        <div style={S.infoSection}>
          <div style={S.infoLabel}>ДҮРЭМ</div>
          <div style={{ fontSize: 11, color: 'rgba(255,255,255,.4)', lineHeight: 1.6 }}>
            Хүндэтгэлтэй хандаарай. Монгол хэлээр бичнэ үү.
          </div>
        </div>
      </div>

    </div>
  );
}

// ── Styles ────────────────────────────────────────────────────
const S = {
  root: {
    height: '100vh',
    display: 'flex',
    background: '#0d0620',
    fontFamily: "'Segoe UI', Arial, sans-serif",
    fontSize: 14,
    overflow: 'hidden',
    position: 'relative',
  },
  // Panel
  panel: {
    width: 240,
    background: '#1a0a3d',
    display: 'flex',
    flexDirection: 'column',
    flexShrink: 0,
    borderRight: '1px solid rgba(255,255,255,.05)',
  },
  myProfile: {
    background: 'linear-gradient(135deg,#4D068E,#7c3aed)',
    padding: '14px 12px',
    display: 'flex',
    alignItems: 'center',
    gap: 10,
    position: 'relative',
  },
  myInfo: { flex: 1, minWidth: 0 },
  myName: { color: '#fff', fontSize: 13, fontWeight: 700, overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' },
  myStatusRow: { display: 'flex', alignItems: 'center', gap: 5, cursor: 'pointer', marginTop: 3 },
  myStatusText: { fontSize: 11, color: 'rgba(255,255,255,.75)' },
  backBtn: { background: 'rgba(255,255,255,.1)', border: 'none', color: '#fff', borderRadius: 8, padding: '4px 8px', cursor: 'pointer', fontSize: 14, flexShrink: 0 },
  statusMenu: {
    position: 'absolute', top: 70, left: 12, zIndex: 100,
    background: '#2d1b69', border: '1px solid rgba(255,255,255,.1)',
    borderRadius: 10, overflow: 'hidden', minWidth: 150,
    boxShadow: '0 4px 20px rgba(0,0,0,.5)',
  },
  statusOpt: {
    display: 'flex', alignItems: 'center', gap: 8,
    padding: '9px 14px', cursor: 'pointer', fontSize: 12,
    color: 'rgba(255,255,255,.8)',
    borderBottom: '1px solid rgba(255,255,255,.05)',
  },
  searchWrap: { padding: '10px 12px', background: '#120830' },
  searchInput: {
    width: '100%', background: '#2d1b69',
    border: '1px solid rgba(255,255,255,.08)',
    borderRadius: 16, padding: '6px 12px',
    color: '#fff', fontSize: 12, outline: 'none',
  },
  tabs: { display: 'flex', background: '#120830', borderBottom: '1px solid rgba(255,255,255,.05)' },
  tab: { flex: 1, padding: '8px 4px', textAlign: 'center', fontSize: 11, color: 'rgba(255,255,255,.45)', cursor: 'pointer', borderBottom: '2px solid transparent' },
  tabActive: { color: '#FFD700', borderBottomColor: '#FFD700' },
  listScroll: { flex: 1, overflowY: 'auto', paddingBottom: 8 },
  groupLabel: { padding: '10px 12px 4px', fontSize: 9, fontWeight: 700, color: 'rgba(255,255,255,.3)', letterSpacing: '.8px', textTransform: 'uppercase' },
  listItem: { display: 'flex', alignItems: 'center', gap: 9, padding: '8px 12px', cursor: 'pointer' },
  listItemActive: { background: 'rgba(77,6,142,.45)' },
  roomIcon: { width: 32, height: 32, borderRadius: 8, background: 'rgba(255,255,255,.08)', display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: 16, flexShrink: 0 },
  listInfo: { flex: 1, minWidth: 0 },
  listName: { fontSize: 12, fontWeight: 600, color: '#e2e8f0', overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' },
  listSub: { fontSize: 10, color: 'rgba(255,255,255,.35)', marginTop: 1, overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' },
  emptyMsg: { fontSize: 11, color: 'rgba(255,255,255,.3)', textAlign: 'center', padding: '16px 12px' },
  panelFooter: { padding: '10px 12px', background: '#120830', borderTop: '1px solid rgba(255,255,255,.05)', display: 'flex', gap: 6 },
  footerBtn: { flex: 1, background: 'rgba(255,255,255,.06)', border: 'none', color: 'rgba(255,255,255,.6)', borderRadius: 8, padding: 7, cursor: 'pointer', fontSize: 14 },
  // Chat
  chatArea: { flex: 1, display: 'flex', flexDirection: 'column', background: '#f8f9fa', minWidth: 0 },
  chatHeader: { background: '#fff', padding: '10px 16px', display: 'flex', alignItems: 'center', gap: 12, borderBottom: '1px solid #eee', boxShadow: '0 1px 4px rgba(0,0,0,.05)' },
  chatHeaderInfo: { flex: 1 },
  chatTitle: { fontSize: 14, fontWeight: 700, color: '#1a1a2e' },
  chatSub: { fontSize: 11, color: '#888', marginTop: 1 },
  chatActions: { display: 'flex', gap: 6 },
  actionBtn: { width: 30, height: 30, border: '1px solid #e0e0e0', borderRadius: 8, background: 'none', cursor: 'pointer', fontSize: 14 },
  toolbar: { background: '#fff', borderBottom: '1px solid #f0f0f0', padding: '5px 12px', display: 'flex', alignItems: 'center', gap: 2, flexWrap: 'wrap' },
  toolBtn: { width: 28, height: 26, border: 'none', background: 'none', cursor: 'pointer', fontSize: 14, borderRadius: 5, display: 'flex', alignItems: 'center', justifyContent: 'center' },
  toolSep: { width: 1, height: 18, background: '#eee', margin: '0 4px' },
  messages: { flex: 1, overflowY: 'auto', padding: 16, display: 'flex', flexDirection: 'column', gap: 12 },
  emptyChat: { flex: 1, display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center', color: '#aaa', margin: 'auto' },
  msgRow: { display: 'flex', gap: 8, alignItems: 'flex-end' },
  msgRowMe: { flexDirection: 'row-reverse' },
  msgBody: { maxWidth: '65%' },
  msgSender: { fontSize: 10, color: '#888', marginBottom: 3, fontWeight: 600 },
  bubble: { padding: '9px 13px', borderRadius: 16, fontSize: 13, lineHeight: 1.5, wordBreak: 'break-word' },
  bubbleThem: { background: '#fff', border: '1px solid #eee', borderBottomLeftRadius: 4, boxShadow: '0 1px 2px rgba(0,0,0,.05)' },
  bubbleMe: { background: 'linear-gradient(135deg,#4D068E,#7c3aed)', color: '#fff', borderBottomRightRadius: 4 },
  msgTime: { fontSize: 10, color: '#bbb', marginTop: 3 },
  inputArea: { background: '#fff', padding: '10px 14px', display: 'flex', gap: 10, alignItems: 'center', borderTop: '1px solid #eee' },
  input: { flex: 1, background: '#f8f9fa', border: '1.5px solid #e0e0e0', borderRadius: 12, padding: '9px 14px', fontSize: 13, outline: 'none', fontFamily: 'inherit' },
  sendBtn: { background: 'linear-gradient(135deg,#4D068E,#7c3aed)', color: '#fff', border: 'none', borderRadius: 10, padding: '9px 18px', cursor: 'pointer', fontSize: 13, fontWeight: 600, whiteSpace: 'nowrap' },
  // Info panel
  infoPanel: { width: 190, background: '#1a0a3d', borderLeft: '1px solid rgba(255,255,255,.05)', display: 'flex', flexDirection: 'column', flexShrink: 0, overflowY: 'auto' },
  infoTop: { padding: '20px 14px 14px', textAlign: 'center', borderBottom: '1px solid rgba(255,255,255,.06)' },
  infoName: { fontSize: 13, fontWeight: 700, color: '#fff', marginBottom: 3 },
  infoSub: { fontSize: 11, color: 'rgba(255,255,255,.45)', marginBottom: 8 },
  memberCount: { display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 5, fontSize: 11, color: 'rgba(255,255,255,.4)' },
  infoSection: { padding: '12px 14px', borderBottom: '1px solid rgba(255,255,255,.05)' },
  infoLabel: { fontSize: 9, fontWeight: 700, color: 'rgba(255,255,255,.3)', letterSpacing: '.8px', textTransform: 'uppercase', marginBottom: 8 },
  infoUser: { display: 'flex', alignItems: 'center', gap: 7, marginBottom: 7 },
  infoUserName: { fontSize: 11, fontWeight: 600, color: 'rgba(255,255,255,.7)', flex: 1, overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' },
  meBadge: { background: 'rgba(77,6,142,.5)', color: '#c4b5fd', fontSize: 9, padding: '1px 5px', borderRadius: 8 },
  infoItem: { display: 'flex', alignItems: 'center', gap: 6, fontSize: 11, color: 'rgba(255,255,255,.5)', marginBottom: 5 },
  // Shared
  ava: { borderRadius: '50%', display: 'flex', alignItems: 'center', justifyContent: 'center', fontWeight: 700, color: '#fff', flexShrink: 0 },
  dot: { display: 'inline-block', width: 7, height: 7, borderRadius: '50%', background: '#4ade80', flexShrink: 0 },
};
