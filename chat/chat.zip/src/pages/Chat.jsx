import { useState, useEffect, useRef } from 'react';
import { useNavigate } from 'react-router-dom';
import {
  collection, addDoc, query, orderBy,
  onSnapshot, serverTimestamp, limit,
  doc, setDoc, where
} from 'firebase/firestore';
import { auth, db } from '../firebase.js';

const ROOMS = [
  { id:'general',  name:'🌍 Нийтийн өрөө',  desc:'Бүгдэд нээлттэй',    members:1247 },
  { id:'mongolia', name:'🇲🇳 Монгол дотор',  desc:'УБ болон дотоод',    members:432  },
  { id:'korea',    name:'🇰🇷 Солонгос',       desc:'Солонгост байгаа',   members:342  },
  { id:'usa',      name:'🇺🇸 Америк',         desc:'АНУ-д байгаа',       members:218  },
  { id:'europe',   name:'🇪🇺 Европ',          desc:'Европт байгаа',      members:331  },
  { id:'japan',    name:'🇯🇵 Япон',           desc:'Японд байгаа',       members:156  },
  { id:'china',    name:'🇨🇳 Хятад',          desc:'Хятадад байгаа',     members:189  },
  { id:'other',    name:'🌐 Бусад орон',      desc:'Дэлхийн өнцөг',     members:97   },
];
const EMOJIS=['😊','😄','🤣','😍','🥰','😎','🤔','😅','🙏','👍','❤️','🔥','🎉','💪','✅','🏇','🇲🇳','🍖'];
const COLORS=['#7c3aed','#059669','#d97706','#0ea5e9','#ec4899','#f97316','#14b8a6','#8b5cf6'];
const gc=uid=>COLORS[(uid?.charCodeAt(0)||0)%COLORS.length];
const gi=name=>(name||'?')[0].toUpperCase();
const ft=ts=>{if(!ts)return'';const d=ts.toDate?ts.toDate():new Date(ts);return d.toLocaleTimeString('mn-MN',{hour:'2-digit',minute:'2-digit'});};
const fd=ts=>{if(!ts)return'';const d=ts.toDate?ts.toDate():new Date(ts);const t=new Date();const df=Math.floor((t-d)/86400000);if(df===0)return'Өнөөдөр';if(df===1)return'Өчигдөр';return d.toLocaleDateString('mn-MN');};

export default function Chat(){
  const nav=useNavigate();
  const [user,setUser]=useState(null);
  const [room,setRoom]=useState(ROOMS[0]);
  const [msgs,setMsgs]=useState([]);
  const [input,setInput]=useState('');
  const [online,setOnline]=useState([]);
  const [showEmoji,setShowEmoji]=useState(false);
  const [search,setSearch]=useState('');
  const [tab,setTab]=useState('rooms');
  const [sideOpen,setSideOpen]=useState(true);
  const [unread,setUnread]=useState({});
  const bottomRef=useRef(null);
  const inputRef=useRef(null);

  useEffect(()=>{
    const pu=localStorage.getItem('phone_user');
    if(pu){try{setUser(JSON.parse(pu));}catch{}}
    const unsub=auth.onAuthStateChanged(u=>{
      if(u)setUser(u);
      else if(!pu)nav('/login');
    });
    return()=>unsub();
  },[nav]);

  useEffect(()=>{
    if(!user)return;
    const ref=doc(db,'presence',user.uid);
    setDoc(ref,{uid:user.uid,name:user.displayName||user.phoneNumber||'Монгол',photo:user.photoURL||null,status:'online',room:room.id,at:serverTimestamp()},{merge:true});
    const unsub=onSnapshot(query(collection(db,'presence'),where('status','!=','offline')),snap=>{
      setOnline(snap.docs.map(d=>d.data()).filter(u=>u.uid!==user?.uid));
    });
    return()=>{unsub();setDoc(ref,{status:'offline'},{merge:true});};
  },[user,room]);

  useEffect(()=>{
    const q=query(collection(db,`rooms/${room.id}/messages`),orderBy('createdAt','asc'),limit(100));
    const unsub=onSnapshot(q,snap=>{setMsgs(snap.docs.map(d=>({id:d.id,...d.data()})));});
    return()=>unsub();
  },[room]);

  useEffect(()=>{bottomRef.current?.scrollIntoView({behavior:'smooth'});},[msgs]);

  const send=async()=>{
    const text=input.trim();
    if(!text||!user)return;
    setInput('');setShowEmoji(false);
    await addDoc(collection(db,`rooms/${room.id}/messages`),{text,uid:user.uid,name:user.displayName||user.phoneNumber||'Монгол',photo:user.photoURL||null,createdAt:serverTimestamp()});
    inputRef.current?.focus();
  };

  const logout=async()=>{
    if(user)await setDoc(doc(db,'presence',user.uid),{status:'offline'},{merge:true});
    localStorage.removeItem('phone_user');
    await auth.signOut();
    nav('/login');
  };

  const myName=user?.displayName||user?.phoneNumber||'Монгол';
  const fRooms=ROOMS.filter(r=>r.name.toLowerCase().includes(search.toLowerCase()));
  const fOnline=online.filter(u=>u.name?.toLowerCase().includes(search.toLowerCase()));

  const grouped=[];
  let lastD=null;
  msgs.forEach(msg=>{
    const d=msg.createdAt?fd(msg.createdAt):'';
    if(d!==lastD){grouped.push({type:'date',label:d});lastD=d;}
    grouped.push({type:'msg',...msg});
  });

  return(
    <div style={S.root}>
      <style>{`
        @keyframes fadeUp{from{opacity:0;transform:translateY(6px)}to{opacity:1;transform:translateY(0)}}
        *{box-sizing:border-box}
        ::-webkit-scrollbar{width:4px}
        ::-webkit-scrollbar-thumb{background:rgba(255,255,255,.1);border-radius:4px}
        textarea{outline:none;resize:none;}
        textarea::placeholder{color:rgba(255,255,255,.3)}
        input::placeholder{color:rgba(255,255,255,.3)}
        input{outline:none;}
        button:hover{opacity:.85}
      `}</style>

      {/* SIDEBAR */}
      <div style={{...S.side,...(!sideOpen&&{width:0,minWidth:0,overflow:'hidden'})}}>
        <div style={S.sideTop}>
          <div style={S.logoRow}>
            <div style={S.logoIc}>М</div>
            <div><div style={S.logoT}>ЗуунМод</div><div style={S.logoS}>Дэлхийн монголчууд</div></div>
          </div>
          <div style={S.myRow}>
            <div style={{...S.ava,background:gc(user?.uid),width:34,height:34,fontSize:13,flexShrink:0}}>
              {user?.photoURL?<img src={user.photoURL} style={{width:'100%',height:'100%',borderRadius:'50%',objectFit:'cover'}} alt=""/>:gi(myName)}
            </div>
            <div style={{flex:1,minWidth:0}}>
              <div style={S.myN}>{myName}</div>
              <div style={S.myS}><span style={S.dot}/>Онлайн</div>
            </div>
            <button style={S.ib} onClick={()=>nav('/')}>🏠</button>
            <button style={S.ib} onClick={logout}>🚪</button>
          </div>
          <div style={S.searchBox}>
            <input style={S.searchIn} placeholder="🔍 Хайх..." value={search} onChange={e=>setSearch(e.target.value)}/>
          </div>
          <div style={S.tabs}>
            <div style={{...S.tab,...(tab==='rooms'&&S.tabA)}} onClick={()=>setTab('rooms')}>🚪 Өрөөнүүд</div>
            <div style={{...S.tab,...(tab==='online'&&S.tabA)}} onClick={()=>setTab('online')}>🟢 ({online.length})</div>
          </div>
        </div>

        <div style={S.listScroll}>
          {tab==='rooms'&&fRooms.map(r=>(
            <div key={r.id} style={{...S.rItem,...(room.id===r.id&&S.rActive)}} onClick={()=>{setRoom(r);setSearch('');}}>
              <div style={S.rIc}>{r.name.slice(0,2)}</div>
              <div style={{flex:1,minWidth:0}}>
                <div style={S.rName}>{r.name.slice(2)}</div>
                <div style={S.rDesc}>{r.desc}</div>
              </div>
              {unread[r.id]>0&&<div style={S.badge}>{unread[r.id]}</div>}
            </div>
          ))}
          {tab==='online'&&(
            <>
              <div style={S.secLabel}>ОНЛАЙН ({fOnline.length})</div>
              {fOnline.length===0&&<div style={S.emptyL}>Одоохондоо хэн ч байхгүй</div>}
              {fOnline.map(u=>(
                <div key={u.uid} style={S.oItem}>
                  <div style={{...S.ava,background:gc(u.uid),width:28,height:28,fontSize:10,flexShrink:0,position:'relative'}}>
                    {u.photo?<img src={u.photo} style={{width:'100%',height:'100%',borderRadius:'50%',objectFit:'cover'}} alt=""/>:gi(u.name)}
                    <span style={{...S.dot,position:'absolute',bottom:-1,right:-1,border:'2px solid #160830'}}/>
                  </div>
                  <div style={{flex:1,minWidth:0}}>
                    <div style={S.oName}>{u.name}</div>
                    <div style={S.oRoom}>{ROOMS.find(r=>r.id===u.room)?.name.slice(0,4)||'🌐'}</div>
                  </div>
                </div>
              ))}
            </>
          )}
        </div>

        <div style={S.sideFt}>
          <span style={S.dot}/><span style={{fontSize:10,color:'rgba(255,255,255,.35)'}}>{online.length+1} монгол онлайн</span>
        </div>
      </div>

      {/* MAIN */}
      <div style={S.main}>
        <div style={S.hdr}>
          <button style={{background:'none',border:'none',color:'rgba(255,255,255,.5)',cursor:'pointer',fontSize:18,padding:'2px 8px'}} onClick={()=>setSideOpen(v=>!v)}>☰</button>
          <div style={S.hdrRoom}>{room.name}</div>
          <div style={S.hdrDesc}>{room.desc} · {room.members.toLocaleString()} гишүүн</div>
          <div style={{display:'flex',alignItems:'center',gap:8,marginLeft:'auto'}}>
            <div style={S.pill}><span style={S.dot}/>{online.filter(u=>u.room===room.id).length+1} онлайн</div>
            <button style={S.ib} onClick={()=>nav('/messenger')}>💬</button>
          </div>
        </div>

        <div style={S.msgs}>
          {msgs.length===0&&(
            <div style={S.emptyC}>
              <div style={{fontSize:48,marginBottom:12}}>{room.name.slice(0,2)}</div>
              <div style={{fontSize:15,fontWeight:700,color:'#fff',marginBottom:6}}>{room.name.slice(2)}</div>
              <div style={{fontSize:12,color:'rgba(255,255,255,.35)'}}>{room.desc} — яриа эхлүүлнэ үү!</div>
            </div>
          )}
          {grouped.map((item,i)=>{
            if(item.type==='date')return(
              <div key={`d${i}`} style={S.dateSep}>
                <div style={S.dLine}/><span style={S.dLbl}>{item.label}</span><div style={S.dLine}/>
              </div>
            );
            const msg=item;
            const isMe=msg.uid===user?.uid;
            const prev=grouped[i-1];
            const showH=!prev||prev.type==='date'||prev.uid!==msg.uid;
            return(
              <div key={msg.id} style={{display:'flex',gap:10,alignItems:'flex-end',flexDirection:isMe?'row-reverse':'row',marginTop:showH?12:2,animation:'fadeUp .2s ease'}}>
                <div style={{...S.ava,background:gc(msg.uid),width:30,height:30,fontSize:11,flexShrink:0,alignSelf:'flex-end',marginBottom:2,visibility:showH?'visible':'hidden'}}>
                  {msg.photo?<img src={msg.photo} style={{width:'100%',height:'100%',borderRadius:'50%',objectFit:'cover'}} alt=""/>:gi(msg.name)}
                </div>
                <div style={{maxWidth:'68%'}}>
                  {showH&&!isMe&&<div style={{fontSize:11,fontWeight:700,color:'rgba(255,255,255,.45)',marginBottom:3}}>{msg.name}</div>}
                  <div style={{padding:'9px 14px',borderRadius:16,fontSize:13,lineHeight:1.55,wordBreak:'break-word',background:isMe?'linear-gradient(135deg,#7c3aed,#4D068E)':'rgba(255,255,255,.08)',color:isMe?'#fff':'#e2e8f0',borderBottomLeftRadius:isMe?16:4,borderBottomRightRadius:isMe?4:16}}>
                    {msg.text}
                  </div>
                  <div style={{fontSize:10,color:'rgba(255,255,255,.0)',marginTop:2,textAlign:isMe?'right':'left',transition:'color .2s'}}
    onMouseEnter={e=>e.currentTarget.style.color='rgba(255,255,255,.4)'}
    onMouseLeave={e=>e.currentTarget.style.color='rgba(255,255,255,.0)'}
  >{ft(msg.createdAt)}</div>
                </div>
              </div>
            );
          })}
          <div ref={bottomRef}/>
        </div>

        {showEmoji&&(
          <div style={{background:'#1a0840',borderTop:'1px solid rgba(255,255,255,.06)',padding:'10px 14px',display:'flex',flexWrap:'wrap',gap:6}}>
            {EMOJIS.map(em=><button key={em} style={{background:'none',border:'none',cursor:'pointer',fontSize:22,padding:'4px',borderRadius:6}} onClick={()=>setInput(v=>v+em)}>{em}</button>)}
          </div>
        )}

        <div style={S.inputWrap}>
          <button style={S.ib} onClick={()=>setShowEmoji(v=>!v)}>😊</button>
          <textarea
            ref={inputRef}
            style={S.inp}
            value={input}
            rows={1}
            onChange={e=>setInput(e.target.value)}
            onKeyDown={e=>{if(e.key==='Enter'&&!e.shiftKey){e.preventDefault();send();}}}
            placeholder={`${room.name.slice(2)} өрөөнд бичих... (Enter илгээх)`}
          />
          <button
            style={{...S.sendB,...(input.trim()&&{background:'linear-gradient(135deg,#7c3aed,#4D068E)',color:'#fff',cursor:'pointer'})}}
            onClick={send}
          >➤</button>
        </div>
      </div>
    </div>
  );
}

const S={
  root:{display:'flex',height:'100vh',background:'#0d0620',fontFamily:"'Segoe UI',Arial,sans-serif",overflow:'hidden'},
  side:{width:256,minWidth:256,background:'#160830',display:'flex',flexDirection:'column',transition:'all .3s',overflow:'hidden'},
  sideTop:{flexShrink:0},
  logoRow:{display:'flex',alignItems:'center',gap:10,padding:'14px 14px 10px'},
  logoIc:{width:32,height:32,borderRadius:10,background:'linear-gradient(135deg,#f59e0b,#ef4444)',display:'flex',alignItems:'center',justifyContent:'center',fontSize:15,fontWeight:900,color:'#fff'},
  logoT:{fontSize:13,fontWeight:800,color:'#fff'},
  logoS:{fontSize:10,color:'rgba(255,255,255,.3)'},
  myRow:{display:'flex',alignItems:'center',gap:8,padding:'0 12px 10px',borderBottom:'1px solid rgba(255,255,255,.06)'},
  myN:{fontSize:12,fontWeight:700,color:'#e2e8f0',overflow:'hidden',textOverflow:'ellipsis',whiteSpace:'nowrap'},
  myS:{display:'flex',alignItems:'center',gap:4,fontSize:10,color:'rgba(255,255,255,.35)'},
  dot:{display:'inline-block',width:7,height:7,borderRadius:'50%',background:'#4ade80',flexShrink:0},
  ib:{background:'none',border:'none',color:'rgba(255,255,255,.4)',cursor:'pointer',fontSize:14,padding:'4px',borderRadius:6},
  searchBox:{padding:'8px 12px',background:'#0f0620'},
  searchIn:{width:'100%',background:'rgba(255,255,255,.07)',border:'1px solid rgba(255,255,255,.07)',borderRadius:20,padding:'6px 12px',color:'#fff',fontSize:12},
  tabs:{display:'flex',background:'#0f0620',borderBottom:'1px solid rgba(255,255,255,.05)'},
  tab:{flex:1,padding:'8px 4px',textAlign:'center',fontSize:11,color:'rgba(255,255,255,.4)',cursor:'pointer',borderBottom:'2px solid transparent'},
  tabA:{color:'#FFD700',borderBottomColor:'#FFD700'},
  listScroll:{flex:1,overflowY:'auto',paddingBottom:8},
  rItem:{display:'flex',alignItems:'center',gap:8,padding:'8px 12px',cursor:'pointer',borderLeft:'3px solid transparent',transition:'.15s'},
  rActive:{background:'rgba(124,58,237,.2)',borderLeftColor:'#7c3aed'},
  rIc:{width:32,height:32,borderRadius:9,background:'rgba(255,255,255,.07)',display:'flex',alignItems:'center',justifyContent:'center',fontSize:17,flexShrink:0},
  rName:{fontSize:12,fontWeight:600,color:'#e2e8f0',overflow:'hidden',textOverflow:'ellipsis',whiteSpace:'nowrap'},
  rDesc:{fontSize:10,color:'rgba(255,255,255,.3)',marginTop:1},
  badge:{background:'#ef4444',color:'#fff',fontSize:9,fontWeight:700,borderRadius:10,padding:'2px 6px'},
  secLabel:{padding:'10px 12px 4px',fontSize:9,fontWeight:700,color:'rgba(255,255,255,.3)',letterSpacing:'.8px',textTransform:'uppercase'},
  emptyL:{fontSize:11,color:'rgba(255,255,255,.25)',textAlign:'center',padding:'14px'},
  oItem:{display:'flex',alignItems:'center',gap:8,padding:'7px 12px'},
  oName:{fontSize:11,fontWeight:600,color:'rgba(255,255,255,.7)',overflow:'hidden',textOverflow:'ellipsis',whiteSpace:'nowrap'},
  oRoom:{fontSize:10,color:'rgba(255,255,255,.3)'},
  sideFt:{padding:'8px 12px',borderTop:'1px solid rgba(255,255,255,.05)',display:'flex',alignItems:'center',gap:6},
  main:{flex:1,display:'flex',flexDirection:'column',minWidth:0},
  hdr:{background:'rgba(22,8,48,.95)',backdropFilter:'blur(10px)',padding:'12px 16px',display:'flex',alignItems:'center',gap:10,borderBottom:'1px solid rgba(255,255,255,.06)',flexShrink:0},
  hdrRoom:{fontSize:14,fontWeight:800,color:'#fff',whiteSpace:'nowrap'},
  hdrDesc:{fontSize:11,color:'rgba(255,255,255,.35)',flex:1},
  pill:{display:'flex',alignItems:'center',gap:5,background:'rgba(74,222,128,.1)',border:'1px solid rgba(74,222,128,.15)',borderRadius:20,padding:'4px 10px',fontSize:11,color:'#4ade80',whiteSpace:'nowrap'},
  msgs:{flex:1,overflowY:'auto',padding:'16px 20px',display:'flex',flexDirection:'column'},
  emptyC:{flex:1,display:'flex',flexDirection:'column',alignItems:'center',justifyContent:'center',color:'rgba(255,255,255,.3)',textAlign:'center',margin:'auto'},
  dateSep:{display:'flex',alignItems:'center',gap:10,margin:'14px 0'},
  dLine:{flex:1,height:1,background:'rgba(255,255,255,.06)'},
  dLbl:{fontSize:10,color:'rgba(255,255,255,.3)',whiteSpace:'nowrap',padding:'0 4px'},
  inputWrap:{background:'rgba(22,8,48,.95)',padding:'12px 16px',display:'flex',alignItems:'center',gap:8,borderTop:'1px solid rgba(255,255,255,.06)',flexShrink:0},
  inp:{flex:1,background:'rgba(255,255,255,.07)',border:'1.5px solid rgba(255,255,255,.1)',borderRadius:12,padding:'9px 14px',color:'#fff',fontSize:13,fontFamily:'inherit',maxHeight:120,lineHeight:1.5},
  sendB:{background:'rgba(124,58,237,.25)',color:'rgba(255,255,255,.3)',border:'none',borderRadius:10,width:38,height:38,fontSize:15,flexShrink:0,transition:'.2s'},
  ava:{borderRadius:'50%',display:'flex',alignItems:'center',justifyContent:'center',fontWeight:700,color:'#fff',overflow:'hidden'},
};
