import { useNavigate } from 'react-router-dom';
import { useEffect, useState } from 'react';
import { auth, db } from '../firebase.js';
import { collection, onSnapshot, where, query } from 'firebase/firestore';

export default function Home() {
  const navigate = useNavigate();
  const [user, setUser] = useState(null);
  const [online, setOnline] = useState(0);

  useEffect(() => {
    const pu = localStorage.getItem('phone_user');
    if (pu) { try { setUser(JSON.parse(pu)); } catch {} }
    const unsub = auth.onAuthStateChanged(u => {
      if (u) setUser(u);
      else if (!pu) navigate('/login');
    });
    const unsub2 = onSnapshot(
      query(collection(db, 'presence'), where('status', '!=', 'offline')),
      snap => setOnline(snap.size)
    );
    return () => { unsub(); unsub2(); };
  }, [navigate]);

  const myName = user?.displayName || user?.phoneNumber || 'Монгол';

  const logout = async () => {
    localStorage.removeItem('phone_user');
    await auth.signOut();
    navigate('/login');
  };

  return (
    <div style={S.root}>
      <div style={S.card}>
        {/* Header */}
        <div style={S.header}>
          <div style={S.logo}><span style={S.logoM}>Зуун</span><span style={S.logoA}>Мод</span><span style={S.logoD}>.мн</span></div>
          <button style={S.logoutBtn} onClick={logout}>Гарах</button>
        </div>

        {/* Greeting */}
        <div style={S.greeting}>
          <div style={S.ava}>{myName[0]?.toUpperCase()}</div>
          <div>
            <div style={S.greetName}>Сайн байна уу, {myName}!</div>
            <div style={S.greetOnline}>
              <span style={S.dot}/>{online.toLocaleString()} монгол одоо онлайн байна
            </div>
          </div>
        </div>

        {/* Chat button */}
        <button style={S.chatBtn} onClick={() => navigate('/messenger')}>
          <span style={{fontSize:24}}>💬</span>
          <div>
            <div style={S.chatBtnTitle}>Мессенжер нээх</div>
            <div style={S.chatBtnSub}>Yahoo Messenger загвар — buddy list, чат өрөөнүүд</div>
          </div>
          <span style={{marginLeft:'auto', opacity:.5}}>→</span>
        </button>

        {/* Settings */}
        <button style={S.settingsBtn} onClick={() => navigate('/profile')}>
          <span>⚙️</span>
          <div style={{flex:1}}>
            <div style={S.setBtnTitle}>Тохиргоо & Профайл</div>
            <div style={S.setBtnSub}>Нэр, зураг, статус, мэдэгдэл тохируулах</div>
          </div>
          <span style={{opacity:.4}}>→</span>
        </button>

        <div style={S.footer}>Дэлхий дээр тархан суугаа монголчуудын нэг цэг</div>
      </div>
    </div>
  );
}

const S = {
  root:{minHeight:'100vh',background:'#0d0620',display:'flex',alignItems:'center',justifyContent:'center',padding:20,fontFamily:"'Segoe UI',Arial,sans-serif"},
  card:{width:'100%',maxWidth:440,display:'flex',flexDirection:'column',gap:12},
  header:{display:'flex',alignItems:'center',justifyContent:'space-between',marginBottom:8},
  logo:{fontSize:22,fontWeight:900},
  logoM:{color:'#fff'},
  logoA:{color:'#FFD700'},
  logoD:{color:'rgba(255,255,255,.3)',fontSize:16},
  logoutBtn:{background:'rgba(255,255,255,.07)',border:'1px solid rgba(255,255,255,.1)',color:'rgba(255,255,255,.5)',borderRadius:20,padding:'6px 16px',fontSize:12,cursor:'pointer'},
  greeting:{background:'rgba(255,255,255,.05)',border:'1px solid rgba(255,255,255,.08)',borderRadius:16,padding:'16px',display:'flex',alignItems:'center',gap:14},
  ava:{width:46,height:46,borderRadius:'50%',background:'linear-gradient(135deg,#7c3aed,#4D068E)',display:'flex',alignItems:'center',justifyContent:'center',fontSize:20,fontWeight:700,color:'#FFD700',flexShrink:0},
  greetName:{fontSize:16,fontWeight:600,color:'#fff',marginBottom:4},
  greetOnline:{display:'flex',alignItems:'center',gap:6,fontSize:12,color:'rgba(255,255,255,.45)'},
  dot:{display:'inline-block',width:7,height:7,borderRadius:'50%',background:'#4ade80'},
  chatBtn:{background:'rgba(124,58,237,.2)',border:'1.5px solid rgba(124,58,237,.5)',borderRadius:16,padding:'18px 20px',display:'flex',alignItems:'center',gap:14,cursor:'pointer',textAlign:'left',transition:'all .2s',width:'100%'},
  chatBtnTitle:{fontSize:15,fontWeight:700,color:'#fff',marginBottom:3},
  chatBtnSub:{fontSize:12,color:'rgba(255,255,255,.45)'},
  settingsBtn:{background:'rgba(255,255,255,.04)',border:'1px solid rgba(255,255,255,.07)',borderRadius:14,padding:'14px 18px',display:'flex',alignItems:'center',gap:12,cursor:'pointer',textAlign:'left',width:'100%'},
  setBtnTitle:{fontSize:13,fontWeight:600,color:'#fff',marginBottom:2},
  setBtnSub:{fontSize:11,color:'rgba(255,255,255,.35)'},
  footer:{textAlign:'center',fontSize:11,color:'rgba(255,255,255,.2)',marginTop:8},
};
