import { BrowserRouter, Routes, Route, Navigate } from 'react-router-dom';
import { useState, useEffect } from 'react';
import { auth } from './firebase.js';
import Login     from './pages/Login.jsx';
import Home      from './pages/Home.jsx';
import Messenger from './pages/Messenger.jsx';
import Chat      from './pages/Chat.jsx';

// localStorage-с ШУУД уншина — async хүлээхгүй
function getPhoneUser() {
  try {
    const s = localStorage.getItem('phone_user');
    if (s) { const p = JSON.parse(s); if (p && p.uid) return p; }
  } catch {}
  return null;
}

function PrivateRoute({ children }) {
  // Эхний утгыг localStorage-с шууд авна
  const [user, setUser] = useState(() => getPhoneUser());

  useEffect(() => {
    const unsub = auth.onAuthStateChanged(u => {
      if (u) {
        setUser(u);
      } else {
        // Firebase user байхгүй — phone user шалгах
        const phoneUser = getPhoneUser();
        setUser(phoneUser); // null эсвэл phone object
      }
    });
    return () => unsub();
  }, []);

  // phone user байвал шууд харуулна — ачааллах хүлээхгүй
  if (user === undefined) return (
    <div style={{ minHeight:'100vh', background:'#0d0620', display:'flex', alignItems:'center', justifyContent:'center' }}>
      <div style={{ color:'rgba(255,255,255,.5)', fontSize:14 }}>Ачааллаж байна...</div>
    </div>
  );
  return user ? children : <Navigate to="/login" replace />;
}

export default function App() {
  return (
    <BrowserRouter>
      <Routes>
        <Route path="/login" element={<Login />} />
        <Route path="/" element={<PrivateRoute><Home /></PrivateRoute>} />
        <Route path="/messenger" element={<PrivateRoute><Messenger /></PrivateRoute>} />
        <Route path="/chat" element={<PrivateRoute><Chat /></PrivateRoute>} />
        <Route path="*" element={<Navigate to="/" replace />} />
      </Routes>
    </BrowserRouter>
  );
}
