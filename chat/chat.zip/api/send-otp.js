// api/send-otp.js — Twilio Verify OTP илгээх
// Vercel Serverless Function

const twilio_account_sid = process.env.TWILIO_ACCOUNT_SID;
const twilio_auth_token  = process.env.TWILIO_AUTH_TOKEN;
const twilio_service_sid = process.env.TWILIO_VERIFY_SERVICE_SID;

export default async function handler(req, res) {
  // CORS
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'POST, OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type');
  if (req.method === 'OPTIONS') return res.status(200).end();

  if (req.method !== 'POST') {
    return res.status(405).json({ error: 'Method not allowed' });
  }

  const { phone } = req.body;
  if (!phone) return res.status(400).json({ error: 'Phone required' });

  try {
    const url = `https://verify.twilio.com/v2/Services/${twilio_service_sid}/Verifications`;
    const body = new URLSearchParams({ To: phone, Channel: 'sms' });

    const response = await fetch(url, {
      method: 'POST',
      headers: {
        'Authorization': 'Basic ' + Buffer.from(`${twilio_account_sid}:${twilio_auth_token}`).toString('base64'),
        'Content-Type': 'application/x-www-form-urlencoded',
      },
      body: body.toString(),
    });

    const data = await response.json();

    if (!response.ok) {
      return res.status(400).json({ error: data.message || 'SMS илгээхэд алдаа гарлаа' });
    }

    return res.status(200).json({ success: true, status: data.status });
  } catch (err) {
    return res.status(500).json({ error: err.message });
  }
}
