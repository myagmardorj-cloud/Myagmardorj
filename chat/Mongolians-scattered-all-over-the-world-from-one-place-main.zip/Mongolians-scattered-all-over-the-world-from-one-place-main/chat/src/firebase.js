// firebase.js — Монгол Чат Firebase тохиргоо
import { initializeApp, getApps }    from 'firebase/app';
import { getAuth }                   from 'firebase/auth';
import { getFirestore }              from 'firebase/firestore';

const firebaseConfig = {
  apiKey:            "AIzaSyBGcF8jYHDzd78PHSGRWByb9gIibMANH0Q",
  authDomain:        "mongolian-chat-21aa8.firebaseapp.com",
  projectId:         "mongolian-chat-21aa8",
  storageBucket:     "mongolian-chat-21aa8.firebasestorage.app",
  messagingSenderId: "586052790198",
  appId:             "1:586052790198:web:edf8269e11e304edd88317",
  measurementId:     "G-62BTGY6MTN",
};

const app = getApps().length ? getApps()[0] : initializeApp(firebaseConfig);
const auth = getAuth(app);
const db   = getFirestore(app);

export { auth, db };
