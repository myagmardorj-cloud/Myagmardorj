import { useState } from "react";

// ─── Mock Data ───────────────────────────────────────────────
const STATS = [
  { label: "Нийт хэрэглэгч", value: "12,481", delta: "+124", up: true, icon: "👥" },
  { label: "Өнөөдрийн идэвхтэй", value: "1,830", delta: "+18%", up: true, icon: "🟢" },
  { label: "Нийт мессеж", value: "348,920", delta: "+2,341", up: true, icon: "💬" },
  { label: "Тайлагдсан контент", value: "14", delta: "+3", up: false, icon: "🚩" },
];

const USERS = [
  { id: 1, name: "Болд Баатар", email: "bold@mongol.chat", role: "Гишүүн", status: "Идэвхтэй", joined: "2024-11-02", messages: 1204, avatar: "ББ", color: "#f59e0b" },
  { id: 2, name: "Оюун-Эрдэнэ", email: "oyun@mongol.chat", role: "Модератор", status: "Идэвхтэй", joined: "2024-10-15", messages: 3812, avatar: "ОЭ", color: "#34d399" },
  { id: 3, name: "Мөнхбаяр", email: "munkh@mongol.chat", role: "Гишүүн", status: "Хориглосон", joined: "2024-12-01", messages: 230, avatar: "МБ", color: "#818cf8" },
  { id: 4, name: "Нарантуяа", email: "nara@mongol.chat", role: "Гишүүн", status: "Идэвхтэй", joined: "2025-01-10", messages: 678, avatar: "НТ", color: "#f472b6" },
  { id: 5, name: "Сүхбаатар", email: "sukh@mongol.chat", role: "Админ", status: "Идэвхтэй", joined: "2024-09-01", messages: 5021, avatar: "СБ", color: "#60a5fa" },
  { id: 6, name: "Энхтүвшин", email: "enkh@mongol.chat", role: "Гишүүн", status: "Идэвхгүй", joined: "2025-02-20", messages: 45, avatar: "ЭТ", color: "#fb923c" },
];

const CHANNELS = [
  { id: 1, name: "ерөнхий", type: "Нийтийн", members: 1248, messages: 98200, created: "2024-09-01", status: "Идэвхтэй" },
  { id: 2, name: "технологи", type: "Нийтийн", members: 876, messages: 42100, created: "2024-09-01", status: "Идэвхтэй" },
  { id: 3, name: "спорт", type: "Нийтийн", members: 1102, messages: 61300, created: "2024-09-05", status: "Идэвхтэй" },
  { id: 4, name: "хөгжим", type: "Нийтийн", members: 590, messages: 18700, created: "2024-09-10", status: "Идэвхтэй" },
  { id: 5, name: "нууц-зөвлөл", type: "Хувийн", members: 8, messages: 340, created: "2025-01-15", status: "Хаалттай" },
];

const REPORTS = [
  { id: 1, reporter: "Нарантуяа", target: "Мөнхбаяр", reason: "Спам мессеж", time: "10 мин өмнө", status: "Хүлээгдэж байна", severity: "Дунд" },
  { id: 2, reporter: "Болд Баатар", target: "Үл мэдэгдэх хэрэглэгч", reason: "Дарамт шахалт", time: "1 цаг өмнө", status: "Шийдвэрлэсэн", severity: "Өндөр" },
  { id: 3, reporter: "Оюун-Эрдэнэ", target: "Сүхбаатар", reason: "Зохисгүй контент", time: "3 цаг өмнө", status: "Хянагдаж байна", severity: "Бага" },
];

const ACTIVITY = [
  { icon: "👤", text: "Нарантуяа шинээр бүртгүүллээ", time: "2 мин өмнө", color: "#34d399" },
  { icon: "🚩", text: "Шинэ тайлан: Спам мессеж", time: "10 мин өмнө", color: "#ef4444" },
  { icon: "💬", text: "#технологи: 48 шинэ мессеж", time: "15 мин өмнө", color: "#60a5fa" },
  { icon: "🔒", text: "Мөнхбаяр хориглогдлоо", time: "32 мин өмнө", color: "#f59e0b" },
  { icon: "⚙️", text: "Системийн шинэчлэл хийгдлээ", time: "1 цаг өмнө", color: "#818cf8" },
  { icon: "👤", text: "Энхтүвшин бүртгүүллээ", time: "2 цаг өмнө", color: "#34d399" },
];

const NAV = [
  { id: "dashboard", label: "Хяналтын самбар", icon: "▦" },
  { id: "users", label: "Хэрэглэгчид", icon: "👥" },
  { id: "channels", label: "Сувгууд", icon: "#" },
  { id: "reports", label: "Тайлангууд", icon: "🚩", badge: 3 },
  { id: "analytics", label: "Аналитик", icon: "📊" },
  { id: "settings", label: "Тохиргоо", icon: "⚙️" },
];

// ─── Helpers ─────────────────────────────────────────────────
const Badge = ({ label, type }) => {
  const styles = {
    Идэвхтэй: { bg: "#052e16", color: "#4ade80", border: "#166534" },
    Хориглосон: { bg: "#450a0a", color: "#f87171", border: "#991b1b" },
    Идэвхгүй: { bg: "#1c1917", color: "#a8a29e", border: "#44403c" },
    Модератор: { bg: "#172554", color: "#93c5fd", border: "#1d4ed8" },
    Админ: { bg: "#2e1065", color: "#c4b5fd", border: "#7c3aed" },
    Гишүүн: { bg: "#12151c", color: "#94a3b8", border: "#1e2330" },
    Нийтийн: { bg: "#052e16", color: "#4ade80", border: "#166534" },
    Хувийн: { bg: "#1e1b4b", color: "#a5b4fc", border: "#4338ca" },
    Хаалттай: { bg: "#450a0a", color: "#f87171", border: "#991b1b" },
    "Хүлээгдэж байна": { bg: "#431407", color: "#fb923c", border: "#9a3412" },
    "Шийдвэрлэсэн": { bg: "#052e16", color: "#4ade80", border: "#166534" },
    "Хянагдаж байна": { bg: "#1e1b4b", color: "#a5b4fc", border: "#4338ca" },
    Өндөр: { bg: "#450a0a", color: "#f87171", border: "#991b1b" },
    Дунд: { bg: "#431407", color: "#fb923c", border: "#9a3412" },
    Бага: { bg: "#052e16", color: "#4ade80", border: "#166534" },
  };
  const s = styles[label] || styles["Гишүүн"];
  return (
    <span style={{
      background: s.bg, color: s.color, border: `1px solid ${s.border}`,
      borderRadius: 6, fontSize: 11, fontWeight: 700,
      padding: "2px 8px", whiteSpace: "nowrap",
    }}>{label}</span>
  );
};

const MiniBar = ({ value, max = 100, color = "#f59e0b" }) => (
  <div style={{ width: 80, height: 6, background: "#1e2330", borderRadius: 3, overflow: "hidden" }}>
    <div style={{ width: `${(value / max) * 100}%`, height: "100%", background: color, borderRadius: 3, transition: "width 0.4s" }} />
  </div>
);

// ─── Page Components ──────────────────────────────────────────
function Dashboard() {
  return (
    <div>
      <h2 style={{ fontSize: 20, fontWeight: 800, color: "#f8fafc", marginBottom: 20 }}>Хяналтын самбар</h2>

      {/* Stat cards */}
      <div style={{ display: "grid", gridTemplateColumns: "repeat(4, 1fr)", gap: 14, marginBottom: 24 }}>
        {STATS.map((s, i) => (
          <div key={i} style={{
            background: "#12151c", border: "1px solid #1e2330", borderRadius: 14,
            padding: "18px 18px 14px",
          }}>
            <div style={{ display: "flex", justifyContent: "space-between", marginBottom: 10 }}>
              <span style={{ fontSize: 22 }}>{s.icon}</span>
              <span style={{
                fontSize: 11, fontWeight: 700, padding: "2px 8px", borderRadius: 20,
                background: s.up ? "#052e16" : "#450a0a",
                color: s.up ? "#4ade80" : "#f87171",
              }}>{s.delta}</span>
            </div>
            <div style={{ fontSize: 24, fontWeight: 800, color: "#f8fafc", marginBottom: 2 }}>{s.value}</div>
            <div style={{ fontSize: 12, color: "#64748b" }}>{s.label}</div>
          </div>
        ))}
      </div>

      <div style={{ display: "grid", gridTemplateColumns: "1fr 300px", gap: 16 }}>
        {/* Activity */}
        <div style={{ background: "#12151c", border: "1px solid #1e2330", borderRadius: 14, padding: 20 }}>
          <div style={{ fontWeight: 700, fontSize: 14, color: "#f8fafc", marginBottom: 16 }}>Сүүлийн үйлдлүүд</div>
          {ACTIVITY.map((a, i) => (
            <div key={i} style={{
              display: "flex", alignItems: "flex-start", gap: 12,
              padding: "10px 0", borderBottom: i < ACTIVITY.length - 1 ? "1px solid #1e2330" : "none",
            }}>
              <div style={{
                width: 34, height: 34, borderRadius: "50%", flexShrink: 0,
                background: `${a.color}18`, border: `1px solid ${a.color}44`,
                display: "flex", alignItems: "center", justifyContent: "center", fontSize: 15,
              }}>{a.icon}</div>
              <div style={{ flex: 1 }}>
                <div style={{ fontSize: 13, color: "#cbd5e1" }}>{a.text}</div>
                <div style={{ fontSize: 11, color: "#475569", marginTop: 2 }}>{a.time}</div>
              </div>
            </div>
          ))}
        </div>

        {/* Top channels */}
        <div style={{ background: "#12151c", border: "1px solid #1e2330", borderRadius: 14, padding: 20 }}>
          <div style={{ fontWeight: 700, fontSize: 14, color: "#f8fafc", marginBottom: 16 }}>Шилдэг сувгууд</div>
          {CHANNELS.slice(0, 5).map((ch, i) => {
            const colors = ["#f59e0b", "#34d399", "#60a5fa", "#f472b6", "#818cf8"];
            const pct = Math.round((ch.messages / 98200) * 100);
            return (
              <div key={i} style={{ marginBottom: 14 }}>
                <div style={{ display: "flex", justifyContent: "space-between", marginBottom: 5 }}>
                  <span style={{ fontSize: 13, fontWeight: 600, color: "#e2e8f0" }}>#{ch.name}</span>
                  <span style={{ fontSize: 12, color: "#64748b" }}>{(ch.messages / 1000).toFixed(1)}к</span>
                </div>
                <div style={{ width: "100%", height: 6, background: "#1e2330", borderRadius: 3 }}>
                  <div style={{ width: `${pct}%`, height: "100%", background: colors[i], borderRadius: 3 }} />
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
}

function Users() {
  const [search, setSearch] = useState("");
  const [selected, setSelected] = useState(null);
  const filtered = USERS.filter(u =>
    u.name.toLowerCase().includes(search.toLowerCase()) ||
    u.email.toLowerCase().includes(search.toLowerCase())
  );

  return (
    <div>
      <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 20 }}>
        <h2 style={{ fontSize: 20, fontWeight: 800, color: "#f8fafc" }}>Хэрэглэгчид</h2>
        <button style={{
          background: "linear-gradient(135deg, #f59e0b, #ef4444)",
          border: "none", borderRadius: 9, padding: "8px 18px",
          color: "#fff", fontWeight: 700, fontSize: 13, cursor: "pointer",
        }}>+ Хэрэглэгч нэмэх</button>
      </div>

      <div style={{ background: "#12151c", border: "1px solid #1e2330", borderRadius: 14, overflow: "hidden" }}>
        <div style={{ padding: "14px 16px", borderBottom: "1px solid #1e2330" }}>
          <input value={search} onChange={e => setSearch(e.target.value)}
            placeholder="Нэр, и-мэйлээр хайх..."
            style={{
              background: "#0d0f14", border: "1px solid #1e2330", borderRadius: 8,
              padding: "8px 14px", color: "#f1f5f9", fontSize: 13, outline: "none",
              width: 260, fontFamily: "inherit",
            }} />
        </div>
        <table style={{ width: "100%", borderCollapse: "collapse" }}>
          <thead>
            <tr style={{ background: "#0d0f14" }}>
              {["Хэрэглэгч", "Үүрэг", "Статус", "Нэгдсэн", "Мессеж", "Үйлдэл"].map((h, i) => (
                <th key={i} style={{
                  padding: "10px 16px", textAlign: "left",
                  fontSize: 11, fontWeight: 700, color: "#475569",
                  textTransform: "uppercase", letterSpacing: 0.8,
                  borderBottom: "1px solid #1e2330",
                }}>{h}</th>
              ))}
            </tr>
          </thead>
          <tbody>
            {filtered.map((u, i) => (
              <tr key={u.id} onClick={() => setSelected(selected?.id === u.id ? null : u)}
                style={{
                  borderBottom: "1px solid #1a1f2c", cursor: "pointer",
                  background: selected?.id === u.id ? "#1a1f2c" : "transparent",
                  transition: "background 0.1s",
                }}>
                <td style={{ padding: "12px 16px" }}>
                  <div style={{ display: "flex", alignItems: "center", gap: 10 }}>
                    <div style={{
                      width: 34, height: 34, borderRadius: "50%",
                      background: `${u.color}22`, border: `1.5px solid ${u.color}55`,
                      display: "flex", alignItems: "center", justifyContent: "center",
                      fontSize: 11, fontWeight: 700, color: u.color, flexShrink: 0,
                    }}>{u.avatar}</div>
                    <div>
                      <div style={{ fontSize: 13, fontWeight: 600, color: "#f1f5f9" }}>{u.name}</div>
                      <div style={{ fontSize: 11, color: "#64748b" }}>{u.email}</div>
                    </div>
                  </div>
                </td>
                <td style={{ padding: "12px 16px" }}><Badge label={u.role} /></td>
                <td style={{ padding: "12px 16px" }}><Badge label={u.status} /></td>
                <td style={{ padding: "12px 16px", fontSize: 12, color: "#64748b" }}>{u.joined}</td>
                <td style={{ padding: "12px 16px" }}>
                  <div style={{ display: "flex", flexDirection: "column", gap: 4 }}>
                    <span style={{ fontSize: 12, color: "#f1f5f9", fontWeight: 600 }}>{u.messages.toLocaleString()}</span>
                    <MiniBar value={u.messages} max={5500} color={u.color} />
                  </div>
                </td>
                <td style={{ padding: "12px 16px" }}>
                  <div style={{ display: "flex", gap: 6 }}>
                    {["✏️", u.status === "Хориглосон" ? "🔓" : "🔒", "🗑"].map((icon, j) => (
                      <button key={j} onClick={e => e.stopPropagation()} style={{
                        background: "#1e2330", border: "none", borderRadius: 6,
                        padding: "4px 8px", cursor: "pointer", fontSize: 13,
                      }}>{icon}</button>
                    ))}
                  </div>
                </td>
              </tr>
            ))}
          </tbody>
        </table>

        {selected && (
          <div style={{
            background: "#0d0f14", borderTop: "1px solid #1e2330",
            padding: 20, display: "flex", gap: 24, flexWrap: "wrap",
          }}>
            <div style={{ flex: 1, minWidth: 200 }}>
              <div style={{ fontSize: 12, color: "#475569", marginBottom: 10, fontWeight: 700, textTransform: "uppercase", letterSpacing: 0.8 }}>Дэлгэрэнгүй</div>
              {[
                ["Нэр", selected.name], ["И-мэйл", selected.email],
                ["Үүрэг", selected.role], ["Нэгдсэн огноо", selected.joined],
              ].map(([k, v], i) => (
                <div key={i} style={{ display: "flex", gap: 8, marginBottom: 6 }}>
                  <span style={{ fontSize: 12, color: "#64748b", width: 100 }}>{k}</span>
                  <span style={{ fontSize: 12, color: "#f1f5f9" }}>{v}</span>
                </div>
              ))}
            </div>
            <div style={{ display: "flex", gap: 8, alignItems: "flex-start", flexWrap: "wrap" }}>
              {[
                { label: "Модератор болгох", bg: "#172554", color: "#93c5fd" },
                { label: "Мессеж харах", bg: "#1e2330", color: "#94a3b8" },
                { label: selected.status === "Хориглосон" ? "Хориг арилгах" : "Хориглох", bg: "#450a0a", color: "#f87171" },
              ].map((btn, i) => (
                <button key={i} style={{
                  background: btn.bg, border: "none", borderRadius: 8,
                  padding: "8px 14px", color: btn.color,
                  fontSize: 12, fontWeight: 600, cursor: "pointer",
                }}>{btn.label}</button>
              ))}
            </div>
          </div>
        )}
      </div>
    </div>
  );
}

function Channels() {
  return (
    <div>
      <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 20 }}>
        <h2 style={{ fontSize: 20, fontWeight: 800, color: "#f8fafc" }}>Сувгууд</h2>
        <button style={{
          background: "linear-gradient(135deg, #f59e0b, #ef4444)",
          border: "none", borderRadius: 9, padding: "8px 18px",
          color: "#fff", fontWeight: 700, fontSize: 13, cursor: "pointer",
        }}>+ Суваг үүсгэх</button>
      </div>
      <div style={{ background: "#12151c", border: "1px solid #1e2330", borderRadius: 14, overflow: "hidden" }}>
        <table style={{ width: "100%", borderCollapse: "collapse" }}>
          <thead>
            <tr style={{ background: "#0d0f14" }}>
              {["Суваг", "Төрөл", "Гишүүд", "Мессеж", "Статус", "Үйлдэл"].map((h, i) => (
                <th key={i} style={{
                  padding: "10px 16px", textAlign: "left",
                  fontSize: 11, fontWeight: 700, color: "#475569",
                  textTransform: "uppercase", letterSpacing: 0.8,
                  borderBottom: "1px solid #1e2330",
                }}>{h}</th>
              ))}
            </tr>
          </thead>
          <tbody>
            {CHANNELS.map((ch, i) => (
              <tr key={ch.id} style={{ borderBottom: "1px solid #1a1f2c" }}>
                <td style={{ padding: "14px 16px" }}>
                  <span style={{ fontWeight: 700, color: "#f59e0b", fontSize: 14 }}>#</span>
                  <span style={{ fontSize: 13, fontWeight: 600, color: "#f1f5f9", marginLeft: 4 }}>{ch.name}</span>
                </td>
                <td style={{ padding: "14px 16px" }}><Badge label={ch.type} /></td>
                <td style={{ padding: "14px 16px", fontSize: 13, color: "#cbd5e1" }}>{ch.members.toLocaleString()}</td>
                <td style={{ padding: "14px 16px", fontSize: 13, color: "#cbd5e1" }}>{(ch.messages / 1000).toFixed(1)}к</td>
                <td style={{ padding: "14px 16px" }}><Badge label={ch.status} /></td>
                <td style={{ padding: "14px 16px" }}>
                  <div style={{ display: "flex", gap: 6 }}>
                    {["✏️", "🔒", "🗑"].map((icon, j) => (
                      <button key={j} style={{
                        background: "#1e2330", border: "none", borderRadius: 6,
                        padding: "4px 8px", cursor: "pointer", fontSize: 13,
                      }}>{icon}</button>
                    ))}
                  </div>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}

function Reports() {
  return (
    <div>
      <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 20 }}>
        <h2 style={{ fontSize: 20, fontWeight: 800, color: "#f8fafc" }}>Тайлангууд</h2>
        <span style={{
          background: "#450a0a", color: "#f87171", border: "1px solid #991b1b",
          borderRadius: 8, padding: "4px 12px", fontSize: 12, fontWeight: 700,
        }}>1 хүлээгдэж байна</span>
      </div>
      <div style={{ display: "flex", flexDirection: "column", gap: 12 }}>
        {REPORTS.map((r) => (
          <div key={r.id} style={{
            background: "#12151c", border: "1px solid #1e2330", borderRadius: 14,
            padding: "16px 20px",
          }}>
            <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-start", flexWrap: "wrap", gap: 10 }}>
              <div style={{ display: "flex", gap: 12, alignItems: "center" }}>
                <div style={{ fontSize: 24 }}>🚩</div>
                <div>
                  <div style={{ fontSize: 14, fontWeight: 700, color: "#f1f5f9", marginBottom: 2 }}>
                    <span style={{ color: "#f59e0b" }}>{r.reporter}</span>
                    <span style={{ color: "#64748b" }}> → </span>
                    <span style={{ color: "#f87171" }}>{r.target}</span>
                  </div>
                  <div style={{ fontSize: 13, color: "#94a3b8" }}>{r.reason}</div>
                  <div style={{ fontSize: 11, color: "#475569", marginTop: 3 }}>{r.time}</div>
                </div>
              </div>
              <div style={{ display: "flex", gap: 8, alignItems: "center", flexWrap: "wrap" }}>
                <Badge label={r.severity} />
                <Badge label={r.status} />
                {r.status === "Хүлээгдэж байна" && (
                  <>
                    <button style={{
                      background: "#052e16", border: "1px solid #166534",
                      borderRadius: 7, padding: "5px 12px", color: "#4ade80",
                      fontSize: 12, fontWeight: 600, cursor: "pointer",
                    }}>✓ Шийдвэрлэх</button>
                    <button style={{
                      background: "#450a0a", border: "1px solid #991b1b",
                      borderRadius: 7, padding: "5px 12px", color: "#f87171",
                      fontSize: 12, fontWeight: 600, cursor: "pointer",
                    }}>✗ Хориглох</button>
                  </>
                )}
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}

function Analytics() {
  const weeks = ["Да", "Мя", "Лх", "Пү", "Ба", "Бя", "Ня"];
  const data =  [42, 78, 65, 90, 55, 30, 48];
  const maxVal = Math.max(...data);

  return (
    <div>
      <h2 style={{ fontSize: 20, fontWeight: 800, color: "#f8fafc", marginBottom: 20 }}>Аналитик</h2>
      <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 16 }}>
        {/* Weekly activity chart */}
        <div style={{ background: "#12151c", border: "1px solid #1e2330", borderRadius: 14, padding: 20, gridColumn: "1 / -1" }}>
          <div style={{ fontWeight: 700, fontSize: 14, color: "#f8fafc", marginBottom: 20 }}>7 хоногийн идэвхжил</div>
          <div style={{ display: "flex", alignItems: "flex-end", gap: 10, height: 120 }}>
            {data.map((v, i) => (
              <div key={i} style={{ flex: 1, display: "flex", flexDirection: "column", alignItems: "center", gap: 6 }}>
                <div style={{ fontSize: 10, color: "#64748b" }}>{v}к</div>
                <div style={{
                  width: "100%", height: `${(v / maxVal) * 100}px`,
                  background: i === 3
                    ? "linear-gradient(180deg, #f59e0b, #ef4444)"
                    : "linear-gradient(180deg, #1e3a5f, #1a2a4a)",
                  borderRadius: "6px 6px 0 0",
                  border: "1px solid",
                  borderColor: i === 3 ? "#f59e0b44" : "#1e2330",
                  transition: "height 0.4s",
                }} />
                <div style={{ fontSize: 11, color: "#64748b" }}>{weeks[i]}</div>
              </div>
            ))}
          </div>
        </div>

        {/* User growth */}
        <div style={{ background: "#12151c", border: "1px solid #1e2330", borderRadius: 14, padding: 20 }}>
          <div style={{ fontWeight: 700, fontSize: 14, color: "#f8fafc", marginBottom: 16 }}>Хэрэглэгчийн өсөлт</div>
          {[
            { label: "Шинэ гишүүн (7 хоног)", value: 124, max: 200, color: "#34d399" },
            { label: "Идэвхтэй хэрэглэгч", value: 1830, max: 12481, color: "#f59e0b" },
            { label: "Мессеж илгээгч", value: 980, max: 12481, color: "#60a5fa" },
            { label: "Хориглогдсон", value: 14, max: 200, color: "#f87171" },
          ].map((item, i) => (
            <div key={i} style={{ marginBottom: 14 }}>
              <div style={{ display: "flex", justifyContent: "space-between", marginBottom: 5 }}>
                <span style={{ fontSize: 12, color: "#94a3b8" }}>{item.label}</span>
                <span style={{ fontSize: 12, fontWeight: 700, color: item.color }}>{item.value.toLocaleString()}</span>
              </div>
              <div style={{ width: "100%", height: 8, background: "#1e2330", borderRadius: 4 }}>
                <div style={{
                  width: `${(item.value / item.max) * 100}%`, height: "100%",
                  background: item.color, borderRadius: 4,
                }} />
              </div>
            </div>
          ))}
        </div>

        {/* Top content */}
        <div style={{ background: "#12151c", border: "1px solid #1e2330", borderRadius: 14, padding: 20 }}>
          <div style={{ fontWeight: 700, fontSize: 14, color: "#f8fafc", marginBottom: 16 }}>Контентийн тойм</div>
          {[
            { emoji: "💬", label: "Нийт мессеж", value: "348,920" },
            { emoji: "🖼", label: "Зураг", value: "12,441" },
            { emoji: "📎", label: "Файл", value: "3,218" },
            { emoji: "🎥", label: "Видео", value: "841" },
            { emoji: "😊", label: "Emoji", value: "89,100" },
          ].map((item, i) => (
            <div key={i} style={{
              display: "flex", alignItems: "center", gap: 12,
              padding: "8px 0", borderBottom: i < 4 ? "1px solid #1a1f2c" : "none",
            }}>
              <span style={{ fontSize: 18 }}>{item.emoji}</span>
              <span style={{ flex: 1, fontSize: 13, color: "#94a3b8" }}>{item.label}</span>
              <span style={{ fontSize: 13, fontWeight: 700, color: "#f1f5f9" }}>{item.value}</span>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}

function Settings() {
  const [vals, setVals] = useState({
    siteName: "Mongolians scattered all over the world from one place",
    maxUsers: "50000",
    registerOpen: true,
    maintenanceMode: false,
    emailVerify: true,
  });

  const toggle = (key) => setVals(p => ({ ...p, [key]: !p[key] }));

  const Toggle = ({ on, onClick }) => (
    <div onClick={onClick} style={{
      width: 44, height: 24, borderRadius: 12, cursor: "pointer",
      background: on ? "linear-gradient(90deg, #f59e0b, #ef4444)" : "#1e2330",
      border: `1px solid ${on ? "#f59e0b" : "#2d3748"}`,
      position: "relative", transition: "all 0.2s",
    }}>
      <div style={{
        width: 18, height: 18, borderRadius: "50%", background: "#fff",
        position: "absolute", top: 2,
        left: on ? 22 : 3, transition: "left 0.2s",
        boxShadow: "0 1px 4px #0008",
      }} />
    </div>
  );

  return (
    <div>
      <h2 style={{ fontSize: 20, fontWeight: 800, color: "#f8fafc", marginBottom: 20 }}>Тохиргоо</h2>
      <div style={{ display: "flex", flexDirection: "column", gap: 14, maxWidth: 620 }}>
        {/* General */}
        <div style={{ background: "#12151c", border: "1px solid #1e2330", borderRadius: 14, padding: 22 }}>
          <div style={{ fontWeight: 700, fontSize: 14, color: "#f8fafc", marginBottom: 18 }}>Ерөнхий тохиргоо</div>
          {[
            { label: "Сайтын нэр", key: "siteName", type: "text" },
            { label: "Хамгийн их хэрэглэгч", key: "maxUsers", type: "number" },
          ].map(({ label, key, type }) => (
            <div key={key} style={{ marginBottom: 14 }}>
              <label style={{ fontSize: 12, color: "#64748b", display: "block", marginBottom: 6 }}>{label}</label>
              <input type={type} value={vals[key]}
                onChange={e => setVals(p => ({ ...p, [key]: e.target.value }))}
                style={{
                  background: "#0d0f14", border: "1px solid #1e2330", borderRadius: 8,
                  padding: "9px 14px", color: "#f1f5f9", fontSize: 13, outline: "none",
                  width: "100%", boxSizing: "border-box", fontFamily: "inherit",
                }} />
            </div>
          ))}
        </div>

        {/* Toggles */}
        <div style={{ background: "#12151c", border: "1px solid #1e2330", borderRadius: 14, padding: 22 }}>
          <div style={{ fontWeight: 700, fontSize: 14, color: "#f8fafc", marginBottom: 18 }}>Системийн тохиргоо</div>
          {[
            { label: "Бүртгэл нээлттэй", sub: "Шинэ хэрэглэгч бүртгүүлэх боломжтой", key: "registerOpen" },
            { label: "Техник засвар горим", sub: "Сайт зөвхөн админд харагдана", key: "maintenanceMode" },
            { label: "И-мэйл баталгаажуулалт", sub: "Бүртгүүлэхдээ и-мэйл баталгаажуулна", key: "emailVerify" },
          ].map(({ label, sub, key }) => (
            <div key={key} style={{
              display: "flex", alignItems: "center", justifyContent: "space-between",
              padding: "12px 0", borderBottom: key !== "emailVerify" ? "1px solid #1a1f2c" : "none",
            }}>
              <div>
                <div style={{ fontSize: 13, fontWeight: 600, color: "#f1f5f9" }}>{label}</div>
                <div style={{ fontSize: 11, color: "#475569", marginTop: 2 }}>{sub}</div>
              </div>
              <Toggle on={vals[key]} onClick={() => toggle(key)} />
            </div>
          ))}
        </div>

        <button style={{
          background: "linear-gradient(135deg, #f59e0b, #ef4444)",
          border: "none", borderRadius: 10, padding: "12px",
          color: "#fff", fontWeight: 800, fontSize: 14, cursor: "pointer",
          boxShadow: "0 0 20px #f59e0b33",
        }}>Хадгалах</button>
      </div>
    </div>
  );
}

// ─── Main App ────────────────────────────────────────────────
export default function Admin({ user, onLogout }) {
  const [page, setPage] = useState("dashboard");

  const pages = { dashboard: <Dashboard />, users: <Users />, channels: <Channels />, reports: <Reports />, analytics: <Analytics />, settings: <Settings /> };

  return (
    <>
    <div style={{
      display: "flex", height: "100vh", fontFamily: "'Noto Sans', 'Segoe UI', sans-serif",
      background: "#0d0f14", color: "#e2e8f0", overflow: "hidden",
      paddingBottom: 30,
    }}>
      {/* Sidebar */}
      <div style={{
        width: 220, background: "#12151c", borderRight: "1px solid #1e2330",
        display: "flex", flexDirection: "column", flexShrink: 0,
      }}>
        {/* Logo */}
        <div style={{ padding: "18px 16px", borderBottom: "1px solid #1e2330", display: "flex", alignItems: "center", gap: 10 }}>
          <div style={{
            width: 36, height: 36, borderRadius: 10,
            background: "linear-gradient(135deg, #f59e0b, #ef4444)",
            display: "flex", alignItems: "center", justifyContent: "center",
            fontSize: 18, fontWeight: 900, color: "#fff",
            boxShadow: "0 0 16px #f59e0b44", flexShrink: 0,
          }}>М</div>
          <div>
            <div style={{ fontWeight: 800, fontSize: 10, color: "#f8fafc", lineHeight: 1.3 }}>Mongolians scattered all<br/>over the world from one place</div>
            <div style={{ fontSize: 10, color: "#f59e0b", fontWeight: 700 }}>АДМИН САМБАР</div>
          </div>
        </div>

        {/* Nav */}
        <nav style={{ flex: 1, padding: "10px 8px" }}>
          {NAV.map((item) => (
            <button key={item.id} onClick={() => setPage(item.id)} style={{
              width: "100%", display: "flex", alignItems: "center", gap: 10,
              padding: "9px 12px", borderRadius: 9, border: "none", cursor: "pointer",
              background: page === item.id ? "linear-gradient(90deg, #1e2a3a, #1a2030)" : "transparent",
              color: page === item.id ? "#f8fafc" : "#64748b",
              textAlign: "left", marginBottom: 2, transition: "all 0.1s",
              borderLeft: page === item.id ? "2px solid #f59e0b" : "2px solid transparent",
            }}>
              <span style={{ fontSize: 15 }}>{item.icon}</span>
              <span style={{ flex: 1, fontSize: 13, fontWeight: page === item.id ? 700 : 400 }}>{item.label}</span>
              {item.badge && (
                <span style={{
                  background: "#ef4444", color: "#fff", borderRadius: 10,
                  fontSize: 10, fontWeight: 700, padding: "1px 6px",
                }}>{item.badge}</span>
              )}
            </button>
          ))}
        </nav>

        {/* Admin info */}
        <div style={{ padding: "12px", borderTop: "1px solid #1e2330", display: "flex", alignItems: "center", gap: 10 }}>
          {user?.photoURL ? (
            <img src={user.photoURL} style={{ width:32, height:32, borderRadius:"50%", objectFit:"cover" }} />
          ) : (
            <div style={{
              width: 32, height: 32, borderRadius: "50%",
              background: "linear-gradient(135deg, #7c3aed, #4f46e5)",
              display: "flex", alignItems: "center", justifyContent: "center",
              fontSize: 11, fontWeight: 700, color: "#fff",
            }}>{(user?.displayName || "СА").slice(0,2).toUpperCase()}</div>
          )}
          <div style={{ flex: 1 }}>
            <div style={{ fontSize: 12, fontWeight: 600, color: "#f1f5f9" }}>{user?.displayName || "Super Admin"}</div>
            <div style={{ fontSize: 10, color: "#7c3aed" }}>● Super Admin</div>
          </div>
          <button onClick={onLogout} title="Гарах" style={{
            background:"none", border:"none", color:"#475569",
            cursor:"pointer", fontSize:16, padding:"2px 6px",
          }}>⏏</button>
        </div>
      </div>

      {/* Content */}
      <div style={{ flex: 1, overflowY: "auto", padding: 28 }}>
        {pages[page]}
      </div>

      {/* Bottom marquee */}
      <style>{`
        @keyframes marquee-bottom {
          0% { transform: translateX(0); }
          100% { transform: translateX(-50%); }
        }
      `}</style>
    </div>

    {/* Full-width bottom bar */}
    <div style={{
      position: "fixed", bottom: 0, left: 0, right: 0,
      background: "#0a0c11",
      borderTop: "1px solid #1e2330",
      overflow: "hidden",
      height: 30,
      display: "flex",
      alignItems: "center",
      zIndex: 999,
    }}>
      <div style={{
        display: "inline-block",
        whiteSpace: "nowrap",
        animation: "marquee-bottom 18s linear infinite",
      }}>
        {Array(4).fill(null).map((_, i) => (
          <span key={i} style={{
            fontSize: 12, fontWeight: 700,
            background: "linear-gradient(90deg, #f59e0b, #ef4444, #f59e0b)",
            WebkitBackgroundClip: "text", WebkitTextFillColor: "transparent",
            paddingRight: 60,
          }}>
            🇲🇳 Дэлхий дээр Тархан Суугаа Монголчууд &nbsp;•&nbsp; Mongolians scattered all over the world from one place
          </span>
        ))}
      </div>
    </div>
  </>
  );
}
