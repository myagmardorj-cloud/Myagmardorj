import { useState, useRef, useEffect } from "react";

const CHANNELS = [
  { id: 1, name: "ерөнхий", icon: "🏠", unread: 3, type: "public" },
  { id: 2, name: "технологи", icon: "💻", unread: 12, type: "public" },
  { id: 3, name: "спорт", icon: "⚽", unread: 0, type: "public" },
  { id: 4, name: "хөгжим", icon: "🎵", unread: 5, type: "public" },
  { id: 5, name: "аялал", icon: "🏔️", unread: 0, type: "public" },
];

const DMS = [
  { id: 10, name: "Болд Баатар", avatar: "ББ", online: true, unread: 2 },
  { id: 11, name: "Оюун-Эрдэнэ", avatar: "ОЭ", online: true, unread: 0 },
  { id: 12, name: "Мөнхбаяр", avatar: "МБ", online: false, unread: 1 },
];

const INITIAL_MESSAGES = {
  1: [
    { id: 1, user: "Болд Баатар", avatar: "ББ", time: "09:14", text: "Нийт хамт олон өдрийн мэнд! 🌄", color: "#f59e0b" },
    { id: 2, user: "Оюун-Эрдэнэ", avatar: "ОЭ", time: "09:17", text: "Өдрийн мэнд! Шинэ платформ үнэхээр сайхан байна даа", color: "#34d399" },
    { id: 3, user: "Мөнхбаяр", avatar: "МБ", time: "09:21", text: "Монгол хэлээр чатлах газар эцэст нь гарлаа 🇲🇳", color: "#818cf8" },
    { id: 4, user: "Болд Баатар", avatar: "ББ", time: "09:35", text: "Workplace закрылся гэж сонслоо, гэхдээ Монгол чат байна шүү 😄", color: "#f59e0b" },
    { id: 5, user: "Оюун-Эрдэнэ", avatar: "ОЭ", time: "09:40", text: "Тийм ээ! Манайхаараа нийгмийн сүлжээ байгуулцгаая", color: "#34d399" },
  ],
  2: [
    { id: 1, user: "Мөнхбаяр", avatar: "МБ", time: "08:55", text: "React 19 гарсан байна. Кто нибудь пробовал?", color: "#818cf8" },
    { id: 2, user: "Болд Баатар", avatar: "ББ", time: "09:02", text: "Next.js-тэй хамт ашиглаж байна, server components гайхалтай", color: "#f59e0b" },
  ],
};

const ONLINE_USERS = [
  { name: "Болд Баатар", avatar: "ББ", status: "Идэвхтэй", color: "#f59e0b" },
  { name: "Оюун-Эрдэнэ", avatar: "ОЭ", status: "Идэвхтэй", color: "#34d399" },
  { name: "Нарантуяа", avatar: "НТ", status: "Завгүй", color: "#f472b6" },
  { name: "Сүхбаатар", avatar: "СБ", status: "Идэвхтэй", color: "#60a5fa" },
  { name: "Мөнхбаяр", avatar: "МБ", status: "Офлайн", color: "#818cf8" },
];

export default function MongolChat() {
  const [activeChannel, setActiveChannel] = useState(1);
  const [messages, setMessages] = useState(INITIAL_MESSAGES);
  const [input, setInput] = useState("");
  const [sidebarTab, setSidebarTab] = useState("channels");
  const [showEmojiPanel, setShowEmojiPanel] = useState(false);
  const bottomRef = useRef(null);

  const currentMessages = messages[activeChannel] || [];

  useEffect(() => {
    bottomRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [activeChannel, messages]);

  const sendMessage = () => {
    if (!input.trim()) return;
    const newMsg = {
      id: Date.now(),
      user: "Та",
      avatar: "ТА",
      time: new Date().toLocaleTimeString("mn-MN", { hour: "2-digit", minute: "2-digit" }),
      text: input,
      color: "#fb923c",
      own: true,
    };
    setMessages((prev) => ({
      ...prev,
      [activeChannel]: [...(prev[activeChannel] || []), newMsg],
    }));
    setInput("");
    setShowEmojiPanel(false);
  };

  const activeChannelData = CHANNELS.find((c) => c.id === activeChannel);

  const EMOJIS = ["😄","🇲🇳","🏔️","🐎","🌙","👍","🔥","❤️","💪","✨","🎉","😂"];

  return (
    <>
    <style>{`
      @keyframes marquee-bottom {
        0% { transform: translateX(0); }
        100% { transform: translateX(-50%); }
      }
    `}</style>
    <div style={{
      display: "flex", height: "100vh", fontFamily: "'Noto Sans', 'Segoe UI', sans-serif",
      background: "#0d0f14", color: "#e2e8f0", overflow: "hidden",
      paddingBottom: 30,
    }}>

      {/* Sidebar */}
      <div style={{
        width: 260, background: "#12151c", display: "flex", flexDirection: "column",
        borderRight: "1px solid #1e2330",
      }}>
        {/* Logo */}
        <div style={{
          padding: "18px 16px 14px", borderBottom: "1px solid #1e2330",
          display: "flex", alignItems: "center", gap: 10,
        }}>
          <div style={{
            width: 36, height: 36, borderRadius: 10,
            background: "linear-gradient(135deg, #f59e0b, #ef4444)",
            display: "flex", alignItems: "center", justifyContent: "center",
            fontSize: 18, fontWeight: 900, color: "#fff", letterSpacing: -1,
            boxShadow: "0 0 16px #f59e0b44", flexShrink: 0,
          }}>М</div>
          <div>
            <div style={{ fontWeight: 800, fontSize: 10, color: "#f8fafc", letterSpacing: 0.3, lineHeight: 1.3 }}>Mongolians scattered all<br/>over the world from one place</div>
            <div style={{ fontSize: 11, color: "#64748b" }}>mongol.chat</div>
          </div>
        </div>

        {/* Tabs */}
        <div style={{ display: "flex", padding: "10px 12px 0", gap: 4 }}>
          {["channels", "dms"].map((tab) => (
            <button key={tab} onClick={() => setSidebarTab(tab)} style={{
              flex: 1, padding: "6px 0", borderRadius: 7, border: "none", cursor: "pointer",
              background: sidebarTab === tab ? "#1e2a3a" : "transparent",
              color: sidebarTab === tab ? "#f59e0b" : "#64748b",
              fontSize: 12, fontWeight: 600,
              transition: "all 0.15s",
            }}>
              {tab === "channels" ? "# Суваг" : "✉ Хувийн"}
            </button>
          ))}
        </div>

        {/* Channel list */}
        <div style={{ flex: 1, overflowY: "auto", padding: "8px 8px" }}>
          {sidebarTab === "channels" ? (
            <>
              <div style={{ fontSize: 10, fontWeight: 700, color: "#475569", letterSpacing: 1.2, padding: "8px 8px 4px", textTransform: "uppercase" }}>
                Олон нийтийн суваг
              </div>
              {CHANNELS.map((ch) => (
                <button key={ch.id} onClick={() => setActiveChannel(ch.id)} style={{
                  width: "100%", display: "flex", alignItems: "center", gap: 10,
                  padding: "8px 10px", borderRadius: 8, border: "none", cursor: "pointer",
                  background: activeChannel === ch.id ? "linear-gradient(90deg, #1e2a3a, #1a2030)" : "transparent",
                  color: activeChannel === ch.id ? "#f8fafc" : "#94a3b8",
                  textAlign: "left", transition: "all 0.1s",
                  borderLeft: activeChannel === ch.id ? "2px solid #f59e0b" : "2px solid transparent",
                }}>
                  <span style={{ fontSize: 15 }}>{ch.icon}</span>
                  <span style={{ flex: 1, fontSize: 13, fontWeight: activeChannel === ch.id ? 600 : 400 }}>
                    #{ch.name}
                  </span>
                  {ch.unread > 0 && (
                    <span style={{
                      background: "#ef4444", color: "#fff", borderRadius: 10,
                      fontSize: 10, fontWeight: 700, padding: "1px 6px", minWidth: 18, textAlign: "center",
                    }}>{ch.unread}</span>
                  )}
                </button>
              ))}
            </>
          ) : (
            <>
              <div style={{ fontSize: 10, fontWeight: 700, color: "#475569", letterSpacing: 1.2, padding: "8px 8px 4px", textTransform: "uppercase" }}>
                Шууд мессеж
              </div>
              {DMS.map((dm) => (
                <button key={dm.id} style={{
                  width: "100%", display: "flex", alignItems: "center", gap: 10,
                  padding: "8px 10px", borderRadius: 8, border: "none", cursor: "pointer",
                  background: "transparent", color: "#94a3b8", textAlign: "left",
                  transition: "all 0.1s",
                }}>
                  <div style={{ position: "relative" }}>
                    <div style={{
                      width: 32, height: 32, borderRadius: "50%",
                      background: "linear-gradient(135deg, #1e3a5f, #2d4a6e)",
                      display: "flex", alignItems: "center", justifyContent: "center",
                      fontSize: 11, fontWeight: 700, color: "#93c5fd",
                    }}>{dm.avatar}</div>
                    <div style={{
                      position: "absolute", bottom: 0, right: 0,
                      width: 9, height: 9, borderRadius: "50%",
                      background: dm.online ? "#22c55e" : "#475569",
                      border: "2px solid #12151c",
                    }} />
                  </div>
                  <span style={{ flex: 1, fontSize: 13 }}>{dm.name}</span>
                  {dm.unread > 0 && (
                    <span style={{
                      background: "#ef4444", color: "#fff", borderRadius: 10,
                      fontSize: 10, fontWeight: 700, padding: "1px 6px",
                    }}>{dm.unread}</span>
                  )}
                </button>
              ))}
            </>
          )}
        </div>

        {/* User profile */}
        <div style={{
          padding: "12px 14px", borderTop: "1px solid #1e2330",
          display: "flex", alignItems: "center", gap: 10,
        }}>
          <div style={{
            width: 34, height: 34, borderRadius: "50%",
            background: "linear-gradient(135deg, #fb923c, #ef4444)",
            display: "flex", alignItems: "center", justifyContent: "center",
            fontSize: 12, fontWeight: 700, color: "#fff",
          }}>ТА</div>
          <div style={{ flex: 1 }}>
            <div style={{ fontSize: 13, fontWeight: 600, color: "#f1f5f9" }}>Та</div>
            <div style={{ fontSize: 11, color: "#22c55e" }}>● Идэвхтэй</div>
          </div>
          <button style={{ background: "none", border: "none", color: "#475569", cursor: "pointer", fontSize: 16 }}>⚙</button>
        </div>
      </div>

      {/* Main chat */}
      <div style={{ flex: 1, display: "flex", flexDirection: "column", minWidth: 0 }}>
        {/* Header */}
        <div style={{
          padding: "0 20px", height: 58, display: "flex", alignItems: "center",
          borderBottom: "1px solid #1e2330", background: "#0d0f14",
          gap: 12, flexShrink: 0,
        }}>
          <div style={{ fontSize: 18, color: "#f59e0b" }}>{activeChannelData?.icon}</div>
          <div>
            <div style={{ fontWeight: 700, fontSize: 15, color: "#f8fafc" }}>
              #{activeChannelData?.name}
            </div>
            <div style={{ fontSize: 11, color: "#64748b" }}>Монголын олон нийтийн суваг</div>
          </div>
          <div style={{ marginLeft: "auto", display: "flex", gap: 8 }}>
            {["🔍", "📌", "👥"].map((icon, i) => (
              <button key={i} style={{
                background: "#1e2330", border: "none", borderRadius: 8,
                padding: "6px 10px", color: "#94a3b8", cursor: "pointer", fontSize: 14,
              }}>{icon}</button>
            ))}
          </div>
        </div>

        {/* Messages */}
        <div style={{ flex: 1, overflowY: "auto", padding: "20px 20px 0" }}>
          {/* Welcome banner */}
          <div style={{
            background: "linear-gradient(135deg, #1a1f2e, #1e2a3a)",
            border: "1px solid #2d3748", borderRadius: 14, padding: "18px 20px",
            marginBottom: 24, display: "flex", alignItems: "center", gap: 14,
          }}>
            <div style={{ fontSize: 36 }}>🇲🇳</div>
            <div>
              <div style={{ fontWeight: 700, fontSize: 15, color: "#f8fafc", marginBottom: 3 }}>
                #{activeChannelData?.name} сувагт тавтай морил!
              </div>
              <div style={{ fontSize: 13, color: "#94a3b8" }}>
                Энэ бол Mongolians scattered all over the world from one place — хүндлэлтэй байцгаая 🙏
              </div>
            </div>
          </div>

          {/* Message list */}
          {currentMessages.map((msg, i) => {
            const prev = currentMessages[i - 1];
            const grouped = prev?.user === msg.user;
            return (
              <div key={msg.id} style={{
                display: "flex", gap: 12, marginBottom: grouped ? 2 : 16,
                padding: "4px 8px", borderRadius: 8,
                background: msg.own ? "rgba(251,146,60,0.04)" : "transparent",
                transition: "background 0.15s",
              }}>
                {!grouped ? (
                  <div style={{
                    width: 36, height: 36, borderRadius: "50%", flexShrink: 0,
                    background: msg.own
                      ? "linear-gradient(135deg, #fb923c, #ef4444)"
                      : `linear-gradient(135deg, ${msg.color}44, ${msg.color}22)`,
                    display: "flex", alignItems: "center", justifyContent: "center",
                    fontSize: 12, fontWeight: 700,
                    color: msg.own ? "#fff" : msg.color,
                    border: `1.5px solid ${msg.color}55`,
                  }}>{msg.avatar}</div>
                ) : (
                  <div style={{ width: 36, flexShrink: 0 }} />
                )}
                <div style={{ flex: 1, minWidth: 0 }}>
                  {!grouped && (
                    <div style={{ display: "flex", alignItems: "baseline", gap: 8, marginBottom: 2 }}>
                      <span style={{ fontWeight: 700, fontSize: 13, color: msg.own ? "#fb923c" : msg.color }}>
                        {msg.user}
                      </span>
                      <span style={{ fontSize: 11, color: "#475569" }}>{msg.time}</span>
                    </div>
                  )}
                  <div style={{
                    fontSize: 14, color: "#cbd5e1", lineHeight: 1.55,
                    wordBreak: "break-word",
                  }}>{msg.text}</div>
                </div>
              </div>
            );
          })}
          <div ref={bottomRef} style={{ height: 20 }} />
        </div>

        {/* Emoji panel */}
        {showEmojiPanel && (
          <div style={{
            margin: "0 20px 8px",
            background: "#12151c", border: "1px solid #1e2330",
            borderRadius: 12, padding: "10px 12px",
            display: "flex", flexWrap: "wrap", gap: 6,
          }}>
            {EMOJIS.map((e, i) => (
              <button key={i} onClick={() => setInput(p => p + e)} style={{
                background: "#1e2330", border: "none", borderRadius: 8,
                padding: "6px 10px", fontSize: 18, cursor: "pointer",
                transition: "transform 0.1s",
              }} onMouseEnter={e2 => e2.target.style.transform = "scale(1.2)"}
                 onMouseLeave={e2 => e2.target.style.transform = "scale(1)"}>
                {e}
              </button>
            ))}
          </div>
        )}

        {/* Input area */}
        <div style={{ padding: "12px 20px 16px" }}>
          <div style={{
            display: "flex", alignItems: "center", gap: 8,
            background: "#12151c", border: "1px solid #1e2330",
            borderRadius: 12, padding: "4px 4px 4px 14px",
            transition: "border-color 0.2s",
          }}>
            <input
              value={input}
              onChange={(e) => setInput(e.target.value)}
              onKeyDown={(e) => e.key === "Enter" && !e.shiftKey && sendMessage()}
              placeholder={`#${activeChannelData?.name} сувагт бичих...`}
              style={{
                flex: 1, background: "none", border: "none", outline: "none",
                color: "#f1f5f9", fontSize: 14, padding: "8px 0",
                fontFamily: "inherit",
              }}
            />
            <button onClick={() => setShowEmojiPanel(p => !p)} style={{
              background: showEmojiPanel ? "#1e2330" : "none",
              border: "none", cursor: "pointer",
              padding: "7px 10px", borderRadius: 8, fontSize: 18,
              color: "#64748b", transition: "all 0.15s",
            }}>😊</button>
            <button onClick={() => {}} style={{
              background: "none", border: "none", cursor: "pointer",
              padding: "7px 10px", borderRadius: 8, fontSize: 16,
              color: "#64748b",
            }}>📎</button>
            <button onClick={sendMessage} style={{
              background: input.trim()
                ? "linear-gradient(135deg, #f59e0b, #ef4444)"
                : "#1e2330",
              border: "none", cursor: input.trim() ? "pointer" : "default",
              padding: "8px 16px", borderRadius: 9, fontSize: 14,
              color: input.trim() ? "#fff" : "#475569",
              fontWeight: 700, transition: "all 0.2s",
              boxShadow: input.trim() ? "0 0 16px #f59e0b44" : "none",
            }}>Илгээх →</button>
          </div>
          <div style={{ fontSize: 11, color: "#334155", marginTop: 5, paddingLeft: 2 }}>
            Enter дарж илгээх · Shift+Enter мөр дамжуулах
          </div>
        </div>
      </div>

      {/* Online users sidebar */}
      <div style={{
        width: 200, background: "#12151c", borderLeft: "1px solid #1e2330",
        display: "flex", flexDirection: "column", padding: "16px 12px",
      }}>
        <div style={{ fontSize: 10, fontWeight: 700, color: "#475569", letterSpacing: 1.2, marginBottom: 10, textTransform: "uppercase" }}>
          Онлайн — {ONLINE_USERS.filter(u => u.status !== "Офлайн").length}
        </div>
        {ONLINE_USERS.map((u, i) => (
          <div key={i} style={{
            display: "flex", alignItems: "center", gap: 8,
            padding: "6px 6px", borderRadius: 8, marginBottom: 2,
            opacity: u.status === "Офлайн" ? 0.45 : 1,
          }}>
            <div style={{ position: "relative" }}>
              <div style={{
                width: 30, height: 30, borderRadius: "50%",
                background: `linear-gradient(135deg, ${u.color}44, ${u.color}22)`,
                border: `1.5px solid ${u.color}66`,
                display: "flex", alignItems: "center", justifyContent: "center",
                fontSize: 10, fontWeight: 700, color: u.color,
              }}>{u.avatar}</div>
              <div style={{
                position: "absolute", bottom: 0, right: 0,
                width: 8, height: 8, borderRadius: "50%",
                background: u.status === "Идэвхтэй" ? "#22c55e"
                  : u.status === "Завгүй" ? "#f59e0b" : "#475569",
                border: "1.5px solid #12151c",
              }} />
            </div>
            <div>
              <div style={{ fontSize: 12, fontWeight: 600, color: "#e2e8f0", lineHeight: 1.2 }}>{u.name.split(" ")[0]}</div>
              <div style={{ fontSize: 10, color: "#475569" }}>{u.status}</div>
            </div>
          </div>
        ))}

        {/* Stats */}
        <div style={{
          marginTop: "auto", background: "#0d0f14", borderRadius: 10,
          padding: "12px", border: "1px solid #1e2330",
        }}>
          <div style={{ fontSize: 10, color: "#475569", marginBottom: 8, fontWeight: 700, textTransform: "uppercase", letterSpacing: 1 }}>
            Статистик
          </div>
          {[
            { label: "Гишүүд", value: "1,248" },
            { label: "Мессеж", value: "32.4к" },
            { label: "Суваг", value: "12" },
          ].map((s, i) => (
            <div key={i} style={{ display: "flex", justifyContent: "space-between", marginBottom: 4 }}>
              <span style={{ fontSize: 11, color: "#64748b" }}>{s.label}</span>
              <span style={{ fontSize: 11, fontWeight: 700, color: "#f59e0b" }}>{s.value}</span>
            </div>
          ))}
        </div>
      </div>
    </div>

    {/* Full-width bottom marquee */}
    <div style={{
      position: "fixed", bottom: 0, left: 0, right: 0,
      background: "#0a0c11",
      borderTop: "1px solid #1e2330",
      overflow: "hidden",
      height: 30,
      display: "flex",
      alignItems: "center",
      zIndex: 999,
    }}>
      <div style={{
        display: "inline-block",
        whiteSpace: "nowrap",
        animation: "marquee-bottom 18s linear infinite",
      }}>
        {Array(4).fill(null).map((_, i) => (
          <span key={i} style={{
            fontSize: 12, fontWeight: 700,
            background: "linear-gradient(90deg, #f59e0b, #ef4444, #f59e0b)",
            WebkitBackgroundClip: "text", WebkitTextFillColor: "transparent",
            paddingRight: 60,
          }}>
            🇲🇳 Дэлхий дээр Тархан Суугаа Монголчууд &nbsp;•&nbsp; Mongolians scattered all over the world from one place
          </span>
        ))}
      </div>
    </div>
    </>
  );
}
