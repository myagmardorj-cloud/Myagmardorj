// Login.jsx — Google + Утасны дугаар нэвтрэлт
import { useState, useEffect, useRef } from 'react';
import {
  GoogleAuthProvider, signInWithPopup,
  RecaptchaVerifier, signInWithPhoneNumber,
} from 'firebase/auth';
import { auth } from '../firebase.js';
import { useNavigate } from 'react-router-dom';

const COUNTRIES = [
  { flag:'🇲🇳', code:'+976', name:'Монгол' },
  { flag:'🇰🇷', code:'+82',  name:'Солонгос' },
  { flag:'🇺🇸', code:'+1',   name:'АНУ' },
  { flag:'🇩🇪', code:'+49',  name:'Герман' },
  { flag:'🇯🇵', code:'+81',  name:'Япон' },
  { flag:'🇬🇧', code:'+44',  name:'Их Британи' },
  { flag:'🇨🇳', code:'+86',  name:'Хятад' },
  { flag:'🇷🇺', code:'+7',   name:'Орос' },
  { flag:'🇦🇺', code:'+61',  name:'Австрали' },
  { flag:'🇫🇷', code:'+33',  name:'Франц' },
];

export default function Login() {
  const navigate = useNavigate();
  const [view,       setView]       = useState('main');   // main | phone | otp
  const [country,    setCountry]    = useState(COUNTRIES[0]);
  const [phone,      setPhone]      = useState('');
  const [otp,        setOtp]        = useState('');
  const [confirm,    setConfirm]    = useState(null);
  const [loading,    setLoading]    = useState(false);
  const [error,      setError]      = useState('');
  const recaptchaRef = useRef(null);

  useEffect(() => {
    const unsub = auth.onAuthStateChanged(u => { if (u) navigate('/'); });
    return () => unsub();
  }, [navigate]);

  // ── Google нэвтрэлт ──────────────────────────────────────
  const loginGoogle = async () => {
    setLoading(true); setError('');
    try {
      await signInWithPopup(auth, new GoogleAuthProvider());
      navigate('/');
    } catch (e) {
      setError('Google нэвтрэлт амжилтгүй: ' + e.message);
    } finally { setLoading(false); }
  };

  // ── SMS OTP илгээх ────────────────────────────────────────
  const sendSMS = async () => {
    setError(''); setLoading(true);
    try {
      if (!recaptchaRef.current) {
        recaptchaRef.current = new RecaptchaVerifier(auth, 'recaptcha-container', { size: 'invisible' });
      }
      const full = country.code + phone.replace(/^0/, '');
      const result = await signInWithPhoneNumber(auth, full, recaptchaRef.current);
      setConfirm(result);
      setView('otp');
    } catch (e) {
      if (e.code === 'auth/billing-not-enabled') {
        setError('SMS-д Firebase Blaze план шаардлагатай. Google-аар нэвтэрнэ үү.');
      } else {
        setError(e.message);
      }
      recaptchaRef.current = null;
    } finally { setLoading(false); }
  };

  // ── OTP баталгаажуулах ───────────────────────────────────
  const verifyOTP = async () => {
    setError(''); setLoading(true);
    try {
      await confirm.confirm(otp);
      navigate('/');
    } catch {
      setError('OTP буруу байна. Дахин оруулна уу.');
    } finally { setLoading(false); }
  };

  return (
    <div style={S.root}>
      <style>{`
        @keyframes marquee { from{transform:translateX(0)} to{transform:translateX(-50%)} }
        @keyframes spin { to{transform:rotate(360deg)} }
        @keyframes fadeIn { from{opacity:0;transform:translateY(12px)} to{opacity:1;transform:translateY(0)} }
        * { box-sizing: border-box; }
        input::placeholder { color: rgba(255,255,255,.3); }
        input:focus { outline: none; border-color: #f59e0b !important; }
        select:focus { outline: none; }
        button:active { transform: scale(0.98); }
      `}</style>

      {/* Marquee */}
      <div style={S.marqueeWrap}>
        <div style={S.marqueeInner}>
          {[1,2,3,4].map(i => (
            <span key={i} style={S.marqueeText}>
              🇲🇳 Дэлхий дээр Тархан Суугаа Монголчууд &nbsp;•&nbsp; Mongolians scattered all over the world from one place &nbsp;&nbsp;&nbsp;
            </span>
          ))}
        </div>
      </div>

      {/* Card */}
      <div style={S.card}>
        {/* Logo */}
        <div style={S.logoWrap}>
          <div style={S.logoIcon}>М</div>
          <div style={S.logoTitle}>Mongolians scattered all over<br/>the world from one place</div>
          <div style={S.logoDomain}>mongol.chat</div>
        </div>

        {/* ── MAIN VIEW ── */}
        {view === 'main' && (
          <div style={S.section}>
            <div style={S.heading}>Нэвтрэх</div>
            <div style={S.subheading}>Нэвтрэх аргаа сонгоно уу</div>

            {/* Google */}
            <button style={S.btnGoogle} onClick={loginGoogle} disabled={loading}>
              {loading ? <Spinner /> : (
                <>
                  <svg width="18" height="18" viewBox="0 0 48 48">
                    <path fill="#FFC107" d="M43.611,20.083H42V20H24v8h11.303c-1.649,4.657-6.08,8-11.303,8c-6.627,0-12-5.373-12-12c0-6.627,5.373-12,12-12c3.059,0,5.842,1.154,7.961,3.039l5.657-5.657C34.046,6.053,29.268,4,24,4C12.955,4,4,12.955,4,24c0,11.045,8.955,20,20,20c11.045,0,20-8.955,20-20C44,22.659,43.862,21.35,43.611,20.083z"/>
                    <path fill="#FF3D00" d="M6.306,14.691l6.571,4.819C14.655,15.108,18.961,12,24,12c3.059,0,5.842,1.154,7.961,3.039l5.657-5.657C34.046,6.053,29.268,4,24,4C16.318,4,9.656,8.337,6.306,14.691z"/>
                    <path fill="#4CAF50" d="M24,44c5.166,0,9.86-1.977,13.409-5.192l-6.19-5.238C29.211,35.091,26.715,36,24,36c-5.202,0-9.619-3.317-11.283-7.946l-6.522,5.025C9.505,39.556,16.227,44,24,44z"/>
                    <path fill="#1976D2" d="M43.611,20.083H42V20H24v8h11.303c-0.792,2.237-2.231,4.166-4.087,5.571c0.001-0.001,0.002-0.001,0.003-0.002l6.19,5.238C36.971,39.205,44,34,44,24C44,22.659,43.862,21.35,43.611,20.083z"/>
                  </svg>
                  Google-аар нэвтрэх
                </>
              )}
            </button>

            {/* Divider */}
            <div style={S.divider}><span style={S.dividerText}>эсвэл</span></div>

            {/* Phone */}
            <button style={S.btnPhone} onClick={() => { setView('phone'); setError(''); }}>
              📱 Утасны дугаараар нэвтрэх
            </button>

            {error && <div style={S.error}>{error}</div>}
            <div style={S.terms}>
              Нэвтэрснээр та манай <span style={S.link}>Үйлчилгээний нөхцөл</span> болон <span style={S.link}>Нууцлалын бодлого</span>-г зөвшөөрч байна
            </div>
          </div>
        )}

        {/* ── PHONE VIEW ── */}
        {view === 'phone' && (
          <div style={{ ...S.section, animation: 'fadeIn .3s ease' }}>
            <button style={S.backBtn} onClick={() => { setView('main'); setError(''); }}>← Буцах</button>
            <div style={S.heading}>Утасны дугаар</div>
            <div style={S.subheading}>Утасны дугаараа оруулна уу</div>

            <div style={S.phoneRow}>
              <select
                style={S.countrySelect}
                onChange={e => setCountry(COUNTRIES.find(c => c.code === e.target.value))}
              >
                {COUNTRIES.map(c => (
                  <option key={c.code + c.name} value={c.code}>{c.flag} {c.code}</option>
                ))}
              </select>
              <input
                style={S.phoneInput}
                type="tel"
                placeholder="99001122"
                value={phone}
                onChange={e => setPhone(e.target.value.replace(/\D/g, ''))}
                onKeyDown={e => e.key === 'Enter' && sendSMS()}
              />
            </div>

            <div id="recaptcha-container" />
            {error && <div style={S.error}>{error}</div>}

            <button style={S.btnSend} onClick={sendSMS} disabled={loading || phone.length < 6}>
              {loading ? <Spinner /> : 'SMS код илгээх →'}
            </button>
          </div>
        )}

        {/* ── OTP VIEW ── */}
        {view === 'otp' && (
          <div style={{ ...S.section, animation: 'fadeIn .3s ease' }}>
            <button style={S.backBtn} onClick={() => { setView('phone'); setError(''); }}>← Буцах</button>
            <div style={S.heading}>OTP код</div>
            <div style={S.subheading}>{country.code}{phone} дугаарт SMS илгээлээ</div>

            <input
              style={{ ...S.phoneInput, textAlign:'center', fontSize:22, letterSpacing:8, width:'100%', marginTop:12 }}
              type="number"
              placeholder="------"
              maxLength={6}
              value={otp}
              onChange={e => setOtp(e.target.value.slice(0,6))}
              onKeyDown={e => e.key === 'Enter' && otp.length === 6 && verifyOTP()}
              autoFocus
            />

            {error && <div style={S.error}>{error}</div>}

            <button style={S.btnSend} onClick={verifyOTP} disabled={loading || otp.length < 6}>
              {loading ? <Spinner /> : '✅ Баталгаажуулах'}
            </button>

            <button style={{ ...S.backBtn, marginTop:8, width:'100%', textAlign:'center' }} onClick={sendSMS}>
              🔄 SMS дахин илгээх
            </button>
          </div>
        )}
      </div>
    </div>
  );
}

const Spinner = () => (
  <span style={{ width:16, height:16, border:'2px solid #fff4', borderTop:'2px solid #fff', borderRadius:'50%', display:'inline-block', animation:'spin .8s linear infinite' }} />
);

const S = {
  root: {
    minHeight: '100vh',
    background: 'radial-gradient(ellipse at 30% 20%, #1a0a2e 0%, #0d0620 50%, #0a0c11 100%)',
    display: 'flex', alignItems: 'center', justifyContent: 'center',
    fontFamily: "'Segoe UI', Arial, sans-serif",
    padding: '20px 16px 50px',
  },
  marqueeWrap: {
    position: 'fixed', bottom: 0, left: 0, right: 0,
    background: '#0a0c11', borderTop: '1px solid #1e2330',
    height: 30, overflow: 'hidden', display: 'flex', alignItems: 'center', zIndex: 999,
  },
  marqueeInner: { display: 'inline-block', whiteSpace: 'nowrap', animation: 'marquee 20s linear infinite' },
  marqueeText: {
    fontSize: 12, fontWeight: 700,
    background: 'linear-gradient(90deg,#f59e0b,#ef4444,#f59e0b)',
    WebkitBackgroundClip: 'text', WebkitTextFillColor: 'transparent',
  },
  card: {
    background: 'rgba(255,255,255,.04)',
    border: '1px solid rgba(255,255,255,.08)',
    borderRadius: 20, padding: '32px 28px',
    width: '100%', maxWidth: 380,
    backdropFilter: 'blur(12px)',
  },
  logoWrap: { textAlign: 'center', marginBottom: 28 },
  logoIcon: {
    width: 56, height: 56, borderRadius: 16, margin: '0 auto 12px',
    background: 'linear-gradient(135deg,#f59e0b,#ef4444)',
    display: 'flex', alignItems: 'center', justifyContent: 'center',
    fontSize: 24, fontWeight: 900, color: '#fff',
  },
  logoTitle: { fontSize: 13, fontWeight: 700, color: '#fff', lineHeight: 1.5 },
  logoDomain: { fontSize: 11, color: 'rgba(255,255,255,.3)', marginTop: 4 },
  section: { display: 'flex', flexDirection: 'column', gap: 0 },
  heading: { fontSize: 22, fontWeight: 800, color: '#fff', marginBottom: 6 },
  subheading: { fontSize: 13, color: 'rgba(255,255,255,.45)', marginBottom: 20 },
  btnGoogle: {
    width: '100%', padding: '13px 16px', borderRadius: 12,
    background: '#fff', border: 'none', cursor: 'pointer',
    fontSize: 14, fontWeight: 700, color: '#1a1a2e',
    display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 10,
    marginBottom: 12, transition: 'opacity .15s',
  },
  divider: { display: 'flex', alignItems: 'center', gap: 10, margin: '4px 0 12px' },
  dividerText: { fontSize: 12, color: 'rgba(255,255,255,.25)', background: 'transparent', padding: '0 4px' },
  btnPhone: {
    width: '100%', padding: '13px 16px', borderRadius: 12,
    background: 'linear-gradient(135deg,#f59e0b,#ef4444)',
    border: 'none', cursor: 'pointer',
    fontSize: 14, fontWeight: 700, color: '#fff',
    display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 8,
  },
  btnSend: {
    width: '100%', marginTop: 16, padding: '13px 16px', borderRadius: 12,
    background: 'linear-gradient(135deg,#f59e0b,#ef4444)',
    border: 'none', cursor: 'pointer',
    fontSize: 14, fontWeight: 700, color: '#fff',
    display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 8,
  },
  phoneRow: { display: 'flex', gap: 8, marginBottom: 8 },
  countrySelect: {
    background: 'rgba(255,255,255,.07)', border: '1px solid rgba(255,255,255,.12)',
    borderRadius: 10, padding: '10px 8px', color: '#fff', fontSize: 13,
    width: 96, cursor: 'pointer',
  },
  phoneInput: {
    flex: 1, background: 'rgba(255,255,255,.07)',
    border: '1.5px solid rgba(255,255,255,.12)',
    borderRadius: 10, padding: '10px 14px',
    color: '#fff', fontSize: 15, fontFamily: 'inherit',
  },
  error: {
    background: 'rgba(239,68,68,.15)', border: '1px solid rgba(239,68,68,.3)',
    borderRadius: 10, padding: '10px 14px',
    fontSize: 12, color: '#fca5a5', marginTop: 8,
  },
  backBtn: {
    background: 'none', border: 'none', color: 'rgba(255,255,255,.4)',
    fontSize: 12, cursor: 'pointer', padding: '0 0 12px', textAlign: 'left',
  },
  terms: { fontSize: 11, color: 'rgba(255,255,255,.25)', textAlign: 'center', marginTop: 16, lineHeight: 1.6 },
  link: { color: 'rgba(245,158,11,.7)', cursor: 'pointer' },
};
