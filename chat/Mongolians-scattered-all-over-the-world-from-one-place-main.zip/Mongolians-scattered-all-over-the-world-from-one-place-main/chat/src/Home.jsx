import { useNavigate } from 'react-router-dom';
import { useEffect, useState } from 'react';
import { auth } from '../firebase';

export default function Home() {
  const navigate = useNavigate();
  const [user, setUser] = useState(null);
  const [online, setOnline] = useState(1247);
  const [hovered, setHovered] = useState(null);

  useEffect(() => {
    const unsub = auth.onAuthStateChanged((u) => {
      if (!u) navigate('/login');
      else setUser(u);
    });
    // Online тоо жижиг хэлбэлзэл
    const iv = setInterval(() => {
      setOnline(prev => prev + Math.floor(Math.random() * 5) - 2);
    }, 3000);
    return () => { unsub(); clearInterval(iv); };
  }, [navigate]);

  const getName = () => {
    if (!user) return '';
    if (user.displayName) return user.displayName.split(' ')[0];
    if (user.phoneNumber) return user.phoneNumber;
    return 'Монгол';
  };

  const getInitial = () => {
    const n = getName();
    return n ? n[0].toUpperCase() : 'М';
  };

  return (
    <div style={styles.root}>
      {/* Background pattern */}
      <div style={styles.bgPattern} />

      <div style={styles.container}>

        {/* Header */}
        <div style={styles.header}>
          <div style={styles.logo}>
            <span style={styles.logoMain}>Зуун</span>
            <span style={styles.logoAccent}>Мод</span>
            <span style={styles.logoSub}>.мн</span>
          </div>
          <button style={styles.logoutBtn} onClick={() => auth.signOut().then(() => navigate('/login'))}>
            Гарах
          </button>
        </div>

        {/* Greeting */}
        <div style={styles.greeting}>
          <div style={styles.avatar}>{getInitial()}</div>
          <div>
            <div style={styles.greetTitle}>Сайн байна уу, {getName()}!</div>
            <div style={styles.greetSub}>
              <span style={styles.onlineDot} />
              {online.toLocaleString()} монгол одоо онлайн байна
            </div>
          </div>
        </div>

        {/* Cards */}
        <div style={styles.cards}>

          {/* Old chat */}
          <div
            style={{
              ...styles.card,
              ...(hovered === 'old' ? styles.cardHover : {}),
            }}
            onMouseEnter={() => setHovered('old')}
            onMouseLeave={() => setHovered(null)}
            onClick={() => navigate('/chat')}
          >
            <div style={styles.cardIcon}>💬</div>
            <div style={styles.cardTitle}>Хуучин чат</div>
            <div style={styles.cardDesc}>
              Танил бүлгийн чат, найзуудтайгаа ярилцах, суваг үзэх
            </div>
            <div style={styles.cardFooter}>
              <div style={styles.onlineInfo}>
                <span style={styles.onlineDotGreen} />
                <span style={styles.onlineText}>{online.toLocaleString()} онлайн</span>
              </div>
              <div style={styles.enterBtn}>Орох →</div>
            </div>
          </div>

          {/* New messenger */}
          <div
            style={{
              ...styles.card,
              ...styles.cardNew,
              ...(hovered === 'new' ? styles.cardNewHover : {}),
            }}
            onMouseEnter={() => setHovered('new')}
            onMouseLeave={() => setHovered(null)}
            onClick={() => navigate('/messenger')}
          >
            <div style={styles.newBadge}>✨ ШИНЭ</div>
            <div style={styles.cardIcon}>🚀</div>
            <div style={styles.cardTitle}>Шинэ хүжүүлэлт</div>
            <div style={styles.cardDesc}>
              Yahoo Messenger загвар — buddy list, чат өрөөнүүд, онлайн статус
            </div>
            <div style={styles.cardFooter}>
              <div style={styles.betaBadge}>Beta</div>
              <div style={{ ...styles.enterBtn, color: '#FFD700' }}>Туршиж үзэх →</div>
            </div>
          </div>

        </div>

        {/* Settings row */}
        <div
          style={{
            ...styles.settingsRow,
            ...(hovered === 'settings' ? styles.settingsHover : {}),
          }}
          onMouseEnter={() => setHovered('settings')}
          onMouseLeave={() => setHovered(null)}
          onClick={() => navigate('/profile')}
        >
          <div style={styles.settingsIcon}>⚙️</div>
          <div style={styles.settingsInfo}>
            <div style={styles.settingsTitle}>Тохиргоо & Профайл</div>
            <div style={styles.settingsSub}>Нэр, зураг, статус, мэдэгдэл тохируулах</div>
          </div>
          <div style={styles.settingsArrow}>→</div>
        </div>

        {/* Footer */}
        <div style={styles.footer}>
          Дэлхий дээр тархан суугаа монголчуудын нэг цэг
        </div>

      </div>
    </div>
  );
}

const styles = {
  root: {
    minHeight: '100vh',
    background: '#120830',
    display: 'flex',
    alignItems: 'center',
    justifyContent: 'center',
    position: 'relative',
    overflow: 'hidden',
    padding: '20px',
  },
  bgPattern: {
    position: 'absolute',
    inset: 0,
    backgroundImage: `radial-gradient(circle at 20% 20%, rgba(77,6,142,0.4) 0%, transparent 50%),
                      radial-gradient(circle at 80% 80%, rgba(124,58,237,0.3) 0%, transparent 50%),
                      radial-gradient(circle at 50% 50%, rgba(255,215,0,0.03) 0%, transparent 70%)`,
    pointerEvents: 'none',
  },
  container: {
    width: '100%',
    maxWidth: '560px',
    position: 'relative',
    zIndex: 1,
  },
  header: {
    display: 'flex',
    alignItems: 'center',
    justifyContent: 'space-between',
    marginBottom: '32px',
  },
  logo: {
    fontSize: '22px',
    fontWeight: 900,
    letterSpacing: '-0.5px',
  },
  logoMain: { color: '#ffffff' },
  logoAccent: { color: '#FFD700' },
  logoSub: { color: 'rgba(255,255,255,0.4)', fontSize: '16px' },
  logoutBtn: {
    background: 'rgba(255,255,255,0.07)',
    border: '1px solid rgba(255,255,255,0.12)',
    color: 'rgba(255,255,255,0.6)',
    borderRadius: '20px',
    padding: '6px 16px',
    fontSize: '12px',
    cursor: 'pointer',
  },
  greeting: {
    display: 'flex',
    alignItems: 'center',
    gap: '14px',
    marginBottom: '28px',
    padding: '16px 20px',
    background: 'rgba(255,255,255,0.05)',
    borderRadius: '14px',
    border: '1px solid rgba(255,255,255,0.08)',
  },
  avatar: {
    width: '48px',
    height: '48px',
    borderRadius: '50%',
    background: 'linear-gradient(135deg,#4D068E,#7c3aed)',
    display: 'flex',
    alignItems: 'center',
    justifyContent: 'center',
    fontSize: '20px',
    fontWeight: 700,
    color: '#FFD700',
    border: '2px solid rgba(255,215,0,0.3)',
    flexShrink: 0,
  },
  greetTitle: {
    fontSize: '16px',
    fontWeight: 600,
    color: '#ffffff',
    marginBottom: '4px',
  },
  greetSub: {
    fontSize: '12px',
    color: 'rgba(255,255,255,0.5)',
    display: 'flex',
    alignItems: 'center',
    gap: '6px',
  },
  onlineDot: {
    display: 'inline-block',
    width: '7px',
    height: '7px',
    borderRadius: '50%',
    background: '#4ade80',
    animation: 'pulse 2s infinite',
    flexShrink: 0,
  },
  cards: {
    display: 'grid',
    gridTemplateColumns: '1fr 1fr',
    gap: '14px',
    marginBottom: '14px',
  },
  card: {
    background: 'rgba(255,255,255,0.06)',
    border: '1px solid rgba(255,255,255,0.1)',
    borderRadius: '16px',
    padding: '24px 20px',
    cursor: 'pointer',
    transition: 'all 0.2s ease',
  },
  cardHover: {
    background: 'rgba(77,6,142,0.3)',
    border: '1px solid rgba(77,6,142,0.6)',
    transform: 'translateY(-2px)',
  },
  cardNew: {
    background: 'rgba(77,6,142,0.15)',
    border: '1.5px solid rgba(77,6,142,0.5)',
    position: 'relative',
  },
  cardNewHover: {
    background: 'rgba(77,6,142,0.35)',
    border: '1.5px solid #4D068E',
    transform: 'translateY(-2px)',
  },
  newBadge: {
    position: 'absolute',
    top: '-11px',
    left: '50%',
    transform: 'translateX(-50%)',
    background: '#4D068E',
    color: '#FFD700',
    fontSize: '10px',
    fontWeight: 700,
    padding: '3px 12px',
    borderRadius: '20px',
    whiteSpace: 'nowrap',
    letterSpacing: '0.5px',
  },
  cardIcon: {
    fontSize: '32px',
    marginBottom: '12px',
  },
  cardTitle: {
    fontSize: '15px',
    fontWeight: 700,
    color: '#ffffff',
    marginBottom: '8px',
  },
  cardDesc: {
    fontSize: '12px',
    color: 'rgba(255,255,255,0.5)',
    lineHeight: 1.6,
    marginBottom: '16px',
  },
  cardFooter: {
    display: 'flex',
    alignItems: 'center',
    justifyContent: 'space-between',
  },
  onlineInfo: {
    display: 'flex',
    alignItems: 'center',
    gap: '5px',
  },
  onlineDotGreen: {
    width: '6px',
    height: '6px',
    borderRadius: '50%',
    background: '#4ade80',
    flexShrink: 0,
  },
  onlineText: {
    fontSize: '11px',
    color: 'rgba(255,255,255,0.4)',
  },
  betaBadge: {
    background: 'rgba(77,6,142,0.5)',
    color: '#c4b5fd',
    fontSize: '10px',
    fontWeight: 600,
    padding: '2px 8px',
    borderRadius: '20px',
  },
  enterBtn: {
    fontSize: '12px',
    color: 'rgba(255,255,255,0.5)',
    fontWeight: 600,
  },
  settingsRow: {
    background: 'rgba(255,255,255,0.04)',
    border: '1px solid rgba(255,255,255,0.07)',
    borderRadius: '14px',
    padding: '14px 18px',
    display: 'flex',
    alignItems: 'center',
    gap: '14px',
    cursor: 'pointer',
    transition: 'all 0.2s ease',
  },
  settingsHover: {
    background: 'rgba(255,255,255,0.08)',
    border: '1px solid rgba(255,255,255,0.14)',
  },
  settingsIcon: { fontSize: '20px', flexShrink: 0 },
  settingsInfo: { flex: 1 },
  settingsTitle: {
    fontSize: '13px',
    fontWeight: 600,
    color: '#ffffff',
    marginBottom: '2px',
  },
  settingsSub: {
    fontSize: '11px',
    color: 'rgba(255,255,255,0.4)',
  },
  settingsArrow: {
    fontSize: '16px',
    color: 'rgba(255,255,255,0.3)',
  },
  footer: {
    textAlign: 'center',
    fontSize: '11px',
    color: 'rgba(255,255,255,0.2)',
    marginTop: '24px',
  },
};
