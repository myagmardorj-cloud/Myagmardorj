import { BrowserRouter, Routes, Route, Navigate } from 'react-router-dom';
import { useState, useEffect } from 'react';
import { auth } from './firebase.js';
import Login     from './pages/Login.jsx';
import Home      from './pages/Home.jsx';
import Messenger from './pages/Messenger.jsx';
import Chat      from './pages/Chat.jsx';

function PrivateRoute({ children }) {
  const [user, setUser]   = useState(undefined);
  useEffect(() => {
    const unsub = auth.onAuthStateChanged(u => setUser(u));
    return () => unsub();
  }, []);
  if (user === undefined) return (
    <div style={{ minHeight:'100vh', background:'#0d0620', display:'flex', alignItems:'center', justifyContent:'center' }}>
      <div style={{ color:'rgba(255,255,255,.5)', fontSize:14 }}>Ачааллаж байна...</div>
    </div>
  );
  return user ? children : <Navigate to="/login" replace />;
}

export default function App() {
  return (
    <BrowserRouter>
      <Routes>
        <Route path="/login" element={<Login />} />
        <Route path="/" element={
          <PrivateRoute><Home /></PrivateRoute>
        } />
        <Route path="/messenger" element={
          <PrivateRoute><Messenger /></PrivateRoute>
        } />
        <Route path="/chat" element={
          <PrivateRoute><Chat /></PrivateRoute>
        } />
        <Route path="*" element={<Navigate to="/" replace />} />
      </Routes>
    </BrowserRouter>
  );
}
