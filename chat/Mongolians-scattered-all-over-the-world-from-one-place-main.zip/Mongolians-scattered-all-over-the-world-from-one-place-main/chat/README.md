# ЗуунМод Мессенжер
## Дэлхий дээр тархан суугаа монголчуудын нэг цэг

### Файлын бүтэц
```
src/
  firebase.js          ← Firebase тохиргоо
  main.jsx             ← Эхлэлийн цэг
  App.jsx              ← Routing (react-router-dom)
  pages/
    Login.jsx          ← Утасны дугаар + OTP нэвтрэлт
    Home.jsx           ← Login хийснийхээ дараа сонголт
    Chat.jsx           ← Хуучин Discord загвар чат
    Messenger.jsx      ← Шинэ Yahoo Messenger загвар
```

### Суулгах
```bash
npm install
npm run dev
```

### Deploy (Netlify)
```bash
npm run build
# dist/ хавтасыг Netlify-д upload хийнэ
```

### Firebase Firestore Rules
```
rules_version = '2';
service cloud.firestore {
  match /databases/{database}/documents {
    match /rooms/{room}/messages/{msg} {
      allow read, write: if request.auth != null;
    }
    match /presence/{uid} {
      allow read: if request.auth != null;
      allow write: if request.auth.uid == uid;
    }
    match /dm_{chatId}/{msg} {
      allow read, write: if request.auth != null;
    }
  }
}
```
